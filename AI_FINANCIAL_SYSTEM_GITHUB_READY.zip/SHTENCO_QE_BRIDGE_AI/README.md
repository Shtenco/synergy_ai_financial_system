# SHTENCO QE BRIDGE AI V2

Production-oriented extension for the SINERGY/TROIKA ecosystem. It combines a reserve-backed relay bridge, a bounded QE reserve, an oracle-guarded market maker, and an off-chain AI optimizer with an on-chain timelocked execution policy.

## Components

| Component | Purpose |
|---|---|
| `23_SHTENCOBridgeRelayV2.sol` | M-of-N EIP-712 lock/release and burn/mint endpoint with replay protection, validator epochs, per-chain controls and mandatory daily limits. |
| `24_SHTENCOBridgeQEReserve.sol` | Reserve allocator. It cannot mint and cannot allocate below the configured reserve floor. |
| `25_SHTENCOMarketMaker.sol` | Oracle-bounded swaps, liquidity additions, inventory return and atomic buyback-and-burn. |
| `26_SHTENCOAICentralBank.sol` | Target/selector allowlist, selector-level budget requirements, score/risk policy, timelock, executor and guardian cancellation. |
| `27_SHTENCOBridgeQEAdapter.sol` | Reserve-funded bridge inventory rebalancing through approved bridge/token/chain/recipient routes only. |
| `ai_centrobank_sinergy/` | Deterministic model-predictive optimizer and risk policy. |
| `scripts/relay_daemon.py` | Finality-aware validator signing and optional destination submission. |
| `scripts/materialize_ai_proposal.py` | Converts AI intents into live-quoted, reviewable contract calldata. |

## Economic objective

The optimizer maximizes risk-adjusted ecosystem value rather than internal spot price. It uses:

- reference/oracle prices for NAV and market capitalization;
- only the system-owned LP share, not total pool reserves;
- bridge inventory as an owned asset;
- reserve ratio, peg deviation, bridge imbalance, pool concentration, liquidation NAV, gas and valuation divergence;
- a HOLD action, so doing nothing remains an explicit alternative.

An internal swap cannot create reference NAV merely by moving the ecosystem's own AMM price.

## Safe operating sequence

1. Read a fresh on-chain snapshot and oracle prices.
2. Run the optimizer and create an **intent proposal**.
3. Materialize the intent against current router quotes, oracle floors, balances, roles and budgets.
4. Review the generated calldata.
5. Submit it through the AI proposer key.
6. Wait for the on-chain timelock.
7. Execute with a separate executor key, or cancel with the guardian.

Live broadcasting is disabled by default. `LIVE_EXECUTION=1` and an explicit `--broadcast` flag are both required by the supplied transaction scripts.

## Tests

```bash
node node_modules/hardhat/internal/cli/cli.js compile
node node_modules/hardhat/internal/cli/cli.js test
PYTHONPATH=. python -m unittest ai_centrobank_sinergy.test_engine -v
```

Fork preflight requires `POLYGON_RPC_URL`:

```bash
node node_modules/hardhat/internal/cli/cli.js run scripts/fork_preflight.js --network hardhat
```

No mainnet deployment or transaction is performed by the test suite.
