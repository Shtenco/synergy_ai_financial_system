from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class PolicyDecision:
    allowed: bool
    reason: str
    risk_bps: int
    score_bps: int


def evaluate(metrics: dict[str, float], projected: dict[str, float]) -> PolicyDecision:
    reserve_ratio = projected.get("reserve_ratio", 0.0)
    peg_error = projected.get("peg_error", 1.0)
    bridge_imbalance = projected.get("bridge_imbalance", 1.0)
    valuation_gap = projected.get("valuation_gap", 1.0)
    current_nav = max(metrics.get("ecosystem_nav", 0.0), 1e-9)
    projected_nav = projected.get("ecosystem_nav", 0.0)
    growth = projected_nav / current_nav - 1.0

    risk = 0.0
    risk += max(1.10 - reserve_ratio, 0.0) * 4000
    risk += max(peg_error - 0.12, 0.0) * 5000
    risk += max(bridge_imbalance - 0.35, 0.0) * 3000
    risk += max(valuation_gap - 0.25, 0.0) * 3000
    risk += max(-growth, 0.0) * 5000
    risk_bps = min(10_000, max(0, round(risk)))
    score_bps = min(10_000, max(0, round(6000 + growth * 10000 - risk_bps * 0.35)))

    if reserve_ratio < 1.0:
        return PolicyDecision(False, "reserve ratio below 100%", risk_bps, score_bps)
    if peg_error > 0.25:
        return PolicyDecision(False, "peg deviation above hard limit", risk_bps, score_bps)
    if bridge_imbalance > 0.60:
        return PolicyDecision(False, "bridge imbalance above hard limit", risk_bps, score_bps)
    if valuation_gap > 0.60:
        return PolicyDecision(False, "internal market price diverges from reference valuation", risk_bps, score_bps)
    if risk_bps > 2500:
        return PolicyDecision(False, "risk score above policy", risk_bps, score_bps)
    return PolicyDecision(True, "policy checks passed", risk_bps, score_bps)
