# ВНИМАНИЕ: старые flash-контракты запрещены к deployment

Не использовать в mainnet:

- `20_FlashProfitCycle.sol`
- `21_FlashProfitAtomic.sol`
- `TroikaFlashProfit.sol`

Они оставлены только для истории и сравнительного аудита. Рабочая реализация находится в:

- `22_FlashLoanArbitrage.sol`
- `flash_arb_bot.py`
- `DEPLOY_FLASH_ARBITRAGE.py`

Причина: flash loan не создаёт прибыль самостоятельно. Старые версии пытались считать внутреннюю эмиссию, виртуальный LP или возврат собственного WPOL из Vault внешней прибылью. Это либо не исполняется технически, либо переносит стоимость из TROIKA в flash-контракт и создаёт риск дренажа.
