#!/usr/bin/env python3
"""
ДЕПЛОЙ ПОЛНОЙ СИСТЕМЫ TROIKA
С инстант-выводами (без таймлоков)
"""
import sys, io, os, json, time
from dotenv import load_dotenv
from web3 import Web3
from web3.middleware import ExtraDataToPOAMiddleware
from solcx import compile_source, install_solc, set_solc_version

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

load_dotenv()

# Solc
try:
    set_solc_version('0.8.20')
except:
    print("Устанавливаю solc 0.8.20...")
    install_solc('0.8.20')
    set_solc_version('0.8.20')

w3 = Web3(Web3.HTTPProvider("https://polygon-bor-rpc.publicnode.com", request_kwargs={"timeout": 180}))
w3.middleware_onion.inject(ExtraDataToPOAMiddleware, layer=0)

PK = os.getenv("OWNER_PRIVATE_KEY")
OWNER = "0x6946999DBCE63b140B1bB9D475F7c357130909E5"
ROUTER = "0xa5E0829CaCEd8fFDD4De3c43696c57F7D7A678ff"
FACTORY = "0x5757371414417b8C6CAad45bAeF941aBc7d3Ab32"
WPOL = "0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270"

def C(a): return Web3.to_checksum_address(a)

# Загрузить существующие адреса
with open("deployed_instant.json") as f:
    data = json.load(f)

SYNA = data["tokens"]["SYNA"]
SYNC = data["tokens"]["SYNC"]
SYNR = data["tokens"]["SYNR"]
ALTN = data["tokens"]["ALTN"]

PAIR_SYNA = data["pools"]["SYNA_WPOL"]
PAIR_SYNC = data["pools"]["SYNC_WPOL"]
PAIR_SYNR = data["pools"]["SYNR_WPOL"]
PAIR_ALTN = data["pools"]["ALTN_WPOL"]

print("=" * 70)
print("ДЕПЛОЙ СИСТЕМЫ TROIKA - INSTANT WITHDRAW")
print("=" * 70)
print(f"Баланс: {w3.eth.get_balance(C(OWNER)) / 1e18:.4f} POL")
print(f"SYNA: {SYNA}")
print(f"SYNC: {SYNC}")
print(f"SYNR: {SYNR}")
print("=" * 70)

nonce = w3.eth.get_transaction_count(C(OWNER), "pending")
deployed = {}

def deploy_contract(source, contract_name, args=None, label=None):
    """Компилировать и задеплоить контракт"""
    global nonce

    if label is None:
        label = contract_name

    print(f"\n[DEPLOY] {label}...", flush=True)

    try:
        compiled = compile_source(
            source,
            output_values=['abi', 'bin'],
            solc_version='0.8.20',
            optimize=True,
            optimize_runs=200
        )

        # Найти контракт
        contract_key = None
        for key in compiled.keys():
            if contract_name in key:
                contract_key = key
                break

        if not contract_key:
            print(f"  [ERROR] Контракт {contract_name} не найден в compiled keys: {list(compiled.keys())}")
            return None

        abi = compiled[contract_key]['abi']
        bytecode = compiled[contract_key]['bin']

        if not bytecode:
            print(f"  [ERROR] Пустой bytecode для {contract_name}")
            return None

    except Exception as e:
        print(f"  [ERROR] Компиляция: {e}")
        return None

    # Deploy
    base = w3.eth.get_block("latest").get("baseFeePerGas", int(100e9))
    prio = int(50e9)
    mf = base * 2 + prio

    contract = w3.eth.contract(abi=abi, bytecode=bytecode)

    try:
        if args:
            tx = contract.constructor(*args).build_transaction({
                "from": C(OWNER), "nonce": nonce, "chainId": 137, "type": 2,
                "maxPriorityFeePerGas": prio, "maxFeePerGas": mf, "gas": 8000000
            })
        else:
            tx = contract.constructor().build_transaction({
                "from": C(OWNER), "nonce": nonce, "chainId": 137, "type": 2,
                "maxPriorityFeePerGas": prio, "maxFeePerGas": mf, "gas": 8000000
            })

        signed = w3.eth.account.sign_transaction(tx, PK)
        tx_hash = w3.eth.send_raw_transaction(signed.raw_transaction)
        print(f"  TX: {tx_hash.hex()[:20]}...", flush=True)

        receipt = w3.eth.wait_for_transaction_receipt(tx_hash, timeout=300)
        gas_cost = receipt.gasUsed * mf / 1e18

        if receipt.status == 1:
            addr = receipt.contractAddress
            print(f"  [OK] {addr} (gas: {gas_cost:.4f} POL)", flush=True)
            nonce += 1
            return {"address": addr, "abi": abi}
        else:
            print(f"  [FAIL] TX reverted", flush=True)
            nonce += 1
            return None

    except Exception as e:
        print(f"  [ERROR] Deploy: {e}")
        return None

# ═══════════════════════════════════════════════════════════════════════════
# КОНТРАКТЫ ДЛЯ ДЕПЛОЯ (упрощённые версии без OpenZeppelin)
# ═══════════════════════════════════════════════════════════════════════════

# 1. TroikaVault (упрощённый)
VAULT_SOURCE = '''
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

interface IERC20 {
    function balanceOf(address) external view returns (uint256);
    function transfer(address, uint256) external returns (bool);
    function transferFrom(address, address, uint256) external returns (bool);
    function approve(address, uint256) external returns (bool);
}

interface IRouter {
    function addLiquidityETH(address token, uint amountTokenDesired, uint amountTokenMin, uint amountETHMin, address to, uint deadline) external payable returns (uint, uint, uint);
}

interface IFactory {
    function getPair(address, address) external view returns (address);
    function createPair(address, address) external returns (address);
}

interface IPair {
    function getReserves() external view returns (uint112, uint112, uint32);
    function token0() external view returns (address);
    function balanceOf(address) external view returns (uint256);
}

contract TroikaVault {
    address public owner;
    address public constant WPOL = 0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270;
    address public constant ROUTER = 0xa5E0829CaCEd8fFDD4De3c43696c57F7D7A678ff;
    address public constant FACTORY = 0x5757371414417b8C6CAad45bAeF941aBc7d3Ab32;

    address public syna;
    address public sync;
    address public synr;

    address public pairR; // SYNA/WPOL
    address public pairT; // SYNC/WPOL
    address public pairP; // SYNR/WPOL

    uint256 public lpR;
    uint256 public lpT;
    uint256 public lpP;

    uint256 public traderReserve;
    uint256 public reserveR;
    uint256 public mcgFund;
    uint256 public lpBuf;
    uint256 public buybackAccum;

    bool public initialized;

    mapping(address => bool) public operators;

    event Initialized(address pairR, address pairT, address pairP);

    modifier onlyOwner() { require(msg.sender == owner, "!owner"); _; }
    modifier onlyOperator() { require(operators[msg.sender] || msg.sender == owner, "!op"); _; }

    constructor(address syna_, address sync_, address synr_) {
        owner = msg.sender;
        syna = syna_;
        sync = sync_;
        synr = synr_;
        operators[msg.sender] = true;
    }

    function setOperator(address op, bool status) external onlyOwner {
        operators[op] = status;
    }

    function initialize(address pairR_, address pairT_, address pairP_) external onlyOwner {
        require(!initialized, "init");
        pairR = pairR_;
        pairT = pairT_;
        pairP = pairP_;
        initialized = true;
        syncFromChain();
        emit Initialized(pairR_, pairT_, pairP_);
    }

    function syncFromChain() public {
        lpR = _wpolValue(pairR);
        lpT = _wpolValue(pairT);
        lpP = _wpolValue(pairP);
    }

    function _wpolValue(address pair) internal view returns (uint256) {
        if (pair == address(0)) return 0;
        try IPair(pair).getReserves() returns (uint112 r0, uint112 r1, uint32) {
            address t0 = IPair(pair).token0();
            return (t0 == WPOL ? r0 : r1) * 2;
        } catch { return 0; }
    }

    function totalLP() public view returns (uint256) { return lpR + lpT + lpP; }
    function totalMCap() public view returns (uint256) { return totalLP() * 2; }

    function addToLpBuf(uint256 a) external onlyOperator { lpBuf += a; }
    function addToReserveR(uint256 a) external onlyOperator { reserveR += a; }
    function addToTraderReserve(uint256 a) external onlyOperator { traderReserve += a; }
    function addToMcgFund(uint256 a) external onlyOperator { mcgFund += a; }
    function addToBuyback(uint256 a) external onlyOperator { buybackAccum += a; }
    function resetBuyback() external onlyOperator { buybackAccum = 0; }

    function batchAddLP(uint256 dR, uint256 dT, uint256 dP) external onlyOperator {
        lpR += dR; lpT += dT; lpP += dP;
    }

    function subFromMcgFund(uint256 a) external onlyOperator {
        if (mcgFund >= a) mcgFund -= a;
    }

    function subFromLpP(uint256 a) external onlyOperator { if (lpP >= a) lpP -= a; }
    function subFromLpT(uint256 a) external onlyOperator { if (lpT >= a) lpT -= a; }
    function addToLpP(uint256 a) external onlyOperator { lpP += a; }

    function transferWpol(address to, uint256 amount) external onlyOperator {
        IERC20(WPOL).transfer(to, amount);
    }

    function freeWpol() public view returns (uint256) {
        uint256 bal = IERC20(WPOL).balanceOf(address(this));
        uint256 locked = traderReserve + reserveR + mcgFund;
        return bal > locked ? bal - locked : 0;
    }

    function priceP() public view returns (uint256) { return _price(pairP); }
    function priceT() public view returns (uint256) { return _price(pairT); }
    function priceR() public view returns (uint256) { return _price(pairR); }

    function _price(address pair) internal view returns (uint256) {
        if (pair == address(0)) return 0;
        try IPair(pair).getReserves() returns (uint112 r0, uint112 r1, uint32) {
            address t0 = IPair(pair).token0();
            (uint256 rW, uint256 rT) = t0 == WPOL ? (uint256(r0), uint256(r1)) : (uint256(r1), uint256(r0));
            return rT > 0 ? rW * 1e18 / rT : 0;
        } catch { return 0; }
    }

    function pairPAddress() external view returns (address) { return pairP; }
    function pairTAddress() external view returns (address) { return pairT; }

    function mcgRecycle() external onlyOperator {
        uint256 target = totalLP() * 1500 / 10000;
        if (mcgFund <= target) return;
        uint256 excess = mcgFund - target;
        mcgFund -= excess;
        reserveR += excess * 50 / 100;
        lpBuf += excess * 30 / 100;
        buybackAccum += excess * 20 / 100;
    }

    function flushLpBuf() external onlyOperator {
        // Simplified - just add to LP counters
        uint256 buf = lpBuf;
        if (buf < 1e14) return;
        lpBuf = 0;
        lpP += buf * 55 / 100;
        lpR += buf * 28 / 100;
        lpT += buf * 17 / 100;
    }

    receive() external payable {}
}
'''

# 2. DividendPool (упрощённый)
DIVPOOL_SOURCE = '''
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

interface IERC20 {
    function balanceOf(address) external view returns (uint256);
    function transfer(address, uint256) external returns (bool);
    function totalSupply() external view returns (uint256);
}

contract DividendPool {
    address public owner;
    address public founder;
    address public wpol;
    address public synr;

    uint256 public founderPending;
    uint256 public founderPaidToWallet;
    uint256 public founderReinvestedTotal;
    uint256 public founderEmissionAccum;
    bool public reinvestMode;

    uint256 public holdersPool;
    uint256 public dividendPerToken;
    uint256 public totalPaidHolders;

    mapping(address => uint256) public divDebt;
    mapping(address => uint256) public claimableBal;
    mapping(address => bool) public notifiers;

    event FounderNotified(uint256 amount);
    event HoldersNotified(uint256 amount);
    event FounderWithdrawn(address to, uint256 amount);

    modifier onlyOwner() { require(msg.sender == owner, "!owner"); _; }
    modifier onlyNotifier() { require(notifiers[msg.sender] || msg.sender == owner, "!notifier"); _; }

    constructor(address synr_, address founder_, address wpol_) {
        owner = msg.sender;
        synr = synr_;
        founder = founder_;
        wpol = wpol_;
        notifiers[msg.sender] = true;
    }

    function setNotifier(address n, bool status) external onlyOwner {
        notifiers[n] = status;
    }

    function notifyFounder(uint256 amount) external onlyNotifier {
        founderPending += amount;
        emit FounderNotified(amount);
    }

    function notifyHolders(uint256 amount) external onlyNotifier {
        holdersPool += amount;
        emit HoldersNotified(amount);
    }

    function notifyFounderEmission(uint256 amount) external onlyNotifier {
        founderPending += amount;
        founderEmissionAccum += amount;
    }

    function withdrawFounder() external {
        require(msg.sender == founder || msg.sender == owner, "!founder");
        require(!reinvestMode, "reinvest");
        uint256 amount = founderPending;
        require(amount > 0, "0");
        founderPending = 0;
        founderPaidToWallet += amount;
        IERC20(wpol).transfer(founder, amount);
        emit FounderWithdrawn(founder, amount);
    }

    function withdrawFounderTo(address to) external onlyOwner {
        uint256 amount = founderPending;
        require(amount > 0, "0");
        founderPending = 0;
        founderPaidToWallet += amount;
        IERC20(wpol).transfer(to, amount);
    }

    function reinvestFounder(address vault) external onlyOwner {
        uint256 amount = founderPending;
        require(amount > 0, "0");
        founderPending = 0;
        founderReinvestedTotal += amount;
        IERC20(wpol).transfer(vault, amount);
    }

    function setReinvestMode(bool m) external onlyOwner {
        reinvestMode = m;
    }

    function executeHoldersPayout() external onlyOwner {
        if (holdersPool < 1e12) return;
        uint256 supply = IERC20(synr).totalSupply();
        if (supply == 0) return;
        uint256 toPay = holdersPool * 85 / 100;
        holdersPool -= toPay;
        dividendPerToken += toPay * 1e18 / supply;
        totalPaidHolders += toPay;
    }

    function claimHolders() external {
        uint256 bal = IERC20(synr).balanceOf(msg.sender);
        uint256 earned = bal * (dividendPerToken - divDebt[msg.sender]) / 1e18;
        claimableBal[msg.sender] += earned;
        divDebt[msg.sender] = dividendPerToken;
        uint256 amount = claimableBal[msg.sender];
        if (amount > 0) {
            claimableBal[msg.sender] = 0;
            IERC20(wpol).transfer(msg.sender, amount);
        }
    }

    function pendingFor(address account) external view returns (uint256) {
        uint256 bal = IERC20(synr).balanceOf(account);
        uint256 earned = bal * (dividendPerToken - divDebt[account]) / 1e18;
        return claimableBal[account] + earned;
    }

    receive() external payable {}
}
'''

# 3. EmissionEngine (упрощённый)
EMISSION_SOURCE = '''
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

interface IVault {
    function batchAddLP(uint256, uint256, uint256) external;
    function addToReserveR(uint256) external;
    function addToLpP(uint256) external;
    function buybackAccum() external view returns (uint256);
    function resetBuyback() external;
    function lpP() external view returns (uint256);
    function lpR() external view returns (uint256);
    function lpT() external view returns (uint256);
    function totalLP() external view returns (uint256);
    function transferWpol(address, uint256) external;
    function freeWpol() external view returns (uint256);
    function syncFromChain() external;
}

interface IToken {
    function mint(address, uint256) external;
    function totalSupply() external view returns (uint256);
    function balanceOf(address) external view returns (uint256);
}

interface IDivPool {
    function notifyFounderEmission(uint256) external;
}

contract EmissionEngine {
    address public owner;
    IVault public vault;
    IToken public syna;
    IToken public sync;
    IToken public synr;
    IDivPool public divPool;

    uint256 public constant EMIT_INTERVAL = 1000; // blocks
    uint256 public constant EMIT_RATE = 2e12; // 2e-6 scaled by 1e18
    uint256 public constant FOUNDER_BPS = 3000; // 30%

    uint256 public lastEmitBlock;
    uint256 public totalEmittedR;
    uint256 public totalEmittedT;
    uint256 public totalEmittedP;

    mapping(address => bool) public callers;

    event EmissionExecuted(uint256 emR, uint256 emT, uint256 emP, uint256 toFounder);

    modifier onlyOwner() { require(msg.sender == owner, "!owner"); _; }
    modifier onlyCaller() { require(callers[msg.sender] || msg.sender == owner, "!caller"); _; }

    constructor(address vault_, address syna_, address sync_, address synr_, address divPool_) {
        owner = msg.sender;
        vault = IVault(vault_);
        syna = IToken(syna_);
        sync = IToken(sync_);
        synr = IToken(synr_);
        divPool = IDivPool(divPool_);
        callers[msg.sender] = true;
        lastEmitBlock = block.number;
    }

    function setCaller(address c, bool status) external onlyOwner {
        callers[c] = status;
    }

    function isEmissionDue() public view returns (bool) {
        return block.number >= lastEmitBlock + EMIT_INTERVAL;
    }

    function resetLastEmitBlock() external onlyOwner {
        lastEmitBlock = 0;
    }

    function executeEmission() external onlyCaller {
        require(isEmissionDue(), "too early");

        uint256 sR = syna.totalSupply();
        uint256 sT = sync.totalSupply();
        uint256 sP = synr.totalSupply();

        // em = S * emitRate * 100 / 1e18
        uint256 emR = sR * EMIT_RATE * 100 / 1e18;
        uint256 emT = sT * EMIT_RATE * 100 / 1e18;
        uint256 emP = sP * EMIT_RATE * 100 / 1e18;

        lastEmitBlock = block.number;

        // Mint tokens to vault
        if (emR > 0) { try syna.mint(address(vault), emR) {} catch {} totalEmittedR += emR; }
        if (emT > 0) { try sync.mint(address(vault), emT) {} catch {} totalEmittedT += emT; }
        if (emP > 0) { try synr.mint(address(vault), emP) {} catch {} totalEmittedP += emP; }

        // dlp estimate
        uint256 dlpTotal = (emR + emT + emP) / 10; // simplified

        // 30% to founder
        uint256 toFounder = dlpTotal * FOUNDER_BPS / 10000;
        if (toFounder > 0) {
            uint256 freeW = vault.freeWpol();
            if (freeW >= toFounder) {
                vault.transferWpol(address(divPool), toFounder);
                divPool.notifyFounderEmission(toFounder);
            }
        }

        // Rest to LP
        uint256 toLp = dlpTotal - toFounder;
        vault.batchAddLP(toLp * 22/100, toLp * 13/100, toLp * 65/100);

        vault.syncFromChain();

        emit EmissionExecuted(emR, emT, emP, toFounder);
    }

    function adapt() external onlyCaller {
        // Simplified - no-op
    }

    function recordFee(uint256) external onlyCaller {}
    function setAlphaLP(uint256) external onlyCaller {}
    function setFixBase(uint256) external onlyCaller {}
}
'''

# 4. TroikaCore (упрощённый)
CORE_SOURCE = '''
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

interface IVault {
    function syncFromChain() external;
    function flushLpBuf() external;
    function mcgRecycle() external;
    function totalMCap() external view returns (uint256);
    function mcgFund() external view returns (uint256);
    function subFromMcgFund(uint256) external;
    function batchAddLP(uint256, uint256, uint256) external;
    function addToMcgFund(uint256) external;
}

interface IEmit {
    function isEmissionDue() external view returns (bool);
    function executeEmission() external;
    function adapt() external;
    function recordFee(uint256) external;
}

interface IDivPool {
    function executeHoldersPayout() external;
}

interface IFeeRouter {
    function routeFee(uint256, uint8) external;
}

interface IERC20 {
    function transfer(address, uint256) external returns (bool);
    function transferFrom(address, address, uint256) external returns (bool);
    function balanceOf(address) external view returns (uint256);
}

contract TroikaCore {
    address public owner;
    address public vault;
    address public emitEngine;
    address public divPool;
    address public feeRouter;
    address public wpol;

    uint256 public lastTickBlock;
    uint256 public totalTicks;
    uint256 public keeperFund;
    uint256 public totalFeeProcessed;
    uint256 public prevMCap;

    bool public initialized;
    bool public paused;

    event TickDone(uint256 blockN, uint256 ticks);
    event FeeProcessed(address trader, uint256 amount, uint8 tokenType);

    modifier onlyOwner() { require(msg.sender == owner, "!owner"); _; }

    constructor(address wpol_) {
        owner = msg.sender;
        wpol = wpol_;
    }

    function initialize(address vault_, address emit_, address div_, address feeR_) external onlyOwner {
        require(!initialized, "init");
        vault = vault_;
        emitEngine = emit_;
        divPool = div_;
        feeRouter = feeR_;
        initialized = true;
    }

    function tick() external {
        require(initialized && !paused, "!ready");
        require(block.number > lastTickBlock, "too soon");

        lastTickBlock = block.number;
        totalTicks++;

        // Adapt
        try IEmit(emitEngine).adapt() {} catch {}

        // Flush LP buf
        if (totalTicks % 10 == 0) {
            try IVault(vault).flushLpBuf() {} catch {}
        }

        // Emission
        if (IEmit(emitEngine).isEmissionDue()) {
            try IEmit(emitEngine).executeEmission() {} catch {}
        }

        // Holders payout
        try IDivPool(divPool).executeHoldersPayout() {} catch {}

        // MCG
        _mcapGuard();

        // Sync
        if (totalTicks % 50 == 0) {
            try IVault(vault).syncFromChain() {} catch {}
        }

        // Keeper reward
        _payKeeper();

        emit TickDone(block.number, totalTicks);
    }

    function _mcapGuard() internal {
        uint256 mcNow = IVault(vault).totalMCap();
        if (mcNow < prevMCap) {
            uint256 fund = IVault(vault).mcgFund();
            if (fund > 1e15) {
                uint256 inj = fund * 10 / 10000;
                IVault(vault).subFromMcgFund(inj);
                IVault(vault).batchAddLP(inj * 22/100, inj * 13/100, inj * 65/100);
            }
        }
        try IVault(vault).mcgRecycle() {} catch {}
        prevMCap = mcNow;
    }

    function _payKeeper() internal {
        uint256 r = 1e14; // 0.0001 POL
        if (keeperFund < r) return;
        keeperFund -= r;
        IERC20(wpol).transfer(msg.sender, r);
    }

    function processFee(uint256 feeAmount, uint8 tokenType) external {
        require(initialized && !paused, "!ready");
        require(feeAmount > 0, "0");

        IERC20(wpol).transferFrom(msg.sender, feeRouter, feeAmount);

        try IEmit(emitEngine).recordFee(feeAmount) {} catch {}

        keeperFund += feeAmount * 2 / 10000;
        try IVault(vault).addToMcgFund(feeAmount * 2 / 10000) {} catch {}

        IFeeRouter(feeRouter).routeFee(feeAmount, tokenType);

        totalFeeProcessed += feeAmount;
        emit FeeProcessed(msg.sender, feeAmount, tokenType);
    }

    function fundKeeper(uint256 amount) external {
        IERC20(wpol).transferFrom(msg.sender, address(this), amount);
        keeperFund += amount;
    }

    function initKeeperFund(uint256 amount) external onlyOwner {
        keeperFund += amount;
    }

    function pause() external onlyOwner { paused = true; }
    function unpause() external onlyOwner { paused = false; }

    function systemState() external view returns (uint256 ticks, uint256 keeper, bool isPaused) {
        return (totalTicks, keeperFund, paused);
    }

    receive() external payable {}
}
'''

# 5. FeeRouter (упрощённый)
FEEROUTER_SOURCE = '''
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

interface IERC20 {
    function balanceOf(address) external view returns (uint256);
    function transfer(address, uint256) external returns (bool);
}

interface IVault {
    function addToLpBuf(uint256) external;
    function addToTraderReserve(uint256) external;
    function addToReserveR(uint256) external;
    function addToBuyback(uint256) external;
    function traderReserve() external view returns (uint256);
}

interface IDivPool {
    function notifyFounder(uint256) external;
    function notifyHolders(uint256) external;
}

contract FeeRouter {
    address public owner;
    IVault public vault;
    IDivPool public divPool;
    address public wpol;

    uint256 public alphaLP = 3500;  // 35%
    uint256 public alphaRES = 3000; // 30%
    uint256 public alphaCB = 1500;  // 15%
    uint256 public alphaDIV = 1000; // 10%

    uint256 public totalFeeRouted;

    mapping(address => bool) public callers;

    event FeeRouted(uint256 total, uint256 toLp, uint256 toRes, uint256 toCB, uint256 toDiv, uint256 toRR);

    modifier onlyOwner() { require(msg.sender == owner, "!owner"); _; }
    modifier onlyCaller() { require(callers[msg.sender] || msg.sender == owner, "!caller"); _; }

    constructor(address vault_, address divPool_, address wpol_) {
        owner = msg.sender;
        vault = IVault(vault_);
        divPool = IDivPool(divPool_);
        wpol = wpol_;
        callers[msg.sender] = true;
    }

    function setCaller(address c, bool status) external onlyOwner {
        callers[c] = status;
    }

    function routeFee(uint256 feeAmount, uint8) external onlyCaller {
        require(feeAmount > 0, "0");

        uint256 toLp = feeAmount * alphaLP / 10000;
        uint256 toRes = feeAmount * alphaRES / 10000;
        uint256 toCB = feeAmount * alphaCB / 10000;
        uint256 toDiv = feeAmount * alphaDIV / 10000;
        uint256 toRR = feeAmount - toLp - toRes - toCB - toDiv;

        totalFeeRouted += feeAmount;

        // LP buf
        IERC20(wpol).transfer(address(vault), toLp);
        vault.addToLpBuf(toLp);

        // Trader reserve
        IERC20(wpol).transfer(address(vault), toRes);
        vault.addToTraderReserve(toRes);

        // Reserve R
        IERC20(wpol).transfer(address(vault), toRR);
        vault.addToReserveR(toRR);

        // CB - goes to vault as buyback for simplicity
        IERC20(wpol).transfer(address(vault), toCB);
        vault.addToBuyback(toCB);

        // Dividends - 70% founder, 30% holders
        uint256 founderDiv = toDiv * 70 / 100;
        uint256 holderDiv = toDiv - founderDiv;

        if (founderDiv > 0) {
            IERC20(wpol).transfer(address(divPool), founderDiv);
            divPool.notifyFounder(founderDiv);
        }
        if (holderDiv > 0) {
            IERC20(wpol).transfer(address(divPool), holderDiv);
            divPool.notifyHolders(holderDiv);
        }

        emit FeeRouted(feeAmount, toLp, toRes, toCB, toDiv, toRR);
    }

    receive() external payable {}
}
'''

print("\n[1/5] Деплой TroikaVault...")
vault_result = deploy_contract(VAULT_SOURCE, "TroikaVault", [C(SYNA), C(SYNC), C(SYNR)], "TroikaVault")
if vault_result:
    deployed["vault"] = vault_result["address"]
    time.sleep(3)

print("\n[2/5] Деплой DividendPool...")
divpool_result = deploy_contract(DIVPOOL_SOURCE, "DividendPool", [C(SYNR), C(OWNER), C(WPOL)], "DividendPool")
if divpool_result:
    deployed["divPool"] = divpool_result["address"]
    time.sleep(3)

print("\n[3/5] Деплой FeeRouter...")
if "vault" in deployed and "divPool" in deployed:
    feerouter_result = deploy_contract(FEEROUTER_SOURCE, "FeeRouter",
        [C(deployed["vault"]), C(deployed["divPool"]), C(WPOL)], "FeeRouter")
    if feerouter_result:
        deployed["feeRouter"] = feerouter_result["address"]
        time.sleep(3)

print("\n[4/5] Деплой EmissionEngine...")
if "vault" in deployed and "divPool" in deployed:
    emission_result = deploy_contract(EMISSION_SOURCE, "EmissionEngine",
        [C(deployed["vault"]), C(SYNA), C(SYNC), C(SYNR), C(deployed["divPool"])], "EmissionEngine")
    if emission_result:
        deployed["emitEngine"] = emission_result["address"]
        time.sleep(3)

print("\n[5/5] Деплой TroikaCore...")
core_result = deploy_contract(CORE_SOURCE, "TroikaCore", [C(WPOL)], "TroikaCore")
if core_result:
    deployed["core"] = core_result["address"]
    time.sleep(3)

# Сохранить адреса
data["troika_system"] = deployed
data["system_deployed_at"] = time.strftime("%Y-%m-%d %H:%M:%S")

with open("deployed_instant.json", "w") as f:
    json.dump(data, f, indent=2)

print("\n" + "=" * 70)
print("РЕЗУЛЬТАТ ДЕПЛОЯ")
print("=" * 70)
for name, addr in deployed.items():
    print(f"  {name}: {addr}")
print(f"\nБаланс: {w3.eth.get_balance(C(OWNER)) / 1e18:.4f} POL")
print("=" * 70)
