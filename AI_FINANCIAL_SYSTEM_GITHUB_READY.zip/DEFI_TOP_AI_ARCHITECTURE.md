# SHTENCO DeFi TOP AI v3 — единый контур

## Цель

Контур объединяет Aave flash-loan арбитраж, ИИ-маркетмейкер, резервный QE, relay-мосты и ИИ-центробанк в одну систему управления капиталом. Система не обещает рост рыночной цены и не считает внутренний price impact созданной стоимостью. Целевой показатель — риск-скорректированная фундаментальная стоимость.

## Модули

1. `22_FlashLoanArbitrage.sol` — атомарный внешний арбитраж. Убыточная транзакция откатывается.
2. `32_SHTENCOFlashProfitHarvester.sol` — забирает только уже реализованную flash-прибыль и атомарно регистрирует её в казначействе.
3. `29_SHTENCOValueFlowTreasury.sol` — единый бухгалтерский слой реального дохода.
4. `25_SHTENCOMarketMaker.sol` — oracle-bounded swaps, LP и buyback-and-burn.
5. `24_SHTENCOBridgeQEReserve.sol` — операционный мостовой резерв с floor и daily limit.
6. `27_SHTENCOBridgeQEAdapter.sol` — разрешённые bridge routes и recipients.
7. `23_SHTENCOBridgeRelayV2.sol` — M-of-N relay bridge, escrow/mint-burn и replay protection.
8. `28_SHTENCOSystemStateOracle.sol` — M-of-N подтверждение экономического состояния.
9. `30_SHTENCOTopAIController.sol` — timelock, selector allowlist, бюджеты и повторная проверка риска перед выполнением.
10. `31_SHTENCODeFiContourRegistry.sol` — каноническая карта production-модулей.

## Поток капитала

```text
External DEX price discrepancy
        │
        ▼
Aave Flash Loan → FlashLoanArbitrage
        │  only net positive after premium/minProfit
        ▼
FlashProfitHarvester
        │  exact balance delta + unique sourceId
        ▼
ValueFlowTreasury
        ├─ RESERVE   25–60%
        ├─ LIQUIDITY 15–40% → AI Market Maker → owned LP
        ├─ BUYBACK    0–20% → AI Market Maker → burn
        ├─ BRIDGE     5–20% → QE Reserve → Adapter → Relay Bridge
        ├─ INSURANCE  5–20%
        └─ OPERATIONS 0–10%
```

## QE

QE в этой системе — распределение уже обеспеченного капитала, а не печать стоимости.

- Источник 1: доля реализованного внешнего дохода.
- Источник 2: резерв выше установленного floor и минимального reserve ratio.
- Разрешённые направления резервного QE: `LIQUIDITY`, `BRIDGE`, `INSURANCE`.
- Запрещённые направления резервного QE: `BUYBACK`, `OPERATIONS`, необеспеченный mint.
- Bridge QE не увеличивает NAV в момент перевода: капитал только перемещается между резервом и мостом за вычетом relay costs.

## Атомарный цикл прибыли

1. AI-сканер находит внешний арбитраж.
2. `FlashLoanArbitrage.startArbitrage()` проверяет quote, premium и `minProfit`.
3. Aave callback выполняет маршрут.
4. При недостаточной прибыли вся транзакция откатывается.
5. Следующее timelocked TOP-AI решение вызывает `FlashProfitHarvester.harvest()`.
6. Harvester переводит прибыль в `ValueFlowTreasury` и регистрирует exact delta.
7. В том же proposal казначейство распределяет доход по bucket policy.
8. Отдельные действия могут направить LIQUIDITY/BUYBACK в market maker и BRIDGE в bridge reserve/adapter.

## Fail-closed условия

TOP AI не выполняет proposal, если:

- M-of-N snapshot отсутствует или устарел;
- reserve ratio ниже политики;
- valuation premium слишком высокий;
- peg error, volatility или bridge imbalance превышают лимит;
- liquidity coverage ниже минимума;
- состояние ухудшилось между propose и execute;
- target/selector не разрешён;
- превышен daily token budget;
- timelock не истёк или proposal просрочен.
