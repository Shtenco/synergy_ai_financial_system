// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import "@openzeppelin/contracts/access/Ownable.sol";
import "@openzeppelin/contracts/utils/Pausable.sol";
import "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import "@openzeppelin/contracts/utils/Base64.sol";

// ═══════════════════════════════════════════════════════════════
//                         DEX INTERFACES
// ═══════════════════════════════════════════════════════════════

interface IUniswapV2Factory {
    function createPair(address tokenA, address tokenB) external returns (address pair);
}
interface IUniswapV2Pair {
    function getReserves() external view returns (uint112 r0, uint112 r1, uint32 ts);
    function token0() external view returns (address);
    function totalSupply() external view returns (uint256);
}
interface IUniswapV2Router02 {
    function factory() external pure returns (address);
    function WETH() external pure returns (address);
    function addLiquidityETH(
        address token, uint amountTokenDesired,
        uint amountTokenMin, uint amountETHMin,
        address to, uint deadline
    ) external payable returns (uint amountToken, uint amountETH, uint liquidity);
    function removeLiquidityETH(
        address token, uint liquidity,
        uint amountTokenMin, uint amountETHMin,
        address to, uint deadline
    ) external returns (uint amountToken, uint amountETH);
    function swapExactTokensForETHSupportingFeeOnTransferTokens(
        uint amountIn, uint amountOutMin,
        address[] calldata path, address to, uint deadline
    ) external;
    function swapExactETHForTokensSupportingFeeOnTransferTokens(
        uint amountOutMin,
        address[] calldata path,
        address to, uint deadline
    ) external payable;
}

// ═══════════════════════════════════════════════════════════════
//          ALTYN TOKEN (ALTN) — OMEGA DEFLATIONARY v4
// ═══════════════════════════════════════════════════════════════
//
//  АРХИТЕКТУРА v4: "Split-path" — все операции с роутером
//  вынесены из _update() в отдельную maintenance().
//
//  _update() — только: fee burn, accumulate to contract, velocity count
//  maintenance() — LP burn, buyback, swap&liquify, pool deepening
//
//  Это решает проблему "swap inside swap" (UniswapV2Pair lock).
//
//  14 слоёв дефляции сохранены, но работают корректно:
//  [1] Instant Fee Burn — 60% комиссии → _burn()
//  [2] Auto-Pool — 40% комиссий → контракт → maintenance()
//  [3] LP Burn + ETH Re-injection — через maintenance()
//  [4] ETH Buyback + Burn — через maintenance()
//  [5] Progressive Sell Tax
//  [6] Cascade Burn Tiers
//  [7] Sell Velocity Burn
//  [8] Transfer Burn (wallet→wallet)
//  [9] Price Floor Defense — через maintenance()
//  [10] Anti-Whale Cooldown
//  [11] Elastic Supply — через maintenance()
//  [12] Staking Lock
//  [13] Adaptive Optimizer
//  [14] ETH Pool Deepening — через maintenance()

contract AltynToken is ERC20, Ownable, Pausable, ReentrancyGuard {

    // ─────────────────────────────────────────────────────────
    //                         EVENTS
    // ─────────────────────────────────────────────────────────

    event InstantBurn            (address indexed from, uint256 amount);
    event TransferBurn           (address indexed from, uint256 amount);
    event BuybackExecuted        (uint256 ethSpent, uint256 altnBurned);
    event LPBurnAndReinjected    (uint256 lpRemoved, uint256 altnBurned, uint256 ethReinjected);
    event ETHPoolDeepened        (uint256 altnMinted, uint256 ethAdded);
    event SwapAndLiquify         (uint256 tokensSwapped, uint256 ethReceived, uint256 tokensAdded);
    event FeesDistributed        (uint256 burned, uint256 toLiquidity);
    event CascadeBurnTier        (uint8 tier, uint256 burned, uint256 priceDelta);
    event SellVelocityBurn       (uint256 sells, uint256 burned);
    event PriceFloorDefense      (uint256 level, uint256 ethBuyback, uint256 cascadeBurned);
    event ProgressiveTaxApplied  (address indexed seller, uint256 baseFee, uint256 extraFee);
    event WhaleSellDetected      (address indexed seller, uint256 amount, uint256 pctPool);
    event WhaleOnCooldown        (address indexed seller, uint256 cooldownUntilBlock);
    event Staked                 (address indexed user, uint256 amount);
    event Unstaked               (address indexed user, uint256 returned, uint256 burned);
    event RewardsClaimed         (address indexed user, uint256 amount);
    event ElasticBurn            (uint256 amount, uint256 delta);
    event ElasticMint            (uint256 amount, uint256 delta);
    event MarketHealthUpdated    (int256 score, uint256 burnRate, uint256 mintRate);
    event MaintenanceExecuted    (uint256 blockNumber);
    event ParameterUpdated       (string param, uint256 oldVal, uint256 newVal);

    // ─────────────────────────────────────────────────────────
    //                        CONSTANTS
    // ─────────────────────────────────────────────────────────

    uint256 public constant MAX_SUPPLY = 110_500_000 * 1e18;

    uint256 public constant BURN_SHARE      = 600; // 60% → burn
    uint256 public constant LIQUIDITY_SHARE = 400; // 40% → auto-pool
    uint256 public constant LP_CONTRACT_SHARE = 500;
    uint256 public constant TRANSFER_BURN_RATE = 5; // 0.5% (per 1000)

    // Adaptive optimizer constants
    int256 private constant OPT_LR      = 2;
    int256 private constant OPT_MOM     = 9;
    int256 private constant BURN_MIN    = 5;
    int256 private constant BURN_MAX    = 100;
    int256 private constant MINT_MIN    = 3;
    int256 private constant MINT_MAX    = 60;

    // ─────────────────────────────────────────────────────────
    //                   НАСТРАИВАЕМЫЕ ПАРАМЕТРЫ
    // ─────────────────────────────────────────────────────────

    // AMM fees
    uint256 public buyFee  = 100; // 10%
    uint256 public sellFee = 150; // 15%

    // [5] Progressive sell tax
    uint256 public progressiveTaxStep      = 50;
    uint256 public progressiveTaxThreshold = 5;
    uint256 public maxSellFee              = 300;
    uint256 public whaleSellThreshold      = 10;
    uint256 public whaleExtraTax           = 100;

    // [6] Cascade burn tiers
    uint256 public cascadeTier1Delta  = 5;    uint256 public cascadeTier1Rate   = 20;
    uint256 public cascadeTier2Delta  = 20;   uint256 public cascadeTier2Rate   = 50;
    uint256 public cascadeTier3Delta  = 50;   uint256 public cascadeTier3Rate   = 100;
    uint256 public cascadeTier4Delta  = 100;  uint256 public cascadeTier4Rate   = 200;

    // [7] Sell velocity
    uint256 public velocityWindow     = 20;
    uint256 public velocityThresh1    = 5;
    uint256 public velocityThresh2    = 10;
    uint256 public velocityBurnRate1  = 20;
    uint256 public velocityBurnRate2  = 50;

    // [9] Price floor levels (per 1000 от ATH)
    uint256 public floorLevel1 = 200;
    uint256 public floorLevel2 = 300;
    uint256 public floorLevel3 = 500;

    // [10] Anti-whale cooldown
    bool    public cooldownEnabled    = true;
    uint256 public cooldownBaseBlocks = 2;
    uint256 public cooldownMaxBlocks  = 200;

    // [11] Elastic supply
    uint256 public burnRate             = 20;
    uint256 public mintRate             = 15;
    uint256 public priceChangeThreshold = 5;
    uint256 public priceUpdateInterval  = 5;

    // [3] LP burn
    bool    public lpBurnEnabled    = true;
    uint256 public lpBurnInterval   = 50;
    uint256 public lpBurnRate       = 80;
    uint256 public minLPForBurn     = 1e15;
    uint256 public lpEthReinjection = 700;

    // [4] ETH Buyback
    bool    public buybackEnabled   = true;
    uint256 public buybackThreshold = 0.03 ether;
    uint256 public buybackShare     = 200;

    // Auto-pool
    uint256 public minTokensBeforeSwap   = 500 * 1e18;
    bool    public swapAndLiquifyEnabled = true;

    // [12] Staking
    uint256 public stakingAPY       = 100;
    uint256 public unstakeBurnRate  = 30;
    uint256 public minStakeDuration = 7 days;

    // [13] Adaptive optimizer
    bool    public adaptiveEnabled       = true;
    uint256 public optimizationInterval  = 30;

    // [14] Pool deepening
    bool    public poolDeepeningEnabled  = true;
    uint256 public deepenMintRate        = 10;
    uint256 public deepenPriceThreshold  = 10;

    // ─────────────────────────────────────────────────────────
    //                     STATE VARIABLES
    // ─────────────────────────────────────────────────────────

    uint256 public lastPrice;
    uint256 public ath;
    uint256 public lastUpdateBlock;
    uint256 public lastPriceDrop;
    uint256 public ethAccumulatedBuyback;
    uint256 public lastLpBurnBlock;
    uint256 public lastMaintenanceBlock;

    // [7] Sell velocity
    uint256 public  sellsInWindow;
    uint256 public  velocityWindowStart;

    // [10] Anti-whale cooldown
    mapping(address => uint256) public whaleNextSellBlock;
    mapping(address => uint256) public whaleCooldownLevel;

    // [12] Staking
    mapping(address => uint256) public stakingBalance;
    mapping(address => uint256) public stakingTimestamp;
    uint256 public totalStaked;

    // [13] Optimizer state
    uint256 public lastOptBlock;
    uint256 public lastVol24hSnap;
    int256  private _burnVel;
    int256  private _mintVel;

    // Pending maintenance flags (set in _update, executed in maintenance)
    bool    public pendingElastic;
    uint256 public pendingElasticDelta;
    bool    public pendingElasticUp;

    mapping(address => bool) public isExcludedFromFee;
    mapping(address => bool) public automatedMarketMakerPairs;

    IUniswapV2Router02 public immutable uniswapV2Router;
    address            public immutable uniswapV2Pair;

    bool private _swapping;
    modifier lockTheSwap() { _swapping = true; _; _swapping = false; }

    // ─────────────────────────────────────────────────────────
    //                       CONSTRUCTOR
    // ─────────────────────────────────────────────────────────

    constructor() ERC20("Altyn", "ALTN") Ownable(msg.sender) {
        IUniswapV2Router02 _r = IUniswapV2Router02(
            0xa5E0829CaCEd8fFDD4De3c43696c57F7D7A678ff  // QuickSwap Polygon
        );
        address _p = IUniswapV2Factory(_r.factory())
            .createPair(address(this), _r.WETH());

        uniswapV2Router = _r;
        uniswapV2Pair   = _p;
        automatedMarketMakerPairs[_p] = true;

        isExcludedFromFee[owner()]       = true;
        isExcludedFromFee[address(this)] = true;

        _mint(msg.sender, MAX_SUPPLY * 65 / 100);

        lastUpdateBlock      = block.number;
        lastLpBurnBlock      = block.number;
        lastOptBlock         = block.number;
        lastMaintenanceBlock = block.number;
        velocityWindowStart  = block.number;
    }

    // ══════════════════════════════════════════════════════════
    //  PRICE ORACLE — реальная цена, без floor
    // ══════════════════════════════════════════════════════════

    function getCurrentPrice() public view returns (uint256) {
        try IUniswapV2Pair(uniswapV2Pair).getReserves()
            returns (uint112 r0, uint112 r1, uint32)
        {
            bool isToken0 = IUniswapV2Pair(uniswapV2Pair).token0() == address(this);
            uint256 tokRes  = isToken0 ? uint256(r0) : uint256(r1);
            uint256 ethRes  = isToken0 ? uint256(r1) : uint256(r0);
            if (tokRes == 0) return 0;
            return ethRes * 1e18 / tokRes;
        } catch { return 0; }
    }

    function _getETHReserve() private view returns (uint256) {
        try IUniswapV2Pair(uniswapV2Pair).getReserves()
            returns (uint112 r0, uint112 r1, uint32)
        {
            bool isToken0 = IUniswapV2Pair(uniswapV2Pair).token0() == address(this);
            return isToken0 ? uint256(r1) : uint256(r0);
        } catch { return 0; }
    }

    function _getTokenReserve() private view returns (uint256) {
        try IUniswapV2Pair(uniswapV2Pair).getReserves()
            returns (uint112 r0, uint112 r1, uint32)
        {
            bool isToken0 = IUniswapV2Pair(uniswapV2Pair).token0() == address(this);
            return isToken0 ? uint256(r0) : uint256(r1);
        } catch { return 0; }
    }

    // ══════════════════════════════════════════════════════════
    //  [13] ADAPTIVE OPTIMIZER (lightweight — no router calls)
    // ══════════════════════════════════════════════════════════

    function getMarketHealthScore() public view returns (int256) {
        uint256 cp = getCurrentPrice();
        if (lastPrice == 0 || cp == 0) return 0;
        int256 pg = cp >= lastPrice
            ? int256((cp - lastPrice) * 1e18 / lastPrice)
            : -int256((lastPrice - cp) * 1e18 / lastPrice);
        int256 s = pg;
        if (s > int256(1e18))  return int256(1e18);
        if (s < -int256(1e18)) return -int256(1e18);
        return s;
    }

    function _runOptimizer() private {
        if (!adaptiveEnabled) return;
        if (block.number - lastOptBlock < optimizationInterval) return;
        lastOptBlock = block.number;
        int256 h = getMarketHealthScore();
        int256 bg = -(h / int256(1e17));
        _burnVel = (OPT_MOM * _burnVel + OPT_LR * bg) / 10;
        burnRate = uint256(_clamp(int256(burnRate) + _burnVel, BURN_MIN, BURN_MAX));
        int256 mg = h / int256(1e17);
        _mintVel = (OPT_MOM * _mintVel + OPT_LR * mg) / 10;
        mintRate = uint256(_clamp(int256(mintRate) + _mintVel, MINT_MIN, MINT_MAX));
        emit MarketHealthUpdated(h, burnRate, mintRate);
    }

    function _clamp(int256 v, int256 lo, int256 hi) private pure returns (int256) {
        if (v < lo) return lo;
        if (v > hi) return hi;
        return v;
    }

    // ══════════════════════════════════════════════════════════
    //  [7] SELL VELOCITY TRACKER (lightweight)
    // ══════════════════════════════════════════════════════════

    function _trackSellVelocity() private {
        if (block.number > velocityWindowStart + velocityWindow) {
            velocityWindowStart = block.number;
            sellsInWindow       = 0;
        }
        sellsInWindow++;

        uint256 contractBal = balanceOf(address(this));
        if (contractBal == 0) return;

        uint256 extra;
        if (sellsInWindow > velocityThresh2) {
            extra = contractBal * velocityBurnRate2 / 1000;
        } else if (sellsInWindow > velocityThresh1) {
            extra = contractBal * velocityBurnRate1 / 1000;
        }
        if (extra > 0) {
            _burn(address(this), extra);
            emit SellVelocityBurn(sellsInWindow, extra);
        }
    }

    // ══════════════════════════════════════════════════════════
    //  [6] CASCADE BURN TIERS (lightweight — no router calls)
    // ══════════════════════════════════════════════════════════

    function _cascadeBurn(uint256 delta) private {
        uint256 supply = totalSupply();
        uint256 burned;
        uint8   tier;

        if (delta >= cascadeTier4Delta) {
            burned = supply * cascadeTier4Rate / 1000; tier = 4;
        } else if (delta >= cascadeTier3Delta) {
            burned = supply * cascadeTier3Rate / 1000; tier = 3;
        } else if (delta >= cascadeTier2Delta) {
            burned = supply * cascadeTier2Rate / 1000; tier = 2;
        } else if (delta >= cascadeTier1Delta) {
            burned = supply * cascadeTier1Rate / 1000; tier = 1;
        }

        if (burned > 0) {
            uint256 available = balanceOf(address(this));
            if (available >= burned) {
                _burn(address(this), burned);
            } else {
                if (available > 0) _burn(address(this), available);
                uint256 remainder = burned - available;
                if (totalSupply() + remainder <= MAX_SUPPLY) {
                    _mint(address(this), remainder);
                    _burn(address(this), remainder);
                }
            }
            emit CascadeBurnTier(tier, burned, delta);
        }
    }

    // ══════════════════════════════════════════════════════════
    //  [10] ANTI-WHALE COOLDOWN (lightweight)
    // ══════════════════════════════════════════════════════════

    function _checkWhaleCooldown(address seller, uint256 amount) private {
        if (!cooldownEnabled) return;
        uint256 poolRes = _getTokenReserve();
        if (poolRes == 0) return;
        if (amount * 1000 / poolRes < whaleSellThreshold) return;

        require(
            block.number >= whaleNextSellBlock[seller],
            "ALTN: whale cooldown active"
        );

        uint256 level = whaleCooldownLevel[seller];
        uint256 delay = cooldownBaseBlocks * (2 ** level);
        if (delay > cooldownMaxBlocks) delay = cooldownMaxBlocks;

        whaleCooldownLevel[seller]  = level + 1;
        whaleNextSellBlock[seller]  = block.number + delay;
        emit WhaleOnCooldown(seller, block.number + delay);
    }

    function resetWhaleCooldown(address whale) external onlyOwner {
        whaleCooldownLevel[whale] = 0;
        whaleNextSellBlock[whale] = 0;
    }

    // ══════════════════════════════════════════════════════════
    //  [5] ПРОГРЕССИВНЫЙ SELL TAX (lightweight)
    // ══════════════════════════════════════════════════════════

    function _calcSellFee(address seller, uint256 amount) private returns (uint256) {
        uint256 fee = sellFee;
        if (lastPriceDrop > 0 && progressiveTaxThreshold > 0) {
            uint256 steps = lastPriceDrop / progressiveTaxThreshold;
            uint256 extra = steps * progressiveTaxStep;
            if (extra > 0) { fee += extra; emit ProgressiveTaxApplied(seller, sellFee, extra); }
        }
        if (fee > maxSellFee) fee = maxSellFee;
        uint256 pr = _getTokenReserve();
        if (pr > 0 && amount * 1000 / pr >= whaleSellThreshold) {
            emit WhaleSellDetected(seller, amount, amount * 1000 / pr);
            fee += whaleExtraTax;
            if (fee > maxSellFee) fee = maxSellFee;
        }
        return fee;
    }

    // ══════════════════════════════════════════════════════════
    //  LIGHTWEIGHT PRICE CHECK (set flags for maintenance)
    // ══════════════════════════════════════════════════════════

    function _checkPriceAndSetFlags() private {
        _runOptimizer();

        if (block.number - lastUpdateBlock < priceUpdateInterval) return;

        uint256 cp = getCurrentPrice();
        if (cp == 0) return;

        if (cp > ath) ath = cp;

        if (lastPrice == 0) {
            lastPrice = cp; lastUpdateBlock = block.number; return;
        }

        bool    up;
        uint256 delta;
        if (cp >= lastPrice) {
            delta = (cp - lastPrice) * 1000 / lastPrice;
            up    = true;
            lastPriceDrop = 0;
        } else {
            delta = (lastPrice - cp) * 1000 / lastPrice;
            up    = false;
            lastPriceDrop = delta;
        }

        if (delta >= priceChangeThreshold) {
            // Cascade burn — lightweight, no router calls
            if (!up) _cascadeBurn(delta);

            // Set flags for maintenance() to handle router-dependent operations
            pendingElastic      = true;
            pendingElasticDelta = delta;
            pendingElasticUp    = up;
        }

        lastPrice = cp; lastUpdateBlock = block.number;
    }

    // ══════════════════════════════════════════════════════════
    //  TRANSFER HOOK — ТОЛЬКО ЛЁГКИЕ ОПЕРАЦИИ
    //  Никаких вызовов роутера! Всё тяжёлое → maintenance()
    // ══════════════════════════════════════════════════════════

    function _update(
        address from, address to, uint256 amount
    ) internal virtual override whenNotPaused {

        // Системные (mint / burn / internal swaps) — без комиссий
        if (from == address(0) || to == address(0) || _swapping) {
            super._update(from, to, amount);
            return;
        }

        bool isBuy  = automatedMarketMakerPairs[from];
        bool isSell = automatedMarketMakerPairs[to];
        bool isTransfer = !isBuy && !isSell;

        // [10] Whale cooldown (только продажи)
        if (isSell) _checkWhaleCooldown(from, amount);

        // [7] Sell velocity
        if (isSell) _trackSellVelocity();

        // Lightweight price check + optimizer + cascade burn
        if (isBuy || isSell) _checkPriceAndSetFlags();

        bool takeFee = !isExcludedFromFee[from] && !isExcludedFromFee[to];

        // [8] Transfer burn (wallet → wallet)
        if (takeFee && isTransfer) {
            uint256 tBurn = amount * TRANSFER_BURN_RATE / 1000;
            if (tBurn > 0) {
                _burn(from, tBurn);
                amount -= tBurn;
                emit TransferBurn(from, tBurn);
            }
        }

        // [1][2] AMM fee: 60% instant burn / 40% accumulate on contract
        if (takeFee && (isBuy || isSell)) {
            uint256 feeRate = isBuy ? buyFee : _calcSellFee(from, amount);
            uint256 totalFee = amount * feeRate / 1000;

            if (totalFee > 0) {
                uint256 burnAmt = totalFee * BURN_SHARE    / 1000; // 60%
                uint256 liqAmt  = totalFee - burnAmt;              // 40%
                if (burnAmt > 0) { _burn(from, burnAmt); emit InstantBurn(from, burnAmt); }
                if (liqAmt  > 0) super._update(from, address(this), liqAmt);
                amount -= totalFee;
                emit FeesDistributed(burnAmt, liqAmt);
            }
        }

        super._update(from, to, amount);
    }

    // ══════════════════════════════════════════════════════════
    //  MAINTENANCE — ВСЕ ОПЕРАЦИИ С РОУТЕРОМ
    //  Вызывается отдельной транзакцией (робот/кто угодно)
    // ══════════════════════════════════════════════════════════

    function maintenance() external nonReentrant {
        require(!_swapping, "Already running");

        // [2] Swap accumulated fees → LP
        if (swapAndLiquifyEnabled && balanceOf(address(this)) >= minTokensBeforeSwap) {
            _swapAndLiquify(minTokensBeforeSwap);
        }

        // [3] LP Burn + ETH re-injection
        _tryLPBurn();

        // [4] Buyback
        if (buybackEnabled && ethAccumulatedBuyback >= buybackThreshold) {
            _executeBuyback();
        }

        // [11] Elastic supply (deferred from _update)
        if (pendingElastic) {
            pendingElastic = false;
            if (pendingElasticUp) {
                uint256 mintAmt = totalSupply() * mintRate / 1000;
                if (mintAmt > 0 && totalSupply() + mintAmt <= MAX_SUPPLY) {
                    _mint(address(this), mintAmt);
                    _addMintedToPool(mintAmt);
                    emit ElasticMint(mintAmt, pendingElasticDelta);
                }
                // [14] Pool deepening
                _deepenPool(pendingElasticDelta);
            } else {
                // [9] Price floor defense
                _priceFloorDefense(getCurrentPrice());
                emit ElasticBurn(0, pendingElasticDelta);
            }
        }

        lastMaintenanceBlock = block.number;
        emit MaintenanceExecuted(block.number);
    }

    // ══════════════════════════════════════════════════════════
    //  [3] LP BURN + ETH RE-INJECTION
    // ══════════════════════════════════════════════════════════

    function _tryLPBurn() private {
        if (!lpBurnEnabled) return;
        if (block.number - lastLpBurnBlock < lpBurnInterval) return;
        uint256 lpBal = IERC20(uniswapV2Pair).balanceOf(address(this));
        if (lpBal < minLPForBurn) return;
        uint256 toburn = lpBal * lpBurnRate / 1000;
        if (toburn == 0) return;
        lastLpBurnBlock = block.number;
        _executeLPBurnReinjection(toburn);
    }

    function _forceLPBurn(uint256 ratePer1000) private {
        uint256 lpBal = IERC20(uniswapV2Pair).balanceOf(address(this));
        if (lpBal < minLPForBurn) return;
        uint256 toburn = lpBal * ratePer1000 / 1000;
        if (toburn == 0) return;
        _executeLPBurnReinjection(toburn);
    }

    function _executeLPBurnReinjection(uint256 lpAmount) private lockTheSwap {
        IERC20(uniswapV2Pair).approve(address(uniswapV2Router), lpAmount);

        try uniswapV2Router.removeLiquidityETH(
            address(this), lpAmount, 0, 0,
            address(this), block.timestamp + 300
        ) returns (uint256 altnOut, uint256 ethOut) {

            if (altnOut > 0) _burn(address(this), altnOut);
            if (ethOut == 0) {
                emit LPBurnAndReinjected(lpAmount, altnOut, 0);
                return;
            }

            uint256 ethForPool    = ethOut * lpEthReinjection / 1000;
            uint256 ethForBuyback = ethOut - ethForPool;

            if (ethForPool > 0) {
                uint256 curPrice = getCurrentPrice();
                uint256 tokensNeeded = curPrice > 0
                    ? ethForPool * 1e18 / curPrice
                    : 1e15;
                if (tokensNeeded > 0 && totalSupply() + tokensNeeded <= MAX_SUPPLY) {
                    _mint(address(this), tokensNeeded);
                    _approve(address(this), address(uniswapV2Router), tokensNeeded);
                    try uniswapV2Router.addLiquidityETH{value: ethForPool}(
                        address(this), tokensNeeded, 0, 0,
                        address(this), block.timestamp + 300
                    ) returns (uint256 tUsed, uint256 eUsed, uint256) {
                        uint256 tUnused = tokensNeeded > tUsed ? tokensNeeded - tUsed : 0;
                        if (tUnused > 0) _burn(address(this), tUnused);
                        emit ETHPoolDeepened(tokensNeeded - tUnused, eUsed);
                    } catch {
                        _burn(address(this), tokensNeeded);
                    }
                }
            }

            if (ethForBuyback > 0) {
                ethAccumulatedBuyback += ethForBuyback;
            }

            emit LPBurnAndReinjected(lpAmount, altnOut, ethForPool);

        } catch {
            IERC20(uniswapV2Pair).approve(address(uniswapV2Router), 0);
        }
    }

    function triggerLPBurn() external nonReentrant {
        require(lpBurnEnabled, "Disabled");
        uint256 lpBal = IERC20(uniswapV2Pair).balanceOf(address(this));
        require(lpBal >= minLPForBurn, "Insufficient LP");
        uint256 toburn = lpBal * lpBurnRate / 1000;
        require(toburn > 0, "Zero");
        lastLpBurnBlock = block.number;
        _executeLPBurnReinjection(toburn);
    }

    // ══════════════════════════════════════════════════════════
    //  [14] ETH POOL DEEPENING
    // ══════════════════════════════════════════════════════════

    function _deepenPool(uint256 delta) private lockTheSwap {
        if (!poolDeepeningEnabled) return;
        if (delta < deepenPriceThreshold) return;

        uint256 mintAmt = totalSupply() * deepenMintRate / 1000;
        if (mintAmt == 0 || totalSupply() + mintAmt > MAX_SUPPLY) return;

        _mint(address(this), mintAmt);

        uint256 ethBefore = address(this).balance;
        address[] memory path = new address[](2);
        path[0] = address(this);
        path[1] = uniswapV2Router.WETH();
        _approve(address(this), address(uniswapV2Router), mintAmt);

        try uniswapV2Router.swapExactTokensForETHSupportingFeeOnTransferTokens(
            mintAmt, 0, path, address(this), block.timestamp
        ) {
            uint256 ethGained = address(this).balance - ethBefore;
            if (ethGained == 0) return;

            uint256 curPrice = getCurrentPrice();
            uint256 tokMin = curPrice > 0 ? ethGained * 1e18 / curPrice : 1e15;
            if (tokMin > 0 && totalSupply() + tokMin <= MAX_SUPPLY) {
                _mint(address(this), tokMin);
                _approve(address(this), address(uniswapV2Router), tokMin);
                try uniswapV2Router.addLiquidityETH{value: ethGained}(
                    address(this), tokMin, 0, 0,
                    address(this), block.timestamp + 300
                ) returns (uint256 tUsed, uint256 eUsed, uint256) {
                    uint256 tUnused = tokMin > tUsed ? tokMin - tUsed : 0;
                    if (tUnused > 0) _burn(address(this), tUnused);
                    emit ETHPoolDeepened(tUsed, eUsed);
                } catch {
                    _burn(address(this), tokMin);
                }
            }
        } catch {
            _burn(address(this), mintAmt);
        }
    }

    // ══════════════════════════════════════════════════════════
    //  [9] PRICE FLOOR DEFENSE
    // ══════════════════════════════════════════════════════════

    function _priceFloorDefense(uint256 currentPrice) private {
        if (ath == 0 || currentPrice >= ath) return;
        uint256 dropFromATH = (ath - currentPrice) * 1000 / ath;

        uint256 ethToDefend;
        uint256 cascadeExtra;

        if (dropFromATH >= floorLevel3) {
            ethToDefend  = address(this).balance * 80 / 100;
            cascadeExtra = totalSupply() * 100 / 1000;
        } else if (dropFromATH >= floorLevel2) {
            ethToDefend  = address(this).balance * 50 / 100;
            cascadeExtra = totalSupply() * 50 / 1000;
        } else if (dropFromATH >= floorLevel1) {
            ethToDefend  = address(this).balance * 30 / 100;
            cascadeExtra = totalSupply() * 20 / 1000;
        }

        if (ethToDefend > 0) {
            ethAccumulatedBuyback += ethToDefend;
            _executeBuyback();
        }
        if (cascadeExtra > 0) {
            uint256 avail = balanceOf(address(this));
            uint256 actual = avail < cascadeExtra ? avail : cascadeExtra;
            if (actual > 0) _burn(address(this), actual);
            emit PriceFloorDefense(dropFromATH, ethToDefend, actual);
        }
    }

    // ══════════════════════════════════════════════════════════
    //  [4] ETH BUYBACK + BURN
    // ══════════════════════════════════════════════════════════

    function _executeBuyback() private {
        uint256 eth = ethAccumulatedBuyback;
        if (eth == 0 || address(this).balance < eth) return;
        ethAccumulatedBuyback = 0;
        address[] memory path = new address[](2);
        path[0] = uniswapV2Router.WETH();
        path[1] = address(this);
        uint256 before = balanceOf(address(this));
        try uniswapV2Router.swapExactETHForTokensSupportingFeeOnTransferTokens{
            value: eth
        }(0, path, address(this), block.timestamp) {
            uint256 bought = balanceOf(address(this)) - before;
            if (bought > 0) { _burn(address(this), bought); emit BuybackExecuted(eth, bought); }
        } catch { ethAccumulatedBuyback += eth; }
    }

    function triggerBuyback() external nonReentrant {
        require(buybackEnabled && ethAccumulatedBuyback >= buybackThreshold, "N/A");
        _executeBuyback();
    }

    // ══════════════════════════════════════════════════════════
    //  [2] AUTO-POOL (swap accumulated fees → LP)
    // ══════════════════════════════════════════════════════════

    function _swapAndLiquify(uint256 tokenAmount) private lockTheSwap {
        if (tokenAmount < 2) return;
        uint256 half = tokenAmount / 2;
        uint256 other = tokenAmount - half;
        uint256 eb = address(this).balance;
        _swapForETH(half);
        uint256 ethGained = address(this).balance - eb;
        if (ethGained == 0 || other == 0) return;

        uint256 ethBB    = ethGained * buybackShare / 1000;
        uint256 ethPool  = ethGained - ethBB;
        if (buybackEnabled && ethBB > 0) {
            ethAccumulatedBuyback += ethBB;
        }

        if (ethPool == 0) return;
        _approve(address(this), address(uniswapV2Router), other);
        (, uint256 ea, uint256 lp) = uniswapV2Router.addLiquidityETH{value: ethPool}(
            address(this), other, 0, 0, address(this), block.timestamp + 300
        );
        emit SwapAndLiquify(half, ea, other);
        _distributeLPTokens(lp);
    }

    function _addMintedToPool(uint256 amt) private lockTheSwap {
        if (amt < 2) return;
        uint256 half = amt / 2;
        uint256 other = amt - half;
        uint256 eb = address(this).balance;
        _swapForETH(half);
        uint256 ethGained = address(this).balance - eb;
        if (ethGained == 0 || other == 0) return;
        _approve(address(this), address(uniswapV2Router), other);
        (, uint256 ea, uint256 lp) = uniswapV2Router.addLiquidityETH{value: ethGained}(
            address(this), other, 0, 0, address(this), block.timestamp + 300
        );
        _distributeLPTokens(lp);
    }

    function _distributeLPTokens(uint256 lp) private {
        if (lp == 0) return;
        uint256 toOwner = lp * (1000 - LP_CONTRACT_SHARE) / 1000;
        if (toOwner > 0) IERC20(uniswapV2Pair).transfer(owner(), toOwner);
    }

    function _swapForETH(uint256 amount) private {
        address[] memory path = new address[](2);
        path[0] = address(this);
        path[1] = uniswapV2Router.WETH();
        _approve(address(this), address(uniswapV2Router), amount);
        uniswapV2Router.swapExactTokensForETHSupportingFeeOnTransferTokens(
            amount, 0, path, address(this), block.timestamp
        );
    }

    // ══════════════════════════════════════════════════════════
    //  [12] STAKING
    // ══════════════════════════════════════════════════════════

    function stake(uint256 amount) external nonReentrant whenNotPaused {
        require(amount > 0, "Zero");
        _claimRewards(msg.sender);
        _transfer(msg.sender, address(this), amount);
        stakingBalance[msg.sender]  += amount;
        stakingTimestamp[msg.sender] = block.timestamp;
        totalStaked                 += amount;
        emit Staked(msg.sender, amount);
    }

    function unstake(uint256 amount) external nonReentrant whenNotPaused {
        require(amount > 0 && stakingBalance[msg.sender] >= amount, "Invalid");
        require(block.timestamp >= stakingTimestamp[msg.sender] + minStakeDuration, "Locked");
        _claimRewards(msg.sender);
        stakingBalance[msg.sender] -= amount;
        totalStaked                -= amount;
        uint256 toBurn   = amount * unstakeBurnRate / 1000;
        uint256 toReturn = amount - toBurn;
        if (toBurn > 0)   _burn(address(this), toBurn);
        if (toReturn > 0) _transfer(address(this), msg.sender, toReturn);
        emit Unstaked(msg.sender, toReturn, toBurn);
    }

    function claimStakingRewards() external nonReentrant whenNotPaused {
        _claimRewards(msg.sender);
    }

    function _claimRewards(address user) private {
        uint256 s = stakingBalance[user];
        if (s == 0) return;
        uint256 elapsed = block.timestamp - stakingTimestamp[user];
        uint256 reward  = s * stakingAPY * elapsed / (1000 * 365 days);
        if (reward == 0) return;
        stakingTimestamp[user] = block.timestamp;
        if (balanceOf(address(this)) >= reward) {
            _transfer(address(this), user, reward);
        } else if (totalSupply() + reward <= MAX_SUPPLY) {
            _mint(user, reward);
        }
        emit RewardsClaimed(user, reward);
    }

    function pendingRewards(address user) external view returns (uint256) {
        uint256 s = stakingBalance[user];
        if (s == 0) return 0;
        return s * stakingAPY * (block.timestamp - stakingTimestamp[user]) / (1000 * 365 days);
    }

    // ══════════════════════════════════════════════════════════
    //  TOKEN URI
    // ══════════════════════════════════════════════════════════

    function tokenURI() public view returns (string memory) {
        string memory svg = string(abi.encodePacked(
            '<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">',
            '<defs>',
            '<linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">',
            '<stop offset="0%" stop-color="#050E1F"/>',
            '<stop offset="100%" stop-color="#0E2454"/>',
            '</linearGradient>',
            '<linearGradient id="ac" x1="0%" y1="0%" x2="100%" y2="100%">',
            '<stop offset="0%" stop-color="#00E5FF"/>',
            '<stop offset="100%" stop-color="#0055FF"/>',
            '</linearGradient>',
            '</defs>',
            '<circle cx="100" cy="100" r="96" fill="url(#bg)"/>',
            '<circle cx="100" cy="100" r="96" fill="none" stroke="url(#ac)" stroke-width="1.5"/>',
            '<g fill="none" stroke="url(#ac)" stroke-width="1.2" opacity="0.5">',
            '<polygon points="100,22 162,58 162,142 100,178 38,142 38,58"/>',
            '<polygon points="100,42 142,66 142,134 100,158 58,134 58,66"/>',
            '</g>',
            '<text x="100" y="108" font-family="Arial Black" font-size="56" ',
            'fill="url(#ac)" text-anchor="middle" dominant-baseline="middle">',
            'A</text>',
            '<text x="100" y="148" font-family="Arial" font-size="11" ',
            'fill="#00E5FF" text-anchor="middle" letter-spacing="5" opacity="0.85">',
            'ALTYN</text>',
            '</svg>'
        ));
        string memory json = string(abi.encodePacked(
            '{"name":"Altyn","symbol":"ALTN",',
            '"description":"14-layer omega deflationary token v4. Split-path architecture for QuickSwap/Polygon.",',
            '"image":"data:image/svg+xml;base64,', Base64.encode(bytes(svg)), '",',
            '"attributes":[',
            '{"trait_type":"Deflationary Layers","value":"14"},',
            '{"trait_type":"Network","value":"Polygon"},',
            '{"trait_type":"Current Supply","value":"', _u2s(totalSupply() / 1e18), '"},',
            '{"trait_type":"ATH Price","value":"', _u2s(ath), '"}',
            ']}'
        ));
        return string(abi.encodePacked('data:application/json;base64,', Base64.encode(bytes(json))));
    }

    function _u2s(uint256 v) private pure returns (string memory) {
        if (v == 0) return "0";
        uint256 t = v; uint256 d;
        while (t != 0) { d++; t /= 10; }
        bytes memory b = new bytes(d);
        while (v != 0) { d--; b[d] = bytes1(uint8(48 + v % 10)); v /= 10; }
        return string(b);
    }

    // ══════════════════════════════════════════════════════════
    //  РУЧНОЕ УПРАВЛЕНИЕ ЛИКВИДНОСТЬЮ
    // ══════════════════════════════════════════════════════════

    function addLiquidity(uint256 tokenAmount) external payable nonReentrant {
        require(tokenAmount > 0 && msg.value > 0, "Zero");
        require(allowance(msg.sender, address(this)) >= tokenAmount, "Allowance");
        _transfer(msg.sender, address(this), tokenAmount);
        _approve(address(this), address(uniswapV2Router), tokenAmount);
        (uint256 ta, uint256 ea,) = uniswapV2Router.addLiquidityETH{value: msg.value}(
            address(this), tokenAmount, 0, 0, msg.sender, block.timestamp + 300
        );
        emit ParameterUpdated("addLiq", ta, ea);
    }

    function removeLiquidity(uint256 liquidity) external nonReentrant {
        require(liquidity > 0, "Zero");
        IERC20 lp = IERC20(uniswapV2Pair);
        require(lp.allowance(msg.sender, address(this)) >= liquidity, "Allowance");
        lp.transferFrom(msg.sender, address(this), liquidity);
        lp.approve(address(uniswapV2Router), liquidity);
        uniswapV2Router.removeLiquidityETH(
            address(this), liquidity, 0, 0, msg.sender, block.timestamp + 300
        );
    }

    // ══════════════════════════════════════════════════════════
    //  ADMIN SETTERS
    // ══════════════════════════════════════════════════════════

    function setBuyFee(uint256 v)  external onlyOwner { require(v<=200,"Max 20%"); emit ParameterUpdated("buyFee",buyFee,v); buyFee=v; }
    function setSellFee(uint256 v) external onlyOwner { require(v<=200,"Max 20%"); emit ParameterUpdated("sellFee",sellFee,v); sellFee=v; }
    function setMaxSellFee(uint256 v) external onlyOwner { require(v<=500,"Max 50%"); maxSellFee=v; }
    function setProgressiveTaxStep(uint256 v) external onlyOwner { require(v<=200); progressiveTaxStep=v; }
    function setProgressiveTaxThreshold(uint256 v) external onlyOwner { require(v>0); progressiveTaxThreshold=v; }
    function setWhaleSellThreshold(uint256 v) external onlyOwner { require(v>=3); whaleSellThreshold=v; }
    function setWhaleExtraTax(uint256 v) external onlyOwner { require(v<=300); whaleExtraTax=v; }
    function setCascadeTier1(uint256 delta, uint256 rate) external onlyOwner { cascadeTier1Delta=delta; cascadeTier1Rate=rate; }
    function setCascadeTier2(uint256 delta, uint256 rate) external onlyOwner { cascadeTier2Delta=delta; cascadeTier2Rate=rate; }
    function setCascadeTier3(uint256 delta, uint256 rate) external onlyOwner { cascadeTier3Delta=delta; cascadeTier3Rate=rate; }
    function setCascadeTier4(uint256 delta, uint256 rate) external onlyOwner { cascadeTier4Delta=delta; cascadeTier4Rate=rate; }
    function setVelocityWindow(uint256 v) external onlyOwner { require(v>=5); velocityWindow=v; }
    function setVelocityThresholds(uint256 t1, uint256 t2) external onlyOwner { velocityThresh1=t1; velocityThresh2=t2; }
    function setVelocityBurnRates(uint256 r1, uint256 r2) external onlyOwner { require(r1<=100&&r2<=200); velocityBurnRate1=r1; velocityBurnRate2=r2; }
    function setFloorLevels(uint256 l1, uint256 l2, uint256 l3) external onlyOwner { floorLevel1=l1; floorLevel2=l2; floorLevel3=l3; }
    function setCooldownEnabled(bool v) external onlyOwner { cooldownEnabled=v; }
    function setCooldownParams(uint256 base, uint256 max) external onlyOwner { cooldownBaseBlocks=base; cooldownMaxBlocks=max; }
    function setBurnRate(uint256 v) external onlyOwner { require(v<=200); burnRate=v; }
    function setMintRate(uint256 v) external onlyOwner { require(v<=100); mintRate=v; }
    function setPriceChangeThreshold(uint256 v) external onlyOwner { require(v>0); priceChangeThreshold=v; }
    function setPriceUpdateInterval(uint256 v) external onlyOwner { require(v>=3); priceUpdateInterval=v; }
    function setLPBurnEnabled(bool v) external onlyOwner { lpBurnEnabled=v; }
    function setLPBurnInterval(uint256 v) external onlyOwner { require(v>=5); lpBurnInterval=v; }
    function setLPBurnRate(uint256 v) external onlyOwner { require(v<=150,"Max 15%"); lpBurnRate=v; }
    function setMinLPForBurn(uint256 v) external onlyOwner { minLPForBurn=v; }
    function setLPEthReinjection(uint256 v) external onlyOwner { require(v<=1000); lpEthReinjection=v; }
    function setBuybackEnabled(bool v) external onlyOwner { buybackEnabled=v; }
    function setBuybackThreshold(uint256 v) external onlyOwner { buybackThreshold=v; }
    function setBuybackShare(uint256 v) external onlyOwner { require(v<=500); buybackShare=v; }
    function setMinTokensBeforeSwap(uint256 v) external onlyOwner { minTokensBeforeSwap=v; }
    function setSwapAndLiquifyEnabled(bool v) external onlyOwner { swapAndLiquifyEnabled=v; }
    function setStakingAPY(uint256 v) external onlyOwner { require(v<=1000); stakingAPY=v; }
    function setUnstakeBurnRate(uint256 v) external onlyOwner { require(v<=200); unstakeBurnRate=v; }
    function setMinStakeDuration(uint256 v) external onlyOwner { minStakeDuration=v; }
    function setAdaptiveEnabled(bool v) external onlyOwner { adaptiveEnabled=v; }
    function setOptimizationInterval(uint256 v) external onlyOwner { require(v>=10); optimizationInterval=v; }
    function setPoolDeepeningEnabled(bool v) external onlyOwner { poolDeepeningEnabled=v; }
    function setDeepenMintRate(uint256 v) external onlyOwner { require(v<=50); deepenMintRate=v; }
    function setDeepenPriceThreshold(uint256 v) external onlyOwner { require(v>0); deepenPriceThreshold=v; }
    function excludeFromFee(address a, bool v) external onlyOwner { isExcludedFromFee[a]=v; }
    function setAMM(address pair, bool v) external onlyOwner { automatedMarketMakerPairs[pair]=v; }

    // ══════════════════════════════════════════════════════════
    //  PUBLIC
    // ══════════════════════════════════════════════════════════

    function mint(address to, uint256 amount) external onlyOwner {
        require(totalSupply()+amount<=MAX_SUPPLY,"Max");
        _mint(to,amount);
    }
    function burn(uint256 amount) external {
        _burn(msg.sender,amount);
    }
    function pause()   external onlyOwner { _pause(); }
    function unpause() external onlyOwner { _unpause(); }
    function rescueTokens(address t, uint256 a) external onlyOwner {
        require(t!=address(this),"No ALTN"); IERC20(t).transfer(owner(),a);
    }

    receive() external payable {}
}
