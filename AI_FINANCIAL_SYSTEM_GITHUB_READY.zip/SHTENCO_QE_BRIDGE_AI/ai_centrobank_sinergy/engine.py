from __future__ import annotations

import hashlib
import json
import math
from dataclasses import asdict
from typing import Iterable

from .models import Action, Candidate, EconomyState, PoolState, SearchConfig


ANCHOR_TOKENS = ("WPOL", "USDT", "USDC", "USDS", "SUSD")
ECOSYSTEM_TOKENS = ("SYNA", "SYNC", "SYNR")


class EconomicEngine:
    """Risk-aware model-predictive controller for the SINERGY ecosystem.

    It does not create value synthetically. Candidate actions use existing
    treasury inventory, pool liquidity, bridge inventory and fee revenue. The
    score rewards durable liquidity and reserve health while penalising peg
    drift, bridge imbalance, concentration and drawdown.
    """

    def __init__(self, initial_wpol: float = 50.0, initial_token_liquidity: float = 100.0):
        self.state = self._default_state(initial_wpol, initial_token_liquidity)
        self.reference_prices = self.token_prices(self.state)
        self._initial_state = self.state.copy()
        self._baseline = self.metrics(self.state)

    @staticmethod
    def _default_state(initial_wpol: float, initial_token_liquidity: float) -> EconomyState:
        w = max(float(initial_wpol), 1e-6)
        q = max(float(initial_token_liquidity), 1e-6)
        pools = {
            "SYNA/WPOL": PoolState("SYNA/WPOL", "SYNA", "WPOL", q, w),
            "SYNC/WPOL": PoolState("SYNC/WPOL", "SYNC", "WPOL", q, w * 0.8),
            "SYNR/WPOL": PoolState("SYNR/WPOL", "SYNR", "WPOL", q, q),
            "SYNA/SYNC": PoolState("SYNA/SYNC", "SYNA", "SYNC", q * 0.8, q * 0.8),
        }
        treasury = {
            "WPOL": w * 0.5,
            "USDT": w * 0.25,
            "SYNA": q * 0.1,
            "SYNC": q * 0.1,
            "SYNR": q * 0.1,
        }
        supply = {"SYNA": q * 1000, "SYNC": q * 750, "SYNR": q * 500}
        bridge_inventory = {
            "polygon": {"SYNA": q * 0.1, "SYNC": q * 0.1, "SYNR": q * 0.1},
            "secondary": {"SYNA": q * 0.05, "SYNC": q * 0.05, "SYNR": q * 0.05},
        }
        liabilities = {"USDT": max(treasury["USDT"] * 0.7, 1e-9)}
        return EconomyState(pools, treasury, supply, bridge_inventory, liabilities)

    @classmethod
    def from_mainnet(cls, raw: dict) -> "EconomicEngine":
        engine = cls(50.0, 100.0)
        pools: dict[str, PoolState] = {}
        for item in raw.get("pools", []):
            try:
                name = str(item.get("name") or f"{item['a']}/{item['b']}")
                pools[name] = PoolState(
                    name=name,
                    a=str(item["a"]).upper(),
                    b=str(item["b"]).upper(),
                    ra=max(float(item.get("ra", 0.0)), 0.0),
                    rb=max(float(item.get("rb", 0.0)), 0.0),
                    fee_bps=float(item.get("fee_bps", 30.0)),
                    owner_share=min(1.0, max(float(item.get("owner_share", 1.0)), 0.0)),
                )
            except (KeyError, TypeError, ValueError):
                continue
        if pools:
            engine.state.pools = pools

        wallet = raw.get("wallet", {})
        treasury = dict(engine.state.treasury)
        for token in set(wallet) | set(ECOSYSTEM_TOKENS) | {"WPOL", "USDT", "USDC", "USDS"}:
            if token in wallet:
                try:
                    treasury[token.upper()] = max(float(wallet[token]), 0.0)
                except (TypeError, ValueError):
                    pass
        engine.state.treasury = treasury

        supplies = raw.get("supplies", {})
        for token in ECOSYSTEM_TOKENS:
            if token in supplies:
                try:
                    engine.state.supply[token] = max(float(supplies[token]), 0.0)
                except (TypeError, ValueError):
                    pass

        bridge = raw.get("bridge_inventory") or raw.get("bridges")
        if isinstance(bridge, dict):
            parsed: dict[str, dict[str, float]] = {}
            for chain, values in bridge.items():
                if not isinstance(values, dict):
                    continue
                parsed[str(chain)] = {
                    str(token).upper(): max(float(amount), 0.0)
                    for token, amount in values.items()
                    if isinstance(amount, (int, float, str))
                }
            if parsed:
                engine.state.bridge_inventory = parsed

        liabilities = raw.get("liabilities", {})
        if isinstance(liabilities, dict):
            for token, amount in liabilities.items():
                try:
                    engine.state.liabilities[str(token).upper()] = max(float(amount), 0.0)
                except (TypeError, ValueError):
                    pass

        engine.state.cycle = int(raw.get("cycles_executed", 0) or 0)
        oracle_prices = raw.get("oracle_prices", {})
        if isinstance(oracle_prices, dict) and oracle_prices:
            parsed_prices = {"WPOL": 1.0, "USDT": 1.0, "USDC": 1.0, "USDS": 1.0, "SUSD": 1.0}
            for token, price in oracle_prices.items():
                try:
                    value = float(price)
                    if value > 0 and math.isfinite(value):
                        parsed_prices[str(token).upper()] = value
                except (TypeError, ValueError):
                    pass
            engine.reference_prices = parsed_prices
        else:
            engine.reference_prices = engine.token_prices(engine.state)
        for token in set(engine.state.supply) | set(engine.state.treasury):
            engine.reference_prices.setdefault(token, 0.0)
        engine._initial_state = engine.state.copy()
        engine._baseline = engine.metrics(engine.state)
        return engine

    def reset(self) -> None:
        self.state = self._initial_state.copy()
        self._baseline = self.metrics(self.state)

    def token_prices(self, state: EconomyState) -> dict[str, float]:
        prices: dict[str, float] = {"WPOL": 1.0, "USDT": 1.0, "USDC": 1.0, "USDS": 1.0, "SUSD": 1.0}
        for _ in range(12):
            changed = False
            for pool in state.pools.values():
                if pool.ra <= 0 or pool.rb <= 0:
                    continue
                if pool.b in prices and pool.a not in prices:
                    prices[pool.a] = prices[pool.b] * pool.rb / pool.ra
                    changed = True
                elif pool.a in prices and pool.b not in prices:
                    prices[pool.b] = prices[pool.a] * pool.ra / pool.rb
                    changed = True
                elif pool.a in prices and pool.b in prices:
                    implied_a = prices[pool.b] * pool.rb / pool.ra
                    prices[pool.a] = 0.75 * prices[pool.a] + 0.25 * implied_a
            if not changed:
                break
        for token in set(state.supply) | set(state.treasury):
            prices.setdefault(token, 0.0)
        return prices

    def pool_nav(self, pool: PoolState, prices: dict[str, float], owned_only: bool = True) -> float:
        full_nav = pool.ra * prices.get(pool.a, 0.0) + pool.rb * prices.get(pool.b, 0.0)
        return full_nav * pool.owner_share if owned_only else full_nav

    def metrics(self, state: EconomyState) -> dict[str, float]:
        mark_prices = self.token_prices(state)
        prices = self.reference_prices
        lp_nav = sum(self.pool_nav(pool, prices, owned_only=True) for pool in state.pools.values())
        treasury_nav = sum(max(amount, 0.0) * prices.get(token, 0.0) for token, amount in state.treasury.items())
        bridge_nav = sum(
            max(amount, 0.0) * prices.get(token, 0.0)
            for values in state.bridge_inventory.values()
            for token, amount in values.items()
        )
        mcap = sum(max(state.supply.get(token, 0.0), 0.0) * prices.get(token, 0.0) for token in ECOSYSTEM_TOKENS)
        mark_mcap = sum(max(state.supply.get(token, 0.0), 0.0) * mark_prices.get(token, 0.0) for token in ECOSYSTEM_TOKENS)
        liquid_mcap = mcap * 0.65

        synr_price = mark_prices.get("SYNR", 0.0)
        peg_error = abs(synr_price - 1.0) if synr_price > 0 else 1.0

        bridge_totals: dict[str, float] = {}
        for chain_values in state.bridge_inventory.values():
            for token, amount in chain_values.items():
                bridge_totals[token] = bridge_totals.get(token, 0.0) + max(amount, 0.0)
        bridge_imbalance = 0.0
        samples = 0
        if len(state.bridge_inventory) >= 2:
            chains = list(state.bridge_inventory)
            for token, total in bridge_totals.items():
                if total <= 0:
                    continue
                target = total / len(chains)
                bridge_imbalance += sum(abs(state.bridge_inventory[c].get(token, 0.0) - target) for c in chains) / (2 * total)
                samples += 1
        bridge_imbalance = bridge_imbalance / samples if samples else 0.0

        stable_assets = sum(state.treasury.get(token, 0.0) * prices.get(token, 1.0) for token in ("USDT", "USDC", "USDS", "SUSD"))
        liabilities = sum(max(v, 0.0) for v in state.liabilities.values())
        reserve_ratio = stable_assets / liabilities if liabilities > 0 else 10.0

        pool_navs = [self.pool_nav(pool, prices, owned_only=True) for pool in state.pools.values()]
        total_pool_nav = sum(pool_navs)
        concentration = max(pool_navs) / total_pool_nav if total_pool_nav > 0 and pool_navs else 1.0

        ecosystem_nav = lp_nav + treasury_nav + bridge_nav
        valuation_gap = abs(mark_mcap - mcap) / max(mcap, 1e-9)
        liquidation_nav = treasury_nav + bridge_nav + lp_nav * 0.65
        return {
            "lp_nav": lp_nav,
            "tvl": lp_nav + stable_assets,
            "mcap": mcap,
            "liquid_mcap": liquid_mcap,
            "treasury_nav": treasury_nav,
            "bridge_nav": bridge_nav,
            "ecosystem_nav": ecosystem_nav,
            "liquidation_nav": liquidation_nav,
            "mark_mcap": mark_mcap,
            "valuation_gap": valuation_gap,
            "peg_error": peg_error,
            "bridge_imbalance": bridge_imbalance,
            "reserve_ratio": reserve_ratio,
            "concentration": concentration,
            "burned_total": sum(state.burned.values()),
            "cumulative_fees": state.cumulative_fees,
            "cumulative_gas": state.cumulative_gas,
            "cycles_executed": float(state.cycle),
        }

    def _score(self, metrics: dict[str, float], baseline: dict[str, float], cfg: SearchConfig) -> tuple[float, float]:
        def growth(key: str) -> float:
            start = max(baseline.get(key, 0.0), 1e-9)
            return math.log(max(metrics.get(key, 0.0), 1e-9) / start)

        reserve_shortfall = max(cfg.min_reserve_ratio - metrics["reserve_ratio"], 0.0)
        peg_excess = max(metrics["peg_error"] - cfg.max_peg_error, 0.0)
        bridge_excess = max(metrics["bridge_imbalance"] - cfg.max_bridge_imbalance, 0.0)
        valuation_excess = max(metrics["valuation_gap"] - cfg.max_valuation_gap, 0.0)
        drawdown = max(-growth("ecosystem_nav"), 0.0)
        risk = (
            reserve_shortfall * cfg.reserve_penalty
            + peg_excess * cfg.peg_penalty
            + bridge_excess * cfg.bridge_penalty
            + valuation_excess * cfg.valuation_gap_penalty
            + metrics["concentration"] * cfg.inventory_penalty
            + drawdown * cfg.drawdown_penalty
        )
        score = (
            cfg.growth_weight * growth("ecosystem_nav")
            + cfg.liquidity_weight * growth("lp_nav")
            + cfg.treasury_weight * growth("treasury_nav")
            + cfg.burn_weight * math.log1p(metrics["burned_total"])
            - risk
            - metrics["cumulative_gas"]
        )
        return score, risk

    def _pool_price(self, pool: PoolState, base: str, quote: str) -> float | None:
        if pool.ra <= 0 or pool.rb <= 0:
            return None
        if pool.a == base and pool.b == quote:
            return pool.rb / pool.ra
        if pool.b == base and pool.a == quote:
            return pool.ra / pool.rb
        return None

    def generate_actions(self, state: EconomyState, cfg: SearchConfig) -> list[Action]:
        actions: list[Action] = [Action("HOLD", "HOLD — сохранить резерв и дождаться лучшего сигнала")]
        prices = self.token_prices(state)

        for pool in state.pools.values():
            if pool.ra <= 0 or pool.rb <= 0:
                continue
            for token_in, reserve in ((pool.a, pool.ra), (pool.b, pool.rb)):
                available = state.treasury.get(token_in, 0.0)
                if available <= 0:
                    continue
                amount = min(available * cfg.max_trade_fraction, reserve * 0.02)
                if amount > 1e-9:
                    token_out = pool.b if token_in == pool.a else pool.a
                    actions.append(Action(
                        "SWAP",
                        f"MARKET REBALANCE {amount:.6f} {token_in} → {token_out} через {pool.name}",
                        {"pool": pool.name, "token_in": token_in, "amount": amount},
                    ))

            avail_a = state.treasury.get(pool.a, 0.0)
            avail_b = state.treasury.get(pool.b, 0.0)
            if avail_a > 0 and avail_b > 0:
                frac = cfg.max_liquidity_fraction
                add_a = min(avail_a * frac, pool.ra * 0.03)
                add_b_by_ratio = add_a * pool.rb / pool.ra
                add_b = min(avail_b * frac, add_b_by_ratio)
                add_a = min(add_a, add_b * pool.ra / pool.rb)
                if add_a > 1e-9 and add_b > 1e-9:
                    actions.append(Action(
                        "ADD_LIQUIDITY",
                        f"ADD LIQUIDITY {pool.name}: {add_a:.6f} {pool.a} + {add_b:.6f} {pool.b}",
                        {"pool": pool.name, "amount_a": add_a, "amount_b": add_b},
                    ))

        if state.bridge_inventory and len(state.bridge_inventory) >= 2:
            chains = list(state.bridge_inventory)
            tokens = sorted({t for values in state.bridge_inventory.values() for t in values})
            for token in tokens:
                balances = {chain: state.bridge_inventory[chain].get(token, 0.0) for chain in chains}
                source = max(balances, key=balances.get)
                destination = min(balances, key=balances.get)
                gap = balances[source] - balances[destination]
                if gap > 1e-9:
                    amount = gap * 0.25
                    actions.append(Action(
                        "BRIDGE_REBALANCE",
                        f"BRIDGE QE {amount:.6f} {token}: {source} → {destination}",
                        {"token": token, "source": source, "destination": destination, "amount": amount},
                    ))

        syna_pool = next((p for p in state.pools.values() if {p.a, p.b} == {"SYNA", "WPOL"}), None)
        if syna_pool and state.treasury.get("WPOL", 0.0) > 0 and prices.get("SYNA", 0.0) > 0:
            amount = min(state.treasury["WPOL"] * cfg.max_trade_fraction * 0.5, (syna_pool.rb if syna_pool.b == "WPOL" else syna_pool.ra) * 0.01)
            if amount > 1e-9:
                actions.append(Action(
                    "BUYBACK_BURN",
                    f"BUYBACK & BURN: {amount:.6f} WPOL → SYNA",
                    {"pool": syna_pool.name, "amount_wpol": amount},
                ))

        return actions

    def apply_action(self, state: EconomyState, action: Action, cfg: SearchConfig) -> EconomyState:
        next_state = state.copy()
        next_state.cycle += 1
        if action.kind == "HOLD":
            return next_state

        next_state.cumulative_gas += cfg.gas_wpol

        if action.kind == "SWAP":
            pool = next_state.pools[action.params["pool"]]
            token_in = action.params["token_in"]
            amount_in = min(float(action.params["amount"]), next_state.treasury.get(token_in, 0.0))
            if amount_in <= 0:
                return next_state
            fee_factor = 1.0 - pool.fee_bps / 10_000.0
            effective = amount_in * fee_factor
            if token_in == pool.a:
                amount_out = pool.rb * effective / (pool.ra + effective)
                pool.ra += amount_in
                pool.rb -= amount_out
                token_out = pool.b
            elif token_in == pool.b:
                amount_out = pool.ra * effective / (pool.rb + effective)
                pool.rb += amount_in
                pool.ra -= amount_out
                token_out = pool.a
            else:
                return next_state
            next_state.treasury[token_in] = max(next_state.treasury.get(token_in, 0.0) - amount_in, 0.0)
            next_state.treasury[token_out] = next_state.treasury.get(token_out, 0.0) + amount_out
            next_state.cumulative_fees += amount_in * (1.0 - fee_factor)

        elif action.kind == "ADD_LIQUIDITY":
            pool = next_state.pools[action.params["pool"]]
            amount_a = min(float(action.params["amount_a"]), next_state.treasury.get(pool.a, 0.0))
            amount_b = min(float(action.params["amount_b"]), next_state.treasury.get(pool.b, 0.0))
            if amount_a > 0 and amount_b > 0:
                mint_fraction = min(amount_a / max(pool.ra, 1e-12), amount_b / max(pool.rb, 1e-12))
                next_state.treasury[pool.a] -= amount_a
                next_state.treasury[pool.b] -= amount_b
                pool.owner_share = min(1.0, (pool.owner_share + mint_fraction) / (1.0 + mint_fraction))
                pool.ra += amount_a
                pool.rb += amount_b

        elif action.kind == "BRIDGE_REBALANCE":
            token = action.params["token"]
            source = action.params["source"]
            destination = action.params["destination"]
            amount = min(float(action.params["amount"]), next_state.bridge_inventory[source].get(token, 0.0))
            fee = amount * cfg.bridge_fee_bps / 10_000.0
            delivered = max(amount - fee, 0.0)
            next_state.bridge_inventory[source][token] = max(next_state.bridge_inventory[source].get(token, 0.0) - amount, 0.0)
            next_state.bridge_inventory[destination][token] = next_state.bridge_inventory[destination].get(token, 0.0) + delivered
            next_state.cumulative_fees += fee

        elif action.kind == "BUYBACK_BURN":
            pool = next_state.pools[action.params["pool"]]
            amount_in = min(float(action.params["amount_wpol"]), next_state.treasury.get("WPOL", 0.0))
            if amount_in <= 0:
                return next_state
            fee_factor = 1.0 - pool.fee_bps / 10_000.0
            effective = amount_in * fee_factor
            if pool.a == "WPOL" and pool.b == "SYNA":
                syna_out = pool.rb * effective / (pool.ra + effective)
                pool.ra += amount_in
                pool.rb -= syna_out
            elif pool.b == "WPOL" and pool.a == "SYNA":
                syna_out = pool.ra * effective / (pool.rb + effective)
                pool.rb += amount_in
                pool.ra -= syna_out
            else:
                return next_state
            next_state.treasury["WPOL"] -= amount_in
            next_state.supply["SYNA"] = max(next_state.supply.get("SYNA", 0.0) - syna_out, 0.0)
            next_state.burned["SYNA"] = next_state.burned.get("SYNA", 0.0) + syna_out
            next_state.cumulative_fees += amount_in * (1.0 - fee_factor)

        return next_state

    def search(self, config: SearchConfig | None = None) -> Candidate:
        cfg = (config or SearchConfig()).normalized()
        baseline = self.metrics(self.state)
        initial_score, initial_risk = self._score(baseline, baseline, cfg)
        beam = [Candidate(self.state.copy(), [], baseline, initial_score, initial_risk)]
        best = beam[0]

        for _depth in range(cfg.max_depth):
            expanded: list[Candidate] = []
            for candidate in beam:
                for action in self.generate_actions(candidate.state, cfg):
                    state2 = self.apply_action(candidate.state, action, cfg)
                    metrics2 = self.metrics(state2)
                    score2, risk2 = self._score(metrics2, baseline, cfg)
                    row = Candidate(state2, candidate.actions + [action], metrics2, score2, risk2)
                    expanded.append(row)
                    if row.score > best.score:
                        best = row
            expanded.sort(key=lambda item: (item.score, -item.risk), reverse=True)
            beam = expanded[: cfg.beam_width]
            if not beam:
                break
        return best

    def run_cycles(self, count: int, config: SearchConfig | None = None) -> tuple[list[dict], float]:
        cfg = (config or SearchConfig()).normalized()
        rows: list[dict] = []
        dividends = 0.0
        for cycle in range(1, max(1, int(count)) + 1):
            candidate = self.search(cfg)
            if candidate.actions:
                chosen = candidate.actions[0]
                self.state = self.apply_action(self.state, chosen, cfg)
            else:
                chosen = Action("HOLD", "HOLD")
                self.state = self.apply_action(self.state, chosen, cfg)
            metrics = self.metrics(self.state)
            rows.append({
                "cycle": cycle,
                "action": asdict(chosen),
                "metrics": metrics,
                "score": candidate.score,
                "risk": candidate.risk,
                "state_hash": self.state_hash(self.state),
            })
            dividends += max(metrics["cumulative_fees"] * 0.05, 0.0)
        return rows, dividends

    @staticmethod
    def state_hash(state: EconomyState) -> str:
        payload = {
            "pools": {name: asdict(pool) for name, pool in sorted(state.pools.items())},
            "treasury": dict(sorted(state.treasury.items())),
            "supply": dict(sorted(state.supply.items())),
            "bridges": {chain: dict(sorted(values.items())) for chain, values in sorted(state.bridge_inventory.items())},
            "liabilities": dict(sorted(state.liabilities.items())),
            "cycle": state.cycle,
        }
        raw = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
        return "0x" + hashlib.sha256(raw).hexdigest()
