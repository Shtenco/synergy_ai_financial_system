#!/usr/bin/env python3
"""
ИНИЦИАЛИЗАЦИЯ VAULT - СОЗДАНИЕ ПУЛОВ
"""
import sys, io, os, json, time
from dotenv import load_dotenv
from web3 import Web3
from web3.middleware import ExtraDataToPOAMiddleware

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

load_dotenv()

w3 = Web3(Web3.HTTPProvider("https://polygon-bor-rpc.publicnode.com", request_kwargs={"timeout": 300}))
w3.middleware_onion.inject(ExtraDataToPOAMiddleware, layer=0)

PK = os.getenv("OWNER_PRIVATE_KEY")
OWNER = "0x6946999DBCE63b140B1bB9D475F7c357130909E5"
WPOL = "0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270"

def C(a): return Web3.to_checksum_address(a)

with open("deployed_TROIKA_v3.json") as f:
    deployed = json.load(f)

print("=" * 70)
print("ИНИЦИАЛИЗАЦИЯ VAULT - СОЗДАНИЕ ПУЛОВ")
print("=" * 70)
print(f"POL: {w3.eth.get_balance(C(OWNER)) / 1e18:.4f}")

WPOL_ABI = [
    {"name": "balanceOf", "inputs": [{"type": "address"}], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "transfer", "inputs": [{"name": "to", "type": "address"}, {"name": "amount", "type": "uint256"}], "outputs": [{"type": "bool"}], "stateMutability": "nonpayable", "type": "function"},
    {"name": "deposit", "inputs": [], "outputs": [], "stateMutability": "payable", "type": "function"},
]

wpol_contract = w3.eth.contract(address=C(WPOL), abi=WPOL_ABI)
wpol_bal = wpol_contract.functions.balanceOf(C(OWNER)).call() / 1e18
print(f"WPOL: {wpol_bal:.4f}")

TOKEN_ABI = [
    {"name": "transfer", "inputs": [{"name": "to", "type": "address"}, {"name": "amount", "type": "uint256"}], "outputs": [{"type": "bool"}], "stateMutability": "nonpayable", "type": "function"},
    {"name": "balanceOf", "inputs": [{"type": "address"}], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
]

# Параметры ликвидности
wpolR = int(3e18)   # 3 POL для SYNA пула
tokR = int(2e18)    # 2 SYNA
wpolT = int(3e18)   # 3 POL для SYNC пула
tokT = int(19e18)   # 19 SYNC
wpolP = int(3e18)   # 3 POL для SYNR пула
tokP = int(4e18)    # 4 SYNR
trRes = int(1e18)   # 1 POL traderReserve
rrRes = int(1e18)   # 1 POL reserveR
mcgRes = int(1e18)  # 1 POL mcgFund

totalWpol = wpolR + wpolT + wpolP + trRes + rrRes + mcgRes
print(f"\nНужно WPOL: {totalWpol / 1e18}")

nonce = w3.eth.get_transaction_count(C(OWNER), "pending")

def send_tx(func, label, gas=500000, value=0):
    global nonce
    print(f"  {label}...", flush=True)

    base = w3.eth.get_block("latest").get("baseFeePerGas", int(100e9))
    prio = int(50e9)
    mf = base * 2 + prio

    tx = func.build_transaction({
        "from": C(OWNER), "nonce": nonce, "chainId": 137, "type": 2,
        "maxPriorityFeePerGas": prio, "maxFeePerGas": mf, "gas": gas, "value": value
    })

    signed = w3.eth.account.sign_transaction(tx, PK)
    h = w3.eth.send_raw_transaction(signed.raw_transaction)
    print(f"    TX: {h.hex()[:20]}...")

    r = w3.eth.wait_for_transaction_receipt(h, timeout=300)
    cost = r.gasUsed * mf / 1e18
    if r.status == 1:
        print(f"    [OK] gas: {cost:.4f}")
        nonce += 1
        return True
    else:
        print(f"    [FAIL]")
        nonce += 1
        return False

# Wrap POL -> WPOL если нужно
if wpol_bal * 1e18 < totalWpol:
    need = totalWpol / 1e18 - wpol_bal + 0.5
    print(f"\nWrap {need:.4f} POL -> WPOL...")
    send_tx(wpol_contract.functions.deposit(), "wrap", gas=100000, value=int(need * 1e18))
    time.sleep(3)
    wpol_bal = wpol_contract.functions.balanceOf(C(OWNER)).call() / 1e18
    print(f"WPOL now: {wpol_bal:.4f}")

# Перевести токены и WPOL в Vault
print("\n[1] Перевод токенов в Vault...")
vault_addr = deployed["vault"]

syna = w3.eth.contract(address=C(deployed["tokens"]["SYNA"]), abi=TOKEN_ABI)
sync = w3.eth.contract(address=C(deployed["tokens"]["SYNC"]), abi=TOKEN_ABI)
synr = w3.eth.contract(address=C(deployed["tokens"]["SYNR"]), abi=TOKEN_ABI)

send_tx(syna.functions.transfer(C(vault_addr), tokR), f"SYNA ({tokR/1e18})")
time.sleep(2)
send_tx(sync.functions.transfer(C(vault_addr), tokT), f"SYNC ({tokT/1e18})")
time.sleep(2)
send_tx(synr.functions.transfer(C(vault_addr), tokP), f"SYNR ({tokP/1e18})")
time.sleep(2)

print("\n[2] Перевод WPOL в Vault...")
send_tx(wpol_contract.functions.transfer(C(vault_addr), totalWpol), f"WPOL ({totalWpol/1e18})")
time.sleep(3)

# Vault.initialize
print("\n[3] Vault.initialize...")
with open("out/03_TroikaVault.sol/TroikaVault.json", encoding="utf-8") as f:
    vault_abi = json.load(f)["abi"]

vault = w3.eth.contract(address=C(vault_addr), abi=vault_abi)

init_func = vault.functions.initialize(
    wpolR, tokR,
    wpolT, tokT,
    wpolP, tokP,
    trRes, rrRes, mcgRes
)

send_tx(init_func, "initialize", gas=5000000)
time.sleep(5)

# Получить адреса пулов
print("\n[4] Проверка пулов...")
pairR = vault.functions.pairR().call()
pairT = vault.functions.pairT().call()
pairP = vault.functions.pairP().call()

print(f"  SYNA/WPOL: {pairR}")
print(f"  SYNC/WPOL: {pairT}")
print(f"  SYNR/WPOL: {pairP}")

deployed["pools"] = {
    "SYNA_WPOL": pairR,
    "SYNC_WPOL": pairT,
    "SYNR_WPOL": pairP
}

# Core.linkOraclePairs
print("\n[5] Core.linkOraclePairs...")
with open("out/10_TroikaCore.sol/TroikaCore.json", encoding="utf-8") as f:
    core_abi = json.load(f)["abi"]

core = w3.eth.contract(address=C(deployed["core"]), abi=core_abi)
send_tx(core.functions.linkOraclePairs(), "linkOraclePairs", gas=500000)

# Сохранить
with open("deployed_TROIKA_v3.json", "w") as f:
    json.dump(deployed, f, indent=2)

print("\n" + "=" * 70)
print("VAULT ИНИЦИАЛИЗИРОВАН! ПУЛЫ СОЗДАНЫ!")
print("=" * 70)
print(f"POL: {w3.eth.get_balance(C(OWNER)) / 1e18:.4f}")
print("\nГОТОВО К РАБОТЕ!")
