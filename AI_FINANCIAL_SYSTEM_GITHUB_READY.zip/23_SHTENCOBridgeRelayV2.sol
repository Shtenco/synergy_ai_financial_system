// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import {ERC20Capped} from "@openzeppelin/contracts/token/ERC20/extensions/ERC20Capped.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {AccessControl} from "@openzeppelin/contracts/access/AccessControl.sol";
import {Pausable} from "@openzeppelin/contracts/utils/Pausable.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {EIP712} from "@openzeppelin/contracts/utils/cryptography/EIP712.sol";
import {ECDSA} from "@openzeppelin/contracts/utils/cryptography/ECDSA.sol";

interface ISHTENCOMintBurnToken is IERC20 {
    function mint(address to, uint256 amount) external;
    function burn(uint256 amount) external;
}

/**
 * @title SHTENCOWrappedSYNA
 * @notice Capped wrapped representation used on non-canonical chains.
 */
contract SHTENCOWrappedSYNA is ERC20, ERC20Capped, AccessControl, Pausable {
    bytes32 public constant BRIDGE_ROLE = keccak256("BRIDGE_ROLE");
    bytes32 public constant PAUSER_ROLE = keccak256("PAUSER_ROLE");

    constructor(address admin, uint256 cap_)
        ERC20("SHTENCO Wrapped SYNA", "wsSYNA")
        ERC20Capped(cap_)
    {
        require(admin != address(0) && cap_ > 0, "WSYNA: bad init");
        _grantRole(DEFAULT_ADMIN_ROLE, admin);
        _grantRole(PAUSER_ROLE, admin);
    }

    function mint(address to, uint256 amount) external onlyRole(BRIDGE_ROLE) {
        _mint(to, amount);
    }

    function burn(uint256 amount) external onlyRole(BRIDGE_ROLE) {
        _burn(msg.sender, amount);
    }

    function pause() external onlyRole(PAUSER_ROLE) { _pause(); }
    function unpause() external onlyRole(PAUSER_ROLE) { _unpause(); }

    function _update(address from, address to, uint256 amount)
        internal
        override(ERC20, ERC20Capped)
        whenNotPaused
    {
        super._update(from, to, amount);
    }
}

/**
 * @title SHTENCOBridgeRelayV2
 * @notice Threshold-signed lock/release and burn/mint bridge endpoint.
 *
 * Security model:
 * - explicit peer bridge and remote-token mappings;
 * - M-of-N sorted unique EIP-712 validator signatures;
 * - validator epoch binding;
 * - replay protection;
 * - per-chain and per-asset pause controls;
 * - per-transaction and rolling UTC-day limits;
 * - canonical escrow liabilities are accounted separately from fees;
 * - virtual chain identifiers are allowed only in explicit fork mode.
 */
contract SHTENCOBridgeRelayV2 is
    AccessControl,
    Pausable,
    ReentrancyGuard,
    EIP712
{
    using SafeERC20 for IERC20;

    enum AssetMode { ESCROW, MINT_BURN }

    struct AssetPolicy {
        bool enabled;
        AssetMode mode;
        uint16 feeBps;
        uint256 minTransfer;
        uint256 maxPerTx;
        uint256 dailyOutboundLimit;
        uint256 dailyInboundLimit;
        address feeRecipient;
    }

    struct DailyFlow {
        uint64 day;
        uint192 amount;
    }

    struct InboundMessage {
        uint256 sourceChainId;
        address sourceBridge;
        uint256 sourceNonce;
        address sourceToken;
        uint256 targetChainId;
        address targetBridge;
        address targetToken;
        address recipient;
        uint256 amount;
        uint256 deadline;
        uint256 validatorEpoch;
    }

    bytes32 public constant PAUSER_ROLE = keccak256("PAUSER_ROLE");
    bytes32 public constant POLICY_ROLE = keccak256("POLICY_ROLE");
    bytes32 public constant VALIDATOR_ADMIN_ROLE = keccak256("VALIDATOR_ADMIN_ROLE");

    bytes32 public constant INBOUND_TYPEHASH = keccak256(
        "InboundMessage(uint256 sourceChainId,address sourceBridge,uint256 sourceNonce,address sourceToken,uint256 targetChainId,address targetBridge,address targetToken,address recipient,uint256 amount,uint256 deadline,uint256 validatorEpoch)"
    );

    uint256 public constant BPS = 10_000;
    uint256 public constant MAX_FEE_BPS = 100; // 1%
    uint256 public constant MAX_FUTURE_DEADLINE = 7 days;

    uint256 public immutable localChainId;
    bool public immutable forkMode;

    uint256 public outgoingNonce;
    uint256 public validatorEpoch = 1;
    uint256 public validatorCount;
    uint256 public threshold;

    mapping(address => bool) public isValidator;
    mapping(address => AssetPolicy) public assetPolicy;
    mapping(address => uint256) public escrowLiability;

    mapping(uint256 => address) public peerBridge;
    mapping(uint256 => bool) public chainEnabled;
    mapping(uint256 => bool) public chainPaused;
    mapping(uint256 => mapping(address => address)) public remoteToken;

    mapping(bytes32 => bool) public processedMessage;
    // Independent replay key prevents the same source nonce from being signed
    // again with a different deadline or other relay-only metadata.
    mapping(bytes32 => bool) public processedSourceTransfer;
    mapping(address => mapping(uint256 => DailyFlow)) private _outboundFlow;
    mapping(address => mapping(uint256 => DailyFlow)) private _inboundFlow;

    uint256 public totalOutbound;
    uint256 public totalInbound;
    uint256 public totalFees;

    event AssetPolicySet(address indexed token, AssetPolicy policy);
    event PeerSet(uint256 indexed remoteChainId, address indexed peer, bool enabled);
    event RemoteTokenSet(uint256 indexed remoteChainId, address indexed localToken, address indexed remoteToken);
    event ChainPauseSet(uint256 indexed remoteChainId, bool paused);
    event ValidatorSet(address indexed validator, bool enabled, uint256 epoch);
    event ThresholdSet(uint256 threshold, uint256 epoch);

    event BridgeOutbound(
        bytes32 indexed messageId,
        uint256 indexed sourceChainId,
        uint256 indexed targetChainId,
        uint256 nonce,
        address sourceBridge,
        address targetBridge,
        address sourceToken,
        address targetToken,
        address sender,
        address recipient,
        uint256 grossAmount,
        uint256 netAmount,
        uint256 fee,
        uint256 validatorEpoch
    );

    event BridgeInbound(
        bytes32 indexed messageId,
        uint256 indexed sourceChainId,
        uint256 indexed sourceNonce,
        address targetToken,
        address recipient,
        uint256 amount
    );

    constructor(
        address admin,
        uint256 localChainId_,
        bool forkMode_,
        address[] memory validators,
        uint256 threshold_
    ) EIP712("SHTENCO SYNA Relay Bridge", "2") {
        require(admin != address(0), "BRIDGE: zero admin");
        require(localChainId_ != 0, "BRIDGE: zero chain");
        require(forkMode_ || localChainId_ == block.chainid, "BRIDGE: chain mismatch");
        require(validators.length > 0, "BRIDGE: no validators");
        require(threshold_ > 0 && threshold_ <= validators.length, "BRIDGE: bad threshold");

        localChainId = localChainId_;
        forkMode = forkMode_;

        _grantRole(DEFAULT_ADMIN_ROLE, admin);
        _grantRole(PAUSER_ROLE, admin);
        _grantRole(POLICY_ROLE, admin);
        _grantRole(VALIDATOR_ADMIN_ROLE, admin);

        for (uint256 i; i < validators.length; ++i) {
            address validator = validators[i];
            require(validator != address(0) && !isValidator[validator], "BRIDGE: bad validator");
            isValidator[validator] = true;
            ++validatorCount;
            emit ValidatorSet(validator, true, validatorEpoch);
        }
        threshold = threshold_;
        emit ThresholdSet(threshold_, validatorEpoch);
    }

    function bridgeOut(
        address token,
        uint256 amount,
        uint256 targetChainId,
        address recipient
    ) external nonReentrant whenNotPaused returns (bytes32 messageId, uint256 nonce) {
        AssetPolicy memory policy = assetPolicy[token];
        require(policy.enabled, "BRIDGE: asset disabled");
        require(chainEnabled[targetChainId] && !chainPaused[targetChainId], "BRIDGE: chain unavailable");
        require(peerBridge[targetChainId] != address(0), "BRIDGE: no peer");
        address targetToken = remoteToken[targetChainId][token];
        require(targetToken != address(0), "BRIDGE: no token route");
        require(recipient != address(0), "BRIDGE: zero recipient");
        require(amount >= policy.minTransfer, "BRIDGE: below minimum");
        require(policy.maxPerTx == 0 || amount <= policy.maxPerTx, "BRIDGE: tx limit");

        _consumeFlow(_outboundFlow[token][targetChainId], amount, policy.dailyOutboundLimit);

        uint256 fee = (amount * policy.feeBps) / BPS;
        uint256 netAmount = amount - fee;
        require(netAmount > 0, "BRIDGE: zero net");

        nonce = ++outgoingNonce;
        totalOutbound += netAmount;
        totalFees += fee;

        _pullExact(token, msg.sender, amount);
        if (policy.mode == AssetMode.ESCROW) {
            escrowLiability[token] += netAmount;
            if (fee != 0) IERC20(token).safeTransfer(policy.feeRecipient, fee);
        } else {
            ISHTENCOMintBurnToken(token).burn(netAmount);
            if (fee != 0) IERC20(token).safeTransfer(policy.feeRecipient, fee);
        }

        messageId = keccak256(abi.encode(
            localChainId,
            targetChainId,
            nonce,
            address(this),
            peerBridge[targetChainId],
            token,
            targetToken,
            msg.sender,
            recipient,
            netAmount,
            validatorEpoch
        ));

        emit BridgeOutbound(
            messageId,
            localChainId,
            targetChainId,
            nonce,
            address(this),
            peerBridge[targetChainId],
            token,
            targetToken,
            msg.sender,
            recipient,
            amount,
            netAmount,
            fee,
            validatorEpoch
        );
    }

    function completeInbound(InboundMessage calldata message, bytes[] calldata signatures)
        external
        nonReentrant
        whenNotPaused
        returns (bytes32 messageId)
    {
        require(message.targetChainId == localChainId, "BRIDGE: wrong target chain");
        require(message.targetBridge == address(this), "BRIDGE: wrong target bridge");
        require(message.sourceBridge == peerBridge[message.sourceChainId], "BRIDGE: wrong peer");
        require(chainEnabled[message.sourceChainId] && !chainPaused[message.sourceChainId], "BRIDGE: chain unavailable");
        require(message.sourceToken == remoteToken[message.sourceChainId][message.targetToken], "BRIDGE: token mismatch");
        require(message.recipient != address(0) && message.amount > 0, "BRIDGE: bad transfer");
        require(message.validatorEpoch == validatorEpoch, "BRIDGE: stale validator epoch");
        require(message.deadline >= block.timestamp, "BRIDGE: expired");
        require(message.deadline <= block.timestamp + MAX_FUTURE_DEADLINE, "BRIDGE: deadline too far");

        AssetPolicy memory policy = assetPolicy[message.targetToken];
        require(policy.enabled, "BRIDGE: asset disabled");
        require(policy.maxPerTx == 0 || message.amount <= policy.maxPerTx, "BRIDGE: tx limit");

        bytes32 sourceTransferId = keccak256(abi.encode(
            message.sourceChainId, message.sourceBridge, message.sourceNonce
        ));
        require(!processedSourceTransfer[sourceTransferId], "BRIDGE: source transfer replay");
        messageId = _messageId(message);
        require(!processedMessage[messageId], "BRIDGE: replay");
        _verifySignatures(_hashTypedDataV4(_structHash(message)), signatures);
        _consumeFlow(_inboundFlow[message.targetToken][message.sourceChainId], message.amount, policy.dailyInboundLimit);

        processedSourceTransfer[sourceTransferId] = true;
        processedMessage[messageId] = true;
        totalInbound += message.amount;

        if (policy.mode == AssetMode.ESCROW) {
            require(escrowLiability[message.targetToken] >= message.amount, "BRIDGE: insufficient escrow");
            escrowLiability[message.targetToken] -= message.amount;
            IERC20(message.targetToken).safeTransfer(message.recipient, message.amount);
        } else {
            ISHTENCOMintBurnToken(message.targetToken).mint(message.recipient, message.amount);
        }

        emit BridgeInbound(
            messageId,
            message.sourceChainId,
            message.sourceNonce,
            message.targetToken,
            message.recipient,
            message.amount
        );
    }

    function _structHash(InboundMessage calldata message) internal pure returns (bytes32) {
        return keccak256(abi.encode(
            INBOUND_TYPEHASH,
            message.sourceChainId,
            message.sourceBridge,
            message.sourceNonce,
            message.sourceToken,
            message.targetChainId,
            message.targetBridge,
            message.targetToken,
            message.recipient,
            message.amount,
            message.deadline,
            message.validatorEpoch
        ));
    }

    function _messageId(InboundMessage calldata message) internal pure returns (bytes32) {
        return keccak256(abi.encode(message));
    }

    function _verifySignatures(bytes32 digest, bytes[] calldata signatures) internal view {
        require(signatures.length >= threshold, "BRIDGE: signatures below threshold");
        address lastSigner = address(0);
        uint256 valid;
        for (uint256 i; i < signatures.length; ++i) {
            address signer = ECDSA.recover(digest, signatures[i]);
            require(signer > lastSigner, "BRIDGE: signatures not sorted/unique");
            require(isValidator[signer], "BRIDGE: invalid validator");
            lastSigner = signer;
            ++valid;
        }
        require(valid >= threshold, "BRIDGE: insufficient valid signatures");
    }

    function _pullExact(address token, address from, uint256 amount) internal {
        uint256 beforeBalance = IERC20(token).balanceOf(address(this));
        IERC20(token).safeTransferFrom(from, address(this), amount);
        uint256 received = IERC20(token).balanceOf(address(this)) - beforeBalance;
        require(received == amount, "BRIDGE: unsupported transfer token");
    }

    function _consumeFlow(DailyFlow storage flow, uint256 amount, uint256 limit) internal {
        uint64 currentDay = uint64(block.timestamp / 1 days);
        if (flow.day != currentDay) {
            flow.day = currentDay;
            flow.amount = 0;
        }
        uint256 next = uint256(flow.amount) + amount;
        require(limit == 0 || next <= limit, "BRIDGE: daily limit");
        require(next <= type(uint192).max, "BRIDGE: flow overflow");
        flow.amount = uint192(next);
    }

    function setAssetPolicy(address token, AssetPolicy calldata policy) external onlyRole(POLICY_ROLE) {
        require(token != address(0), "BRIDGE: zero token");
        require(policy.feeBps <= MAX_FEE_BPS, "BRIDGE: fee too high");
        require(!policy.enabled || policy.feeRecipient != address(0), "BRIDGE: zero fee recipient");
        if (policy.enabled) {
            require(policy.minTransfer > 0 && policy.maxPerTx >= policy.minTransfer, "BRIDGE: bad tx limits");
            require(policy.dailyOutboundLimit >= policy.maxPerTx, "BRIDGE: bad outbound limit");
            require(policy.dailyInboundLimit >= policy.maxPerTx, "BRIDGE: bad inbound limit");
        }
        assetPolicy[token] = policy;
        emit AssetPolicySet(token, policy);
    }

    function setPeer(uint256 remoteChainId, address peer, bool enabled) external onlyRole(POLICY_ROLE) {
        require(remoteChainId != 0 && remoteChainId != localChainId, "BRIDGE: bad remote chain");
        require(!enabled || peer != address(0), "BRIDGE: zero peer");
        peerBridge[remoteChainId] = peer;
        chainEnabled[remoteChainId] = enabled;
        emit PeerSet(remoteChainId, peer, enabled);
    }

    function setRemoteToken(uint256 remoteChainId, address localToken, address tokenOnRemote)
        external onlyRole(POLICY_ROLE)
    {
        require(localToken != address(0) && tokenOnRemote != address(0), "BRIDGE: zero token");
        remoteToken[remoteChainId][localToken] = tokenOnRemote;
        emit RemoteTokenSet(remoteChainId, localToken, tokenOnRemote);
    }

    function setChainPaused(uint256 remoteChainId, bool paused_) external onlyRole(PAUSER_ROLE) {
        chainPaused[remoteChainId] = paused_;
        emit ChainPauseSet(remoteChainId, paused_);
    }

    function addValidator(address validator) external onlyRole(VALIDATOR_ADMIN_ROLE) {
        require(validator != address(0) && !isValidator[validator], "BRIDGE: bad validator");
        isValidator[validator] = true;
        ++validatorCount;
        ++validatorEpoch;
        emit ValidatorSet(validator, true, validatorEpoch);
    }

    function removeValidator(address validator) external onlyRole(VALIDATOR_ADMIN_ROLE) {
        require(isValidator[validator], "BRIDGE: not validator");
        require(validatorCount - 1 >= threshold, "BRIDGE: threshold violation");
        isValidator[validator] = false;
        --validatorCount;
        ++validatorEpoch;
        emit ValidatorSet(validator, false, validatorEpoch);
    }

    function setThreshold(uint256 threshold_) external onlyRole(VALIDATOR_ADMIN_ROLE) {
        require(threshold_ > 0 && threshold_ <= validatorCount, "BRIDGE: bad threshold");
        threshold = threshold_;
        ++validatorEpoch;
        emit ThresholdSet(threshold_, validatorEpoch);
    }

    function flowStatus(address token, uint256 remoteChainId)
        external view returns (uint256 outboundToday, uint256 inboundToday)
    {
        uint64 currentDay = uint64(block.timestamp / 1 days);
        DailyFlow memory outFlow = _outboundFlow[token][remoteChainId];
        DailyFlow memory inFlow = _inboundFlow[token][remoteChainId];
        outboundToday = outFlow.day == currentDay ? outFlow.amount : 0;
        inboundToday = inFlow.day == currentDay ? inFlow.amount : 0;
    }

    function backingHealth(address token)
        external view returns (uint256 balance, uint256 liability, int256 delta)
    {
        balance = IERC20(token).balanceOf(address(this));
        liability = escrowLiability[token];
        delta = int256(balance) - int256(liability);
    }

    function pause() external onlyRole(PAUSER_ROLE) { _pause(); }
    function unpause() external onlyRole(PAUSER_ROLE) { _unpause(); }
}
