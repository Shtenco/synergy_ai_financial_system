#!/usr/bin/env python3
"""
ТЕСТ FLASH LOAN ЦИКЛА НА ФОРКЕ POLYGON
Детальный анализ всех взаимодействий контрактов
"""
import sys, io, os, json, time
from dotenv import load_dotenv
from web3 import Web3
from web3.middleware import ExtraDataToPOAMiddleware
from decimal import Decimal

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

load_dotenv()

# Подключаемся к Polygon mainnet (будем симулировать без отправки)
w3 = Web3(Web3.HTTPProvider("https://polygon-bor-rpc.publicnode.com", request_kwargs={"timeout": 120}))
w3.middleware_onion.inject(ExtraDataToPOAMiddleware, layer=0)

OWNER = "0x6946999DBCE63b140B1bB9D475F7c357130909E5"
ROUTER = "0xa5E0829CaCEd8fFDD4De3c43696c57F7D7A678ff"
FACTORY = "0x5757371414417b8C6CAad45bAeF941aBc7d3Ab32"
WPOL = "0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270"
AAVE_POOL = "0x794a61358D6845594F94dc1DB02A252b5b4814aD"

# Загружаем адреса наших контрактов
with open("deployed_instant.json") as f:
    data = json.load(f)

SYNA = data["tokens"]["SYNA"]
SYNC = data["tokens"]["SYNC"]
SYNR = data["tokens"]["SYNR"]
ALTN = data["tokens"]["ALTN"]

PAIR_SYNA = data["pools"]["SYNA_WPOL"]
PAIR_SYNC = data["pools"]["SYNC_WPOL"]
PAIR_SYNR = data["pools"]["SYNR_WPOL"]
PAIR_ALTN = data["pools"]["ALTN_WPOL"]

def C(a): return Web3.to_checksum_address(a)

print("=" * 70)
print("АНАЛИЗ FLASH LOAN ЦИКЛА - ФОРК ТЕСТ")
print("=" * 70)

# ABI для чтения резервов пула
PAIR_ABI = [
    {"name": "getReserves", "inputs": [], "outputs": [{"type": "uint112"}, {"type": "uint112"}, {"type": "uint32"}], "stateMutability": "view", "type": "function"},
    {"name": "token0", "inputs": [], "outputs": [{"type": "address"}], "stateMutability": "view", "type": "function"},
    {"name": "totalSupply", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
]

ROUTER_ABI = [
    {"name": "getAmountsOut", "inputs": [{"name": "amountIn", "type": "uint256"}, {"name": "path", "type": "address[]"}], "outputs": [{"type": "uint256[]"}], "stateMutability": "view", "type": "function"},
    {"name": "getAmountOut", "inputs": [{"name": "amountIn", "type": "uint256"}, {"name": "reserveIn", "type": "uint256"}, {"name": "reserveOut", "type": "uint256"}], "outputs": [{"type": "uint256"}], "stateMutability": "pure", "type": "function"},
]

router = w3.eth.contract(address=C(ROUTER), abi=ROUTER_ABI)

def get_pool_info(pair_addr, token_addr, name):
    """Получить информацию о пуле"""
    pair = w3.eth.contract(address=C(pair_addr), abi=PAIR_ABI)
    r0, r1, _ = pair.functions.getReserves().call()
    token0 = pair.functions.token0().call()
    total_lp = pair.functions.totalSupply().call()

    if token0.lower() == C(WPOL).lower():
        wpol_reserve = r0
        token_reserve = r1
    else:
        wpol_reserve = r1
        token_reserve = r0

    price = wpol_reserve / token_reserve if token_reserve > 0 else 0

    print(f"\n{name} пул ({pair_addr[:10]}...):")
    print(f"  WPOL резерв: {wpol_reserve / 1e18:.6f} POL")
    print(f"  {name} резерв: {token_reserve / 1e18:.2f}")
    print(f"  Цена: {price:.8f} POL/{name}")
    print(f"  LP Supply: {total_lp / 1e18:.6f}")

    return {
        "wpol": wpol_reserve,
        "token": token_reserve,
        "price": price,
        "lp_supply": total_lp,
        "pair": pair_addr,
        "token_addr": token_addr
    }

print("\n" + "=" * 70)
print("ТЕКУЩЕЕ СОСТОЯНИЕ ПУЛОВ")
print("=" * 70)

pools = {
    "SYNA": get_pool_info(PAIR_SYNA, SYNA, "SYNA"),
    "SYNC": get_pool_info(PAIR_SYNC, SYNC, "SYNC"),
    "SYNR": get_pool_info(PAIR_SYNR, SYNR, "SYNR"),
    "ALTN": get_pool_info(PAIR_ALTN, ALTN, "ALTN"),
}

total_wpol = sum(p["wpol"] for p in pools.values())
print(f"\nОбщий WPOL в пулах: {total_wpol / 1e18:.4f} POL")

print("\n" + "=" * 70)
print("МАТЕМАТИКА FLASH LOAN ЦИКЛА")
print("=" * 70)

def simulate_swap(amount_in, reserve_in, reserve_out):
    """Симуляция свапа по формуле AMM"""
    # QuickSwap fee = 0.3%
    amount_in_with_fee = amount_in * 997
    numerator = amount_in_with_fee * reserve_out
    denominator = reserve_in * 1000 + amount_in_with_fee
    return numerator // denominator

def simulate_add_liquidity(wpol_amount, pool):
    """Симуляция добавления ликвидности"""
    wpol_reserve = pool["wpol"]
    token_reserve = pool["token"]
    lp_supply = pool["lp_supply"]

    # Сколько токенов нужно для пропорционального добавления
    token_needed = wpol_amount * token_reserve // wpol_reserve

    # Сколько LP получим
    lp_minted = wpol_amount * lp_supply // wpol_reserve

    return {
        "wpol_added": wpol_amount,
        "token_needed": token_needed,
        "lp_minted": lp_minted,
        "new_wpol_reserve": wpol_reserve + wpol_amount,
        "new_token_reserve": token_reserve + token_needed,
        "new_lp_supply": lp_supply + lp_minted,
        "our_share": lp_minted / (lp_supply + lp_minted)
    }

def simulate_remove_liquidity(lp_amount, pool, new_wpol, new_token, new_lp):
    """Симуляция удаления ликвидности"""
    wpol_out = lp_amount * new_wpol // new_lp
    token_out = lp_amount * new_token // new_lp
    return wpol_out, token_out

print("\n### СЦЕНАРИЙ 1: Простой цикл через один пул (SYNR)")
print("-" * 50)

# Параметры
FLASH_LOAN = int(10e18)  # 10 POL (маленький для теста)
AAVE_FEE_BPS = 5  # 0.05%

pool = pools["SYNR"]
wpol_reserve = pool["wpol"]
token_reserve = pool["token"]

print(f"Flash Loan: {FLASH_LOAN / 1e18:.4f} POL")
print(f"Aave fee (0.05%): {FLASH_LOAN * AAVE_FEE_BPS / 10000 / 1e18:.6f} POL")

# Шаг 1: Купить токены за 50% POL
buy_amount = FLASH_LOAN // 2
tokens_bought = simulate_swap(buy_amount, wpol_reserve, token_reserve)
new_wpol_1 = wpol_reserve + buy_amount
new_token_1 = token_reserve - tokens_bought

print(f"\n1. Купить SYNR за {buy_amount / 1e18:.4f} POL:")
print(f"   Получим: {tokens_bought / 1e18:.4f} SYNR")
print(f"   Резервы после: {new_wpol_1/1e18:.4f} WPOL / {new_token_1/1e18:.4f} SYNR")

# Шаг 2: Добавить LP
lp_wpol = FLASH_LOAN - buy_amount
# Сколько токенов нужно для LP
token_for_lp = lp_wpol * new_token_1 // new_wpol_1

if token_for_lp > tokens_bought:
    print(f"\n   [!] Недостаточно токенов для LP!")
    print(f"   Нужно: {token_for_lp/1e18:.4f}, есть: {tokens_bought/1e18:.4f}")
    token_for_lp = tokens_bought
    lp_wpol = token_for_lp * new_wpol_1 // new_token_1

lp_supply = pool["lp_supply"]
lp_minted = lp_wpol * lp_supply // new_wpol_1

new_wpol_2 = new_wpol_1 + lp_wpol
new_token_2 = new_token_1 + token_for_lp
new_lp = lp_supply + lp_minted

our_share = lp_minted / new_lp

print(f"\n2. Добавить LP: {lp_wpol/1e18:.4f} WPOL + {token_for_lp/1e18:.4f} SYNR")
print(f"   LP получим: {lp_minted/1e18:.6f}")
print(f"   Наша доля пула: {our_share*100:.2f}%")

# Шаг 3: Торговля (генерация комиссий)
remaining_pol = FLASH_LOAN - buy_amount - lp_wpol
remaining_tokens = tokens_bought - token_for_lp

print(f"\n3. Осталось для торговли:")
print(f"   POL: {remaining_pol/1e18:.4f}")
print(f"   SYNR: {remaining_tokens/1e18:.4f}")

# Делаем несколько свапов туда-обратно
trade_rounds = 5
trade_amount = remaining_pol // trade_rounds if remaining_pol > 0 else 0
total_fees_generated = 0

current_wpol = new_wpol_2
current_token = new_token_2

for i in range(trade_rounds):
    if trade_amount > 0:
        # POL -> TOKEN
        fee = trade_amount * 3 // 1000  # 0.3%
        tokens_out = simulate_swap(trade_amount, current_wpol, current_token)
        current_wpol += trade_amount
        current_token -= tokens_out
        total_fees_generated += fee

        # TOKEN -> POL
        fee2 = tokens_out * 3 // 1000
        pol_back = simulate_swap(tokens_out, current_token, current_wpol)
        current_token += tokens_out
        current_wpol -= pol_back
        total_fees_generated += fee2

print(f"\n   Всего комиссий сгенерировано: {total_fees_generated/1e18:.6f} POL")
print(f"   Наша доля комиссий ({our_share*100:.1f}%): {total_fees_generated * our_share / 1e18:.6f} POL")

# Шаг 4: Удалить LP
wpol_out, token_out = simulate_remove_liquidity(lp_minted, pool, current_wpol, current_token, new_lp)

print(f"\n4. Удалить LP:")
print(f"   Получим: {wpol_out/1e18:.6f} WPOL + {token_out/1e18:.6f} SYNR")

# Шаг 5: Продать все токены
final_tokens = token_out + remaining_tokens
final_current_wpol = current_wpol - wpol_out
final_current_token = current_token - token_out

pol_from_sell = simulate_swap(final_tokens, final_current_token + final_tokens, final_current_wpol)

print(f"\n5. Продать {final_tokens/1e18:.6f} SYNR:")
print(f"   Получим: {pol_from_sell/1e18:.6f} POL")

# Итог
total_pol_back = wpol_out + pol_from_sell + remaining_pol
aave_fee = FLASH_LOAN * AAVE_FEE_BPS // 10000
need_to_repay = FLASH_LOAN + aave_fee

print(f"\n" + "=" * 50)
print(f"ИТОГ ЦИКЛА:")
print(f"  Вернули POL: {total_pol_back/1e18:.6f}")
print(f"  Нужно вернуть: {need_to_repay/1e18:.6f}")
print(f"  ПРОФИТ/УБЫТОК: {(total_pol_back - need_to_repay)/1e18:.6f} POL")
print("=" * 50)

if total_pol_back >= need_to_repay:
    print(">>> ПРИБЫЛЬНО! <<<")
else:
    print(">>> УБЫТОЧНО <<<")

print("\n" + "=" * 70)
print("АНАЛИЗ: ПОЧЕМУ ПРОСТОЙ ЦИКЛ НЕ РАБОТАЕТ")
print("=" * 70)
print("""
ПРОБЛЕМА: В одном пуле нельзя заработать на Flash Loan без арбитража!

МАТЕМАТИКА:
1. Комиссия swap = 0.3% (идёт LP провайдерам)
2. Мы КАК LP получаем часть комиссий
3. НО мы также ПЛАТИМ эти комиссии при свапах!

Если наша доля пула = X%, то:
- Платим: 0.3% от объёма торговли
- Получаем: X% от 0.3% = 0.3% * X

Даже если X = 100% (мы единственный LP), мы получаем ровно столько,
сколько платим. А из-за slippage и round-trip теряем ещё больше.

ВЫВОД: Нужен АРБИТРАЖ между разными пулами!
""")

print("\n" + "=" * 70)
print("СЦЕНАРИЙ 2: АРБИТРАЖ МЕЖДУ ПУЛАМИ")
print("=" * 70)

# Проверяем цены между нашими пулами и ищем арбитраж
print("\nТекущие цены в POL:")
for name, pool in pools.items():
    print(f"  {name}: {pool['price']:.8f} POL")

# Сравним с теоретическими ценами
# SYNA: 600 токенов за 3 POL = 0.005 POL/token
# SYNC: 6000 токенов за 3 POL = 0.0005 POL/token
# SYNR: 300 токенов за 3 POL = 0.01 POL/token
# ALTN: 1500 токенов за 3 POL = 0.002 POL/token

print("\nАрбитраж между нашими пулами невозможен - все пулы новые,")
print("цены установлены нами, нет расхождений.")

print("\n" + "=" * 70)
print("СЦЕНАРИЙ 3: ЕДИНСТВЕННЫЙ 100% ПРИБЫЛЬНЫЙ МЕТОД")
print("=" * 70)
print("""
РЕШЕНИЕ: Flash Loan для увеличения LP позиции + ВНЕШНИЙ ДОХОД

Механизм TROIKA системы:
1. EmissionEngine выпускает новые токены каждые 1000 блоков
2. FeeRouter распределяет комиссии: 30% основателю, 70% холдерам
3. CBArbitrage делает арбитраж между SYNC/SYNR при gap > 1%

ПРИБЫЛЬНЫЙ ЦИКЛ:
1. Flash Loan 100 POL
2. Add LP во ВСЕ 4 пула → становимся мажоритарным LP
3. Запустить TroikaCore.tick() → эмиссия + дивиденды + арбитраж
4. Получить эмиссию токенов + дивиденды в WPOL
5. Remove LP + собрать всё
6. Repay Flash Loan
7. PROFIT = эмиссия + дивиденды

НО! Для этого нужно задеплоить ВСЮ систему TROIKA (Vault, Core, и т.д.)
""")

print("\n" + "=" * 70)
print("РЕАЛИСТИЧНЫЙ ПРИБЫЛЬНЫЙ ПОДХОД: MANUAL ARBITRAGE")
print("=" * 70)

# Проверяем существующие пулы SYNR на QuickSwap
# Старый SYNR: 0xD7a4D77958D654c630A0B4AB9BeEC9E091fE911F
OLD_SYNR = "0xD7a4D77958D654c630A0B4AB9BeEC9E091fE911F"
OLD_SYNR_PAIR = "0x7d56A9C8C590De09CA82b66ca780e8eBCD259Fce"

print(f"\nПроверяем старый SYNR пул...")
try:
    old_pair = w3.eth.contract(address=C(OLD_SYNR_PAIR), abi=PAIR_ABI)
    r0, r1, _ = old_pair.functions.getReserves().call()
    token0 = old_pair.functions.token0().call()

    if token0.lower() == C(WPOL).lower():
        old_wpol = r0
        old_token = r1
    else:
        old_wpol = r1
        old_token = r0

    old_price = old_wpol / old_token if old_token > 0 else 0

    print(f"Старый SYNR пул:")
    print(f"  WPOL: {old_wpol / 1e18:.4f}")
    print(f"  SYNR: {old_token / 1e18:.4f}")
    print(f"  Цена: {old_price:.8f} POL/SYNR")

    new_price = pools["SYNR"]["price"]
    print(f"\nНовый SYNR пул:")
    print(f"  Цена: {new_price:.8f} POL/SYNR")

    if old_price > 0 and new_price > 0:
        price_diff = abs(old_price - new_price) / min(old_price, new_price) * 100
        print(f"\nРазница цен: {price_diff:.2f}%")

        if price_diff > 1:
            print(">>> АРБИТРАЖ ВОЗМОЖЕН! <<<")
            if old_price > new_price:
                print(f"Купить в НОВОМ пуле, продать в СТАРОМ")
            else:
                print(f"Купить в СТАРОМ пуле, продать в НОВОМ")
except Exception as e:
    print(f"Ошибка проверки старого пула: {e}")

print("\n" + "=" * 70)
print("ВЫВОДЫ")
print("=" * 70)
print("""
100% ПРИБЫЛЬНЫЙ FLASH LOAN требует ОДНОГО из условий:

1. АРБИТРАЖ: Разница цен между площадками > costs (0.3% swap + 0.05% loan)
   - Нужны разные DEX или разные пулы с одним токеном

2. ЛИКВИДАЦИЯ: Купить залог дешевле долга
   - Нужны позиции под ликвидацию

3. СИСТЕМА С ЭМИССИЕЙ: TROIKA полностью развёрнутая
   - EmissionEngine создаёт новые токены
   - Дивиденды распределяются LP провайдерам
   - Self-Reinforcing Loop усиливает эффект

Для варианта 3 нужно задеплоить ВСЮ систему TROIKA:
- TroikaVault
- DividendPool
- FeeRouter
- EmissionEngine
- CBArbitrage
- TroikaCore
- FounderControl

И тогда каждый tick() будет генерировать доход.
""")
