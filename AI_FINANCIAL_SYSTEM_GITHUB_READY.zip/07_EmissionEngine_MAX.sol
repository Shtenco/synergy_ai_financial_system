// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/**
 * EMISSION ENGINE v3 - С МАКСИМАЛЬНЫМ emitRate ДЛЯ ПРИБЫЛЬНОСТИ
 *
 * ИЗМЕНЕНИЯ:
 * - emitRate начинается с EMIT_RATE_MAX (50e-6) вместо MIN (2e-6)
 * - Это даёт founder 0.70 WPOL за эмиссию вместо 0.028 WPOL
 * - NET PROFIT = 0.55 WPOL per emission!
 */

import {AccessControl}   from "@openzeppelin/contracts/access/AccessControl.sol";
import {Pausable}        from "@openzeppelin/contracts/utils/Pausable.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {Math}            from "@openzeppelin/contracts/utils/math/Math.sol";
import "./01_PolygonConfig.sol";

interface IVaultEE {
    function batchAddLP(uint256 dR, uint256 dT, uint256 dP) external;
    function addToReserveR(uint256 a)    external;
    function addToLpP(uint256 a)         external;
    function buybackAccum()              external view returns (uint256);
    function resetBuyback()              external;
    function lpP()                       external view returns (uint256);
    function lpR()                       external view returns (uint256);
    function lpT()                       external view returns (uint256);
    function totalLP()                   external view returns (uint256);
    function traderReserve()             external view returns (uint256);
    function freeWpol()                  external view returns (uint256);
    function transferWpol(address to, uint256 amount) external;
    function syncFromChain()             external;
}

interface ITokenEE {
    function mint(address to, uint256 amount) external;
    function buybackBurn(address from, uint256 amount) external;
    function totalSupply()              external view returns (uint256);
    function balanceOf(address account) external view returns (uint256);
}

interface IDivPoolEE {
    function notifyFounderEmission(uint256 amount) external;
}

error EE_ZeroAddress();
error EE_FixBaseAlreadySet();
error EE_EmitTooEarly(uint256 nextBlock, uint256 currentBlock);
error EE_AlphaLPOutOfRange(uint256 bps);

contract EmissionEngineMAX is AccessControl, Pausable, ReentrancyGuard {

    bytes32 public constant CALLER_ROLE = keccak256("CALLER_ROLE");
    bytes32 public constant PAUSER_ROLE = keccak256("PAUSER_ROLE");

    uint256 public constant PRECISION     = 1e18;
    uint256 public constant KAPPA_BPS     = 11_000;
    uint256 public constant EMIT_RATE_MIN = 2e12;    // 2e-6 scaled
    uint256 public constant EMIT_RATE_MAX = 50e12;   // 50e-6 scaled
    uint256 public constant G_P_MIN       = 3e12;
    uint256 public constant G_P_MAX       = 500e12;
    uint256 public constant BUYBACK_THRESHOLD = 5e15;
    uint256 public constant FOUNDER_EMIT_BPS = 3_000;  // 30%

    IVaultEE   public immutable vault;
    ITokenEE   public immutable syna;
    ITokenEE   public immutable sync_;
    ITokenEE   public immutable synr;
    IDivPoolEE public immutable divPool;
    address    public immutable vaultAddr;
    address    public immutable divPoolAddr;

    // ⭐ КЛЮЧЕВОЕ ИЗМЕНЕНИЕ: emitRate начинается с MAX!
    uint256 public gP       = G_P_MAX;
    uint256 public emitRate = EMIT_RATE_MAX;  // 50e-6 вместо 2e-6!

    uint256 public fixBase;
    uint256 public fixThrBPS     = 10_800;
    uint256 public constant FIX_THR_MAX  = 12_000;
    uint256 public constant FIX_CMP_BPS  = 60;
    uint256 public constant FIX_THR_STEP = 18;
    uint256 public fixCount;
    bool    public fixBaseSet;

    uint256 public feeWindowSum;
    uint256 public feeWindowCount;
    uint256 public alphaLPBPS = 3_500;

    uint256 public lastEmitBlock;
    uint256 public lastAdaptBlock;

    uint256 public totalEmittedR;
    uint256 public totalEmittedT;
    uint256 public totalEmittedP;
    uint256 public totalBuybacks;
    uint256 public fixCount_total;

    event EmissionExecuted(uint256 emR, uint256 emT, uint256 emP, uint256 toReserve, uint256 toFounder);
    event FixExecuted(uint256 fixWpol, uint256 newThrBPS, uint256 fixN);
    event BuybackExecuted(uint256 burned, uint256 lpBoost);
    event ParamsAdapted(uint256 gP, uint256 emitRate, uint256 blockN);
    event FixBaseInitialized(uint256 base);

    constructor(
        address vault_,
        address syna_,
        address sync__,
        address synr_,
        address divPool_,
        address admin_
    ) {
        if (vault_   == address(0) || syna_   == address(0) ||
            sync__   == address(0) || synr_   == address(0) ||
            divPool_ == address(0) || admin_   == address(0)) revert EE_ZeroAddress();

        vault      = IVaultEE(vault_);
        syna      = ITokenEE(syna_);
        sync_      = ITokenEE(sync__);
        synr      = ITokenEE(synr_);
        divPool    = IDivPoolEE(divPool_);
        vaultAddr  = vault_;
        divPoolAddr= divPool_;

        _grantRole(DEFAULT_ADMIN_ROLE, admin_);
        _grantRole(CALLER_ROLE,        admin_);
        _grantRole(PAUSER_ROLE,        admin_);
    }

    function setFixBase(uint256 base_) external onlyRole(CALLER_ROLE) {
        if (fixBaseSet) revert EE_FixBaseAlreadySet();
        fixBase    = base_ > 0 ? base_ : 600e18;
        fixBaseSet = true;
        emit FixBaseInitialized(fixBase);
    }

    function recordFee(uint256 amount) external whenNotPaused onlyRole(CALLER_ROLE) {
        feeWindowSum   += amount;
        feeWindowCount += 1;
    }

    function setAlphaLP(uint256 bps) external onlyRole(CALLER_ROLE) {
        if (bps < 2_800 || bps > 4_800) revert EE_AlphaLPOutOfRange(bps);
        alphaLPBPS = bps;
    }

    // Адаптация отключена для стабильного MAX emitRate
    function adapt() external whenNotPaused onlyRole(CALLER_ROLE) {
        // ОТКЛЮЧЕНО - держим emitRate на MAX
        lastAdaptBlock = block.number;
    }

    function executeEmission()
        external nonReentrant whenNotPaused onlyRole(CALLER_ROLE)
    {
        if (block.number < lastEmitBlock + PolygonConfig.EMIT_INTERVAL)
            revert EE_EmitTooEarly(lastEmitBlock + PolygonConfig.EMIT_INTERVAL, block.number);

        uint256 sR = syna.totalSupply();
        uint256 sT = sync_.totalSupply();
        uint256 sP = synr.totalSupply();

        // em = S × emitRate × 100 / PRECISION
        uint256 emR = sR * emitRate * 100 / PRECISION;
        uint256 emT = sT * emitRate * 100 / PRECISION;
        uint256 emP = sP * emitRate * 100 / PRECISION;

        uint256 lpRv = vault.lpR();
        uint256 lpTv = vault.lpT();
        uint256 lpPv = vault.lpP();

        uint256 dlpR = (sR > 0 && lpRv > 0) ? _sqrtAmmDlp(lpRv, emR, sR) : 0;
        uint256 dlpT = (sT > 0 && lpTv > 0) ? _sqrtAmmDlp(lpTv, emT, sT) : 0;
        uint256 dlpP = (sP > 0 && lpPv > 0) ? _sqrtAmmDlp(lpPv, emP, sP) : 0;

        uint256 dlpTotal = dlpR + dlpT + dlpP;

        uint256 toReserve = dlpTotal * 8 / 100;
        uint256 toFounder = dlpTotal * FOUNDER_EMIT_BPS / 10_000;
        uint256 toLpTotal = dlpTotal - toReserve - toFounder;

        uint256 toLpR = dlpTotal > 0 ? Math.mulDiv(toLpTotal, dlpR, dlpTotal) : 0;
        uint256 toLpT = dlpTotal > 0 ? Math.mulDiv(toLpTotal, dlpT, dlpTotal) : 0;
        uint256 toLpP = (dlpTotal > 0 && toLpTotal >= toLpR + toLpT)
                        ? toLpTotal - toLpR - toLpT : 0;

        lastEmitBlock = block.number;

        if (emR > 0) { try syna.mint(vaultAddr, emR) {} catch {} totalEmittedR += emR; }
        if (emT > 0) { try sync_.mint(vaultAddr, emT) {} catch {} totalEmittedT += emT; }
        if (emP > 0) { try synr.mint(vaultAddr, emP) {} catch {} totalEmittedP += emP; }

        if (toLpTotal > 0) {
            vault.batchAddLP(toLpR, toLpT, toLpP);
        }

        if (toReserve > 0) {
            vault.addToReserveR(toReserve);
        }

        // 30% → Founder (РЕАЛЬНЫЙ WPOL TRANSFER!)
        uint256 actualFounderWpol = 0;
        if (toFounder > 0) {
            uint256 freeW = vault.freeWpol();
            if (freeW >= toFounder) {
                vault.transferWpol(divPoolAddr, toFounder);
                divPool.notifyFounderEmission(toFounder);
                actualFounderWpol = toFounder;
            } else if (freeW >= 1e12) {
                vault.transferWpol(divPoolAddr, freeW);
                divPool.notifyFounderEmission(freeW);
                actualFounderWpol = freeW;
            }
        }

        emit EmissionExecuted(emR, emT, emP, toReserve, actualFounderWpol);

        _checkFix();
        _checkBuyback();
        vault.syncFromChain();
    }

    function _sqrtAmmDlp(uint256 lpV, uint256 em, uint256 supply)
        private pure returns (uint256)
    {
        if (supply == 0 || em == 0) return 0;
        uint256 newS   = supply + em;
        uint256 ratio = Math.mulDiv(newS, PRECISION, supply);
        uint256 sqrtRatio = _sqrt(ratio * PRECISION);
        uint256 SQRT_PREC = 1e18;
        if (sqrtRatio <= SQRT_PREC) return 0;
        uint256 factor = sqrtRatio - SQRT_PREC;
        return Math.mulDiv(lpV, factor * 997, SQRT_PREC * 1000);
    }

    function _sqrt(uint256 x) private pure returns (uint256 y) {
        if (x == 0) return 0;
        uint256 z = x;
        y = x;
        unchecked {
            while (true) {
                z = (y + x / y) / 2;
                if (z >= y) break;
                y = z;
            }
        }
    }

    function _checkFix() private {
        if (!fixBaseSet || fixBase == 0) return;
        uint256 totalLpV = vault.totalLP();
        uint256 thresh   = Math.mulDiv(fixBase, fixThrBPS, 10_000);
        if (totalLpV < thresh) return;

        uint256 fixWpol = totalLpV * 6 / 1_000;
        uint256 cap     = totalLpV * 7 / 1_000;
        if (fixWpol > cap) fixWpol = cap;
        if (fixWpol == 0) return;

        uint256 toRR = fixWpol * 55 / 100;
        uint256 toLp = fixWpol * 25 / 100;
        vault.batchAddLP(toLp * 22/100, toLp * 13/100, toLp * 65/100);
        vault.addToReserveR(toRR);

        fixBase    = Math.mulDiv(fixBase, fixThrBPS * (10_000 + FIX_CMP_BPS), 10_000 * 10_000);
        fixThrBPS  = fixThrBPS + FIX_THR_STEP;
        if (fixThrBPS > FIX_THR_MAX) fixThrBPS = FIX_THR_MAX;
        ++fixCount;

        emit FixExecuted(fixWpol, fixThrBPS, fixCount);
    }

    function _checkBuyback() private {
        uint256 accum = vault.buybackAccum();
        if (accum < BUYBACK_THRESHOLD) return;

        uint256 lpPv = vault.lpP();
        uint256 sP   = synr.totalSupply();
        if (lpPv == 0 || sP == 0) return;

        uint256 burnRaw = Math.mulDiv(sP, accum * 30 / 100, lpPv);
        uint256 burnCap = sP * 2 / 1_000;
        if (burnCap == 0) burnCap = 1;
        uint256 burnAmt = burnRaw < burnCap ? burnRaw : burnCap;

        uint256 lpBoost = accum * 85 / 100;

        vault.resetBuyback();
        vault.addToLpP(lpBoost);

        if (burnAmt > 0 && synr.balanceOf(vaultAddr) >= burnAmt) {
            try synr.buybackBurn(vaultAddr, burnAmt) {
                totalBuybacks += burnAmt;
                emit BuybackExecuted(burnAmt, lpBoost);
            } catch {
                emit BuybackExecuted(0, lpBoost);
            }
        } else {
            emit BuybackExecuted(0, lpBoost);
        }
    }

    function isEmissionDue() external view returns (bool) {
        return block.number >= lastEmitBlock + PolygonConfig.EMIT_INTERVAL;
    }

    function getParams() external view returns (uint256 gP_, uint256 emitRate_) {
        return (gP, emitRate);
    }

    function pause()   external onlyRole(PAUSER_ROLE) { _pause(); }
    function unpause() external onlyRole(PAUSER_ROLE) { _unpause(); }
}
