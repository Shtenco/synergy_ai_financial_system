const assert = require("assert");
const { ethers, network } = require("hardhat");

async function expectRevert(promise, text) {
  try {
    await promise;
    throw new Error("expected revert");
  } catch (error) {
    assert(String(error).includes(text), `expected revert containing ${text}, got ${error}`);
  }
}

async function advance(seconds) {
  await network.provider.send("evm_increaseTime", [seconds]);
  await network.provider.send("evm_mine");
}

describe("SHTENCO AI Central Bank stack", function () {
  it("timelocks and executes a guarded AI market-maker rebalance", async function () {
    const [admin, ai, executor, guardian, treasury] = await ethers.getSigners();
    const Token = await ethers.getContractFactory("MockERC20");
    const tokenA = await Token.deploy("Reserve A", "A", 18);
    const tokenB = await Token.deploy("Reserve B", "B", 18);
    const Router = await ethers.getContractFactory("MockV2Router");
    const router = await Router.deploy();
    const Guard = await ethers.getContractFactory("MockPriceGuard");
    const guard = await Guard.deploy();

    const MM = await ethers.getContractFactory("SHTENCOMarketMaker");
    const mm = await MM.deploy(admin.address, treasury.address);
    const CB = await ethers.getContractFactory("SHTENCOAICentralBank");
    const cb = await CB.deploy(admin.address, ai.address, executor.address, guardian.address);

    await mm.grantRole(await mm.CONTROLLER_ROLE(), await cb.getAddress());
    await mm.setRouter(await router.getAddress(), true);
    await mm.setToken(await tokenA.getAddress(), true, ethers.parseEther("1000"));
    await mm.setToken(await tokenB.getAddress(), true, ethers.parseEther("1000"));
    await mm.setGuard(await guard.getAddress(), 150, 3600);
    await router.setRate(await tokenA.getAddress(), await tokenB.getAddress(), 2, 1);
    await guard.setRate(await tokenA.getAddress(), await tokenB.getAddress(), 2, 1);

    await tokenA.mint(await mm.getAddress(), ethers.parseEther("100"));
    await tokenB.mint(await router.getAddress(), ethers.parseEther("1000"));

    const selector = mm.interface.getFunction("executeSwap").selector;
    await cb.setTarget(await mm.getAddress(), true);
    await cb.setSelector(await mm.getAddress(), selector, true);
    await cb.setSelectorBudgetRequired(await mm.getAddress(), selector, true);
    await cb.setBudgetLimit(await tokenA.getAddress(), ethers.parseEther("200"));
    await cb.setDelayPolicy(60, 86400, 3600);

    const block = await ethers.provider.getBlock("latest");
    const deadline = block.timestamp + 240;
    const data = mm.interface.encodeFunctionData("executeSwap", [
      await router.getAddress(),
      ethers.parseEther("100"),
      ethers.parseEther("198"),
      [await tokenA.getAddress(), await tokenB.getAddress()],
      deadline,
      ethers.id("inventory-rebalance"),
    ]);
    const action = {
      target: await mm.getAddress(),
      value: 0,
      data,
      budgetToken: await tokenA.getAddress(),
      budgetAmount: ethers.parseEther("100"),
    };
    const executeAfter = block.timestamp + 65;
    const expiresAt = executeAfter + 1800;
    const proposalId = await cb.connect(ai).propose.staticCall(
      [action], ethers.id("state-1"), ethers.id("risk-adjusted-tvl-growth"),
      8200, 900, executeAfter, expiresAt
    );
    await cb.connect(ai).propose(
      [action], ethers.id("state-1"), ethers.id("risk-adjusted-tvl-growth"),
      8200, 900, executeAfter, expiresAt
    );

    await expectRevert(cb.connect(executor).execute(proposalId), "AI-CB: timelocked");
    await advance(66);
    await cb.connect(executor).execute(proposalId);
    assert.equal(await tokenB.balanceOf(await mm.getAddress()), ethers.parseEther("200"));
    assert.equal(await cb.budgetUsedToday(await tokenA.getAddress()), ethers.parseEther("100"));
    assert.equal((await cb.proposals(proposalId)).executed, true);
  });

  it("rejects excessive risk and protects reserve floors", async function () {
    const [admin, ai, executor, guardian, recipient] = await ethers.getSigners();
    const CB = await ethers.getContractFactory("SHTENCOAICentralBank");
    const cb = await CB.deploy(admin.address, ai.address, executor.address, guardian.address);
    const Target = await ethers.getContractFactory("MockActionTarget");
    const target = await Target.deploy();
    await cb.setTarget(await target.getAddress(), true);
    const targetSelector = target.interface.getFunction("setValue").selector;
    await cb.setSelector(await target.getAddress(), targetSelector, true);
    await cb.setSelectorBudgetRequired(await target.getAddress(), targetSelector, true);
    await cb.setDelayPolicy(60, 86400, 3600);
    const block = await ethers.provider.getBlock("latest");
    const action = {
      target: await target.getAddress(), value: 0,
      data: target.interface.encodeFunctionData("setValue", [7, ethers.id("test")]),
      budgetToken: ethers.ZeroAddress, budgetAmount: 0,
    };
    await expectRevert(
      cb.connect(ai).propose([action], ethers.id("state"), ethers.id("objective"), 8000, 3000, block.timestamp + 61, block.timestamp + 1200),
      "AI-CB: risk above policy"
    );
    const freshBlock = await ethers.provider.getBlock("latest");
    await expectRevert(
      cb.connect(ai).propose([action], ethers.id("state"), ethers.id("objective"), 8000, 1000, freshBlock.timestamp + 65, freshBlock.timestamp + 1200),
      "AI-CB: budget required"
    );

    const Token = await ethers.getContractFactory("MockERC20");
    const token = await Token.deploy("USDT", "USDT", 6);
    const Reserve = await ethers.getContractFactory("SHTENCOBridgeQEReserve");
    const reserve = await Reserve.deploy(admin.address);
    await reserve.grantRole(await reserve.CONTROLLER_ROLE(), admin.address);
    await reserve.setRecipient(recipient.address, true);
    await reserve.setTokenPolicy(await token.getAddress(), {
      enabled: true,
      minimumReserve: 800_000000n,
      dailyAllocationLimit: 300_000000n,
    });
    await token.mint(await reserve.getAddress(), 1_000_000000n);
    await reserve.allocate(await token.getAddress(), recipient.address, 200_000000n, ethers.id("bridge-liquidity"));
    await expectRevert(
      reserve.allocate(await token.getAddress(), recipient.address, 1n, ethers.id("too-much")),
      "RESERVE: reserve floor"
    );
  });


  it("supports oracle-bounded liquidity and atomic buyback burn", async function () {
    const [admin, treasury] = await ethers.getSigners();
    const Token = await ethers.getContractFactory("MockERC20");
    const tokenA = await Token.deploy("Reserve A", "A", 18);
    const tokenB = await Token.deploy("Burn B", "B", 18);
    const Router = await ethers.getContractFactory("MockV2Router");
    const router = await Router.deploy();
    const Guard = await ethers.getContractFactory("MockPriceGuard");
    const guard = await Guard.deploy();
    const MM = await ethers.getContractFactory("SHTENCOMarketMaker");
    const mm = await MM.deploy(admin.address, treasury.address);
    await mm.grantRole(await mm.CONTROLLER_ROLE(), admin.address);
    await mm.setRouter(await router.getAddress(), true);
    await mm.setToken(await tokenA.getAddress(), true, ethers.parseEther("1000"));
    await mm.setToken(await tokenB.getAddress(), true, ethers.parseEther("2000"));
    await mm.setBurnableToken(await tokenB.getAddress(), true);
    await mm.setGuard(await guard.getAddress(), 150, 3600);
    await mm.setCooldown(30);
    await router.setRate(await tokenA.getAddress(), await tokenB.getAddress(), 2, 1);
    await guard.setRate(await tokenA.getAddress(), await tokenB.getAddress(), 2, 1);
    await tokenA.mint(await mm.getAddress(), ethers.parseEther("100"));
    await tokenB.mint(await mm.getAddress(), ethers.parseEther("200"));
    await tokenB.mint(await router.getAddress(), ethers.parseEther("1000"));

    let block = await ethers.provider.getBlock("latest");
    await mm.addLiquidity(
      await router.getAddress(), await tokenA.getAddress(), await tokenB.getAddress(),
      ethers.parseEther("20"), ethers.parseEther("40"),
      ethers.parseEther("19.7"), ethers.parseEther("39.4"),
      block.timestamp + 120, ethers.id("deepen-liquidity")
    );
    assert.equal(await mm.totalLiquidityActions(), 1n);

    await advance(31);
    block = await ethers.provider.getBlock("latest");
    const supplyBefore = await tokenB.totalSupply();
    const burned = await mm.executeBuybackAndBurn.staticCall(
      await router.getAddress(), ethers.parseEther("10"), ethers.parseEther("19.7"),
      [await tokenA.getAddress(), await tokenB.getAddress()], block.timestamp + 120,
      ethers.id("buyback-burn")
    );
    await mm.executeBuybackAndBurn(
      await router.getAddress(), ethers.parseEther("10"), ethers.parseEther("19.7"),
      [await tokenA.getAddress(), await tokenB.getAddress()], block.timestamp + 120,
      ethers.id("buyback-burn")
    );
    assert.equal(burned, ethers.parseEther("20"));
    assert.equal(await tokenB.totalSupply(), supplyBefore - burned);
  });

});
