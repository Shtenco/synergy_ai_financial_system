const assert = require("assert");
const { ethers } = require("hardhat");

async function expectRevert(promise, text) {
  try {
    await promise;
    throw new Error("expected revert");
  } catch (error) {
    assert(String(error).includes(text), `expected revert containing ${text}, got ${error}`);
  }
}

async function sortedSignatures(signers, domain, types, value) {
  const rows = [];
  for (const signer of signers) {
    rows.push({
      address: (await signer.getAddress()).toLowerCase(),
      signature: await signer.signTypedData(domain, types, value),
    });
  }
  rows.sort((a, b) => a.address.localeCompare(b.address));
  return rows.map((row) => row.signature);
}

describe("SHTENCOBridgeRelayV2", function () {
  it("locks, threshold-mints, burns, releases, and blocks replay", async function () {
    const [admin, user, feeRecipient, v1, v2, v3] = await ethers.getSigners();
    const Token = await ethers.getContractFactory("MockERC20");
    const canonical = await Token.deploy("SYNA", "SYNA", 18);
    await canonical.waitForDeployment();

    const Wrapped = await ethers.getContractFactory("SHTENCOWrappedSYNA");
    const wrapped = await Wrapped.deploy(admin.address, ethers.parseEther("100000000"));
    await wrapped.waitForDeployment();

    const Bridge = await ethers.getContractFactory("SHTENCOBridgeRelayV2");
    const validators = [v1.address, v2.address, v3.address];
    const source = await Bridge.deploy(admin.address, 1001, true, validators, 2);
    const destination = await Bridge.deploy(admin.address, 1002, true, validators, 2);
    await source.waitForDeployment();
    await destination.waitForDeployment();

    await wrapped.grantRole(await wrapped.BRIDGE_ROLE(), await destination.getAddress());
    await source.setPeer(1002, await destination.getAddress(), true);
    await destination.setPeer(1001, await source.getAddress(), true);
    await source.setRemoteToken(1002, await canonical.getAddress(), await wrapped.getAddress());
    await destination.setRemoteToken(1001, await wrapped.getAddress(), await canonical.getAddress());

    const sourcePolicy = {
      enabled: true,
      mode: 0,
      feeBps: 10,
      minTransfer: ethers.parseEther("1"),
      maxPerTx: ethers.parseEther("1000"),
      dailyOutboundLimit: ethers.parseEther("5000"),
      dailyInboundLimit: ethers.parseEther("5000"),
      feeRecipient: feeRecipient.address,
    };
    const destinationPolicy = { ...sourcePolicy, mode: 1 };
    await source.setAssetPolicy(await canonical.getAddress(), sourcePolicy);
    await destination.setAssetPolicy(await wrapped.getAddress(), destinationPolicy);

    await canonical.mint(user.address, ethers.parseEther("1000"));
    await canonical.connect(user).approve(await source.getAddress(), ethers.MaxUint256);

    const gross = ethers.parseEther("100");
    const fee1 = gross * 10n / 10000n;
    const net1 = gross - fee1;
    await source.connect(user).bridgeOut(await canonical.getAddress(), gross, 1002, user.address);
    assert.equal(await source.escrowLiability(await canonical.getAddress()), net1);
    assert.equal(await source.outgoingNonce(), 1n);

    const now = (await ethers.provider.getBlock("latest")).timestamp;
    const epoch1 = await destination.validatorEpoch();
    const inbound1 = {
      sourceChainId: 1001,
      sourceBridge: await source.getAddress(),
      sourceNonce: 1,
      sourceToken: await canonical.getAddress(),
      targetChainId: 1002,
      targetBridge: await destination.getAddress(),
      targetToken: await wrapped.getAddress(),
      recipient: user.address,
      amount: net1,
      deadline: now + 3600,
      validatorEpoch: epoch1,
    };
    const network = await ethers.provider.getNetwork();
    const domain1 = {
      name: "SHTENCO SYNA Relay Bridge",
      version: "2",
      chainId: network.chainId,
      verifyingContract: await destination.getAddress(),
    };
    const types = {
      InboundMessage: [
        { name: "sourceChainId", type: "uint256" },
        { name: "sourceBridge", type: "address" },
        { name: "sourceNonce", type: "uint256" },
        { name: "sourceToken", type: "address" },
        { name: "targetChainId", type: "uint256" },
        { name: "targetBridge", type: "address" },
        { name: "targetToken", type: "address" },
        { name: "recipient", type: "address" },
        { name: "amount", type: "uint256" },
        { name: "deadline", type: "uint256" },
        { name: "validatorEpoch", type: "uint256" },
      ],
    };
    const sigs1 = await sortedSignatures([v1, v2], domain1, types, inbound1);
    await destination.completeInbound(inbound1, sigs1);
    assert.equal(await wrapped.balanceOf(user.address), net1);
    await expectRevert(destination.completeInbound(inbound1, sigs1), "BRIDGE: source transfer replay");
    const inbound1Altered = { ...inbound1, deadline: inbound1.deadline + 1 };
    const sigs1Altered = await sortedSignatures([v1, v2], domain1, types, inbound1Altered);
    await expectRevert(
      destination.completeInbound(inbound1Altered, sigs1Altered),
      "BRIDGE: source transfer replay"
    );

    await wrapped.connect(user).approve(await destination.getAddress(), ethers.MaxUint256);
    await destination.connect(user).bridgeOut(await wrapped.getAddress(), net1, 1001, user.address);
    const fee2 = net1 * 10n / 10000n;
    const net2 = net1 - fee2;

    const now2 = (await ethers.provider.getBlock("latest")).timestamp;
    const inbound2 = {
      sourceChainId: 1002,
      sourceBridge: await destination.getAddress(),
      sourceNonce: 1,
      sourceToken: await wrapped.getAddress(),
      targetChainId: 1001,
      targetBridge: await source.getAddress(),
      targetToken: await canonical.getAddress(),
      recipient: user.address,
      amount: net2,
      deadline: now2 + 3600,
      validatorEpoch: await source.validatorEpoch(),
    };
    const domain2 = { ...domain1, verifyingContract: await source.getAddress() };
    const sigs2 = await sortedSignatures([v2, v3], domain2, types, inbound2);
    const before = await canonical.balanceOf(user.address);
    await source.completeInbound(inbound2, sigs2);
    assert.equal(await canonical.balanceOf(user.address), before + net2);
    assert.equal(await source.escrowLiability(await canonical.getAddress()), fee2);
  });

  it("enforces daily limits and validator epoch", async function () {
    const [admin, user, feeRecipient, v1, v2] = await ethers.getSigners();
    const Token = await ethers.getContractFactory("MockERC20");
    const token = await Token.deploy("SYNA", "SYNA", 18);
    const Bridge = await ethers.getContractFactory("SHTENCOBridgeRelayV2");
    const bridge = await Bridge.deploy(admin.address, 1001, true, [v1.address, v2.address], 2);
    await bridge.setPeer(1002, admin.address, true);
    await bridge.setRemoteToken(1002, await token.getAddress(), user.address);
    await bridge.setAssetPolicy(await token.getAddress(), {
      enabled: true, mode: 0, feeBps: 0,
      minTransfer: 1, maxPerTx: ethers.parseEther("50"),
      dailyOutboundLimit: ethers.parseEther("50"), dailyInboundLimit: ethers.parseEther("50"),
      feeRecipient: feeRecipient.address,
    });
    await token.mint(user.address, ethers.parseEther("100"));
    await token.connect(user).approve(await bridge.getAddress(), ethers.MaxUint256);
    await bridge.connect(user).bridgeOut(await token.getAddress(), ethers.parseEther("40"), 1002, user.address);
    await expectRevert(
      bridge.connect(user).bridgeOut(await token.getAddress(), ethers.parseEther("20"), 1002, user.address),
      "BRIDGE: daily limit"
    );
    const epoch = await bridge.validatorEpoch();
    await bridge.setThreshold(1);
    assert.equal(await bridge.validatorEpoch(), epoch + 1n);
  });


  it("rejects fee-on-transfer assets so escrow accounting stays exact", async function () {
    const [admin, user, feeRecipient, v1] = await ethers.getSigners();
    const Token = await ethers.getContractFactory("MockFeeOnTransferToken");
    const token = await Token.deploy();
    const Bridge = await ethers.getContractFactory("SHTENCOBridgeRelayV2");
    const bridge = await Bridge.deploy(admin.address, 1001, true, [v1.address], 1);
    await bridge.setPeer(1002, admin.address, true);
    await bridge.setRemoteToken(1002, await token.getAddress(), user.address);
    await bridge.setAssetPolicy(await token.getAddress(), {
      enabled: true, mode: 0, feeBps: 0,
      minTransfer: 1, maxPerTx: ethers.parseEther("100"),
      dailyOutboundLimit: ethers.parseEther("1000"), dailyInboundLimit: ethers.parseEther("1000"),
      feeRecipient: feeRecipient.address,
    });
    await token.mint(user.address, ethers.parseEther("100"));
    await token.connect(user).approve(await bridge.getAddress(), ethers.MaxUint256);
    await expectRevert(
      bridge.connect(user).bridgeOut(await token.getAddress(), ethers.parseEther("10"), 1002, user.address),
      "BRIDGE: unsupported transfer token"
    );
  });



  it("executes reserve-funded bridge QE only through approved routes", async function () {
    const [admin, treasury, recipient, feeRecipient, validator] = await ethers.getSigners();
    const Token = await ethers.getContractFactory("MockERC20");
    const token = await Token.deploy("SYNA", "SYNA", 18);
    const Bridge = await ethers.getContractFactory("SHTENCOBridgeRelayV2");
    const bridge = await Bridge.deploy(admin.address, 1001, true, [validator.address], 1);
    await bridge.setPeer(1002, treasury.address, true);
    await bridge.setRemoteToken(1002, await token.getAddress(), recipient.address);
    await bridge.setAssetPolicy(await token.getAddress(), {
      enabled: true, mode: 0, feeBps: 10,
      minTransfer: 1, maxPerTx: ethers.parseEther("100"),
      dailyOutboundLimit: ethers.parseEther("1000"), dailyInboundLimit: ethers.parseEther("1000"),
      feeRecipient: feeRecipient.address,
    });

    const Adapter = await ethers.getContractFactory("SHTENCOBridgeQEAdapter");
    const adapter = await Adapter.deploy(admin.address, treasury.address);
    await adapter.grantRole(await adapter.CONTROLLER_ROLE(), admin.address);
    await adapter.setRoute(await bridge.getAddress(), await token.getAddress(), 1002, {
      enabled: true, maxPerTx: ethers.parseEther("100"), dailyLimit: ethers.parseEther("500"),
    });
    await adapter.setRecipient(1002, recipient.address, true);
    await token.mint(await adapter.getAddress(), ethers.parseEther("50"));
    await adapter.executeRebalance(
      await bridge.getAddress(), await token.getAddress(), ethers.parseEther("20"),
      1002, recipient.address, ethers.id("bridge-inventory-balance")
    );
    assert.equal(await bridge.outgoingNonce(), 1n);
    assert.equal(await token.balanceOf(await adapter.getAddress()), ethers.parseEther("30"));
    assert.equal(await adapter.flowToday(await bridge.getAddress(), await token.getAddress(), 1002), ethers.parseEther("20"));
  });

});
