#!/usr/bin/env python3
"""
ДЕПЛОЙ ОСТАВШИХСЯ КОНТРАКТОВ + ИНИЦИАЛИЗАЦИЯ
"""
import sys, io, os, json, time
from dotenv import load_dotenv
from web3 import Web3
from web3.middleware import ExtraDataToPOAMiddleware

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

load_dotenv()

w3 = Web3(Web3.HTTPProvider("https://polygon-bor-rpc.publicnode.com", request_kwargs={"timeout": 300}))
w3.middleware_onion.inject(ExtraDataToPOAMiddleware, layer=0)

PK = os.getenv("OWNER_PRIVATE_KEY")
OWNER = "0x6946999DBCE63b140B1bB9D475F7c357130909E5"
WPOL = "0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270"

def C(a): return Web3.to_checksum_address(a)

# Уже задеплоено (из предыдущего запуска)
deployed = {
    "tokens": {
        "SYNA": "0xF3603c393FB2A03Ae735F7FeE09D021de4260197",
        "SYNC": "0x7a60B741E955Bc8346f21d44586B73FF09490202",
        "SYNR": "0x7dC13f3166e4B3d8a8b2EdE8BAc3162608761675"
    },
    "core": "0x70D4702bB100Ad4CB10E0332f28bD923c81aF6df",
    "vault": "0x4515BBf04Aa56349Fadc85Fb61fE4Cd69Add5182",
    "oracle": "0x3954a794Fd02C8a135A2FB8723BA2C9eD0b4CD10",
    "divPool": "0x4B6dcAE8377C09bf35f33A40bC4E893A33840f4c",
    "cbArb": "0x3f69BC84E9cc1A1f2e0964E6aCf8E1cC0A4055d7",
    "feeRouter": "0x3ff8294647246Dc60D8C392E46a66aecf77858E3",
    "emitEngine": "0x76d26FEA2ec4A7179081288E9D3D1A445d4a55A7",
    "loop": "0xfe48909cCC562cEC54c469c66f0f99B7Bfd939dB"
}

print("=" * 70)
print("ДЕПЛОЙ ОСТАВШИХСЯ + ИНИЦИАЛИЗАЦИЯ")
print("=" * 70)
print(f"POL: {w3.eth.get_balance(C(OWNER)) / 1e18:.4f}")

nonce = w3.eth.get_transaction_count(C(OWNER), "pending")

def deploy_contract(name, artifact_path, constructor_args):
    global nonce
    print(f"\n[DEPLOY] {name}...", flush=True)

    with open(artifact_path, encoding="utf-8") as f:
        artifact = json.load(f)

    abi = artifact["abi"]
    bytecode = artifact["bytecode"]["object"]

    base = w3.eth.get_block("latest").get("baseFeePerGas", int(100e9))
    prio = int(50e9)
    mf = base * 2 + prio

    contract = w3.eth.contract(abi=abi, bytecode=bytecode)

    tx = contract.constructor(*constructor_args).build_transaction({
        "from": C(OWNER), "nonce": nonce, "chainId": 137, "type": 2,
        "maxPriorityFeePerGas": prio, "maxFeePerGas": mf, "gas": 8_000_000
    })

    signed = w3.eth.account.sign_transaction(tx, PK)
    h = w3.eth.send_raw_transaction(signed.raw_transaction)
    print(f"  TX: {h.hex()[:20]}...")

    r = w3.eth.wait_for_transaction_receipt(h, timeout=300)
    cost = r.gasUsed * mf / 1e18

    if r.status == 1:
        addr = r.contractAddress
        print(f"  [OK] {addr} (gas: {cost:.4f})")
        nonce += 1
        return addr, abi
    else:
        print(f"  [FAIL]")
        nonce += 1
        return None, None

def send_tx(func, label, gas=500000):
    global nonce
    print(f"  {label}...", flush=True)

    base = w3.eth.get_block("latest").get("baseFeePerGas", int(100e9))
    prio = int(50e9)
    mf = base * 2 + prio

    tx = func.build_transaction({
        "from": C(OWNER), "nonce": nonce, "chainId": 137, "type": 2,
        "maxPriorityFeePerGas": prio, "maxFeePerGas": mf, "gas": gas
    })

    signed = w3.eth.account.sign_transaction(tx, PK)
    h = w3.eth.send_raw_transaction(signed.raw_transaction)

    r = w3.eth.wait_for_transaction_receipt(h, timeout=300)
    if r.status == 1:
        print(f"    [OK]")
        nonce += 1
        return True
    else:
        print(f"    [FAIL]")
        nonce += 1
        return False

# ═══════════════════════════════════════════════════════════════════════════
# DEPLOY FOUNDER CONTROL
# ═══════════════════════════════════════════════════════════════════════════
print("\n[STEP 10] DEPLOY FOUNDER CONTROL")

fc_addr, fc_abi = deploy_contract("FounderControl", "out/11_FounderControl.sol/FounderControl.json",
    [C(deployed["core"]), C(deployed["vault"]), C(deployed["divPool"]),
     C(deployed["loop"]), C(OWNER), C(OWNER)])
time.sleep(3)
deployed["founderCtl"] = fc_addr

# ═══════════════════════════════════════════════════════════════════════════
# INITIALIZE CORE
# ═══════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 70)
print("ИНИЦИАЛИЗАЦИЯ СИСТЕМЫ")
print("=" * 70)

with open("out/10_TroikaCore.sol/TroikaCore.json", encoding="utf-8") as f:
    core_abi = json.load(f)["abi"]

core = w3.eth.contract(address=C(deployed["core"]), abi=core_abi)

print("\n[1] Core.initialize...")
init_func = core.functions.initialize((
    C(deployed["vault"]),
    C(deployed["oracle"]),
    C(deployed["feeRouter"]),
    C(deployed["cbArb"]),
    C(deployed["emitEngine"]),
    C(deployed["divPool"]),
    C(deployed["loop"])
))
send_tx(init_func, "initialize", gas=1000000)
time.sleep(2)

print("\n[2] Core.setFounderControl...")
fc_func = core.functions.setFounderControl(C(deployed["founderCtl"]))
send_tx(fc_func, "setFounderControl", gas=200000)
time.sleep(2)

# ═══════════════════════════════════════════════════════════════════════════
# GRANT ROLES
# ═══════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 70)
print("ВЫДАЧА РОЛЕЙ")
print("=" * 70)

# Load ABIs
with open("out/03_TroikaVault.sol/TroikaVault.json", encoding="utf-8") as f:
    vault_abi = json.load(f)["abi"]
with open("out/02_Tokens.sol/SYNA.json", encoding="utf-8") as f:
    token_abi = json.load(f)["abi"]
with open("out/05_DividendPool.sol/DividendPool.json", encoding="utf-8") as f:
    divpool_abi = json.load(f)["abi"]
with open("out/04_TWAPOracle.sol/TWAPOracle.json", encoding="utf-8") as f:
    oracle_abi = json.load(f)["abi"]
with open("out/06_FeeRouter.sol/FeeRouter.json", encoding="utf-8") as f:
    feerouter_abi = json.load(f)["abi"]
with open("out/08_CBArbitrage.sol/CBArbitrage.json", encoding="utf-8") as f:
    cbarb_abi = json.load(f)["abi"]
with open("out/07_EmissionEngine.sol/EmissionEngine.json", encoding="utf-8") as f:
    emit_abi = json.load(f)["abi"]
with open("out/09_SelfReinforcingLoop.sol/SelfReinforcingLoop.json", encoding="utf-8") as f:
    loop_abi = json.load(f)["abi"]

vault = w3.eth.contract(address=C(deployed["vault"]), abi=vault_abi)
syna = w3.eth.contract(address=C(deployed["tokens"]["SYNA"]), abi=token_abi)
sync = w3.eth.contract(address=C(deployed["tokens"]["SYNC"]), abi=token_abi)
synr = w3.eth.contract(address=C(deployed["tokens"]["SYNR"]), abi=token_abi)
divpool = w3.eth.contract(address=C(deployed["divPool"]), abi=divpool_abi)
oracle = w3.eth.contract(address=C(deployed["oracle"]), abi=oracle_abi)
feerouter = w3.eth.contract(address=C(deployed["feeRouter"]), abi=feerouter_abi)
cbarb = w3.eth.contract(address=C(deployed["cbArb"]), abi=cbarb_abi)
emit = w3.eth.contract(address=C(deployed["emitEngine"]), abi=emit_abi)
loop = w3.eth.contract(address=C(deployed["loop"]), abi=loop_abi)

# Vault OPERATOR_ROLE
print("\n[Vault] OPERATOR_ROLE...")
OP = vault.functions.OPERATOR_ROLE().call()
for addr, name in [(deployed["core"], "core"), (deployed["feeRouter"], "feeRouter"),
                   (deployed["cbArb"], "cbArb"), (deployed["emitEngine"], "emitEngine"),
                   (deployed["loop"], "loop"), (deployed["founderCtl"], "founderCtl")]:
    send_tx(vault.functions.grantRole(OP, C(addr)), f"grant to {name}")
    time.sleep(1)

# Token MINTER_ROLE -> EmitEngine
print("\n[Tokens] MINTER_ROLE -> EmitEngine...")
MINTER = syna.functions.MINTER_ROLE().call()
send_tx(syna.functions.grantRole(MINTER, C(deployed["emitEngine"])), "SYNA")
time.sleep(1)
send_tx(sync.functions.grantRole(MINTER, C(deployed["emitEngine"])), "SYNC")
time.sleep(1)
send_tx(synr.functions.grantRole(MINTER, C(deployed["emitEngine"])), "SYNR")
time.sleep(1)

# SYNR BURNER_ROLE -> EmitEngine
print("\n[SYNR] BURNER_ROLE -> EmitEngine...")
BURNER = synr.functions.BURNER_ROLE().call()
send_tx(synr.functions.grantRole(BURNER, C(deployed["emitEngine"])), "SYNR burner")
time.sleep(1)

# DividendPool roles
print("\n[DividendPool] roles...")
NOT = divpool.functions.NOTIFIER_ROLE().call()
send_tx(divpool.functions.grantRole(NOT, C(deployed["feeRouter"])), "notifier feeRouter")
time.sleep(1)
send_tx(divpool.functions.grantRole(NOT, C(deployed["cbArb"])), "notifier cbArb")
time.sleep(1)
send_tx(divpool.functions.grantRole(NOT, C(deployed["emitEngine"])), "notifier emitEngine")
time.sleep(1)

PAY = divpool.functions.PAYOUT_ROLE().call()
send_tx(divpool.functions.grantRole(PAY, C(deployed["core"])), "payout core")
time.sleep(1)

FC_ROLE = divpool.functions.FOUNDER_CTL_ROLE().call()
send_tx(divpool.functions.grantRole(FC_ROLE, C(deployed["founderCtl"])), "founderCtl role")
time.sleep(1)

# Oracle UPDATER_ROLE
print("\n[Oracle] UPDATER_ROLE -> core...")
UPD = oracle.functions.UPDATER_ROLE().call()
send_tx(oracle.functions.grantRole(UPD, C(deployed["core"])), "oracle updater")
time.sleep(1)

# FeeRouter CALLER_ROLE
print("\n[FeeRouter] CALLER_ROLE -> core...")
CALL = feerouter.functions.CALLER_ROLE().call()
send_tx(feerouter.functions.grantRole(CALL, C(deployed["core"])), "feeRouter caller")
time.sleep(1)

# CBArb roles
print("\n[CBArb] roles...")
CALL = cbarb.functions.CALLER_ROLE().call()
send_tx(cbarb.functions.grantRole(CALL, C(deployed["core"])), "cbArb caller")
time.sleep(1)
FEED = cbarb.functions.FEEDER_ROLE().call()
send_tx(cbarb.functions.grantRole(FEED, C(deployed["feeRouter"])), "cbArb feeder")
time.sleep(1)

# EmitEngine CALLER_ROLE
print("\n[EmitEngine] CALLER_ROLE -> core...")
CALL = emit.functions.CALLER_ROLE().call()
send_tx(emit.functions.grantRole(CALL, C(deployed["core"])), "emit caller")
time.sleep(1)

# Loop roles
print("\n[Loop] roles...")
CONT = loop.functions.CONTRIBUTOR_ROLE().call()
send_tx(loop.functions.grantRole(CONT, C(deployed["core"])), "loop contributor")
time.sleep(1)
EXEC = loop.functions.EXECUTOR_ROLE().call()
send_tx(loop.functions.grantRole(EXEC, C(deployed["core"])), "loop executor")
time.sleep(1)

# Сохраняем
deployed["deployed_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
deployed["owner"] = OWNER

with open("deployed_TROIKA_v3.json", "w") as f:
    json.dump(deployed, f, indent=2)

print("\n" + "=" * 70)
print("КОНТРАКТЫ ЗАДЕПЛОЕНЫ И РОЛИ ВЫДАНЫ!")
print("=" * 70)
print(f"POL: {w3.eth.get_balance(C(OWNER)) / 1e18:.4f}")
print("\nСохранено в deployed_TROIKA_v3.json")
print("\nСледующий шаг: INITIALIZE_VAULT.py (добавить ликвидность)")
