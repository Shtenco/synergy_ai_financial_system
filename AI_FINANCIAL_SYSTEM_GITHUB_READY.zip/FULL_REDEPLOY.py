#!/usr/bin/env python3
"""
ПОЛНЫЙ РЕДЕПЛОЙ ВСЕЙ СИСТЕМЫ TROIKA
С нормальными токенами из 02_Tokens.sol
"""
import sys, io, os, json, time, subprocess
from dotenv import load_dotenv
from web3 import Web3
from web3.middleware import ExtraDataToPOAMiddleware

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

load_dotenv()

w3 = Web3(Web3.HTTPProvider("https://polygon-bor-rpc.publicnode.com", request_kwargs={"timeout": 180}))
w3.middleware_onion.inject(ExtraDataToPOAMiddleware, layer=0)

PK = os.getenv("OWNER_PRIVATE_KEY")
OWNER = "0x6946999DBCE63b140B1bB9D475F7c357130909E5"
WPOL = "0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270"
ROUTER = "0xa5E0829CaCEd8fFDD4De3c43696c57F7D7A678ff"
FACTORY = "0x5757371414417b8C6CAad45bAeF941aBc7d3Ab32"

def C(a): return Web3.to_checksum_address(a)

print("=" * 70)
print("ПОЛНЫЙ РЕДЕПЛОЙ TROIKA - НОРМАЛЬНЫЕ ТОКЕНЫ")
print("=" * 70)
print(f"Баланс: {w3.eth.get_balance(C(OWNER)) / 1e18:.4f} POL")
print("=" * 70)

# Компилируем через solc напрямую с remappings
# Нужен npm install @openzeppelin/contracts

# Сначала проверим есть ли node_modules
if not os.path.exists("node_modules"):
    print("\nУстанавливаю OpenZeppelin...")
    os.system("npm init -y 2>NUL")
    os.system("npm install @openzeppelin/contracts 2>NUL")

# Создадим foundry.toml для remappings
with open("foundry.toml", "w") as f:
    f.write("""[profile.default]
src = "."
out = "out"
libs = ["node_modules"]
remappings = ["@openzeppelin/=node_modules/@openzeppelin/"]
optimizer = true
optimizer_runs = 200
""")

print("\nИспользую inline контракты (без forge)...")

# Создаём inline версию токенов без внешних импортов
TOKENS_INLINE = '''
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

// Minimal ERC20 with AccessControl, Pausable, Permit
abstract contract Context {
    function _msgSender() internal view virtual returns (address) { return msg.sender; }
}

interface IERC20 {
    event Transfer(address indexed from, address indexed to, uint256 value);
    event Approval(address indexed owner, address indexed spender, uint256 value);
    function totalSupply() external view returns (uint256);
    function balanceOf(address account) external view returns (uint256);
    function transfer(address to, uint256 value) external returns (bool);
    function allowance(address owner, address spender) external view returns (uint256);
    function approve(address spender, uint256 value) external returns (bool);
    function transferFrom(address from, address to, uint256 value) external returns (bool);
}

abstract contract ERC20 is Context, IERC20 {
    mapping(address => uint256) private _balances;
    mapping(address => mapping(address => uint256)) private _allowances;
    uint256 private _totalSupply;
    string private _name;
    string private _symbol;

    constructor(string memory name_, string memory symbol_) {
        _name = name_;
        _symbol = symbol_;
    }

    function name() public view returns (string memory) { return _name; }
    function symbol() public view returns (string memory) { return _symbol; }
    function decimals() public pure returns (uint8) { return 18; }
    function totalSupply() public view override returns (uint256) { return _totalSupply; }
    function balanceOf(address account) public view override returns (uint256) { return _balances[account]; }

    function transfer(address to, uint256 value) public override returns (bool) {
        _transfer(_msgSender(), to, value);
        return true;
    }

    function allowance(address owner, address spender) public view override returns (uint256) {
        return _allowances[owner][spender];
    }

    function approve(address spender, uint256 value) public override returns (bool) {
        _approve(_msgSender(), spender, value);
        return true;
    }

    function transferFrom(address from, address to, uint256 value) public override returns (bool) {
        address spender = _msgSender();
        uint256 currentAllowance = _allowances[from][spender];
        if (currentAllowance != type(uint256).max) {
            require(currentAllowance >= value, "ERC20: insufficient allowance");
            unchecked { _approve(from, spender, currentAllowance - value); }
        }
        _transfer(from, to, value);
        return true;
    }

    function _transfer(address from, address to, uint256 value) internal virtual {
        require(from != address(0) && to != address(0), "ERC20: zero address");
        _update(from, to, value);
    }

    function _update(address from, address to, uint256 value) internal virtual {
        if (from == address(0)) {
            _totalSupply += value;
        } else {
            uint256 fromBalance = _balances[from];
            require(fromBalance >= value, "ERC20: insufficient balance");
            unchecked { _balances[from] = fromBalance - value; }
        }

        if (to == address(0)) {
            unchecked { _totalSupply -= value; }
        } else {
            unchecked { _balances[to] += value; }
        }

        emit Transfer(from, to, value);
    }

    function _mint(address account, uint256 value) internal {
        require(account != address(0), "ERC20: mint to zero");
        _update(address(0), account, value);
    }

    function _burn(address account, uint256 value) internal {
        require(account != address(0), "ERC20: burn from zero");
        _update(account, address(0), value);
    }

    function _approve(address owner, address spender, uint256 value) internal {
        require(owner != address(0) && spender != address(0), "ERC20: zero address");
        _allowances[owner][spender] = value;
        emit Approval(owner, spender, value);
    }
}

abstract contract AccessControl {
    struct RoleData {
        mapping(address => bool) hasRole;
        bytes32 adminRole;
    }
    mapping(bytes32 => RoleData) private _roles;
    bytes32 public constant DEFAULT_ADMIN_ROLE = 0x00;

    event RoleGranted(bytes32 indexed role, address indexed account, address indexed sender);

    modifier onlyRole(bytes32 role) {
        require(_roles[role].hasRole[msg.sender], "AccessControl: missing role");
        _;
    }

    function hasRole(bytes32 role, address account) public view returns (bool) {
        return _roles[role].hasRole[account];
    }

    function grantRole(bytes32 role, address account) public onlyRole(DEFAULT_ADMIN_ROLE) {
        _grantRole(role, account);
    }

    function _grantRole(bytes32 role, address account) internal {
        if (!_roles[role].hasRole[account]) {
            _roles[role].hasRole[account] = true;
            emit RoleGranted(role, account, msg.sender);
        }
    }
}

abstract contract Pausable is Context {
    bool private _paused;
    event Paused(address account);
    event Unpaused(address account);

    constructor() { _paused = false; }

    modifier whenNotPaused() {
        require(!_paused, "Pausable: paused");
        _;
    }

    function paused() public view returns (bool) { return _paused; }
    function _pause() internal whenNotPaused { _paused = true; emit Paused(_msgSender()); }
    function _unpause() internal { _paused = false; emit Unpaused(_msgSender()); }
}

abstract contract ReentrancyGuard {
    uint256 private constant NOT_ENTERED = 1;
    uint256 private constant ENTERED = 2;
    uint256 private _status = NOT_ENTERED;

    modifier nonReentrant() {
        require(_status != ENTERED, "ReentrancyGuard: reentrant call");
        _status = ENTERED;
        _;
        _status = NOT_ENTERED;
    }
}

// ═══════════════════════════════════════════════════════════════════════════
//  SYNA Token
// ═══════════════════════════════════════════════════════════════════════════
contract SYNA is ERC20, AccessControl, Pausable, ReentrancyGuard {
    bytes32 public constant MINTER_ROLE = keccak256("MINTER_ROLE");
    bytes32 public constant BURNER_ROLE = keccak256("BURNER_ROLE");
    bytes32 public constant PAUSER_ROLE = keccak256("PAUSER_ROLE");

    uint256 public constant MAX_SUPPLY = 1_000_000_000e18;
    uint256 public constant INITIAL_SUPPLY = 10_000_000e18;
    uint256 public constant MAX_SINGLE_MINT = 10_000_000e18;

    constructor(address admin_) ERC20("Sinergy Anchor", "SYNA") {
        require(admin_ != address(0), "zero admin");
        _grantRole(DEFAULT_ADMIN_ROLE, admin_);
        _grantRole(MINTER_ROLE, admin_);
        _grantRole(BURNER_ROLE, admin_);
        _grantRole(PAUSER_ROLE, admin_);
        _mint(admin_, INITIAL_SUPPLY);
    }

    function mint(address to, uint256 amount) external nonReentrant whenNotPaused onlyRole(MINTER_ROLE) {
        require(to != address(0) && amount > 0, "invalid");
        require(amount <= MAX_SINGLE_MINT, "exceeds mint cap");
        require(totalSupply() + amount <= MAX_SUPPLY, "exceeds max supply");
        _mint(to, amount);
    }

    function burn(uint256 amount) external { _burn(msg.sender, amount); }
    function pause() external onlyRole(PAUSER_ROLE) { _pause(); }
    function unpause() external onlyRole(PAUSER_ROLE) { _unpause(); }
}

// ═══════════════════════════════════════════════════════════════════════════
//  SYNC Token
// ═══════════════════════════════════════════════════════════════════════════
contract SYNC is ERC20, AccessControl, Pausable, ReentrancyGuard {
    bytes32 public constant MINTER_ROLE = keccak256("MINTER_ROLE");
    bytes32 public constant BURNER_ROLE = keccak256("BURNER_ROLE");
    bytes32 public constant PAUSER_ROLE = keccak256("PAUSER_ROLE");

    uint256 public constant MAX_SUPPLY = 10_000_000_000e18;
    uint256 public constant INITIAL_SUPPLY = 100_000_000e18;
    uint256 public constant MAX_SINGLE_MINT = 50_000_000e18;

    constructor(address admin_) ERC20("Sinergy Cycle", "SYNC") {
        require(admin_ != address(0), "zero admin");
        _grantRole(DEFAULT_ADMIN_ROLE, admin_);
        _grantRole(MINTER_ROLE, admin_);
        _grantRole(BURNER_ROLE, admin_);
        _grantRole(PAUSER_ROLE, admin_);
        _mint(admin_, INITIAL_SUPPLY);
    }

    function mint(address to, uint256 amount) external nonReentrant whenNotPaused onlyRole(MINTER_ROLE) {
        require(to != address(0) && amount > 0, "invalid");
        require(amount <= MAX_SINGLE_MINT, "exceeds mint cap");
        require(totalSupply() + amount <= MAX_SUPPLY, "exceeds max supply");
        _mint(to, amount);
    }

    function burn(uint256 amount) external { _burn(msg.sender, amount); }
    function pause() external onlyRole(PAUSER_ROLE) { _pause(); }
    function unpause() external onlyRole(PAUSER_ROLE) { _unpause(); }
}

// ═══════════════════════════════════════════════════════════════════════════
//  SYNR Token
// ═══════════════════════════════════════════════════════════════════════════
contract SYNR is ERC20, AccessControl, Pausable, ReentrancyGuard {
    bytes32 public constant MINTER_ROLE = keccak256("MINTER_ROLE");
    bytes32 public constant BURNER_ROLE = keccak256("BURNER_ROLE");
    bytes32 public constant PAUSER_ROLE = keccak256("PAUSER_ROLE");

    uint256 public constant MAX_SUPPLY = 1_000_000_000e18;
    uint256 public constant INITIAL_SUPPLY = 21_000_000e18;
    uint256 public constant MAX_SINGLE_MINT = 5_000_000e18;

    uint256 public totalBurned;

    constructor(address admin_) ERC20("Sinergy Rise", "SYNR") {
        require(admin_ != address(0), "zero admin");
        _grantRole(DEFAULT_ADMIN_ROLE, admin_);
        _grantRole(MINTER_ROLE, admin_);
        _grantRole(BURNER_ROLE, admin_);
        _grantRole(PAUSER_ROLE, admin_);
        _mint(admin_, INITIAL_SUPPLY);
    }

    function mint(address to, uint256 amount) external nonReentrant whenNotPaused onlyRole(MINTER_ROLE) {
        require(to != address(0) && amount > 0, "invalid");
        require(amount <= MAX_SINGLE_MINT, "exceeds mint cap");
        require(totalSupply() + amount <= MAX_SUPPLY, "exceeds max supply");
        _mint(to, amount);
    }

    function burn(uint256 amount) external {
        _burn(msg.sender, amount);
        totalBurned += amount;
    }
    function pause() external onlyRole(PAUSER_ROLE) { _pause(); }
    function unpause() external onlyRole(PAUSER_ROLE) { _unpause(); }
}

// ═══════════════════════════════════════════════════════════════════════════
//  ALTN Token (простой)
// ═══════════════════════════════════════════════════════════════════════════
contract ALTN is ERC20, AccessControl, Pausable, ReentrancyGuard {
    bytes32 public constant MINTER_ROLE = keccak256("MINTER_ROLE");
    bytes32 public constant BURNER_ROLE = keccak256("BURNER_ROLE");
    bytes32 public constant PAUSER_ROLE = keccak256("PAUSER_ROLE");

    uint256 public constant MAX_SUPPLY = 1_000_000_000e18;
    uint256 public constant INITIAL_SUPPLY = 10_000_000e18;
    uint256 public constant MAX_SINGLE_MINT = 10_000_000e18;

    constructor(address admin_) ERC20("Altyn Token", "ALTN") {
        require(admin_ != address(0), "zero admin");
        _grantRole(DEFAULT_ADMIN_ROLE, admin_);
        _grantRole(MINTER_ROLE, admin_);
        _grantRole(BURNER_ROLE, admin_);
        _grantRole(PAUSER_ROLE, admin_);
        _mint(admin_, INITIAL_SUPPLY);
    }

    function mint(address to, uint256 amount) external nonReentrant whenNotPaused onlyRole(MINTER_ROLE) {
        require(to != address(0) && amount > 0, "invalid");
        require(amount <= MAX_SINGLE_MINT, "exceeds mint cap");
        require(totalSupply() + amount <= MAX_SUPPLY, "exceeds max supply");
        _mint(to, amount);
    }

    function burn(uint256 amount) external { _burn(msg.sender, amount); }
    function pause() external onlyRole(PAUSER_ROLE) { _pause(); }
    function unpause() external onlyRole(PAUSER_ROLE) { _unpause(); }
}
'''

from solcx import compile_source, install_solc, set_solc_version

try:
    set_solc_version('0.8.20')
except:
    print("Устанавливаю solc 0.8.20...")
    install_solc('0.8.20')
    set_solc_version('0.8.20')

print("\nКомпиляция inline токенов...")
compiled = compile_source(
    TOKENS_INLINE,
    output_values=['abi', 'bin'],
    solc_version='0.8.20',
    optimize=True,
    optimize_runs=200
)

nonce = w3.eth.get_transaction_count(C(OWNER), "pending")
deployed = {"tokens": {}, "pools": {}}

def deploy(name, abi, bytecode, args=None):
    global nonce
    print(f"\n[DEPLOY] {name}...", flush=True)

    base = w3.eth.get_block("latest").get("baseFeePerGas", int(100e9))
    prio = int(50e9)
    mf = base * 2 + prio

    contract = w3.eth.contract(abi=abi, bytecode=bytecode)

    try:
        if args:
            tx = contract.constructor(*args).build_transaction({
                "from": C(OWNER), "nonce": nonce, "chainId": 137, "type": 2,
                "maxPriorityFeePerGas": prio, "maxFeePerGas": mf, "gas": 5000000
            })
        else:
            tx = contract.constructor().build_transaction({
                "from": C(OWNER), "nonce": nonce, "chainId": 137, "type": 2,
                "maxPriorityFeePerGas": prio, "maxFeePerGas": mf, "gas": 5000000
            })

        signed = w3.eth.account.sign_transaction(tx, PK)
        tx_hash = w3.eth.send_raw_transaction(signed.raw_transaction)
        print(f"  TX: {tx_hash.hex()[:20]}...", flush=True)

        receipt = w3.eth.wait_for_transaction_receipt(tx_hash, timeout=300)
        gas_cost = receipt.gasUsed * mf / 1e18

        if receipt.status == 1:
            addr = receipt.contractAddress
            print(f"  [OK] {addr} (gas: {gas_cost:.4f} POL)", flush=True)
            nonce += 1
            return addr, abi
        else:
            print(f"  [FAIL] reverted")
            nonce += 1
            return None, None
    except Exception as e:
        print(f"  [ERROR] {e}")
        return None, None

# Деплой токенов
print("\n" + "=" * 50)
print("[1/4] ДЕПЛОЙ ТОКЕНОВ")
print("=" * 50)

for name in ["SYNA", "SYNC", "SYNR", "ALTN"]:
    key = f"<stdin>:{name}"
    if key in compiled:
        abi = compiled[key]['abi']
        bytecode = compiled[key]['bin']
        addr, _ = deploy(name, abi, bytecode, [C(OWNER)])
        if addr:
            deployed["tokens"][name] = addr
            deployed[f"{name}_abi"] = abi
        time.sleep(3)

print(f"\nБаланс после деплоя токенов: {w3.eth.get_balance(C(OWNER)) / 1e18:.4f} POL")

# Сохраняем
deployed["deployed_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
deployed["owner"] = OWNER
deployed["network"] = "Polygon Mainnet"
deployed["version"] = "v2_with_access_control"

with open("deployed_v2.json", "w") as f:
    json.dump({k: v for k, v in deployed.items() if not k.endswith("_abi")}, f, indent=2)

print("\n" + "=" * 70)
print("ТОКЕНЫ ЗАДЕПЛОЕНЫ!")
print("=" * 70)
for name, addr in deployed["tokens"].items():
    print(f"  {name}: {addr}")
print(f"\nСохранено в deployed_v2.json")
print(f"Баланс: {w3.eth.get_balance(C(OWNER)) / 1e18:.4f} POL")
