// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {AccessControl} from "@openzeppelin/contracts/access/AccessControl.sol";
import {Pausable} from "@openzeppelin/contracts/utils/Pausable.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";

/**
 * @title SHTENCOAICentralBank
 * @notice Timelocked, policy-constrained execution layer for an off-chain AI
 *         optimizer. The AI can propose only allowlisted target/selectors; a
 *         separate executor submits the transaction after the delay, while a
 *         guardian can cancel or pause.
 */
contract SHTENCOAICentralBank is AccessControl, Pausable, ReentrancyGuard {
    bytes32 public constant AI_PROPOSER_ROLE = keccak256("AI_PROPOSER_ROLE");
    bytes32 public constant EXECUTOR_ROLE = keccak256("EXECUTOR_ROLE");
    bytes32 public constant POLICY_ROLE = keccak256("POLICY_ROLE");
    bytes32 public constant GUARDIAN_ROLE = keccak256("GUARDIAN_ROLE");

    uint256 public constant MAX_ACTIONS = 8;
    uint256 public constant BPS = 10_000;

    struct Action {
        address target;
        uint256 value;
        bytes data;
        address budgetToken;
        uint256 budgetAmount;
    }

    struct Proposal {
        address proposer;
        uint64 proposedAt;
        uint64 executeAfter;
        uint64 expiresAt;
        uint16 scoreBps;
        uint16 riskBps;
        bytes32 stateHash;
        bytes32 objectiveHash;
        bool executed;
        bool cancelled;
    }

    struct DailyBudget {
        uint64 day;
        uint192 amount;
    }

    uint256 public proposalNonce;
    uint256 public minDelay = 15 minutes;
    uint256 public maxDelay = 7 days;
    uint256 public maxExecutionWindow = 2 days;
    uint16 public minimumScoreBps = 5_000;
    uint16 public maximumRiskBps = 2_500;

    mapping(address => bool) public targetEnabled;
    mapping(address => mapping(bytes4 => bool)) public selectorEnabled;
    mapping(address => mapping(bytes4 => bool)) public selectorBudgetRequired;
    mapping(address => uint256) public dailyBudgetLimit;
    mapping(address => DailyBudget) private _dailyBudget;

    mapping(bytes32 => Proposal) public proposals;
    mapping(bytes32 => Action[]) private _actions;

    event TargetPolicySet(address indexed target, bool enabled);
    event SelectorPolicySet(address indexed target, bytes4 indexed selector, bool enabled);
    event SelectorBudgetPolicySet(address indexed target, bytes4 indexed selector, bool required);
    event BudgetLimitSet(address indexed token, uint256 dailyLimit);
    event RiskPolicySet(uint16 minimumScoreBps, uint16 maximumRiskBps);
    event DelayPolicySet(uint256 minDelay, uint256 maxDelay, uint256 maxExecutionWindow);
    event ProposalCreated(
        bytes32 indexed proposalId,
        address indexed proposer,
        uint256 executeAfter,
        uint256 expiresAt,
        uint256 scoreBps,
        uint256 riskBps,
        bytes32 stateHash,
        bytes32 objectiveHash,
        uint256 actionCount
    );
    event ProposalCancelled(bytes32 indexed proposalId, address indexed guardian);
    event ActionExecuted(bytes32 indexed proposalId, uint256 indexed actionIndex, address indexed target, bytes4 selector);
    event ProposalExecuted(bytes32 indexed proposalId, address indexed executor);

    constructor(address admin, address aiProposer, address executor, address guardian) {
        require(
            admin != address(0) && aiProposer != address(0) &&
            executor != address(0) && guardian != address(0),
            "AI-CB: bad init"
        );
        _grantRole(DEFAULT_ADMIN_ROLE, admin);
        _grantRole(POLICY_ROLE, admin);
        _grantRole(AI_PROPOSER_ROLE, aiProposer);
        _grantRole(EXECUTOR_ROLE, executor);
        _grantRole(GUARDIAN_ROLE, guardian);
    }

    function propose(
        Action[] calldata actions,
        bytes32 stateHash,
        bytes32 objectiveHash,
        uint16 scoreBps,
        uint16 riskBps,
        uint64 executeAfter,
        uint64 expiresAt
    ) external onlyRole(AI_PROPOSER_ROLE) whenNotPaused returns (bytes32 proposalId) {
        require(actions.length > 0 && actions.length <= MAX_ACTIONS, "AI-CB: bad action count");
        require(stateHash != bytes32(0) && objectiveHash != bytes32(0), "AI-CB: empty evidence");
        require(scoreBps >= minimumScoreBps && scoreBps <= BPS, "AI-CB: score below policy");
        require(riskBps <= maximumRiskBps, "AI-CB: risk above policy");
        require(executeAfter >= block.timestamp + minDelay, "AI-CB: delay too short");
        require(executeAfter <= block.timestamp + maxDelay, "AI-CB: delay too long");
        require(expiresAt > executeAfter && expiresAt <= executeAfter + maxExecutionWindow, "AI-CB: bad expiry");

        bytes32 actionsHash;
        uint256 totalNativeValue;
        for (uint256 i; i < actions.length; ++i) {
            _validateAction(actions[i]);
            totalNativeValue += actions[i].value;
            actionsHash = keccak256(abi.encode(actionsHash, actions[i].target, actions[i].value, keccak256(actions[i].data), actions[i].budgetToken, actions[i].budgetAmount));
        }
        require(totalNativeValue <= address(this).balance, "AI-CB: native budget total");

        proposalId = keccak256(abi.encode(
            block.chainid,
            address(this),
            ++proposalNonce,
            msg.sender,
            actionsHash,
            stateHash,
            objectiveHash,
            scoreBps,
            riskBps,
            executeAfter,
            expiresAt
        ));

        proposals[proposalId] = Proposal({
            proposer: msg.sender,
            proposedAt: uint64(block.timestamp),
            executeAfter: executeAfter,
            expiresAt: expiresAt,
            scoreBps: scoreBps,
            riskBps: riskBps,
            stateHash: stateHash,
            objectiveHash: objectiveHash,
            executed: false,
            cancelled: false
        });
        for (uint256 i; i < actions.length; ++i) _actions[proposalId].push(actions[i]);

        emit ProposalCreated(
            proposalId,
            msg.sender,
            executeAfter,
            expiresAt,
            scoreBps,
            riskBps,
            stateHash,
            objectiveHash,
            actions.length
        );
    }

    function execute(bytes32 proposalId)
        external
        onlyRole(EXECUTOR_ROLE)
        nonReentrant
        whenNotPaused
        returns (bytes[] memory results)
    {
        Proposal storage proposal = proposals[proposalId];
        require(proposal.proposer != address(0), "AI-CB: unknown proposal");
        require(!proposal.executed && !proposal.cancelled, "AI-CB: closed proposal");
        require(block.timestamp >= proposal.executeAfter, "AI-CB: timelocked");
        require(block.timestamp <= proposal.expiresAt, "AI-CB: expired");

        Action[] storage actions = _actions[proposalId];
        results = new bytes[](actions.length);
        proposal.executed = true;

        for (uint256 i; i < actions.length; ++i) {
            Action storage action = actions[i];
            _validateStoredAction(action);
            _consumeBudget(action.budgetToken, action.budgetAmount);
            (bool success, bytes memory result) = action.target.call{value: action.value}(action.data);
            if (!success) _bubbleRevert(result);
            results[i] = result;
            emit ActionExecuted(proposalId, i, action.target, _selector(action.data));
        }

        emit ProposalExecuted(proposalId, msg.sender);
    }

    function cancel(bytes32 proposalId) external onlyRole(GUARDIAN_ROLE) {
        Proposal storage proposal = proposals[proposalId];
        require(proposal.proposer != address(0), "AI-CB: unknown proposal");
        require(!proposal.executed && !proposal.cancelled, "AI-CB: closed proposal");
        proposal.cancelled = true;
        emit ProposalCancelled(proposalId, msg.sender);
    }

    function _validateAction(Action calldata action) internal view {
        require(action.target != address(0) && action.data.length >= 4, "AI-CB: malformed action");
        require(targetEnabled[action.target], "AI-CB: target disabled");
        bytes4 selector = _selector(action.data);
        require(selectorEnabled[action.target][selector], "AI-CB: selector disabled");
        if (selectorBudgetRequired[action.target][selector]) {
            require(action.budgetToken != address(0) && action.budgetAmount > 0, "AI-CB: budget required");
        }
        require(action.budgetAmount == 0 || action.budgetToken != address(0), "AI-CB: zero budget token");
        require(action.value <= address(this).balance, "AI-CB: native budget");
    }

    function _validateStoredAction(Action storage action) internal view {
        require(targetEnabled[action.target], "AI-CB: target disabled");
        bytes4 selector = _selector(action.data);
        require(selectorEnabled[action.target][selector], "AI-CB: selector disabled");
        if (selectorBudgetRequired[action.target][selector]) {
            require(action.budgetToken != address(0) && action.budgetAmount > 0, "AI-CB: budget required");
        }
    }

    function _consumeBudget(address token, uint256 amount) internal {
        if (amount == 0) return;
        DailyBudget storage budget = _dailyBudget[token];
        uint64 day = uint64(block.timestamp / 1 days);
        if (budget.day != day) {
            budget.day = day;
            budget.amount = 0;
        }
        uint256 next = uint256(budget.amount) + amount;
        uint256 limit = dailyBudgetLimit[token];
        require(limit != 0 && next <= limit, "AI-CB: daily budget");
        require(next <= type(uint192).max, "AI-CB: budget overflow");
        budget.amount = uint192(next);
    }

    function _selector(bytes memory data) internal pure returns (bytes4 selector) {
        require(data.length >= 4, "AI-CB: missing selector");
        assembly ("memory-safe") { selector := mload(add(data, 32)) }
    }

    function _bubbleRevert(bytes memory reason) internal pure {
        if (reason.length == 0) revert("AI-CB: action failed");
        assembly ("memory-safe") { revert(add(reason, 32), mload(reason)) }
    }

    function setTarget(address target, bool enabled) external onlyRole(POLICY_ROLE) {
        require(target != address(0) && target != address(this), "AI-CB: invalid target");
        require(!enabled || target.code.length > 0, "AI-CB: target has no code");
        targetEnabled[target] = enabled;
        emit TargetPolicySet(target, enabled);
    }

    function setSelector(address target, bytes4 selector, bool enabled) external onlyRole(POLICY_ROLE) {
        require(target != address(0) && selector != bytes4(0), "AI-CB: bad selector");
        selectorEnabled[target][selector] = enabled;
        emit SelectorPolicySet(target, selector, enabled);
    }

    function setSelectorBudgetRequired(address target, bytes4 selector, bool required)
        external onlyRole(POLICY_ROLE)
    {
        require(targetEnabled[target] && selectorEnabled[target][selector], "AI-CB: selector not enabled");
        selectorBudgetRequired[target][selector] = required;
        emit SelectorBudgetPolicySet(target, selector, required);
    }

    function setBudgetLimit(address token, uint256 dailyLimit) external onlyRole(POLICY_ROLE) {
        dailyBudgetLimit[token] = dailyLimit;
        emit BudgetLimitSet(token, dailyLimit);
    }

    function setRiskPolicy(uint16 minScore, uint16 maxRisk) external onlyRole(POLICY_ROLE) {
        require(minScore <= BPS && maxRisk <= BPS, "AI-CB: bad risk policy");
        minimumScoreBps = minScore;
        maximumRiskBps = maxRisk;
        emit RiskPolicySet(minScore, maxRisk);
    }

    function setDelayPolicy(uint256 minDelay_, uint256 maxDelay_, uint256 executionWindow)
        external onlyRole(POLICY_ROLE)
    {
        require(minDelay_ >= 1 minutes && maxDelay_ >= minDelay_ && maxDelay_ <= 30 days, "AI-CB: bad delay");
        require(executionWindow >= 1 hours && executionWindow <= 7 days, "AI-CB: bad window");
        minDelay = minDelay_;
        maxDelay = maxDelay_;
        maxExecutionWindow = executionWindow;
        emit DelayPolicySet(minDelay_, maxDelay_, executionWindow);
    }

    function getActionCount(bytes32 proposalId) external view returns (uint256) {
        return _actions[proposalId].length;
    }

    function getAction(bytes32 proposalId, uint256 index) external view returns (Action memory) {
        return _actions[proposalId][index];
    }

    function budgetUsedToday(address token) external view returns (uint256) {
        DailyBudget memory budget = _dailyBudget[token];
        return budget.day == uint64(block.timestamp / 1 days) ? budget.amount : 0;
    }

    function pause() external onlyRole(GUARDIAN_ROLE) { _pause(); }
    function unpause() external onlyRole(DEFAULT_ADMIN_ROLE) { _unpause(); }

    receive() external payable {}
}
