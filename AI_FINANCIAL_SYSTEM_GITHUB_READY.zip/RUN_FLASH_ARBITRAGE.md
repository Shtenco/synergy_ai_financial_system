# Запуск безопасного Flash Loan Arbitrage

## Что реализовано

Система ищет только такие маршруты, где текущая котировка покрывает:

`principal + live Aave premium + gas reserve × safety multiplier + minimum net profit`

После получения займа смарт-контракт повторно проверяет конечный баланс. При недостаче хотя бы 1 wei вся транзакция откатывается. Газ не возвращается при revert, поэтому бот до отправки выполняет полный `eth_call` и `estimate_gas`.

## 1. Установка

Windows PowerShell из папки `D:\SYNA_FINANCIAL_SYSTEMS\FINAL\INSTANT_DEPLOY`:

```powershell
npm install
npm test
py -m pip install -r requirements_flash_arb.txt
Copy-Item .env.flash.example .env.flash
```

## 2. Настройка `.env.flash`

Обязательно заполнить:

```env
POLYGON_RPC_URL=https://ВАШ_ЗАЩИЩЕННЫЙ_POLYGON_RPC
OWNER_PRIVATE_KEY=0x...
OWNER_ADDRESS=0x...
```

Для отдельного bot wallet:

```env
BOT_PRIVATE_KEY=0x...
BOT_ADDRESS=0x...
```

Никогда не помещать private key в `.py`, `.sol`, JSON или git.

## 3. Проверка без отправки транзакций

```powershell
py flash_arb_bot.py --once --top 10
```

По умолчанию бот работает только как scanner. Он проверяет существование всех пар через QuickSwap Factory, перебирает размеры займа геометрической сеткой и выводит только те котировки, которые покрывают все заданные расходы.

Если mutual TOKEN/TOKEN пары ещё не созданы, треугольные маршруты из `flash_arb_config.json` будут пропущены. Это корректное поведение, а не ошибка.

## 4. Деплой нового исполнителя

```powershell
py DEPLOY_FLASH_ARBITRAGE.py --max-flash-wpol 100 --yes
```

Скрипт:

- отказывается работать не в chain ID 137;
- деплоит `FlashLoanArbitrage`;
- разрешает только настроенный QuickSwap V2 Router;
- разрешает WPOL, SYNA, SYNC и SYNR;
- не разрешает ALTN по умолчанию из-за fee-on-transfer;
- сохраняет адрес и transaction hashes в `deployed_flash_arbitrage.json`.

Проверьте код и адрес на PolygonScan до включения live-режима.

## 5. Live-режим

Сначала запустите scanner длительно и убедитесь, что opportunities появляются стабильно:

```powershell
py flash_arb_bot.py
```

Только после проверки:

```powershell
py flash_arb_bot.py --live --yes
```

Live-режим требует одновременно `--live` и `--yes`. Перед подписью бот пересчитывает gas reserve, выполняет `estimate_gas` и полный atomic preflight через `eth_call`.

## 6. Основные настройки

Файл `flash_arb_config.json`:

- `minimum_loan_wpol` / `maximum_loan_wpol` — диапазон principal;
- `amount_samples` — число тестируемых размеров;
- `slippage_bps` — допустимое проскальзывание;
- `minimum_net_profit_wpol` — прибыль после premium и gas reserve;
- `gas_safety_multiplier` — запас на изменение газа;
- `poll_seconds` — частота сканирования;
- `route_templates` — циклические маршруты, начинающиеся и заканчивающиеся WPOL.

Начинайте с маленького `maximum_loan_wpol`. Больший flash loan часто ухудшает цену сильнее, чем увеличивает gross profit.

## 7. Ограничения

- Прибыль не гарантирована: если цены сбалансированы, бот не должен отправлять транзакцию.
- Публичный mempool позволяет конкурентам скопировать или опередить сделку. Для live рекомендуется защищённая/private transaction delivery, совместимая с Polygon.
- `eth_call` не гарантирует результат следующего блока: котировка может измениться между simulation и inclusion.
- Треугольный маршрут требует всех трёх реально ликвидных пар.
- ALTN исключён из стандартных маршрутов из-за transfer tax.
- Основной TROIKA Vault, EmissionEngine и CollateralEmission не используются новым flash-контрактом.
