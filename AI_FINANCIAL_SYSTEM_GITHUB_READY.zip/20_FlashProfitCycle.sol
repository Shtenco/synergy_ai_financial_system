// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  TROIKA FLASH LOAN PROFIT CYCLE
 *
 *  ЕДИНСТВЕННЫЙ СПОСОБ ПОЛУЧИТЬ ГАРАНТИРОВАННУЮ ПРИБЫЛЬ:
 *  ══════════════════════════════════════════════════════
 *
 *  1. Flash Loan WPOL из Aave
 *  2. addLiquidity (увеличиваем TVL пулов)
 *  3. executeEmission() - создаются НОВЫЕ токены (инфляция)
 *  4. 30% эмиссии → Founder (в WPOL)
 *  5. 62% эмиссии → LP pools (NAV растёт)
 *  6. removeLiquidity - получаем больше чем вложили
 *  7. Swap excess tokens → WPOL
 *  8. Return Flash Loan + 0.05% fee
 *  9. PROFIT = founder_share + lp_gain - fees - gas
 *
 *  КЛЮЧ: Мы OWNER системы, поэтому 30% эмиссии идёт НАМ как founder!
 * ═══════════════════════════════════════════════════════════════════════════
 */

import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import "@aave/core-v3/contracts/flashloan/base/FlashLoanSimpleReceiverBase.sol";
import "@aave/core-v3/contracts/interfaces/IPoolAddressesProvider.sol";
import "./01_PolygonConfig.sol";

interface ITroikaVault {
    function deposit(uint256 wpolAmount) external returns (uint256 lpMinted);
    function withdraw(uint256 lpAmount) external returns (uint256 wpolOut);
    function totalLP() external view returns (uint256);
    function freeWpol() external view returns (uint256);
}

interface IEmissionEngine {
    function executeEmission() external;
    function isEmissionDue() external view returns (bool);
}

interface IDividendPool {
    function founderPending() external view returns (uint256);
    function withdrawFounder() external;
}

interface IWPOL {
    function deposit() external payable;
    function withdraw(uint256) external;
    function balanceOf(address) external view returns (uint256);
    function approve(address, uint256) external returns (bool);
    function transfer(address, uint256) external returns (bool);
}

contract FlashProfitCycle is FlashLoanSimpleReceiverBase {
    using SafeERC20 for IERC20;

    address public immutable owner;
    address public immutable wpol;
    ITroikaVault public immutable vault;
    IEmissionEngine public immutable emissionEngine;
    IDividendPool public immutable dividendPool;

    // Stats
    uint256 public totalCycles;
    uint256 public totalProfit;
    uint256 public lastCycleBlock;

    event CycleExecuted(
        uint256 flashAmount,
        uint256 lpMinted,
        uint256 lpBurned,
        uint256 founderWithdrawn,
        int256 netProfit
    );

    error NotOwner();
    error EmissionNotDue();
    error NoProfitPossible();

    constructor(
        address poolProvider_,
        address vault_,
        address emissionEngine_,
        address dividendPool_
    ) FlashLoanSimpleReceiverBase(IPoolAddressesProvider(poolProvider_)) {
        owner = msg.sender;
        wpol = PolygonConfig.WPOL;
        vault = ITroikaVault(vault_);
        emissionEngine = IEmissionEngine(emissionEngine_);
        dividendPool = IDividendPool(dividendPool_);

        // Pre-approve
        IERC20(wpol).approve(address(vault_), type(uint256).max);
        IERC20(wpol).approve(address(POOL), type(uint256).max);
    }

    modifier onlyOwner() {
        if (msg.sender != owner) revert NotOwner();
        _;
    }

    /**
     * @notice Основной профитный цикл
     * @param flashAmount Сумма Flash Loan в WPOL (wei)
     */
    function executeProfitCycle(uint256 flashAmount) external onlyOwner {
        if (!emissionEngine.isEmissionDue()) revert EmissionNotDue();

        // Запоминаем баланс до
        uint256 wpolBefore = IWPOL(wpol).balanceOf(address(this));

        // Берём Flash Loan из Aave
        // executeOperation будет вызван автоматически
        POOL.flashLoanSimple(
            address(this),      // receiver
            wpol,               // asset
            flashAmount,        // amount
            "",                 // params (empty)
            0                   // referralCode
        );

        // После возврата Flash Loan - считаем профит
        uint256 wpolAfter = IWPOL(wpol).balanceOf(address(this));
        int256 profit = int256(wpolAfter) - int256(wpolBefore);

        totalCycles++;
        if (profit > 0) {
            totalProfit += uint256(profit);
        }
        lastCycleBlock = block.number;

        emit CycleExecuted(flashAmount, 0, 0, 0, profit);
    }

    /**
     * @notice Callback от Aave - здесь вся логика цикла
     */
    function executeOperation(
        address asset,
        uint256 amount,
        uint256 premium,
        address initiator,
        bytes calldata /* params */
    ) external override returns (bool) {
        require(msg.sender == address(POOL), "Invalid caller");
        require(initiator == address(this), "Invalid initiator");
        require(asset == wpol, "Invalid asset");

        // [1] Deposit WPOL в Vault → получаем LP
        uint256 lpMinted = vault.deposit(amount);

        // [2] Trigger emission - создаёт НОВЫЕ токены
        // 30% → founder (WPOL), 62% → LP pools
        if (emissionEngine.isEmissionDue()) {
            emissionEngine.executeEmission();
        }

        // [3] Получаем founder дивиденды (30% от эмиссии)
        uint256 founderPending = dividendPool.founderPending();
        if (founderPending > 0) {
            dividendPool.withdrawFounder();
        }

        // [4] Withdraw LP → получаем WPOL обратно (+ прибыль от emission)
        uint256 wpolFromLP = vault.withdraw(lpMinted);

        // [5] Вернуть Flash Loan + premium (0.05%)
        uint256 amountOwed = amount + premium;
        IERC20(wpol).approve(address(POOL), amountOwed);

        // Профит остаётся на контракте (включая founder dividends)
        return true;
    }

    /**
     * @notice Вывод накопленного профита owner'у
     */
    function withdrawProfit() external onlyOwner {
        uint256 balance = IWPOL(wpol).balanceOf(address(this));
        if (balance > 0) {
            IWPOL(wpol).transfer(owner, balance);
        }

        // Также вывести native POL если есть
        if (address(this).balance > 0) {
            payable(owner).transfer(address(this).balance);
        }
    }

    /**
     * @notice Оценка профита для данного flash amount
     */
    function estimateProfit(uint256 flashAmount) external view returns (
        uint256 estimatedLPMinted,
        uint256 estimatedEmissionValue,
        uint256 estimatedFounderShare,
        uint256 aaveFee,
        int256 estimatedNetProfit
    ) {
        // Aave fee = 0.05%
        aaveFee = flashAmount * 5 / 10000;

        // LP minted ≈ flashAmount / NAV
        // Упрощённо: при deposit WPOL, получаем пропорционально LP
        uint256 currentTotalLP = vault.totalLP();
        estimatedLPMinted = flashAmount; // Упрощение

        // Emission value зависит от supply и emitRate
        // Это примерная оценка на основе текущих параметров
        estimatedEmissionValue = 9e16; // ~0.09 WPOL (из расчётов)

        // Founder получает 30%
        estimatedFounderShare = estimatedEmissionValue * 30 / 100;

        // LP share 62%
        uint256 lpShare = estimatedEmissionValue * 62 / 100;

        // Наша доля от LP share зависит от нашего % в total LP
        // При большом flash amount наша доля большая
        uint256 newTotalLP = currentTotalLP + estimatedLPMinted;
        uint256 ourLPShare = lpShare * estimatedLPMinted / newTotalLP;

        // Net profit = founder_share + our_lp_share - aave_fee
        estimatedNetProfit = int256(estimatedFounderShare + ourLPShare) - int256(aaveFee);
    }

    /**
     * @notice Проверка готовности к циклу
     */
    function isReadyForCycle() external view returns (
        bool emissionDue,
        uint256 founderPending,
        uint256 currentBlock,
        uint256 blocksUntilNext
    ) {
        emissionDue = emissionEngine.isEmissionDue();
        founderPending = dividendPool.founderPending();
        currentBlock = block.number;
        // 50 blocks interval
        blocksUntilNext = emissionDue ? 0 : (lastCycleBlock + 50 > currentBlock ? lastCycleBlock + 50 - currentBlock : 0);
    }

    receive() external payable {}
}
