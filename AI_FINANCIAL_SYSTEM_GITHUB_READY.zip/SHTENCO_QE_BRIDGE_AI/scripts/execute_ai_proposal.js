const fs = require("fs");
const path = require("path");
const { ethers } = require("ethers");
const ABI = [
  "function execute(bytes32 proposalId) returns (bytes[] results)",
  "function proposals(bytes32) view returns (address proposer,uint64 proposedAt,uint64 executeAfter,uint64 expiresAt,uint16 scoreBps,uint16 riskBps,bytes32 stateHash,bytes32 objectiveHash,bool executed,bool cancelled)"
];
async function main() {
  const file = process.argv.find(x => x.endsWith(".json"));
  const broadcast = process.argv.includes("--broadcast");
  if (!file) throw new Error("Usage: node execute_ai_proposal.js submitted.json [--broadcast]");
  const submitted = JSON.parse(fs.readFileSync(file, "utf8"));
  const materializedPath = file.replace(/-submitted\.json$/, ".json");
  const materialized = fs.existsSync(materializedPath) ? JSON.parse(fs.readFileSync(materializedPath, "utf8")) : null;
  const centralBank = submitted.centralBank || materialized?.centralBank || process.env.AI_CENTRAL_BANK_ADDRESS;
  const proposalId = submitted.proposalId;
  const rpc = process.env.POLYGON_RPC_URL || process.env.RPC_URL;
  const key = process.env.EXECUTOR_PRIVATE_KEY;
  if (!centralBank || !proposalId || !rpc || !key) throw new Error("central bank, proposalId, RPC and EXECUTOR_PRIVATE_KEY are required");
  const provider = new ethers.JsonRpcProvider(rpc);
  const signer = new ethers.Wallet(key, provider);
  const contract = new ethers.Contract(centralBank, ABI, signer);
  const proposal = await contract.proposals(proposalId);
  const now = Math.floor(Date.now() / 1000);
  const preflight = { proposalId, executeAfter: Number(proposal.executeAfter), expiresAt: Number(proposal.expiresAt), executed: proposal.executed, cancelled: proposal.cancelled, now };
  console.log(JSON.stringify({ mode: broadcast ? "BROADCAST" : "DRY_RUN", preflight }, null, 2));
  if (!broadcast) return;
  if (process.env.LIVE_EXECUTION !== "1") throw new Error("LIVE_EXECUTION=1 is required for broadcast");
  if (proposal.executed || proposal.cancelled || now < Number(proposal.executeAfter) || now > Number(proposal.expiresAt)) throw new Error("proposal not executable now");
  const gas = await contract.execute.estimateGas(proposalId);
  const tx = await contract.execute(proposalId, { gasLimit: gas * 120n / 100n });
  const receipt = await tx.wait();
  const report = { proposalId, txHash: tx.hash, blockNumber: receipt.blockNumber, status: receipt.status };
  const out = path.join(path.dirname(file), path.basename(file, ".json") + "-executed.json");
  fs.writeFileSync(out, JSON.stringify(report, null, 2));
  console.log(JSON.stringify(report, null, 2));
}
main().catch(e => { console.error(e); process.exitCode = 1; });
