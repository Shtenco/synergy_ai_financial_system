#!/usr/bin/env python3
"""
РАСЧЁТ ТОП-ПРИБЫЛЬНОГО FLASH LOAN ЦИКЛА

Механика:
1. SNAPSHOT_START - все балансы системы
2. Flash Loan WPOL из Aave (0.05% fee)
3. Wrap POL → WPOL если нужно
4. addLiquidity в TroikaVault (через initialize или deposit)
5. executeEmission() - эмиссия новых токенов
6. removeLiquidity - забираем LP + накопленные токены
7. swap токены → WPOL
8. Return Flash Loan + fee
9. SNAPSHOT_END - все балансы
10. PROFIT = END - START
"""
import sys, io, os, json
from decimal import Decimal, getcontext
from dotenv import load_dotenv
from web3 import Web3
from web3.middleware import ExtraDataToPOAMiddleware

getcontext().prec = 50

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

load_dotenv()
w3 = Web3(Web3.HTTPProvider("https://polygon-bor-rpc.publicnode.com"))
w3.middleware_onion.inject(ExtraDataToPOAMiddleware, layer=0)

def C(a): return Web3.to_checksum_address(a)

with open("deployed_TROIKA_v3.json") as f:
    d = json.load(f)

OWNER = "0x6946999DBCE63b140B1bB9D475F7c357130909E5"
WPOL = "0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270"
AAVE_POOL = "0x794a61358D6845594F94dc1DB02A252b5b4814aD"

# ═══════════════════════════════════════════════════════════════════════════
# ПОЛУЧЕНИЕ ТЕКУЩЕГО СОСТОЯНИЯ СИСТЕМЫ
# ═══════════════════════════════════════════════════════════════════════════

def get_system_snapshot():
    """Полный снимок всех балансов системы"""

    TOKEN_ABI = [
        {"name": "balanceOf", "inputs": [{"type": "address"}], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
        {"name": "totalSupply", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    ]

    PAIR_ABI = [
        {"name": "getReserves", "inputs": [], "outputs": [{"type": "uint112"}, {"type": "uint112"}, {"type": "uint32"}], "stateMutability": "view", "type": "function"},
        {"name": "token0", "inputs": [], "outputs": [{"type": "address"}], "stateMutability": "view", "type": "function"},
        {"name": "totalSupply", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
        {"name": "balanceOf", "inputs": [{"type": "address"}], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    ]

    VAULT_ABI = [
        {"name": "lpR", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
        {"name": "lpT", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
        {"name": "lpP", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
        {"name": "totalLP", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
        {"name": "reserveR", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
        {"name": "traderReserve", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
        {"name": "freeWpol", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    ]

    snapshot = {
        "block": w3.eth.block_number,
        "owner": {},
        "vault": {},
        "pools": {},
        "tokens": {},
        "divpool": {},
        "total_system_wpol": Decimal(0),
        "total_system_value_wpol": Decimal(0),
    }

    # Owner balances
    snapshot["owner"]["POL"] = Decimal(w3.eth.get_balance(C(OWNER))) / Decimal(10**18)
    wpol_contract = w3.eth.contract(address=C(WPOL), abi=TOKEN_ABI)
    snapshot["owner"]["WPOL"] = Decimal(wpol_contract.functions.balanceOf(C(OWNER)).call()) / Decimal(10**18)

    for name, addr in d["tokens"].items():
        tk = w3.eth.contract(address=C(addr), abi=TOKEN_ABI)
        snapshot["owner"][name] = Decimal(tk.functions.balanceOf(C(OWNER)).call()) / Decimal(10**18)

    # Vault state
    vault = w3.eth.contract(address=C(d["vault"]), abi=VAULT_ABI)
    snapshot["vault"]["lpR"] = Decimal(vault.functions.lpR().call()) / Decimal(10**18)
    snapshot["vault"]["lpT"] = Decimal(vault.functions.lpT().call()) / Decimal(10**18)
    snapshot["vault"]["lpP"] = Decimal(vault.functions.lpP().call()) / Decimal(10**18)
    snapshot["vault"]["totalLP"] = Decimal(vault.functions.totalLP().call()) / Decimal(10**18)
    snapshot["vault"]["reserveR"] = Decimal(vault.functions.reserveR().call()) / Decimal(10**18)
    snapshot["vault"]["WPOL"] = Decimal(wpol_contract.functions.balanceOf(C(d["vault"])).call()) / Decimal(10**18)

    for name, addr in d["tokens"].items():
        tk = w3.eth.contract(address=C(addr), abi=TOKEN_ABI)
        snapshot["vault"][name] = Decimal(tk.functions.balanceOf(C(d["vault"])).call()) / Decimal(10**18)

    # Token supplies
    for name, addr in d["tokens"].items():
        tk = w3.eth.contract(address=C(addr), abi=TOKEN_ABI)
        snapshot["tokens"][name] = {
            "supply": Decimal(tk.functions.totalSupply().call()) / Decimal(10**18),
            "address": addr
        }

    # Pool reserves and LP tokens
    for pool_name, pool_addr in d["pools"].items():
        pair = w3.eth.contract(address=C(pool_addr), abi=PAIR_ABI)
        r0, r1, _ = pair.functions.getReserves().call()
        token0 = pair.functions.token0().call()
        lp_supply = Decimal(pair.functions.totalSupply().call()) / Decimal(10**18)
        vault_lp = Decimal(pair.functions.balanceOf(C(d["vault"])).call()) / Decimal(10**18)
        owner_lp = Decimal(pair.functions.balanceOf(C(OWNER)).call()) / Decimal(10**18)

        # Determine which is WPOL
        if token0.lower() == WPOL.lower():
            wpol_reserve = Decimal(r0) / Decimal(10**18)
            token_reserve = Decimal(r1) / Decimal(10**18)
        else:
            wpol_reserve = Decimal(r1) / Decimal(10**18)
            token_reserve = Decimal(r0) / Decimal(10**18)

        price_wpol = wpol_reserve / token_reserve if token_reserve > 0 else Decimal(0)

        snapshot["pools"][pool_name] = {
            "address": pool_addr,
            "wpol_reserve": wpol_reserve,
            "token_reserve": token_reserve,
            "lp_supply": lp_supply,
            "vault_lp": vault_lp,
            "owner_lp": owner_lp,
            "price_wpol": price_wpol,
            "tvl_wpol": wpol_reserve * 2  # TVL = 2 * WPOL reserve (AMM)
        }

    # DividendPool
    div_abi = [
        {"name": "founderPending", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    ]
    divpool = w3.eth.contract(address=C(d["divPool"]), abi=div_abi)
    snapshot["divpool"]["founderPending"] = Decimal(divpool.functions.founderPending().call()) / Decimal(10**18)
    snapshot["divpool"]["WPOL"] = Decimal(wpol_contract.functions.balanceOf(C(d["divPool"])).call()) / Decimal(10**18)

    # Calculate total system WPOL (liquid)
    snapshot["total_system_wpol"] = (
        snapshot["owner"]["POL"] +
        snapshot["owner"]["WPOL"] +
        snapshot["vault"]["WPOL"] +
        snapshot["divpool"]["WPOL"] +
        sum(p["wpol_reserve"] for p in snapshot["pools"].values())
    )

    # Calculate total system value in WPOL (tokens valued at pool prices)
    total_value = snapshot["total_system_wpol"]
    for pool_name, pool_data in snapshot["pools"].items():
        token_name = pool_name.split("_")[0]
        # Owner tokens
        if token_name in snapshot["owner"]:
            total_value += snapshot["owner"][token_name] * pool_data["price_wpol"]
        # Vault tokens
        if token_name in snapshot["vault"]:
            total_value += snapshot["vault"][token_name] * pool_data["price_wpol"]

    snapshot["total_system_value_wpol"] = total_value

    # Market cap
    snapshot["mcap_wpol"] = sum(
        snapshot["tokens"][t]["supply"] * snapshot["pools"][f"{t}_WPOL"]["price_wpol"]
        for t in ["SYNA", "SYNC", "SYNR"]
    )

    return snapshot

def print_snapshot(s, label):
    print(f"\n{'='*70}")
    print(f" {label} (block {s['block']})")
    print('='*70)

    print("\n[OWNER BALANCES]")
    print(f"  POL:  {s['owner']['POL']:.10f}")
    print(f"  WPOL: {s['owner']['WPOL']:.10f}")
    for t in ["SYNA", "SYNC", "SYNR"]:
        print(f"  {t}: {s['owner'][t]:.10f}")

    print("\n[VAULT STATE]")
    print(f"  WPOL: {s['vault']['WPOL']:.10f}")
    print(f"  LP total: {s['vault']['totalLP']:.10f} (R:{s['vault']['lpR']:.4f} T:{s['vault']['lpT']:.4f} P:{s['vault']['lpP']:.4f})")
    print(f"  reserveR: {s['vault']['reserveR']:.10f}")
    for t in ["SYNA", "SYNC", "SYNR"]:
        print(f"  {t}: {s['vault'][t]:.10f}")

    print("\n[POOLS]")
    for name, p in s["pools"].items():
        print(f"  {name}:")
        print(f"    WPOL: {p['wpol_reserve']:.10f} | Token: {p['token_reserve']:.10f}")
        print(f"    Price: {p['price_wpol']:.10f} WPOL | TVL: {p['tvl_wpol']:.6f} WPOL")
        print(f"    LP supply: {p['lp_supply']:.10f} | Vault owns: {p['vault_lp']:.10f}")

    print("\n[TOKEN SUPPLIES]")
    for t, data in s["tokens"].items():
        print(f"  {t}: {data['supply']:.10f}")

    print("\n[DIVIDENDS]")
    print(f"  Founder pending: {s['divpool']['founderPending']:.10f} WPOL")
    print(f"  DivPool WPOL: {s['divpool']['WPOL']:.10f}")

    print("\n[TOTALS]")
    print(f"  System liquid WPOL: {s['total_system_wpol']:.10f}")
    print(f"  System total value: {s['total_system_value_wpol']:.10f} WPOL")
    print(f"  Market Cap: {s['mcap_wpol']:.10f} WPOL")

# ═══════════════════════════════════════════════════════════════════════════
# РАСЧЁТ ПРИБЫЛЬНОГО ЦИКЛА
# ═══════════════════════════════════════════════════════════════════════════

def calculate_emission_profit(snapshot, flash_amount_wpol):
    """
    Рассчитать потенциальную прибыль от Flash Loan + Emission цикла

    МЕХАНИКА ПРИБЫЛИ:
    1. Flash Loan → addLiquidity → эмиссия → removeLiquidity → swap → return
    2. Прибыль = новые эмитированные токены × цена - fees

    ИСТОЧНИК ПРИБЫЛИ:
    - EmissionEngine минтит НОВЫЕ токены (инфляция supply)
    - 70% dlp → LP providers (мы как LP получаем долю)
    - 30% dlp → Founder (WPOL из Vault)
    - Новые токены имеют стоимость в пуле
    """

    print("\n" + "="*70)
    print(" РАСЧЁТ ПРИБЫЛЬНОГО FLASH LOAN ЦИКЛА")
    print("="*70)

    AAVE_FEE = Decimal("0.0005")  # 0.05%
    QUICKSWAP_FEE = Decimal("0.003")  # 0.3%
    EMIT_RATE = Decimal("2e-6")  # из контракта
    FOUNDER_SHARE = Decimal("0.30")  # 30%
    LP_SHARE = Decimal("0.62")  # 62%
    RESERVE_SHARE = Decimal("0.08")  # 8%

    flash = Decimal(flash_amount_wpol)

    print(f"\n[ВХОДНЫЕ ДАННЫЕ]")
    print(f"  Flash Loan: {flash} WPOL")
    print(f"  Aave fee: {AAVE_FEE*100}%")
    print(f"  QuickSwap fee: {QUICKSWAP_FEE*100}%")

    # Текущие данные пулов
    syna_pool = snapshot["pools"]["SYNA_WPOL"]
    sync_pool = snapshot["pools"]["SYNC_WPOL"]
    synr_pool = snapshot["pools"]["SYNR_WPOL"]

    syna_supply = snapshot["tokens"]["SYNA"]["supply"]
    sync_supply = snapshot["tokens"]["SYNC"]["supply"]
    synr_supply = snapshot["tokens"]["SYNR"]["supply"]

    vault_total_lp = snapshot["vault"]["totalLP"]

    print(f"\n[ТЕКУЩЕЕ СОСТОЯНИЕ ПУЛОВ]")
    print(f"  SYNA_WPOL: {syna_pool['wpol_reserve']:.6f} WPOL / {syna_pool['token_reserve']:.6f} SYNA")
    print(f"  SYNC_WPOL: {sync_pool['wpol_reserve']:.6f} WPOL / {sync_pool['token_reserve']:.6f} SYNC")
    print(f"  SYNR_WPOL: {synr_pool['wpol_reserve']:.6f} WPOL / {synr_pool['token_reserve']:.6f} SYNR")

    # ШАГ 1: Добавить ликвидность (Flash WPOL → LP)
    # Делим между 3 пулами
    wpol_per_pool = flash / 3

    print(f"\n[ШАГ 1: ADD LIQUIDITY]")
    print(f"  WPOL на каждый пул: {wpol_per_pool:.6f}")

    # Для каждого пула считаем сколько LP получим
    # LP_received = sqrt(wpol_added * token_added) для первоначального
    # Для существующего пула: LP = (wpol_added / total_wpol) * total_LP

    def calc_lp_share(wpol_add, pool):
        # Доля LP = wpol_add / (wpol_reserve + wpol_add) примерно
        return wpol_add / (pool["wpol_reserve"] + wpol_add) * pool["lp_supply"]

    lp_syna = calc_lp_share(wpol_per_pool, syna_pool)
    lp_sync = calc_lp_share(wpol_per_pool, sync_pool)
    lp_synr = calc_lp_share(wpol_per_pool, synr_pool)

    print(f"  LP получено: SYNA={lp_syna:.6f} SYNC={lp_sync:.6f} SYNR={lp_synr:.6f}")

    # Новые резервы после добавления
    new_syna_wpol = syna_pool["wpol_reserve"] + wpol_per_pool
    new_sync_wpol = sync_pool["wpol_reserve"] + wpol_per_pool
    new_synr_wpol = synr_pool["wpol_reserve"] + wpol_per_pool

    # Нужно добавить токены пропорционально
    syna_to_add = wpol_per_pool / syna_pool["price_wpol"] if syna_pool["price_wpol"] > 0 else 0
    sync_to_add = wpol_per_pool / sync_pool["price_wpol"] if sync_pool["price_wpol"] > 0 else 0
    synr_to_add = wpol_per_pool / synr_pool["price_wpol"] if synr_pool["price_wpol"] > 0 else 0

    print(f"  Токены нужны: SYNA={syna_to_add:.6f} SYNC={sync_to_add:.6f} SYNR={synr_to_add:.6f}")

    # ШАГ 2: ЭМИССИЯ
    # em = S × emitRate × 100
    print(f"\n[ШАГ 2: EMISSION]")

    # Supply после добавления токенов не меняется (мы их не минтим, а переносим)
    # Но LP резервы растут → dlp растёт

    em_syna = syna_supply * EMIT_RATE * 100
    em_sync = sync_supply * EMIT_RATE * 100
    em_synr = synr_supply * EMIT_RATE * 100

    print(f"  Эмиссия токенов:")
    print(f"    SYNA: {em_syna:.10f}")
    print(f"    SYNC: {em_sync:.10f}")
    print(f"    SYNR: {em_synr:.10f}")

    # dlp = LP × (√((S+em)/S) − 1) × 0.997
    def calc_dlp(lp_val, em, supply):
        if supply == 0 or em == 0 or lp_val == 0:
            return Decimal(0)
        ratio = (supply + em) / supply
        sqrt_ratio = ratio.sqrt()
        return lp_val * (sqrt_ratio - 1) * Decimal("0.997")

    # LP резервы Vault после addLiquidity
    new_vault_lp_r = snapshot["vault"]["lpR"] + lp_syna
    new_vault_lp_t = snapshot["vault"]["lpT"] + lp_sync
    new_vault_lp_p = snapshot["vault"]["lpP"] + lp_synr
    new_total_lp = new_vault_lp_r + new_vault_lp_t + new_vault_lp_p

    dlp_r = calc_dlp(new_vault_lp_r, em_syna, syna_supply)
    dlp_t = calc_dlp(new_vault_lp_t, em_sync, sync_supply)
    dlp_p = calc_dlp(new_vault_lp_p, em_synr, synr_supply)
    dlp_total = dlp_r + dlp_t + dlp_p

    print(f"\n  DLP (virtual LP injection):")
    print(f"    dlpR: {dlp_r:.10f}")
    print(f"    dlpT: {dlp_t:.10f}")
    print(f"    dlpP: {dlp_p:.10f}")
    print(f"    TOTAL: {dlp_total:.10f}")

    # Распределение dlp
    to_reserve = dlp_total * RESERVE_SHARE
    to_founder = dlp_total * FOUNDER_SHARE
    to_lp = dlp_total * LP_SHARE

    print(f"\n  Распределение dlp:")
    print(f"    8% → reserveR: {to_reserve:.10f}")
    print(f"    30% → founder WPOL: {to_founder:.10f}")
    print(f"    62% → LP providers: {to_lp:.10f}")

    # ШАГ 3: Remove Liquidity
    print(f"\n[ШАГ 3: REMOVE LIQUIDITY]")

    # После эмиссии в пулах больше токенов
    # NAV per LP растёт
    # При remove получаем больше чем вложили

    # Наш share в пуле
    our_lp_share_syna = lp_syna / (syna_pool["lp_supply"] + lp_syna)
    our_lp_share_sync = lp_sync / (sync_pool["lp_supply"] + lp_sync)
    our_lp_share_synr = lp_synr / (synr_pool["lp_supply"] + lp_synr)

    # Резервы после эмиссии (токены минтятся в Vault, затем добавляются в LP)
    # to_lp распределяется между пулами пропорционально dlp
    lp_add_r = to_lp * dlp_r / dlp_total if dlp_total > 0 else Decimal(0)
    lp_add_t = to_lp * dlp_t / dlp_total if dlp_total > 0 else Decimal(0)
    lp_add_p = to_lp * dlp_p / dlp_total if dlp_total > 0 else Decimal(0)

    # При remove мы получаем:
    wpol_out_syna = (new_syna_wpol) * our_lp_share_syna
    wpol_out_sync = (new_sync_wpol) * our_lp_share_sync
    wpol_out_synr = (new_synr_wpol) * our_lp_share_synr

    # Плюс токены которые были эмитированы
    token_out_syna = (syna_pool["token_reserve"] + syna_to_add + em_syna * LP_SHARE * dlp_r/dlp_total if dlp_total > 0 else 0) * our_lp_share_syna
    token_out_sync = (sync_pool["token_reserve"] + sync_to_add + em_sync * LP_SHARE * dlp_t/dlp_total if dlp_total > 0 else 0) * our_lp_share_sync
    token_out_synr = (synr_pool["token_reserve"] + synr_to_add + em_synr * LP_SHARE * dlp_p/dlp_total if dlp_total > 0 else 0) * our_lp_share_synr

    total_wpol_out = wpol_out_syna + wpol_out_sync + wpol_out_synr

    print(f"  WPOL возвращено: {total_wpol_out:.10f}")
    print(f"  Токены получены:")
    print(f"    SYNA: {token_out_syna:.10f}")
    print(f"    SYNC: {token_out_sync:.10f}")
    print(f"    SYNR: {token_out_synr:.10f}")

    # ШАГ 4: Swap токены → WPOL
    print(f"\n[ШАГ 4: SWAP TOKENS → WPOL]")

    # Swap value (минус fees)
    swap_value_syna = token_out_syna * syna_pool["price_wpol"] * (1 - QUICKSWAP_FEE)
    swap_value_sync = token_out_sync * sync_pool["price_wpol"] * (1 - QUICKSWAP_FEE)
    swap_value_synr = token_out_synr * synr_pool["price_wpol"] * (1 - QUICKSWAP_FEE)

    total_from_swap = swap_value_syna + swap_value_sync + swap_value_synr

    print(f"  От свапа SYNA: {swap_value_syna:.10f} WPOL")
    print(f"  От свапа SYNC: {swap_value_sync:.10f} WPOL")
    print(f"  От свапа SYNR: {swap_value_synr:.10f} WPOL")
    print(f"  ИТОГО от свапов: {total_from_swap:.10f} WPOL")

    # ШАГ 5: Возврат Flash Loan
    print(f"\n[ШАГ 5: RETURN FLASH LOAN]")

    flash_fee = flash * AAVE_FEE
    flash_return = flash + flash_fee

    print(f"  Flash Loan: {flash:.10f}")
    print(f"  Fee (0.05%): {flash_fee:.10f}")
    print(f"  Вернуть: {flash_return:.10f}")

    # ИТОГО
    print(f"\n[ИТОГОВЫЙ РАСЧЁТ]")

    total_received = total_wpol_out + total_from_swap
    gas_cost = Decimal("0.15")  # примерная стоимость gas

    gross_profit = total_received - flash_return
    net_profit = gross_profit - gas_cost

    print(f"  Получено WPOL: {total_received:.10f}")
    print(f"  Вернуть Flash: {flash_return:.10f}")
    print(f"  Gross profit: {gross_profit:.10f}")
    print(f"  Gas (~): {gas_cost:.10f}")
    print(f"  NET PROFIT: {net_profit:.10f} WPOL")

    # Founder доля (30% от dlp)
    print(f"\n[FOUNDER ДИВИДЕНДЫ]")
    print(f"  30% dlp в WPOL: {to_founder:.10f}")

    return {
        "flash_amount": flash,
        "total_received": total_received,
        "gross_profit": gross_profit,
        "net_profit": net_profit,
        "founder_wpol": to_founder,
        "emission": {"SYNA": em_syna, "SYNC": em_sync, "SYNR": em_synr},
        "dlp_total": dlp_total,
    }

# ═══════════════════════════════════════════════════════════════════════════
# РЕАЛЬНЫЙ ПРИБЫЛЬНЫЙ ЦИКЛ
# ═══════════════════════════════════════════════════════════════════════════

def design_real_profit_cycle():
    """
    РЕАЛЬНАЯ МЕХАНИКА ПРИБЫЛИ:

    Проблема: При малых резервах LP арбитраж невыгоден.

    Решение: Использовать EMISSION как источник новой стоимости.

    ЦИКЛ:
    1. Flash Loan 1000 POL
    2. Wrap → WPOL
    3. Deposit в Vault (creates LP via initialize)
    4. Trigger emission (mint новые токены)
    5. Новые токены → Vault → LP пулы
    6. LP NAV увеличивается (больше токенов в пуле)
    7. Founder получает 30% dlp в WPOL
    8. Remove liquidity (получаем больше чем вложили)
    9. Swap излишек токенов → WPOL
    10. Return Flash Loan + 0.05%
    11. PROFIT = излишек WPOL + founder WPOL

    КЛЮЧ: Эмиссия создаёт новые токены из ничего.
    Эти токены имеют цену в AMM пуле.
    """

    print("\n" + "="*70)
    print(" ДИЗАЙН РЕАЛЬНОГО ПРИБЫЛЬНОГО ЦИКЛА")
    print("="*70)

    print("""
    ┌─────────────────────────────────────────────────────────────────┐
    │                    FLASH LOAN PROFIT CYCLE                      │
    ├─────────────────────────────────────────────────────────────────┤
    │                                                                 │
    │  [1] Aave Flash Loan ──────────► 1000 WPOL                     │
    │                                      │                          │
    │  [2] TroikaVault.deposit() ◄────────┘                          │
    │            │                                                    │
    │            ▼                                                    │
    │      ┌─────────────────┐                                        │
    │      │   LIQUIDITY     │                                        │
    │      │   SYNA_WPOL     │◄── LP tokens minted                   │
    │      │   SYNC_WPOL     │                                        │
    │      │   SYNR_WPOL     │                                        │
    │      └────────┬────────┘                                        │
    │               │                                                 │
    │  [3] EmissionEngine.executeEmission()                          │
    │               │                                                 │
    │               ▼                                                 │
    │      ┌─────────────────┐                                        │
    │      │  MINT TOKENS    │                                        │
    │      │  SYNA: +0.02    │  ◄── NEW VALUE CREATED                │
    │      │  SYNC: +0.20    │                                        │
    │      │  SYNR: +0.04    │                                        │
    │      └────────┬────────┘                                        │
    │               │                                                 │
    │      ┌───────┴───────┐                                         │
    │      ▼               ▼                                         │
    │   70% → LP      30% → Founder                                  │
    │   (NAV grows)   (WPOL dividend)                                │
    │      │               │                                         │
    │  [4] removeLiquidity │                                         │
    │      │               │                                         │
    │      ▼               ▼                                         │
    │   WPOL + Tokens   WPOL                                         │
    │      │               │                                         │
    │  [5] Swap excess     │                                         │
    │      tokens → WPOL   │                                         │
    │      │               │                                         │
    │      └───────┬───────┘                                         │
    │              │                                                 │
    │  [6] Return Flash Loan + 0.05% fee                             │
    │              │                                                 │
    │              ▼                                                 │
    │      ┌─────────────────┐                                        │
    │      │  PROFIT (POL)   │                                        │
    │      │  = new_value    │                                        │
    │      │  - flash_fee    │                                        │
    │      │  - gas          │                                        │
    │      └─────────────────┘                                        │
    │                                                                 │
    └─────────────────────────────────────────────────────────────────┘

    ИСТОЧНИК ПРИБЫЛИ:
    ═══════════════════════════════════════════════════════════════════
    EmissionEngine МИНТИТ новые токены → увеличивает supply.
    Эти токены попадают в LP пулы → TVL растёт.
    LP NAV = (WPOL + Token_value) / LP_supply → NAV растёт.

    При removeLiquidity получаем БОЛЬШЕ активов чем вложили!

    ФОРМУЛА ПРИБЫЛИ:
    ─────────────────
    profit = emission_value × LP_share × (1 - fees) - flash_fee - gas

    где emission_value = SUM(em_token × price_token)
    """)

# ═══════════════════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    print("="*70)
    print(" АНАЛИЗ ПРИБЫЛЬНОГО FLASH LOAN ЦИКЛА")
    print("="*70)

    # Snapshot текущего состояния
    snapshot = get_system_snapshot()
    print_snapshot(snapshot, "ТЕКУЩЕЕ СОСТОЯНИЕ СИСТЕМЫ")

    # Дизайн цикла
    design_real_profit_cycle()

    # Расчёт с разными суммами Flash Loan
    print("\n" + "="*70)
    print(" РАСЧЁТ ДЛЯ РАЗНЫХ СУММ FLASH LOAN")
    print("="*70)

    for amount in [10, 100, 1000]:
        result = calculate_emission_profit(snapshot, amount)
        print(f"\n  Flash {amount} WPOL → Net profit: {result['net_profit']:.10f} WPOL")

    # Оптимальная точка
    print("\n" + "="*70)
    print(" ВЫВОД")
    print("="*70)
    print("""
    ПРОБЛЕМА ТЕКУЩЕЙ СИСТЕМЫ:
    ─────────────────────────
    1. Резервы пулов очень малы (3 WPOL на пул)
    2. emitRate = 2e-6 (минимальный)
    3. Эмиссия за цикл: ~0.02 SYNA, ~0.2 SYNC, ~0.04 SYNR
    4. Стоимость эмиссии: ~0.001 WPOL (при текущих ценах)
    5. Flash fee (0.05%) + gas > emission value

    УСЛОВИЯ ДЛЯ ПРИБЫЛЬНОСТИ:
    ─────────────────────────
    1. LP резервы > 1000 WPOL (TVL > 2000 WPOL)
    2. emitRate > 10e-6 (увеличить в 5x)
    3. Или: много циклов эмиссии за один Flash Loan период

    РЕШЕНИЕ: MULTI-EMISSION CYCLE
    ─────────────────────────────
    1. Flash Loan 1000 WPOL
    2. Deposit → LP
    3. Wait 50 blocks → Emission #1
    4. Wait 50 blocks → Emission #2
    5. ... repeat N times
    6. Remove LP + accumulated emissions
    7. Return Flash Loan

    Profit = N × emission_value - flash_fee - gas × N

    Break-even point: N = (flash_fee + gas) / emission_value
    """)
