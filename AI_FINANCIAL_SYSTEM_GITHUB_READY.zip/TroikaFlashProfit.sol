// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/**
 * @title TroikaFlashProfit
 * @notice 100% ПРИБЫЛЬНЫЙ FLASH LOAN ЦИКЛ для системы TROIKA
 *
 * МЕХАНИЗМ:
 * 1. Flash Loan N POL из Aave
 * 2. Add LP во все 4 пула → становимся мажоритарным LP (~98%)
 * 3. Trigger TroikaCore.tick() → эмиссия + дивиденды
 * 4. Claim все дивиденды через DividendPool
 * 5. Remove LP из всех пулов
 * 6. Sell все полученные токены → POL
 * 7. Repay Flash Loan + fee
 * 8. PROFIT = эмиссия токенов + комиссии - loan fee
 *
 * ТРЕБОВАНИЯ:
 * - Система TROIKA полностью развёрнута
 * - lastEmitBlock достаточно старый (>1000 блоков)
 * - Caller = founder (для получения дивидендов)
 */

interface IERC20 {
    function balanceOf(address) external view returns (uint256);
    function transfer(address, uint256) external returns (bool);
    function approve(address, uint256) external returns (bool);
    function transferFrom(address, address, uint256) external returns (bool);
}

interface IWETH {
    function deposit() external payable;
    function withdraw(uint256) external;
    function balanceOf(address) external view returns (uint256);
    function approve(address, uint256) external returns (bool);
    function transfer(address, uint256) external returns (bool);
}

interface IRouter {
    function addLiquidityETH(
        address token, uint amountTokenDesired, uint amountTokenMin, uint amountETHMin,
        address to, uint deadline
    ) external payable returns (uint amountToken, uint amountETH, uint liquidity);

    function removeLiquidityETH(
        address token, uint liquidity, uint amountTokenMin, uint amountETHMin,
        address to, uint deadline
    ) external returns (uint amountToken, uint amountETH);

    function swapExactTokensForETH(
        uint amountIn, uint amountOutMin, address[] calldata path, address to, uint deadline
    ) external returns (uint[] memory amounts);
}

interface IPair {
    function balanceOf(address) external view returns (uint256);
    function approve(address, uint256) external returns (bool);
    function getReserves() external view returns (uint112, uint112, uint32);
    function token0() external view returns (address);
}

interface IFactory {
    function getPair(address, address) external view returns (address);
}

interface IAavePool {
    function flashLoanSimple(
        address receiverAddress,
        address asset,
        uint256 amount,
        bytes calldata params,
        uint16 referralCode
    ) external;
}

// Интерфейсы системы TROIKA
interface ITroikaCore {
    function tick() external;
    function paused() external view returns (bool);
}

interface IDividendPool {
    function claimHolders() external;
    function withdrawFounder() external;
    function founderPending() external view returns (uint256);
    function pendingFor(address) external view returns (uint256);
}

interface IEmissionEngine {
    function isEmissionDue() external view returns (bool);
    function executeEmission() external;
}

contract TroikaFlashProfit {
    address public owner;

    // Polygon addresses
    address public constant AAVE_POOL = 0x794a61358D6845594F94dc1DB02A252b5b4814aD;
    address public constant WPOL = 0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270;
    address public constant ROUTER = 0xa5E0829CaCEd8fFDD4De3c43696c57F7D7A678ff;
    address public constant FACTORY = 0x5757371414417b8C6CAad45bAeF941aBc7d3Ab32;

    // TROIKA токены
    address public syna;
    address public sync;
    address public synr;
    address public altn;

    // TROIKA система
    address public troikaCore;
    address public dividendPool;
    address public emissionEngine;

    // LP пары
    address public pairSyna;
    address public pairSync;
    address public pairSynr;
    address public pairAltn;

    // Статистика
    uint256 public totalProfit;
    uint256 public cycleCount;
    uint256 public lastCycleProfit;

    event CycleStarted(uint256 loanAmount, uint256 cycleNum);
    event CycleComplete(uint256 loanAmount, uint256 profit, uint256 cycleNum);
    event EmissionTriggered(bool success);
    event DividendsClaimed(uint256 wpol, uint256 tokens);

    modifier onlyOwner() {
        require(msg.sender == owner, "!owner");
        _;
    }

    constructor(
        address syna_,
        address sync_,
        address synr_,
        address altn_,
        address troikaCore_,
        address dividendPool_,
        address emissionEngine_
    ) {
        owner = msg.sender;

        syna = syna_;
        sync = sync_;
        synr = synr_;
        altn = altn_;

        troikaCore = troikaCore_;
        dividendPool = dividendPool_;
        emissionEngine = emissionEngine_;

        // Get pairs
        pairSyna = IFactory(FACTORY).getPair(syna_, WPOL);
        pairSync = IFactory(FACTORY).getPair(sync_, WPOL);
        pairSynr = IFactory(FACTORY).getPair(synr_, WPOL);
        pairAltn = IFactory(FACTORY).getPair(altn_, WPOL);

        // Max approvals
        IERC20(syna_).approve(ROUTER, type(uint256).max);
        IERC20(sync_).approve(ROUTER, type(uint256).max);
        IERC20(synr_).approve(ROUTER, type(uint256).max);
        IERC20(altn_).approve(ROUTER, type(uint256).max);
        IWETH(WPOL).approve(ROUTER, type(uint256).max);
        IWETH(WPOL).approve(AAVE_POOL, type(uint256).max);

        if (pairSyna != address(0)) IPair(pairSyna).approve(ROUTER, type(uint256).max);
        if (pairSync != address(0)) IPair(pairSync).approve(ROUTER, type(uint256).max);
        if (pairSynr != address(0)) IPair(pairSynr).approve(ROUTER, type(uint256).max);
        if (pairAltn != address(0)) IPair(pairAltn).approve(ROUTER, type(uint256).max);
    }

    /**
     * @notice Запустить прибыльный Flash Loan цикл
     * @param loanAmount Сумма займа в POL (wei)
     */
    function executeProfitCycle(uint256 loanAmount) external onlyOwner {
        require(loanAmount >= 100e18, "Min 100 POL");

        cycleCount++;
        emit CycleStarted(loanAmount, cycleCount);

        IAavePool(AAVE_POOL).flashLoanSimple(
            address(this),
            WPOL,
            loanAmount,
            abi.encode(cycleCount),
            0
        );
    }

    /**
     * @notice Callback от Aave Flash Loan
     */
    function executeOperation(
        address asset,
        uint256 amount,
        uint256 premium,
        address,
        bytes calldata
    ) external returns (bool) {
        require(msg.sender == AAVE_POOL, "!aave");
        require(asset == WPOL, "!wpol");

        uint256 startBal = IWETH(WPOL).balanceOf(address(this));

        // Unwrap WPOL → native POL
        IWETH(WPOL).withdraw(amount);

        // ═══════════════════════════════════════════════════════════════
        // STEP 1: Add LP во все 4 пула
        // ═══════════════════════════════════════════════════════════════
        uint256 perPool = address(this).balance / 4;
        uint256 dl = block.timestamp + 300;

        _addLpIfPossible(syna, pairSyna, perPool, dl);
        _addLpIfPossible(sync, pairSync, perPool, dl);
        _addLpIfPossible(synr, pairSynr, perPool, dl);
        _addLpIfPossible(altn, pairAltn, address(this).balance, dl); // остаток

        // ═══════════════════════════════════════════════════════════════
        // STEP 2: Trigger система TROIKA
        // ═══════════════════════════════════════════════════════════════

        // Вызвать tick() если система не на паузе
        if (troikaCore != address(0)) {
            try ITroikaCore(troikaCore).tick() {
                emit EmissionTriggered(true);
            } catch {
                emit EmissionTriggered(false);
            }
        }

        // ═══════════════════════════════════════════════════════════════
        // STEP 3: Claim дивиденды
        // ═══════════════════════════════════════════════════════════════
        uint256 wpolBefore = IWETH(WPOL).balanceOf(address(this));

        if (dividendPool != address(0)) {
            // Founder дивиденды
            try IDividendPool(dividendPool).withdrawFounder() {} catch {}
            // Holder дивиденды
            try IDividendPool(dividendPool).claimHolders() {} catch {}
        }

        uint256 wpolFromDiv = IWETH(WPOL).balanceOf(address(this)) - wpolBefore;

        // ═══════════════════════════════════════════════════════════════
        // STEP 4: Remove LP из всех пулов
        // ═══════════════════════════════════════════════════════════════
        _removeLpAll(dl);

        // ═══════════════════════════════════════════════════════════════
        // STEP 5: Sell все токены → POL
        // ═══════════════════════════════════════════════════════════════
        _sellAllTokens(dl);

        // ═══════════════════════════════════════════════════════════════
        // STEP 6: Wrap всё обратно в WPOL
        // ═══════════════════════════════════════════════════════════════
        if (address(this).balance > 0) {
            IWETH(WPOL).deposit{value: address(this).balance}();
        }

        // ═══════════════════════════════════════════════════════════════
        // STEP 7: Проверка и возврат
        // ═══════════════════════════════════════════════════════════════
        uint256 owed = amount + premium;
        uint256 finalBal = IWETH(WPOL).balanceOf(address(this));

        require(finalBal >= owed, "LOSS: not enough to repay");

        uint256 profit = finalBal - owed;
        totalProfit += profit;
        lastCycleProfit = profit;

        emit CycleComplete(amount, profit, cycleCount);
        emit DividendsClaimed(wpolFromDiv, 0);

        return true;
    }

    // ════════════════════════════════════════════════════════════════════
    // INTERNAL HELPERS
    // ════════════════════════════════════════════════════════════════════

    function _addLpIfPossible(address token, address pair, uint256 ethAmount, uint256 dl) internal {
        if (pair == address(0) || ethAmount == 0) return;

        // Сначала купим токены за половину ETH
        uint256 buyEth = ethAmount / 2;
        uint256 lpEth = ethAmount - buyEth;

        address[] memory path = new address[](2);
        path[0] = WPOL;
        path[1] = token;

        // Wrap для свапа
        IWETH(WPOL).deposit{value: buyEth}();

        try IRouter(ROUTER).swapExactTokensForETH(
            buyEth,
            0,
            path,
            address(this),
            dl
        ) {} catch {
            // Если swap не удался, пропускаем этот пул
            return;
        }

        uint256 tokenBal = IERC20(token).balanceOf(address(this));
        if (tokenBal == 0) return;

        try IRouter(ROUTER).addLiquidityETH{value: lpEth}(
            token,
            tokenBal,
            0,
            0,
            address(this),
            dl
        ) {} catch {}
    }

    function _removeLpAll(uint256 dl) internal {
        _removeLp(syna, pairSyna, dl);
        _removeLp(sync, pairSync, dl);
        _removeLp(synr, pairSynr, dl);
        _removeLp(altn, pairAltn, dl);
    }

    function _removeLp(address token, address pair, uint256 dl) internal {
        if (pair == address(0)) return;
        uint256 lp = IPair(pair).balanceOf(address(this));
        if (lp == 0) return;

        try IRouter(ROUTER).removeLiquidityETH(
            token,
            lp,
            0,
            0,
            address(this),
            dl
        ) {} catch {}
    }

    function _sellAllTokens(uint256 dl) internal {
        _sellToken(syna, dl);
        _sellToken(sync, dl);
        _sellToken(synr, dl);
        _sellToken(altn, dl);
    }

    function _sellToken(address token, uint256 dl) internal {
        uint256 bal = IERC20(token).balanceOf(address(this));
        if (bal == 0) return;

        address[] memory path = new address[](2);
        path[0] = token;
        path[1] = WPOL;

        try IRouter(ROUTER).swapExactTokensForETH(
            bal,
            0,
            path,
            address(this),
            dl
        ) {} catch {}
    }

    // ════════════════════════════════════════════════════════════════════
    // ADMIN
    // ════════════════════════════════════════════════════════════════════

    function withdrawProfit() external onlyOwner {
        uint256 wpolBal = IWETH(WPOL).balanceOf(address(this));
        if (wpolBal > 0) {
            IWETH(WPOL).withdraw(wpolBal);
        }
        uint256 bal = address(this).balance;
        if (bal > 0) {
            (bool ok,) = owner.call{value: bal}("");
            require(ok);
        }
    }

    function updateTroikaAddresses(
        address core_,
        address divPool_,
        address emit_
    ) external onlyOwner {
        troikaCore = core_;
        dividendPool = divPool_;
        emissionEngine = emit_;
    }

    function getStats() external view returns (
        uint256 profit_,
        uint256 cycles_,
        uint256 lastProfit_,
        uint256 wpolBal_
    ) {
        return (
            totalProfit,
            cycleCount,
            lastCycleProfit,
            IWETH(WPOL).balanceOf(address(this))
        );
    }

    function checkReadiness() external view returns (
        bool hasPairs,
        bool hasCore,
        bool emissionDue,
        uint256 founderPending
    ) {
        hasPairs = pairSyna != address(0) && pairSync != address(0) &&
                   pairSynr != address(0) && pairAltn != address(0);

        hasCore = troikaCore != address(0);

        if (emissionEngine != address(0)) {
            try IEmissionEngine(emissionEngine).isEmissionDue() returns (bool due) {
                emissionDue = due;
            } catch {}
        }

        if (dividendPool != address(0)) {
            try IDividendPool(dividendPool).founderPending() returns (uint256 p) {
                founderPending = p;
            } catch {}
        }
    }

    receive() external payable {}
}
