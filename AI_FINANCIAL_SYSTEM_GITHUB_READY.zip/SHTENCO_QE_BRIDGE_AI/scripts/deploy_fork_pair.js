const fs = require("fs");
const path = require("path");
const { ethers } = require("hardhat");

async function main() {
  const [admin, user, feeRecipient, v1, v2, v3] = await ethers.getSigners();
  const Token = await ethers.getContractFactory("MockERC20");
  const canonical = await Token.deploy("SYNA Canonical", "SYNA", 18);
  const Wrapped = await ethers.getContractFactory("SHTENCOWrappedSYNA");
  const wrapped = await Wrapped.deploy(admin.address, ethers.parseEther("100000000"));
  const Bridge = await ethers.getContractFactory("SHTENCOBridgeRelayV2");
  const validators = [v1.address, v2.address, v3.address];
  const source = await Bridge.deploy(admin.address, 1001, true, validators, 2);
  const destination = await Bridge.deploy(admin.address, 1002, true, validators, 2);
  await Promise.all([canonical.waitForDeployment(), wrapped.waitForDeployment(), source.waitForDeployment(), destination.waitForDeployment()]);

  await (await wrapped.grantRole(await wrapped.BRIDGE_ROLE(), await destination.getAddress())).wait();
  await (await source.setPeer(1002, await destination.getAddress(), true)).wait();
  await (await destination.setPeer(1001, await source.getAddress(), true)).wait();
  await (await source.setRemoteToken(1002, await canonical.getAddress(), await wrapped.getAddress())).wait();
  await (await destination.setRemoteToken(1001, await wrapped.getAddress(), await canonical.getAddress())).wait();

  const policy = {
    enabled: true,
    mode: 0,
    feeBps: 10,
    minTransfer: ethers.parseEther("1"),
    maxPerTx: ethers.parseEther("100000"),
    dailyOutboundLimit: ethers.parseEther("1000000"),
    dailyInboundLimit: ethers.parseEther("1000000"),
    feeRecipient: feeRecipient.address,
  };
  await (await source.setAssetPolicy(await canonical.getAddress(), policy)).wait();
  await (await destination.setAssetPolicy(await wrapped.getAddress(), { ...policy, mode: 1 })).wait();
  await (await canonical.mint(user.address, ethers.parseEther("10000"))).wait();

  const Adapter = await ethers.getContractFactory("SHTENCOBridgeQEAdapter");
  const adapter = await Adapter.deploy(admin.address, admin.address);
  await adapter.waitForDeployment();
  await (await adapter.grantRole(await adapter.CONTROLLER_ROLE(), admin.address)).wait();
  await (await adapter.setRoute(await source.getAddress(), await canonical.getAddress(), 1002, {
    enabled: true,
    maxPerTx: ethers.parseEther("100000"),
    dailyLimit: ethers.parseEther("1000000"),
  })).wait();
  await (await adapter.setRecipient(1002, user.address, true)).wait();

  const output = {
    network: await ethers.provider.getNetwork().then(n => ({ chainId: n.chainId.toString() })),
    forkMode: true,
    virtualDomains: { source: 1001, destination: 1002 },
    canonical: await canonical.getAddress(),
    wrapped: await wrapped.getAddress(),
    sourceBridge: await source.getAddress(),
    destinationBridge: await destination.getAddress(),
    bridgeQEAdapter: await adapter.getAddress(),
    validators,
    threshold: 2,
    admin: admin.address,
    user: user.address,
    feeRecipient: feeRecipient.address,
  };
  const outDir = path.join(__dirname, "..", "deployments");
  fs.mkdirSync(outDir, { recursive: true });
  const outPath = path.join(outDir, "fork-bridge-pair.json");
  fs.writeFileSync(outPath, JSON.stringify(output, null, 2));
  console.log(JSON.stringify(output, null, 2));
  console.log(`Saved ${outPath}`);
}

main().catch(error => { console.error(error); process.exitCode = 1; });
