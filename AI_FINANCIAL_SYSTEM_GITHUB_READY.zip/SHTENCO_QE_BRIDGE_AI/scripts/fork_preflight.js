const fs = require("fs");
const path = require("path");
const { ethers } = require("hardhat");

async function main() {
  const configPath = process.argv[2] || path.join(__dirname, "..", "config", "polygon.example.json");
  const config = JSON.parse(fs.readFileSync(configPath, "utf8"));
  const network = await ethers.provider.getNetwork();
  const addresses = {
    quickswap_v2_router: config.quickswap_v2_router,
    quickswap_v2_factory: config.quickswap_v2_factory,
    aave_v3_pool: config.aave_v3_pool,
    ...config.tokens,
  };
  const report = { expectedChainId: String(config.chain_id), actualChainId: network.chainId.toString(), contracts: {} };
  for (const [name, address] of Object.entries(addresses)) {
    const code = await ethers.provider.getCode(address);
    report.contracts[name] = { address, hasCode: code !== "0x", codeBytes: Math.max(0, (code.length - 2) / 2) };
  }
  report.ok = report.actualChainId === report.expectedChainId && Object.values(report.contracts).every(x => x.hasCode);
  console.log(JSON.stringify(report, null, 2));
  if (!report.ok) process.exitCode = 2;
}

main().catch(error => { console.error(error); process.exitCode = 1; });
