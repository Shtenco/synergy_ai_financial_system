const fs = require("fs");
const path = require("path");
const { ethers } = require("ethers");

const ABI = [
  "function propose((address target,uint256 value,bytes data,address budgetToken,uint256 budgetAmount)[] actions,bytes32 stateHash,bytes32 objectiveHash,uint16 scoreBps,uint16 riskBps,uint64 executeAfter,uint64 expiresAt) returns (bytes32 proposalId)",
  "event ProposalCreated(bytes32 indexed proposalId,address indexed proposer,uint256 executeAfter,uint256 expiresAt,uint256 scoreBps,uint256 riskBps,bytes32 stateHash,bytes32 objectiveHash,uint256 actionCount)"
];

async function main() {
  const file = process.argv.find(x => x.endsWith(".json"));
  const broadcast = process.argv.includes("--broadcast");
  if (!file) throw new Error("Usage: node submit_ai_proposal.js proposal-materialized.json [--broadcast]");
  const payload = JSON.parse(fs.readFileSync(file, "utf8"));
  const rpc = process.env.POLYGON_RPC_URL || process.env.RPC_URL;
  const key = process.env.AI_PROPOSER_PRIVATE_KEY;
  if (!rpc || !key) throw new Error("POLYGON_RPC_URL/RPC_URL and AI_PROPOSER_PRIVATE_KEY are required");
  const provider = new ethers.JsonRpcProvider(rpc);
  const signer = new ethers.Wallet(key, provider);
  const network = await provider.getNetwork();
  if (String(network.chainId) !== String(payload.chainId)) throw new Error("chainId mismatch");
  const contract = new ethers.Contract(payload.centralBank, ABI, signer);
  const actions = payload.actions.map(a => ({
    target: a.target, value: BigInt(a.value), data: a.data,
    budgetToken: a.budgetToken, budgetAmount: BigInt(a.budgetAmount),
  }));
  const args = [actions, payload.stateHash, payload.objectiveHash, payload.scoreBps, payload.riskBps, payload.executeAfter, payload.expiresAt];
  const proposalId = await contract.propose.staticCall(...args);
  const gas = await contract.propose.estimateGas(...args);
  console.log(JSON.stringify({ mode: broadcast ? "BROADCAST" : "DRY_RUN", proposalId, gas: gas.toString(), signer: signer.address }, null, 2));
  if (!broadcast) return;
  if (process.env.LIVE_EXECUTION !== "1") throw new Error("LIVE_EXECUTION=1 is required for broadcast");
  const tx = await contract.propose(...args, { gasLimit: gas * 120n / 100n });
  const receipt = await tx.wait();
  const report = { centralBank: payload.centralBank, chainId: String(payload.chainId), proposalId, txHash: tx.hash, blockNumber: receipt.blockNumber, status: receipt.status };
  const out = path.join(path.dirname(file), path.basename(file, ".json") + "-submitted.json");
  fs.writeFileSync(out, JSON.stringify(report, null, 2));
  console.log(JSON.stringify(report, null, 2));
}
main().catch(e => { console.error(e); process.exitCode = 1; });
