# TOP AI Security Report

## Закрытые архитектурные риски

- Self-reported AI score больше не является единственной защитой: controller требует свежий M-of-N snapshot.
- Рыночная цена не формирует fundamental value без резервов и дохода.
- Flash principal не входит в NAV; учитывается только реализованный net profit.
- Revenue source IDs защищены от повторной регистрации.
- Harvester проверяет точный balance delta.
- Buyback нельзя финансировать резервным QE.
- Reserve QE не может идти в operations.
- Proposal повторно проверяет состояние непосредственно перед execute.
- Target и function selector должны быть разрешены отдельно.
- На каждый token действует daily budget.
- Governance, AI proposer, executor, reporters и guardian разделяются.

## Оставшиеся production-риски

- bridge validator collusion;
- oracle reporter collusion или одинаковый источник данных;
- ошибки token decimals и расчётной единицы;
- DEX manipulation между snapshot и swap quote;
- governance key compromise;
- malicious/upgradeable external target;
- smart-contract bugs и chain reorg;
- недостаточная ликвидность или MEV;
- модельный риск Monte Carlo и неверные параметры спроса.

## Обязательные меры перед mainnet

- multisig + hardware wallets;
- минимум 3 reporters, threshold 2 или выше;
- независимые data pipelines;
- Chainlink/TWAP/reference price guard;
- fork tests на свежем фиксированном блоке;
- selector-by-selector review;
- небольшие стартовые daily limits;
- emergency pause drill;
- аудит сторонней командой;
- bug bounty;
- мониторинг reserve ratio, bridge imbalance, stale reports и execution failures.
