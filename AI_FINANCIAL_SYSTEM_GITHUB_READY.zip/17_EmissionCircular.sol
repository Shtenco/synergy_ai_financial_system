// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

// ═══════════════════════════════════════════════════════════════════════════
//  SINERGY DEFLATION SYSTEM — 17_EmissionCircular.sol
//  Патч EmissionEngine + TroikaCore для глубокой связки с CircularHub
//
//  PATCH 1: EmissionEngine
//   Новый метод: setExternalPriceSignal(uint256 crossPricePOL)
//     Вызывается CircularHub при каждом tick() и при onALTNBurn()
//     gP_new = gP × 0.70 + crossPricePOL × 0.30
//     Если crossPrice > gP × 1.05 → экстра-boost +5%
//     Эффект: рост ALTN/SYNR цены = более агрессивная эмиссия
//
//   После executeEmission():
//     → collEmit.onSYNREmit(dlpTotal)  — пересчёт залогов
//     → hub.onPriceUpdate()            — CrossPrice refresh
//
//  PATCH 2: TroikaCore
//   После processFee() вызвать:
//     → hub.onFeeProcessed(feeAmount, tokenType)
//     Эффект: каждая торговая комиссия = сигнал в Ring A/B
// ═══════════════════════════════════════════════════════════════════════════

import {AccessControl}  from "@openzeppelin/contracts/access/AccessControl.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import "./00_CircularInterfaces.sol";

error ECE_ZeroAddress();
error ECE_Unauthorized();

// ── PATCH 1: EmissionEngine ───────────────────────────────────────────────
contract EmissionCircularPatch is AccessControl, ReentrancyGuard {

    bytes32 public constant HUB_ROLE    = keccak256("HUB_ROLE");
    bytes32 public constant CALLER_ROLE = keccak256("CALLER_ROLE"); // TroikaCore

    ICircularHub      public hub;
    ICircularCollEmit public collEmit;

    // Вес внешнего сигнала: 30%
    uint256 public externalSignalWeight = 300; // /1000
    uint256 public lastExternalPrice;
    uint256 public lastExternalBlock;
    uint256 public externalBoostCount;
    uint256 public totalCollEmitNotified;

    event ExternalSignalApplied(uint256 crossPrice, uint256 oldGP, uint256 newGP);
    event CollEmitNotified(uint256 dlpTotal);
    event HubNotified(uint256 crossPrice);

    function setCircularConnections(address hub_, address collEmit_)
        external onlyRole(DEFAULT_ADMIN_ROLE)
    {
        if (hub_ != address(0)) {
            hub = ICircularHub(hub_);
            _grantRole(HUB_ROLE, hub_);
        }
        if (collEmit_ != address(0)) {
            collEmit = ICircularCollEmit(collEmit_);
        }
    }

    // ─────────────────────────────────────────────────────────────────
    /// @notice Принять ценовой сигнал от CircularHub
    /// Вызывается при каждом hub.tick() и при каждом onALTNBurn()
    ///
    /// В реальном EmissionEngine добавить:
    ///   function setExternalPriceSignal(uint256 crossPricePOL) external onlyRole(HUB_ROLE) {
    ///       lastExternalPrice = crossPricePOL;
    ///       lastExternalBlock = block.number;
    ///       // gP = gP*(1-w) + crossPrice*w
    ///       uint256 newGP = (gP * (1000 - externalSignalWeight)
    ///                       + crossPricePOL * externalSignalWeight) / 1000;
    ///       gP = _clamp(newGP, G_P_MIN, G_P_MAX);
    ///       if (gP > oldGP) externalBoostCount++;
    ///   }
    function setExternalPriceSignal(uint256 crossPricePOL)
        external onlyRole(HUB_ROLE)
    {
        if (crossPricePOL == 0) return;
        lastExternalPrice = crossPricePOL;
        lastExternalBlock = block.number;
        externalBoostCount++;
        emit ExternalSignalApplied(crossPricePOL, 0, crossPricePOL);
    }

    // ─────────────────────────────────────────────────────────────────
    /// @notice Добавить в конец executeEmission() в EmissionEngine:
    ///
    ///   // Уведомить CollateralEmission: залоги теперь дороже
    ///   if (address(collEmit) != address(0)) {
    ///       try ICircularCollEmit(collEmit).onSYNREmit(dlpTotal) {} catch {}
    ///   }
    ///   // Уведомить Hub: цена обновилась
    ///   if (address(hub) != address(0)) {
    ///       try ICircularHub(hub).onPriceUpdate() {} catch {}
    ///   }
    function _notifyAfterEmission(uint256 dlpTotal) internal {
        if (address(collEmit) != address(0) && dlpTotal > 0) {
            totalCollEmitNotified += dlpTotal;
            try ICircularCollEmit(address(collEmit)).onSYNREmit(dlpTotal) {
                emit CollEmitNotified(dlpTotal);
            } catch {}
        }
        if (address(hub) != address(0)) {
            try ICircularHub(address(hub)).onPriceUpdate() {
                emit HubNotified(lastExternalPrice);
            } catch {}
        }
    }

    function patchStats() external view returns (
        uint256 lastPrice_,   uint256 lastBlock_,
        uint256 boosts_,      uint256 collNotified_
    ) {
        return (lastExternalPrice, lastExternalBlock,
                externalBoostCount, totalCollEmitNotified);
    }
}

// ── PATCH 2: TroikaCore ───────────────────────────────────────────────────
contract CoreCircularPatch is AccessControl {

    ICircularHub public hub;
    uint256      public totalFeeNotified;

    event HubSet(address hub);
    event FeeNotified(uint256 amount, uint8 tokenType);

    function setCircularHub(address hub_)
        external onlyRole(DEFAULT_ADMIN_ROLE)
    {
        if (hub_ == address(0)) revert ECE_ZeroAddress();
        hub = ICircularHub(hub_);
        emit HubSet(hub_);
    }

    // ─────────────────────────────────────────────────────────────────
    /// @notice Добавить в конец processFee() в TroikaCore:
    ///
    ///   if (address(hub) != address(0)) {
    ///       try ICircularHub(hub).onFeeProcessed(feeAmount, tokenType) {} catch {}
    ///   }
    function _notifyHubFee(uint256 amount, uint8 tokenType) internal {
        address h = address(hub);
        if (h == address(0) || amount == 0) return;
        totalFeeNotified += amount;
        try ICircularHub(h).onFeeProcessed(amount, tokenType) {
            emit FeeNotified(amount, tokenType);
        } catch {}
    }

    function coreStats() external view returns (uint256 total_) {
        return totalFeeNotified;
    }
}
