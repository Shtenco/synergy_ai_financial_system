from __future__ import annotations

import random
import unittest

from .econometrics import apply_month, hard_policy_ok, metrics
from .models import Decision, ModelPolicy, RevenueAllocation, SystemState
from .optimizer import optimize


def state(**overrides) -> SystemState:
    values = dict(
        liquid_reserves=1500.0, liabilities=1000.0, owned_liquidity_nav=600.0,
        bridge_capital=300.0, insurance_fund=80.0, circulating_supply=1_000_000.0,
        market_price=0.0015, liquidity_depth=800.0, monthly_volume=3000.0,
        protocol_fee_revenue_30d=18.0, flash_profit_30d=8.0, yield_revenue_30d=5.0,
        bridge_fee_revenue_30d=3.0, operating_cost_30d=7.0, gas_cost_30d=4.0,
        volatility_bps=1800.0, peg_error_bps=250.0, bridge_imbalance_bps=800.0,
    )
    values.update(overrides)
    return SystemState(**values)


def balanced(qe: float = 0.10, buyback_bps: int = 1250) -> Decision:
    # Keep the total at 10,000 when the buyback share changes.
    reserve = 3500 + (1250 - buyback_bps)
    return Decision(
        name="TEST",
        allocation=RevenueAllocation(reserve, 3000, buyback_bps, 1000, 750, 500),
        qe_fraction_of_excess=qe,
        qe_liquidity_share=0.60,
        qe_bridge_share=0.25,
        qe_insurance_share=0.15,
        flash_search_intensity=0.65,
    )


class EconometricModelTests(unittest.TestCase):
    def setUp(self) -> None:
        self.policy = ModelPolicy()

    def test_market_price_does_not_change_fundamental_value(self):
        low = metrics(state(market_price=0.001), self.policy)
        high = metrics(state(market_price=0.01), self.policy)
        self.assertAlmostEqual(low.fundamental_mcap, high.fundamental_mcap)
        self.assertGreater(high.market_mcap, low.market_mcap)

    def test_bridge_qe_is_reallocation_not_instant_value(self):
        s = state(protocol_fee_revenue_30d=0, flash_profit_30d=0, yield_revenue_30d=0,
                  bridge_fee_revenue_30d=0, operating_cost_30d=0, gas_cost_30d=0)
        before = metrics(s, self.policy).backing_nav
        d = balanced(qe=0.10, buyback_bps=0)
        after, flow = apply_month(s, d, self.policy, random.Random(1))
        after_nav = metrics(after, self.policy).backing_nav
        self.assertLessEqual(after_nav, before + 1e-8)
        self.assertGreater(flow["qe_budget"], 0)
        self.assertGreaterEqual(flow["execution_losses"], 0)

    def test_buyback_is_not_executed_above_fundamental_limit(self):
        s = state(market_price=0.02)
        after, flow = apply_month(s, balanced(qe=0.0, buyback_bps=2000), self.policy, random.Random(2))
        self.assertEqual(flow["buyback_spend"], 0)
        self.assertEqual(after.circulating_supply, s.circulating_supply)

    def test_flash_profit_adds_realized_revenue(self):
        s = state(protocol_fee_revenue_30d=0, yield_revenue_30d=0, bridge_fee_revenue_30d=0,
                  operating_cost_30d=0, gas_cost_30d=0, flash_profit_30d=10)
        _, flow = apply_month(s, balanced(qe=0.0), self.policy, random.Random(3))
        self.assertGreater(flow["flash_profit"], 0)
        self.assertAlmostEqual(flow["realized_revenue"], flow["flash_profit"], places=7)

    def test_qe_is_capped_by_excess_reserve(self):
        s = state(liquid_reserves=1210, liabilities=1000)
        _, flow = apply_month(s, balanced(qe=0.25), self.policy, random.Random(4))
        # Revenue can increase the base, but deployment still cannot exceed hard monthly cap.
        self.assertLessEqual(flow["qe_budget"], self.policy.maximum_qe_per_month + 1e-9)

    def test_hard_policy_fails_closed(self):
        ok, reason = hard_policy_ok(state(bridge_imbalance_bps=7000), self.policy)
        self.assertFalse(ok)
        self.assertIn("bridge", reason)

    def test_optimizer_returns_risk_adjusted_rank(self):
        best, ranked = optimize(state(), self.policy, scenarios=80, horizon_months=3, seed=11)
        self.assertTrue(ranked)
        self.assertEqual(best.score, ranked[0].score)
        self.assertGreaterEqual(best.expected_reserve_ratio, 0)
        best.decision.validate()

    def test_optimizer_disables_qe_in_hard_risk_state(self):
        best, _ = optimize(state(bridge_imbalance_bps=7000), self.policy, scenarios=50, horizon_months=2, seed=19)
        self.assertEqual(best.decision.qe_fraction_of_excess, 0.0)
        self.assertTrue(best.decision.name.startswith("DEFENSIVE"))


if __name__ == "__main__":
    unittest.main()
