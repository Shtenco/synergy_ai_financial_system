#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
 ПОЛНЫЙ ЭКОНОМИЧЕСКИЙ АНАЛИЗ TROIKA SYSTEM
 ДЕТАЛЬНЫЙ РАЗБОР ВСЕХ ДЕНЕЖНЫХ ПОТОКОВ
═══════════════════════════════════════════════════════════════════════════════

КОНТРАКТЫ И ИХ РОЛЬ В ДЕНЕЖНЫХ ПОТОКАХ:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

01_PolygonConfig.sol
└── Константы: WPOL, QuickSwap, интервалы

02_Tokens.sol (SYNA, SYNC, SYNR)
└── ERC-20 с MINTER_ROLE и BURNER_ROLE
    ⮕ КЛЮЧ: EmissionEngine может МИНТИТЬ новые токены!

03_TroikaVault.sol
└── Центральное хранилище:
    • LP токены QuickSwap (pairR, pairT, pairP)
    • traderReserve - для дозаправки трейдеров
    • reserveR - collateral резерв
    • mcgFund - MCap Guard
    • lpBuf - буфер для добавления LP
    • buybackAccum - для buyback SYNR

    МЕТОДЫ ПОЛУЧЕНИЯ WPOL:
    • freeWpol() - свободный WPOL сверх locked
    • transferWpol() - вывод WPOL
    • queueEmergencyWithdraw() + executeEmergencyWithdraw() - вывод LP!

04_TWAPOracle.sol
└── TWAP цены для арбитража

05_DividendPool.sol
└── РАСПРЕДЕЛЕНИЕ ПРИБЫЛИ:
    • founderPending - 30% эмиссии + 70% от alphaDIV комиссии
    • holdersPool - 30% от alphaDIV комиссии

    МЕТОДЫ ВЫВОДА WPOL:
    • withdrawFounder() - вывод founder дивидендов
    • claimHolders() - вывод держателям SYNR

06_FeeRouter.sol
└── Маршрутизация комиссий:
    • 35% → lpBuf (LP)
    • 30% → traderReserve
    • 15% → cbFund (арбитраж)
    • 10% → дивиденды (7% founder, 3% holders)
    • 10% → reserveR

07_EmissionEngine.sol ⭐ ИСТОЧНИК НОВЫХ ДЕНЕГ!
└── ЭМИССИЯ (каждые 50 блоков):
    em = Supply × emitRate × 100

    РАСПРЕДЕЛЕНИЕ:
    • 8% → reserveR
    • 62% → LP pools (виртуально)
    • 30% → founder (РЕАЛЬНЫЙ WPOL!)

    КЛЮЧЕВОЕ: Vault.transferWpol(divPool, toFounder)
    └── Если Vault.freeWpol() >= toFounder → РЕАЛЬНЫЙ перевод WPOL!

08_CBArbitrage.sol
└── Арбитраж между SYNC/SYNR пулами

09_SelfReinforcingLoop.sol
└── Автоматизация тиков

10_TroikaCore.sol
└── Координатор всех операций

11_FounderControl.sol
└── Управление founder выводами

═══════════════════════════════════════════════════════════════════════════════
 КЛЮЧЕВАЯ МЕХАНИКА ПРИБЫЛИ
═══════════════════════════════════════════════════════════════════════════════

ИСТОЧНИКИ РЕАЛЬНОГО WPOL:

1. EMISSION (30% → founder):
   └── Vault.transferWpol(divPool, amount)
   └── ТРЕБУЕТ: Vault.freeWpol() > 0

2. FEES (7% → founder):
   └── FeeRouter.routeFee() → DivPool.notifyFounder()
   └── ТРЕБУЕТ: Торговая активность

3. CB ARBITRAGE:
   └── Прибыль от арбитража между пулами
   └── ТРЕБУЕТ: Gap > 1% между SYNC/SYNR ценами

ПРОБЛЕМА ТЕКУЩЕЙ СИСТЕМЫ:
━━━━━━━━━━━━━━━━━━━━━━━━━
Vault.freeWpol() = 0
└── Все 3 WPOL залочены в traderReserve + reserveR + mcgFund
└── 30% эмиссии НЕ ПЕРЕВОДИТСЯ реально!

═══════════════════════════════════════════════════════════════════════════════
 FLASH LOAN PROFIT SCHEME
═══════════════════════════════════════════════════════════════════════════════

ИДЕЯ: Временно увеличить Vault.freeWpol() чтобы получить реальный WPOL

СХЕМА С 2000 POL FLASH LOAN (fee = 1 POL):
──────────────────────────────────────────

[START] Owner: 5 POL, 5 WPOL, 100 SYNA, 1000 SYNC, 200 SYNR

[1] Flash Loan 2000 WPOL из Aave
    Fee: 2000 × 0.05% = 1 WPOL

[2] Wrap → Transfer 2000 WPOL в Vault
    └── Vault WPOL: 3 → 2003
    └── Vault freeWpol: 0 → 2000

[3] Trigger EmissionEngine.executeEmission()
    └── Мinт новых токенов в Vault
    └── 30% dlp ≈ 0.03 WPOL → DividendPool.founderPending
    └── Vault.transferWpol(divPool, 0.03) РАБОТАЕТ!

[4] DividendPool.withdrawFounder()
    └── Получаем 0.03 WPOL на owner

[5] Vault.transferWpol(owner, 2000)
    └── Забираем Flash Loan обратно

[6] Return Flash Loan + 1 POL fee

[END] Owner: 5 POL - 1 POL (fee) - gas + 0.03 WPOL (emission)

УБЫТОК: ~1 POL на fee, ~0.15 POL на gas
ПРИБЫЛЬ: ~0.03 WPOL от эмиссии
NET: -1.12 POL 💀

═══════════════════════════════════════════════════════════════════════════════
 НАСТОЯЩИЙ ПУТЬ К ПРИБЫЛИ
═══════════════════════════════════════════════════════════════════════════════

ПРОБЛЕМА: emitRate = 2e-6 (минимум), эмиссия слишком маленькая

РЕШЕНИЕ 1: Увеличить emitRate
─────────────────────────────
emitRate MAX = 50e-6 (×25 больше!)
emission_value ×25 → ~0.75 WPOL

НО: emitRate адаптируется автоматически через adapt()
    Чтобы увеличить emitRate нужно:
    - Высокая торговая активность
    - Рост fee в окне адаптации

РЕШЕНИЕ 2: Emergency Withdraw LP
────────────────────────────────
TroikaVault.queueEmergencyWithdraw()
+ TroikaVault.executeEmergencyWithdraw()

ТАЙМЛОК = 0 (мгновенно!)
ОКНО = type(uint256).max (бесконечно!)

РЕЗУЛЬТАТ:
- Забираем LP токены из QuickSwap
- LP → removeLiquidity → WPOL + токены
- PROFIT = стоимость LP

СХЕМА РЕАЛЬНОЙ ПРИБЫЛИ:
──────────────────────────
[1] queueEmergencyWithdraw(0, lpAmount) для SYNA_WPOL
[2] executeEmergencyWithdraw(0)
[3] Получаем WPOL + SYNA из пула
[4] Swap SYNA → WPOL
[5] PROFIT = WPOL полученные

ОДНАКО: Это разрушает систему (убирает ликвидность)

РЕШЕНИЕ 3: Торговый арбитраж через CBArbitrage
──────────────────────────────────────────────
executeArb() делает:
1. Покупает дешевый токен за WPOL
2. Продает за WPOL
3. profit = разница

НО: cbFund пополняется из fee (15%)
    Нужна торговая активность!

═══════════════════════════════════════════════════════════════════════════════
 ЕДИНСТВЕННАЯ 100% ПРИБЫЛЬНАЯ СХЕМА
═══════════════════════════════════════════════════════════════════════════════

ФАКТ: Owner = DEFAULT_ADMIN_ROLE = может всё!

СХЕМА "FOUNDER EXTRACTION":
──────────────────────────

[1] Wrap 3 POL → WPOL
    └── Owner WPOL: 5 → 8

[2] Transfer 3 WPOL в Vault
    └── IERC20(WPOL).transfer(vault, 3e18)
    └── Vault freeWpol: 0 → 3

[3] Trigger emission (через EmissionEngine)
    └── 30% dlp = ~0.03 WPOL → DivPool.founderPending
    └── Vault.transferWpol() РАБОТАЕТ!

[4] Wait 50 blocks, repeat emission
    └── Ещё +0.03 WPOL

[5] After N emissions:
    └── founderPending = N × 0.03 WPOL

[6] DividendPool.withdrawFounder()
    └── Получаем N × 0.03 WPOL

[7] Vault.transferWpol(owner, 3 WPOL)
    └── Забираем исходный депозит

PROFIT = N × 0.03 WPOL - gas
При N=100 emissions:
    PROFIT = 3 WPOL - 15 POL gas = -12 POL 💀

ПРОБЛЕМА: Gas >> emission value!

═══════════════════════════════════════════════════════════════════════════════
 РЕШЕНИЕ: УВЕЛИЧИТЬ EMISSION VALUE
═══════════════════════════════════════════════════════════════════════════════

ТЕКУЩИЕ ПАРАМЕТРЫ:
- emitRate = 2e-6 (EMIT_RATE_MIN)
- Supply ≈ 102 SYNA, 1019 SYNC, 204 SYNR
- emission_value ≈ 0.093 WPOL per cycle

СПОСОБ 1: Передеплоить EmissionEngine с emitRate = 50e-6
─────────────────────────────────────────────────────────
emission_value = 0.093 × 25 = 2.33 WPOL!

PROFIT per emission:
  2.33 × 30% = 0.7 WPOL (founder)
  - 0.15 gas
  = 0.55 WPOL NET PROFIT!

СПОСОБ 2: Mint больше токенов
─────────────────────────────
em = Supply × emitRate × 100

При Supply ×10:
  emission_value = 0.93 WPOL

СПОСОБ 3: Увеличить LP reserves (TVL)
────────────────────────────────────
dlp = LP × (√((S+em)/S) − 1) × 0.997

При LP ×10:
  dlp ×10 → founder share ×10

═══════════════════════════════════════════════════════════════════════════════
"""

import sys, io, os, json
from decimal import Decimal, getcontext
from dotenv import load_dotenv
from web3 import Web3
from web3.middleware import ExtraDataToPOAMiddleware

getcontext().prec = 50

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

load_dotenv()
w3 = Web3(Web3.HTTPProvider("https://polygon-bor-rpc.publicnode.com"))
w3.middleware_onion.inject(ExtraDataToPOAMiddleware, layer=0)

def C(a): return Web3.to_checksum_address(a)

with open("deployed_TROIKA_v3.json") as f:
    d = json.load(f)

OWNER = "0x6946999DBCE63b140B1bB9D475F7c357130909E5"
WPOL = "0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270"

print(__doc__)

print("="*80)
print(" ТЕКУЩИЕ ПАРАМЕТРЫ СИСТЕМЫ")
print("="*80)

# Get current data
TOKEN_ABI = [
    {"name": "totalSupply", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "balanceOf", "inputs": [{"type": "address"}], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
]

PAIR_ABI = [
    {"name": "getReserves", "inputs": [], "outputs": [{"type": "uint112"}, {"type": "uint112"}, {"type": "uint32"}], "stateMutability": "view", "type": "function"},
    {"name": "token0", "inputs": [], "outputs": [{"type": "address"}], "stateMutability": "view", "type": "function"},
]

VAULT_ABI = [
    {"name": "freeWpol", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "lpR", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "lpT", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "lpP", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "traderReserve", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "reserveR", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "mcgFund", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
]

EMIT_ABI = [
    {"name": "emitRate", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "EMIT_RATE_MIN", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "EMIT_RATE_MAX", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
]

# Supplies
supplies = {}
for name, addr in d["tokens"].items():
    tk = w3.eth.contract(address=C(addr), abi=TOKEN_ABI)
    supplies[name] = Decimal(tk.functions.totalSupply().call()) / Decimal(10**18)

# Prices
prices = {}
for pool_name, pool_addr in d["pools"].items():
    pair = w3.eth.contract(address=C(pool_addr), abi=PAIR_ABI)
    r0, r1, _ = pair.functions.getReserves().call()
    token0 = pair.functions.token0().call()
    token_name = pool_name.split("_")[0]
    if token0.lower() == WPOL.lower():
        wpol_r = Decimal(r0) / Decimal(10**18)
        token_r = Decimal(r1) / Decimal(10**18)
    else:
        wpol_r = Decimal(r1) / Decimal(10**18)
        token_r = Decimal(r0) / Decimal(10**18)
    prices[token_name] = wpol_r / token_r if token_r > 0 else Decimal(0)

# Vault state
vault = w3.eth.contract(address=C(d["vault"]), abi=VAULT_ABI)
vault_free = Decimal(vault.functions.freeWpol().call()) / Decimal(10**18)
vault_lpR = Decimal(vault.functions.lpR().call()) / Decimal(10**18)
vault_lpT = Decimal(vault.functions.lpT().call()) / Decimal(10**18)
vault_lpP = Decimal(vault.functions.lpP().call()) / Decimal(10**18)

# Emit engine
emit = w3.eth.contract(address=C(d["emitEngine_v2"]), abi=EMIT_ABI)
emit_rate = Decimal(emit.functions.emitRate().call()) / Decimal(10**18)
emit_rate_max = Decimal("50e-6")

print(f"\n[SUPPLIES]")
for t, s in supplies.items():
    print(f"  {t}: {s:.6f}")

print(f"\n[PRICES]")
for t, p in prices.items():
    print(f"  {t}: {p:.6f} WPOL")

print(f"\n[VAULT]")
print(f"  freeWpol: {vault_free:.6f}")
print(f"  LP: R={vault_lpR:.4f} T={vault_lpT:.4f} P={vault_lpP:.4f}")

print(f"\n[EMISSION ENGINE]")
print(f"  emitRate: {emit_rate:.10f} (current)")
print(f"  EMIT_RATE_MAX: {emit_rate_max:.10f}")

# Calculate emission value
EMIT_RATE = Decimal("2e-6")
emission = {}
emission_value = Decimal(0)
for t, s in supplies.items():
    em = s * EMIT_RATE * 100
    value = em * prices[t]
    emission[t] = em
    emission_value += value

print(f"\n[EMISSION PER CYCLE (current emitRate)]")
for t, em in emission.items():
    print(f"  {t}: {em:.10f} = {em * prices[t]:.10f} WPOL")
print(f"  TOTAL: {emission_value:.10f} WPOL")
print(f"  Founder 30%: {emission_value * Decimal('0.30'):.10f} WPOL")

# At max emit rate
emission_max = {}
emission_value_max = Decimal(0)
for t, s in supplies.items():
    em = s * emit_rate_max * 100
    value = em * prices[t]
    emission_max[t] = em
    emission_value_max += value

print(f"\n[EMISSION PER CYCLE (MAX emitRate = 50e-6)]")
for t, em in emission_max.items():
    print(f"  {t}: {em:.10f} = {em * prices[t]:.10f} WPOL")
print(f"  TOTAL: {emission_value_max:.10f} WPOL")
print(f"  Founder 30%: {emission_value_max * Decimal('0.30'):.10f} WPOL")

# Flash loan profitability
print("\n" + "="*80)
print(" FLASH LOAN PROFITABILITY ANALYSIS")
print("="*80)

flash_amounts = [100, 500, 1000, 2000]
gas_cost = Decimal("0.15")

for flash in flash_amounts:
    flash_d = Decimal(flash)
    aave_fee = flash_d * Decimal("0.0005")

    # При текущем emitRate
    founder_share = emission_value * Decimal("0.30")
    gross = founder_share - aave_fee - gas_cost

    # При max emitRate
    founder_share_max = emission_value_max * Decimal("0.30")
    gross_max = founder_share_max - aave_fee - gas_cost

    print(f"\nFlash {flash} POL (fee={aave_fee:.4f} POL):")
    print(f"  Current emitRate: founder={founder_share:.6f}, net={gross:.6f} POL")
    print(f"  Max emitRate:     founder={founder_share_max:.6f}, net={gross_max:.6f} POL")

print("\n" + "="*80)
print(" РЕШЕНИЕ: ПЕРЕДЕПЛОЙ EMISSIONENGINE С EMIT_RATE = 50e-6")
print("="*80)

print("""
При EMIT_RATE = 50e-6 (максимум):

  Emission value: {:.6f} WPOL
  Founder (30%):  {:.6f} WPOL
  Gas:           ~0.15 POL
  ─────────────────────────
  NET PROFIT:    {:.6f} WPOL per emission!

FLASH LOAN SCHEME (fee = 1 POL):
────────────────────────────────
[1] Flash 2000 WPOL (fee = 1 POL)
[2] Transfer to Vault → freeWpol = 2000
[3] executeEmission() → founder gets {:.6f} WPOL
[4] withdrawFounder()
[5] Return 2001 WPOL

NET PROFIT: {:.6f} - 1 - 0.15 = {:.6f} POL

При 10 эмиссиях за 1 Flash Loan период:
  PROFIT = 10 × {:.6f} - 1 - 1.5 = {:.6f} POL

""".format(
    emission_value_max,
    emission_value_max * Decimal("0.30"),
    emission_value_max * Decimal("0.30") - Decimal("0.15"),
    emission_value_max * Decimal("0.30"),
    emission_value_max * Decimal("0.30"),
    emission_value_max * Decimal("0.30") - Decimal("1") - Decimal("0.15"),
    emission_value_max * Decimal("0.30"),
    10 * emission_value_max * Decimal("0.30") - Decimal("1") - Decimal("1.5")
))

print("="*80)
print(" ПЛАН ДЕЙСТВИЙ")
print("="*80)
print("""
1. ПЕРЕДЕПЛОЙ EmissionEngine с измененным emitRate = 50e-6
   └── Или модифицировать контракт чтобы emitRate начинался с MAX

2. Создать Flash Loan контракт:
   - Flash 2000 WPOL
   - Transfer в Vault
   - executeEmission()
   - withdrawFounder()
   - Return Flash

3. Или ПРОЩЕ: Просто transfer POL в Vault вручную
   └── Увеличить freeWpol
   └── Emission будет работать
   └── Founder получит реальный WPOL

ВАЖНО: Нужен Vault с freeWpol > 0 для реальных выплат founder!
""")
