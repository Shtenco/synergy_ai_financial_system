from __future__ import annotations

import unittest

from ai_centrobank_sinergy import EconomicEngine, SearchConfig
from ai_centrobank_sinergy.policy import evaluate


class EconomicEngineTests(unittest.TestCase):
    def test_search_is_deterministic_and_finite(self) -> None:
        engine = EconomicEngine(50.0, 100.0)
        cfg = SearchConfig(max_depth=3, beam_width=50)
        first = engine.search(cfg)
        second = engine.search(cfg)
        self.assertEqual([a.label for a in first.actions], [a.label for a in second.actions])
        self.assertTrue(first.score == first.score)
        self.assertLess(first.risk, 1000)

    def test_bridge_rebalance_reduces_imbalance(self) -> None:
        engine = EconomicEngine(50.0, 100.0)
        before = engine.metrics(engine.state)["bridge_imbalance"]
        action = next(a for a in engine.generate_actions(engine.state, SearchConfig()) if a.kind == "BRIDGE_REBALANCE")
        engine.state = engine.apply_action(engine.state, action, SearchConfig())
        after = engine.metrics(engine.state)["bridge_imbalance"]
        self.assertLess(after, before)

    def test_policy_blocks_unbacked_state(self) -> None:
        engine = EconomicEngine(50.0, 100.0)
        before = engine.metrics(engine.state)
        bad = dict(before)
        bad["reserve_ratio"] = 0.8
        decision = evaluate(before, bad)
        self.assertFalse(decision.allowed)

    def test_cycles_return_auditable_hashes(self) -> None:
        engine = EconomicEngine(50.0, 100.0)
        rows, _ = engine.run_cycles(2, SearchConfig(max_depth=2, beam_width=30))
        self.assertEqual(len(rows), 2)
        self.assertTrue(all(row["state_hash"].startswith("0x") for row in rows))

    def test_internal_swap_cannot_create_reference_nav(self) -> None:
        engine = EconomicEngine(50.0, 100.0)
        before = engine.metrics(engine.state)["ecosystem_nav"]
        action = next(a for a in engine.generate_actions(engine.state, SearchConfig()) if a.kind == "SWAP")
        state2 = engine.apply_action(engine.state, action, SearchConfig())
        after = engine.metrics(state2)["ecosystem_nav"]
        self.assertAlmostEqual(before, after, places=8)

    def test_owner_share_prevents_counting_external_lp_as_owned(self) -> None:
        engine = EconomicEngine(50.0, 100.0)
        pool = next(iter(engine.state.pools.values()))
        pool.owner_share = 0.10
        prices = engine.reference_prices
        self.assertAlmostEqual(engine.pool_nav(pool, prices), engine.pool_nav(pool, prices, owned_only=False) * 0.10)


if __name__ == "__main__":
    unittest.main()
