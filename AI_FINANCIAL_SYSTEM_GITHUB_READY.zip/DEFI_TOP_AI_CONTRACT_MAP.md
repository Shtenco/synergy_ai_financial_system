# SHTENCO DeFi TOP AI v3 — карта взаимодействия контрактов

## Управление

- `28_SHTENCOSystemStateOracle` публикует подтверждённый M-of-N экономический snapshot.
- `30_SHTENCOTopAIController` читает snapshot при propose и execute.
- `31_SHTENCODeFiContourRegistry` фиксирует канонические адреса девяти модулей.

## Реальный доход

- `22_FlashLoanArbitrage` выполняет внешний арбитраж и хранит чистую прибыль.
- `32_SHTENCOFlashProfitHarvester` выводит прибыль и вызывает `29_SHTENCOValueFlowTreasury.recordRevenue()`.
- Другие approved revenue sources могут перечислять protocol fees, yield и bridge fees непосредственно в Treasury с уникальными source IDs.

## Распределение

- `29_SHTENCOValueFlowTreasury.allocateRevenue()` делит доход на шесть buckets.
- `LIQUIDITY` и `BUYBACK` направляются в `25_SHTENCOMarketMaker`.
- `BRIDGE` направляется в `24_SHTENCOBridgeQEReserve`, затем через `27_SHTENCOBridgeQEAdapter` в `23_SHTENCOBridgeRelayV2`.
- `RESERVE` сохраняет backing; часть excess reserve может быть reclassified только в liquidity/bridge/insurance.

## Bridge

- `24_SHTENCOBridgeQEReserve` задаёт floor и daily budget.
- `27_SHTENCOBridgeQEAdapter` ограничивает approved route/network/recipient.
- `23_SHTENCOBridgeRelayV2` выполняет lock/mint или burn/release по M-of-N EIP-712 сообщениям.

## Market maker

- `25_SHTENCOMarketMaker` исполняет только oracle-bounded swaps, LP и buyback-burn.
- Все вызовы проходят target/selector/budget policy нового TOP AI Controller.

## Ownership/roles

- Governance: multisig.
- State reporters: независимые ключи и независимые data pipelines.
- AI proposer: только создаёт proposal.
- Executor: исполняет после timelock.
- Guardian: отменяет/останавливает.
- Treasury controller: TOP AI Controller.
- Harvester controller: TOP AI Controller.
