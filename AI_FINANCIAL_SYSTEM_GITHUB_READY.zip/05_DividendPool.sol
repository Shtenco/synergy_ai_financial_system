// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

// ═══════════════════════════════════════════════════════════════════════════
//  SINERGY SYSTEM — 05_DividendPool.sol
//  Пул дивидендов в WPOL | Polygon
//
//  Паттерн: PUSH + NOTIFY (FeeRouter / CBArb / EmitEngine переводят WPOL
//  сюда через safeTransfer, затем вызывают notify*(). DividendPool
//  только учитывает поступление — нет transferFrom с других контрактов.)
//
//  FOUNDER (70% от alphaDIV комиссии + 30% от эмиссии):
//   founderPending   — ждёт вывода или реинвеста (pull-payment)
//   reinvestMode     — true: FounderControl.reinvestFounder() → LP
//                      false: FounderControl.withdrawFounderTo() → wallet
//
//  HOLDERS (держатели SYNR):
//   dividendPerToken — накопленный доход на 1 токен (ERC-20 checkpoint)
//   executeHoldersPayout() — 85% holdersPool → divPerTok (каждые 1000 блоков)
//   claimHolders()   — pull-payment, msg.sender забирает своё в WPOL
//   updateCheckpoint(addr) — вызывать при каждом transfer SYNR
//
//  Безопасность:
//   ✓ Pull-payment — нет push, нет reentrancy через получателей
//   ✓ ReentrancyGuard на всех withdraw / claim
//   ✓ CEI (Checks→Effects→Interactions) везде
//   ✓ Timelock 2 дня на смену founder
//   ✓ Проверка баланса: founderPending + holdersPool ≤ WPOL
//   ✓ MAX_SINGLE_NOTIFY — защита от аномального одного уведомления
//   ✓ Нет selfdestruct, delegatecall, tx.origin
// ═══════════════════════════════════════════════════════════════════════════

import {IERC20}          from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20}       from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {AccessControl}   from "@openzeppelin/contracts/access/AccessControl.sol";
import {Pausable}        from "@openzeppelin/contracts/utils/Pausable.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {Math}            from "@openzeppelin/contracts/utils/math/Math.sol";
import "./01_PolygonConfig.sol";

// ── Custom Errors ─────────────────────────────────────────────────────────
error DP_ZeroAddress();
error DP_ZeroAmount();
error DP_NotFounder(address caller, address founder_);
error DP_NothingToClaim();
error DP_InsufficientFunds(uint256 available, uint256 required);
error DP_AmountTooLarge(uint256 amount, uint256 max_);
error DP_ReinvestModeActive();
error DP_PayoutTooEarly(uint256 nextBlock, uint256 current);
error DP_FounderChangePending();
error DP_FounderChangeNotQueued();
error DP_FounderChangeTimelockActive(uint256 unlockAt, uint256 now_);

contract DividendPool is AccessControl, Pausable, ReentrancyGuard {
    using SafeERC20 for IERC20;

    bytes32 public constant NOTIFIER_ROLE    = keccak256("NOTIFIER_ROLE");    // FeeRouter, CBArb, EmitEngine
    bytes32 public constant PAYOUT_ROLE      = keccak256("PAYOUT_ROLE");      // TroikaCore
    bytes32 public constant FOUNDER_CTL_ROLE = keccak256("FOUNDER_CTL_ROLE"); // FounderControl
    bytes32 public constant PAUSER_ROLE      = keccak256("PAUSER_ROLE");

    // ── Токены ────────────────────────────────────────────────────────
    IERC20 public immutable WPOL;
    IERC20 public immutable SYNR;

    // ── Founder state ─────────────────────────────────────────────────
    address public founder;
    uint256 public founderPending;          // ждёт действия
    uint256 public founderPaidToWallet;     // суммарно выплачено на кошелёк
    uint256 public founderReinvestedTotal;  // суммарно реинвестировано в LP
    uint256 public founderEmissionAccum;    // из 30% эмиссии
    bool    public reinvestMode;

    // Founder change — INSTANT (no timelock)
    address public pendingFounder;
    uint256 public founderChangeUnlock;
    uint256 public constant FOUNDER_TIMELOCK = 0;

    // ── Holders state ─────────────────────────────────────────────────
    uint256 public holdersPool;
    uint256 public lastPayoutBlock;
    uint256 public dividendPerToken;
    mapping(address => uint256) public divDebt;
    mapping(address => uint256) public claimableBal;

    // ── Статистика ────────────────────────────────────────────────────
    uint256 public totalNotifiedFounder;
    uint256 public totalNotifiedHolders;
    uint256 public totalPaidHolders;

    uint256 public constant MAX_SINGLE_NOTIFY = 1_000_000e18;

    // ── Events ────────────────────────────────────────────────────────
    event FounderNotified(uint256 amount, uint256 pending);
    event HoldersNotified(uint256 amount, uint256 pool);
    event EmissionNotified(uint256 amount, uint256 accumTotal);
    event HoldersPayoutDone(uint256 paid, uint256 newDivPerToken, uint256 blockN);
    event FounderWithdrawn(address indexed to, uint256 amount);
    event FounderReinvested(address indexed vault, uint256 amount);
    event HolderClaimed(address indexed account, uint256 amount);
    event ReinvestModeSet(bool enabled);
    event FounderChangeQueued(address indexed newFounder, uint256 unlockAt);
    event FounderChangeExecuted(address indexed oldFounder, address indexed newFounder);
    event FounderChangeCancelled();

    constructor(address synr_, address founder_, address admin_) {
        if (synr_ == address(0)) revert DP_ZeroAddress();
        if (founder_ == address(0)) revert DP_ZeroAddress();
        if (admin_   == address(0)) revert DP_ZeroAddress();

        WPOL    = IERC20(PolygonConfig.WPOL);
        SYNR   = IERC20(synr_);
        founder = founder_;

        _grantRole(DEFAULT_ADMIN_ROLE, admin_);
        _grantRole(NOTIFIER_ROLE,      admin_);
        _grantRole(PAYOUT_ROLE,        admin_);
        _grantRole(FOUNDER_CTL_ROLE,   admin_);
        _grantRole(PAUSER_ROLE,        admin_);
    }

    // ═══════════════════════════════════════════════════════════════════
    //  NOTIFY — FeeRouter / CBArb уже сделали safeTransfer сюда
    // ═══════════════════════════════════════════════════════════════════

    /// @notice FeeRouter: cash-доля дивидендов основателя (7% комиссии)
    function notifyFounder(uint256 amount)
        external whenNotPaused onlyRole(NOTIFIER_ROLE)
    {
        if (amount == 0) revert DP_ZeroAmount();
        if (amount > MAX_SINGLE_NOTIFY) revert DP_AmountTooLarge(amount, MAX_SINGLE_NOTIFY);
        founderPending       += amount;
        totalNotifiedFounder += amount;
        emit FounderNotified(amount, founderPending);
    }

    /// @notice FeeRouter / CBArb: доля holders
    function notifyHolders(uint256 amount)
        external whenNotPaused onlyRole(NOTIFIER_ROLE)
    {
        if (amount == 0) revert DP_ZeroAmount();
        if (amount > MAX_SINGLE_NOTIFY) revert DP_AmountTooLarge(amount, MAX_SINGLE_NOTIFY);
        holdersPool          += amount;
        totalNotifiedHolders += amount;
        emit HoldersNotified(amount, holdersPool);
    }

    /// @notice EmissionEngine: 30% от dlp → основателю (ключевой источник)
    function notifyFounderEmission(uint256 amount)
        external whenNotPaused onlyRole(NOTIFIER_ROLE)
    {
        if (amount == 0) revert DP_ZeroAmount();
        if (amount > MAX_SINGLE_NOTIFY) revert DP_AmountTooLarge(amount, MAX_SINGLE_NOTIFY);
        founderPending       += amount;
        founderEmissionAccum += amount;
        totalNotifiedFounder += amount;
        emit EmissionNotified(amount, founderEmissionAccum);
    }

    // ═══════════════════════════════════════════════════════════════════
    //  PAYOUT HOLDERS — каждые 1000 блоков (TroikaCore)
    // ═══════════════════════════════════════════════════════════════════
    function executeHoldersPayout()
        external nonReentrant whenNotPaused onlyRole(PAYOUT_ROLE)
    {
        if (block.number < lastPayoutBlock + PolygonConfig.DIV_INTERVAL)
            revert DP_PayoutTooEarly(lastPayoutBlock + PolygonConfig.DIV_INTERVAL, block.number);
        if (holdersPool < 1e12) return;

        uint256 supply = SYNR.totalSupply();
        if (supply == 0) return;

        // Checks done. Effects:
        uint256 toPay    = holdersPool * 85 / 100;
        holdersPool     -= toPay;
        dividendPerToken += Math.mulDiv(toPay, 1e18, supply);
        totalPaidHolders += toPay;
        lastPayoutBlock   = block.number;

        emit HoldersPayoutDone(toPay, dividendPerToken, block.number);
        // Interactions: нет (только учёт)
    }

    // ═══════════════════════════════════════════════════════════════════
    //  REINVEST MODE — управляется FounderControl
    // ═══════════════════════════════════════════════════════════════════

    function setReinvestMode(bool enabled)
        external onlyRole(FOUNDER_CTL_ROLE)
    {
        reinvestMode = enabled;
        emit ReinvestModeSet(enabled);
    }

    /// @notice FounderControl реинвестирует founderPending → Vault.lpBuf
    function reinvestFounder(address vaultAddr)
        external nonReentrant whenNotPaused onlyRole(FOUNDER_CTL_ROLE)
    {
        if (vaultAddr == address(0)) revert DP_ZeroAddress();
        uint256 amount = founderPending;
        if (amount == 0) revert DP_NothingToClaim();
        _checkLiquidity(amount);

        // Effects
        founderPending          = 0;
        founderReinvestedTotal += amount;

        // Interactions
        WPOL.safeTransfer(vaultAddr, amount);
        emit FounderReinvested(vaultAddr, amount);
    }

    /// @notice FounderControl выводит founderPending на кошелёк
    function withdrawFounderTo(address to)
        external nonReentrant whenNotPaused onlyRole(FOUNDER_CTL_ROLE)
    {
        if (to == address(0)) revert DP_ZeroAddress();
        uint256 amount = founderPending;
        if (amount == 0) revert DP_NothingToClaim();
        _checkLiquidity(amount);

        // Effects
        founderPending      = 0;
        founderPaidToWallet += amount;

        // Interactions
        WPOL.safeTransfer(to, amount);
        emit FounderWithdrawn(to, amount);
    }

    /// @notice Прямой вывод основателем (если FounderControl не задан или reinvest off)
    function withdrawFounder()
        external nonReentrant whenNotPaused
    {
        if (msg.sender != founder) revert DP_NotFounder(msg.sender, founder);
        if (reinvestMode)          revert DP_ReinvestModeActive();
        uint256 amount = founderPending;
        if (amount == 0) revert DP_NothingToClaim();
        _checkLiquidity(amount);

        // Effects
        founderPending      = 0;
        founderPaidToWallet += amount;

        // Interactions
        WPOL.safeTransfer(founder, amount);
        emit FounderWithdrawn(founder, amount);
    }

    function _checkLiquidity(uint256 required) private view {
        uint256 bal = WPOL.balanceOf(address(this));
        // Резервируем holdersPool как неприкосновенный запас для holders
        if (bal < required + holdersPool)
            revert DP_InsufficientFunds(bal, required + holdersPool);
    }

    // ═══════════════════════════════════════════════════════════════════
    //  ERC-20 DIVIDEND CHECKPOINT + CLAIM
    // ═══════════════════════════════════════════════════════════════════

    /// @notice Обновить накопленные дивиденды для account.
    ///         Вызывать при каждом transfer SYNR (перед сменой баланса).
    function updateCheckpoint(address account) public whenNotPaused {
        if (account == address(0)) revert DP_ZeroAddress();
        uint256 bal    = SYNR.balanceOf(account);
        uint256 earned = Math.mulDiv(bal, dividendPerToken - divDebt[account], 1e18);
        if (earned > 0) claimableBal[account] += earned;
        divDebt[account] = dividendPerToken;
    }

    function claimHolders() external nonReentrant whenNotPaused {
        updateCheckpoint(msg.sender);
        uint256 amount = claimableBal[msg.sender];
        if (amount == 0) revert DP_NothingToClaim();

        uint256 bal = WPOL.balanceOf(address(this));
        if (bal < amount + founderPending)
            revert DP_InsufficientFunds(bal, amount + founderPending);

        // Effects
        claimableBal[msg.sender] = 0;

        // Interactions
        WPOL.safeTransfer(msg.sender, amount);
        emit HolderClaimed(msg.sender, amount);
    }

    function pendingFor(address account) external view returns (uint256) {
        uint256 bal    = SYNR.balanceOf(account);
        uint256 earned = Math.mulDiv(bal, dividendPerToken - divDebt[account], 1e18);
        return claimableBal[account] + earned;
    }

    // ═══════════════════════════════════════════════════════════════════
    //  FOUNDER CHANGE — Timelock 2 дня
    // ═══════════════════════════════════════════════════════════════════

    function queueFounderChange(address newFounder_)
        external onlyRole(DEFAULT_ADMIN_ROLE)
    {
        if (newFounder_ == address(0)) revert DP_ZeroAddress();
        if (pendingFounder != address(0)) revert DP_FounderChangePending();
        pendingFounder      = newFounder_;
        founderChangeUnlock = block.timestamp + FOUNDER_TIMELOCK;
        emit FounderChangeQueued(newFounder_, founderChangeUnlock);
    }

    function executeFounderChange() external onlyRole(DEFAULT_ADMIN_ROLE) {
        if (pendingFounder == address(0))   revert DP_FounderChangeNotQueued();
        if (block.timestamp < founderChangeUnlock)
            revert DP_FounderChangeTimelockActive(founderChangeUnlock, block.timestamp);
        address old     = founder;
        founder         = pendingFounder;
        pendingFounder  = address(0);
        founderChangeUnlock = 0;
        emit FounderChangeExecuted(old, founder);
    }

    function cancelFounderChange() external onlyRole(DEFAULT_ADMIN_ROLE) {
        pendingFounder      = address(0);
        founderChangeUnlock = 0;
        emit FounderChangeCancelled();
    }

    // ── View helpers ──────────────────────────────────────────────────
    function founderStats() external view returns (
        uint256 pending_,
        uint256 paidToWallet_,
        uint256 reinvested_,
        uint256 emissionAccum_,
        bool    reinvestMode_
    ) {
        return (
            founderPending,
            founderPaidToWallet,
            founderReinvestedTotal,
            founderEmissionAccum,
            reinvestMode
        );
    }

    function pause()   external onlyRole(PAUSER_ROLE) { _pause(); }
    function unpause() external onlyRole(PAUSER_ROLE) { _unpause(); }
}
