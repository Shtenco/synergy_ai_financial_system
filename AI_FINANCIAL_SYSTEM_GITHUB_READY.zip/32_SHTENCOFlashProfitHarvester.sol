// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {AccessControl} from "@openzeppelin/contracts/access/AccessControl.sol";
import {Pausable} from "@openzeppelin/contracts/utils/Pausable.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";

interface ISHTENCOFlashProfitSource {
    function withdrawProfit(address token, address to, uint256 amount) external;
    function acceptOwnership() external;
}

interface ISHTENCORevenueTreasury {
    function recordRevenue(address token, uint256 amount, bytes32 sourceId) external;
}

/**
 * @title SHTENCOFlashProfitHarvester
 * @notice Atomic adapter between the Aave flash-arbitrage executor and the
 *         unified value treasury. The harvester can become owner of approved
 *         flash executors, withdraw only to the configured treasury and record
 *         the exact balance increase as realized protocol revenue.
 */
contract SHTENCOFlashProfitHarvester is AccessControl, Pausable, ReentrancyGuard {
    bytes32 public constant CONTROLLER_ROLE = keccak256("CONTROLLER_ROLE");
    bytes32 public constant POLICY_ROLE = keccak256("POLICY_ROLE");
    bytes32 public constant GUARDIAN_ROLE = keccak256("GUARDIAN_ROLE");

    address public treasury;
    mapping(address => bool) public allowedSource;

    event TreasurySet(address indexed treasury);
    event SourceSet(address indexed source, bool allowed);
    event SourceOwnershipAccepted(address indexed source);
    event ProfitHarvested(
        address indexed source,
        address indexed token,
        uint256 amount,
        bytes32 indexed sourceId
    );

    constructor(address admin, address treasury_) {
        require(admin != address(0) && treasury_ != address(0), "HARVEST: bad init");
        require(treasury_.code.length > 0, "HARVEST: treasury not contract");
        treasury = treasury_;
        _grantRole(DEFAULT_ADMIN_ROLE, admin);
        _grantRole(POLICY_ROLE, admin);
        _grantRole(GUARDIAN_ROLE, admin);
    }

    function harvest(address source, address token, uint256 amount, bytes32 sourceId)
        external
        onlyRole(CONTROLLER_ROLE)
        nonReentrant
        whenNotPaused
    {
        require(allowedSource[source] && token != address(0) && amount > 0, "HARVEST: source or amount");
        require(sourceId != bytes32(0), "HARVEST: empty source id");
        uint256 beforeBalance = IERC20(token).balanceOf(treasury);
        ISHTENCOFlashProfitSource(source).withdrawProfit(token, treasury, amount);
        uint256 afterBalance = IERC20(token).balanceOf(treasury);
        require(afterBalance - beforeBalance == amount, "HARVEST: balance mismatch");
        ISHTENCORevenueTreasury(treasury).recordRevenue(token, amount, sourceId);
        emit ProfitHarvested(source, token, amount, sourceId);
    }

    function acceptSourceOwnership(address source) external onlyRole(POLICY_ROLE) {
        require(allowedSource[source], "HARVEST: source disabled");
        ISHTENCOFlashProfitSource(source).acceptOwnership();
        emit SourceOwnershipAccepted(source);
    }

    function setSource(address source, bool allowed) external onlyRole(POLICY_ROLE) {
        require(source != address(0) && (!allowed || source.code.length > 0), "HARVEST: invalid source");
        allowedSource[source] = allowed;
        emit SourceSet(source, allowed);
    }

    function setTreasury(address treasury_) external onlyRole(POLICY_ROLE) {
        require(treasury_ != address(0) && treasury_.code.length > 0, "HARVEST: invalid treasury");
        treasury = treasury_;
        emit TreasurySet(treasury_);
    }

    function pause() external onlyRole(GUARDIAN_ROLE) { _pause(); }
    function unpause() external onlyRole(DEFAULT_ADMIN_ROLE) { _unpause(); }
}
