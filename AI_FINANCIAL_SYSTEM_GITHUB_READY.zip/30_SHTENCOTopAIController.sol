// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {AccessControl} from "@openzeppelin/contracts/access/AccessControl.sol";
import {Pausable} from "@openzeppelin/contracts/utils/Pausable.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {Math} from "@openzeppelin/contracts/utils/math/Math.sol";

interface ISHTENCOSystemStateOracle {
    struct Snapshot {
        uint256 round;
        uint64 finalizedAt;
        bytes32 snapshotHash;
        bytes32 externalDataHash;
        uint256 liquidReserves;
        uint256 liabilities;
        uint256 ownedLiquidityNav;
        uint256 bridgeCapital;
        uint256 circulatingSupply;
        uint256 protocolRevenue30d;
        uint256 marketPrice;
        uint256 marketCap;
        uint256 backingNav;
        uint256 discountedRevenueValue;
        uint256 fundamentalMcap;
        uint256 fundamentalPrice;
        uint32 reserveRatioBps;
        uint32 valuationPremiumBps;
        uint16 volatilityBps;
        uint16 pegErrorBps;
        uint16 bridgeImbalanceBps;
        uint16 liquidityCoverageBps;
    }

    function getLatestSnapshot() external view returns (Snapshot memory);
}

/**
 * @title SHTENCOTopAIController
 * @notice Unified timelocked controller for flash-profit harvesting, revenue
 *         allocation, market making, reserve QE and bridge rebalancing. The
 *         controller accepts proposals only against a fresh, M-of-N finalized
 *         economic snapshot and rechecks system health immediately before
 *         execution.
 */
contract SHTENCOTopAIController is AccessControl, Pausable, ReentrancyGuard {
    bytes32 public constant AI_PROPOSER_ROLE = keccak256("AI_PROPOSER_ROLE");
    bytes32 public constant EXECUTOR_ROLE = keccak256("EXECUTOR_ROLE");
    bytes32 public constant POLICY_ROLE = keccak256("POLICY_ROLE");
    bytes32 public constant GUARDIAN_ROLE = keccak256("GUARDIAN_ROLE");

    uint256 public constant BPS = 10_000;
    uint256 public constant MAX_ACTIONS = 12;

    struct Action {
        address target;
        uint256 value;
        bytes data;
        address budgetToken;
        uint256 budgetAmount;
    }

    struct ProposalRequest {
        uint256 snapshotRound;
        bytes32 objectiveHash;
        uint256 expectedNavDelta;
        uint256 maxCapitalAtRisk;
        uint16 modelRiskBps;
        uint64 executeAfter;
        uint64 expiresAt;
    }

    struct Proposal {
        address proposer;
        uint64 proposedAt;
        uint64 executeAfter;
        uint64 expiresAt;
        uint16 modelRiskBps;
        uint256 snapshotRound;
        bytes32 snapshotHash;
        bytes32 objectiveHash;
        uint256 baselineBackingNav;
        uint256 baselineFundamentalMcap;
        uint256 expectedNavDelta;
        uint256 maxCapitalAtRisk;
        bool executed;
        bool cancelled;
    }

    struct DailyBudget {
        uint64 day;
        uint192 amount;
    }

    ISHTENCOSystemStateOracle public stateOracle;
    uint256 public proposalNonce;
    uint256 public minDelay = 15 minutes;
    uint256 public maxDelay = 3 days;
    uint256 public maxExecutionWindow = 1 days;
    uint256 public maxSnapshotAge = 30 minutes;

    uint16 public maximumModelRiskBps = 2_500;
    uint16 public maxCapitalAtRiskBps = 1_000;
    uint16 public maxStateDeteriorationBps = 200;
    uint32 public minimumReserveRatioBps = 12_000;
    uint32 public maximumValuationPremiumBps = 20_000;
    uint16 public maximumVolatilityBps = 7_500;
    uint16 public maximumPegErrorBps = 1_200;
    uint16 public maximumBridgeImbalanceBps = 3_500;
    uint16 public minimumLiquidityCoverageBps = 2_000;

    mapping(address => bool) public targetEnabled;
    mapping(address => mapping(bytes4 => bool)) public selectorEnabled;
    mapping(address => mapping(bytes4 => bool)) public selectorBudgetRequired;
    mapping(address => uint256) public dailyBudgetLimit;
    mapping(address => DailyBudget) private _dailyBudget;
    mapping(bytes32 => Proposal) public proposals;
    mapping(bytes32 => Action[]) private _actions;

    event StateOracleSet(address indexed oracle);
    event TargetPolicySet(address indexed target, bool enabled);
    event SelectorPolicySet(address indexed target, bytes4 indexed selector, bool enabled, bool budgetRequired);
    event BudgetLimitSet(address indexed token, uint256 dailyLimit);
    event TimingPolicySet(uint256 minDelay, uint256 maxDelay, uint256 maxExecutionWindow, uint256 maxSnapshotAge);
    event SystemPolicySet(
        uint32 minimumReserveRatioBps,
        uint32 maximumValuationPremiumBps,
        uint16 maximumVolatilityBps,
        uint16 maximumPegErrorBps,
        uint16 maximumBridgeImbalanceBps,
        uint16 minimumLiquidityCoverageBps,
        uint16 maximumModelRiskBps,
        uint16 maxCapitalAtRiskBps,
        uint16 maxStateDeteriorationBps
    );
    event ProposalCreated(
        bytes32 indexed proposalId,
        uint256 indexed snapshotRound,
        bytes32 indexed snapshotHash,
        bytes32 objectiveHash,
        uint256 expectedNavDelta,
        uint256 maxCapitalAtRisk,
        uint16 modelRiskBps,
        uint256 actionCount
    );
    event ActionExecuted(bytes32 indexed proposalId, uint256 indexed actionIndex, address indexed target, bytes4 selector);
    event ProposalExecuted(bytes32 indexed proposalId, address indexed executor, uint256 currentSnapshotRound);
    event ProposalCancelled(bytes32 indexed proposalId, address indexed guardian);

    constructor(
        address admin,
        address oracle,
        address aiProposer,
        address executor,
        address guardian
    ) {
        require(
            admin != address(0) && oracle != address(0) && aiProposer != address(0) &&
            executor != address(0) && guardian != address(0),
            "TOP-AI: bad init"
        );
        require(oracle.code.length > 0, "TOP-AI: oracle not contract");
        stateOracle = ISHTENCOSystemStateOracle(oracle);
        _grantRole(DEFAULT_ADMIN_ROLE, admin);
        _grantRole(POLICY_ROLE, admin);
        _grantRole(AI_PROPOSER_ROLE, aiProposer);
        _grantRole(EXECUTOR_ROLE, executor);
        _grantRole(GUARDIAN_ROLE, guardian);
    }

    function propose(Action[] calldata actions, ProposalRequest calldata request)
        external
        onlyRole(AI_PROPOSER_ROLE)
        whenNotPaused
        returns (bytes32 proposalId)
    {
        require(actions.length > 0 && actions.length <= MAX_ACTIONS, "TOP-AI: bad action count");
        require(request.objectiveHash != bytes32(0) && request.expectedNavDelta > 0, "TOP-AI: no positive objective");
        require(request.modelRiskBps <= maximumModelRiskBps, "TOP-AI: model risk");
        require(
            request.executeAfter >= block.timestamp + minDelay && request.executeAfter <= block.timestamp + maxDelay,
            "TOP-AI: bad delay"
        );
        require(
            request.expiresAt > request.executeAfter && request.expiresAt <= request.executeAfter + maxExecutionWindow,
            "TOP-AI: bad expiry"
        );

        ISHTENCOSystemStateOracle.Snapshot memory snapshot = stateOracle.getLatestSnapshot();
        _validateSnapshot(snapshot);
        require(snapshot.round == request.snapshotRound, "TOP-AI: snapshot round changed");
        uint256 riskLimit = Math.mulDiv(snapshot.liquidReserves, maxCapitalAtRiskBps, BPS);
        require(request.maxCapitalAtRisk <= riskLimit, "TOP-AI: capital at risk");

        (bytes32 actionsHash, uint256 totalNativeValue) = _hashAndValidateActions(actions);
        require(totalNativeValue <= address(this).balance, "TOP-AI: native budget");

        proposalId = keccak256(abi.encode(
            block.chainid,
            address(this),
            ++proposalNonce,
            msg.sender,
            actionsHash,
            snapshot.snapshotHash,
            request
        ));

        proposals[proposalId] = Proposal({
            proposer: msg.sender,
            proposedAt: uint64(block.timestamp),
            executeAfter: request.executeAfter,
            expiresAt: request.expiresAt,
            modelRiskBps: request.modelRiskBps,
            snapshotRound: snapshot.round,
            snapshotHash: snapshot.snapshotHash,
            objectiveHash: request.objectiveHash,
            baselineBackingNav: snapshot.backingNav,
            baselineFundamentalMcap: snapshot.fundamentalMcap,
            expectedNavDelta: request.expectedNavDelta,
            maxCapitalAtRisk: request.maxCapitalAtRisk,
            executed: false,
            cancelled: false
        });
        for (uint256 i; i < actions.length; ++i) _actions[proposalId].push(actions[i]);

        emit ProposalCreated(
            proposalId,
            snapshot.round,
            snapshot.snapshotHash,
            request.objectiveHash,
            request.expectedNavDelta,
            request.maxCapitalAtRisk,
            request.modelRiskBps,
            actions.length
        );
    }

    function _hashAndValidateActions(Action[] calldata actions)
        internal
        view
        returns (bytes32 actionsHash, uint256 totalNativeValue)
    {
        for (uint256 i; i < actions.length; ++i) {
            Action calldata action = actions[i];
            _validateAction(action);
            totalNativeValue += action.value;
            actionsHash = keccak256(abi.encode(
                actionsHash,
                action.target,
                action.value,
                keccak256(action.data),
                action.budgetToken,
                action.budgetAmount
            ));
        }
    }

    function execute(bytes32 proposalId)
        external
        onlyRole(EXECUTOR_ROLE)
        nonReentrant
        whenNotPaused
        returns (bytes[] memory results)
    {
        Proposal storage proposal = proposals[proposalId];
        require(proposal.proposer != address(0), "TOP-AI: unknown proposal");
        require(!proposal.executed && !proposal.cancelled, "TOP-AI: closed proposal");
        require(block.timestamp >= proposal.executeAfter, "TOP-AI: timelocked");
        require(block.timestamp <= proposal.expiresAt, "TOP-AI: expired");

        ISHTENCOSystemStateOracle.Snapshot memory current = stateOracle.getLatestSnapshot();
        _validateSnapshot(current);
        require(current.round >= proposal.snapshotRound, "TOP-AI: oracle rollback");
        require(
            Math.mulDiv(current.backingNav, BPS, proposal.baselineBackingNav) >= BPS - maxStateDeteriorationBps,
            "TOP-AI: backing deteriorated"
        );
        require(
            Math.mulDiv(current.fundamentalMcap, BPS, proposal.baselineFundamentalMcap) >= BPS - maxStateDeteriorationBps,
            "TOP-AI: value deteriorated"
        );

        Action[] storage actions = _actions[proposalId];
        results = new bytes[](actions.length);
        proposal.executed = true;
        for (uint256 i; i < actions.length; ++i) {
            Action storage action = actions[i];
            _validateStoredAction(action);
            _consumeBudget(action.budgetToken, action.budgetAmount);
            (bool success, bytes memory result) = action.target.call{value: action.value}(action.data);
            if (!success) _bubbleRevert(result);
            results[i] = result;
            emit ActionExecuted(proposalId, i, action.target, _selector(action.data));
        }
        emit ProposalExecuted(proposalId, msg.sender, current.round);
    }

    function _validateSnapshot(ISHTENCOSystemStateOracle.Snapshot memory s) internal view {
        require(s.snapshotHash != bytes32(0) && s.finalizedAt != 0, "TOP-AI: no snapshot");
        require(block.timestamp >= s.finalizedAt && block.timestamp - s.finalizedAt <= maxSnapshotAge, "TOP-AI: stale snapshot");
        require(s.backingNav > 0 && s.fundamentalMcap >= s.backingNav, "TOP-AI: invalid value");
        require(s.reserveRatioBps >= minimumReserveRatioBps, "TOP-AI: reserve ratio");
        require(s.valuationPremiumBps <= maximumValuationPremiumBps, "TOP-AI: valuation premium");
        require(s.volatilityBps <= maximumVolatilityBps, "TOP-AI: volatility");
        require(s.pegErrorBps <= maximumPegErrorBps, "TOP-AI: peg error");
        require(s.bridgeImbalanceBps <= maximumBridgeImbalanceBps, "TOP-AI: bridge imbalance");
        require(s.liquidityCoverageBps >= minimumLiquidityCoverageBps, "TOP-AI: liquidity coverage");
    }

    function _validateAction(Action calldata action) internal view {
        require(action.target != address(0) && action.data.length >= 4, "TOP-AI: malformed action");
        require(action.target != address(this) && targetEnabled[action.target], "TOP-AI: target disabled");
        bytes4 selector = _selector(action.data);
        require(selectorEnabled[action.target][selector], "TOP-AI: selector disabled");
        if (selectorBudgetRequired[action.target][selector]) {
            require(action.budgetToken != address(0) && action.budgetAmount > 0, "TOP-AI: budget required");
        }
        require(action.budgetAmount == 0 || action.budgetToken != address(0), "TOP-AI: budget token");
    }

    function _validateStoredAction(Action storage action) internal view {
        require(targetEnabled[action.target], "TOP-AI: target disabled");
        bytes4 selector = _selector(action.data);
        require(selectorEnabled[action.target][selector], "TOP-AI: selector disabled");
        if (selectorBudgetRequired[action.target][selector]) {
            require(action.budgetToken != address(0) && action.budgetAmount > 0, "TOP-AI: budget required");
        }
    }

    function _consumeBudget(address token, uint256 amount) internal {
        if (amount == 0) return;
        DailyBudget storage budget = _dailyBudget[token];
        uint64 day = uint64(block.timestamp / 1 days);
        if (budget.day != day) {
            budget.day = day;
            budget.amount = 0;
        }
        uint256 next = uint256(budget.amount) + amount;
        uint256 limit = dailyBudgetLimit[token];
        require(limit > 0 && next <= limit, "TOP-AI: daily budget");
        require(next <= type(uint192).max, "TOP-AI: budget overflow");
        budget.amount = uint192(next);
    }

    function cancel(bytes32 proposalId) external onlyRole(GUARDIAN_ROLE) {
        Proposal storage proposal = proposals[proposalId];
        require(proposal.proposer != address(0), "TOP-AI: unknown proposal");
        require(!proposal.executed && !proposal.cancelled, "TOP-AI: closed proposal");
        proposal.cancelled = true;
        emit ProposalCancelled(proposalId, msg.sender);
    }

    function setStateOracle(address oracle) external onlyRole(POLICY_ROLE) {
        require(oracle != address(0) && oracle.code.length > 0, "TOP-AI: invalid oracle");
        stateOracle = ISHTENCOSystemStateOracle(oracle);
        emit StateOracleSet(oracle);
    }

    function setTarget(address target, bool enabled) external onlyRole(POLICY_ROLE) {
        require(target != address(0) && target != address(this) && (!enabled || target.code.length > 0), "TOP-AI: invalid target");
        targetEnabled[target] = enabled;
        emit TargetPolicySet(target, enabled);
    }

    function setSelector(address target, bytes4 selector, bool enabled, bool budgetRequired)
        external
        onlyRole(POLICY_ROLE)
    {
        require(targetEnabled[target] && selector != bytes4(0), "TOP-AI: target or selector");
        selectorEnabled[target][selector] = enabled;
        selectorBudgetRequired[target][selector] = enabled && budgetRequired;
        emit SelectorPolicySet(target, selector, enabled, enabled && budgetRequired);
    }

    function setBudgetLimit(address token, uint256 dailyLimit) external onlyRole(POLICY_ROLE) {
        require(token != address(0), "TOP-AI: zero token");
        dailyBudgetLimit[token] = dailyLimit;
        emit BudgetLimitSet(token, dailyLimit);
    }

    function setTimingPolicy(uint256 minDelay_, uint256 maxDelay_, uint256 executionWindow, uint256 snapshotAge)
        external
        onlyRole(POLICY_ROLE)
    {
        require(minDelay_ >= 1 minutes && maxDelay_ >= minDelay_ && maxDelay_ <= 14 days, "TOP-AI: delay range");
        require(executionWindow >= 5 minutes && executionWindow <= 7 days, "TOP-AI: window range");
        require(snapshotAge >= 5 minutes && snapshotAge <= 1 days, "TOP-AI: snapshot age");
        minDelay = minDelay_;
        maxDelay = maxDelay_;
        maxExecutionWindow = executionWindow;
        maxSnapshotAge = snapshotAge;
        emit TimingPolicySet(minDelay_, maxDelay_, executionWindow, snapshotAge);
    }

    function setSystemPolicy(
        uint32 minReserveRatio,
        uint32 maxValuationPremium,
        uint16 maxVolatility,
        uint16 maxPegError,
        uint16 maxBridgeImbalance,
        uint16 minLiquidityCoverage,
        uint16 maxModelRisk,
        uint16 maxCapitalRisk,
        uint16 maxDeterioration
    ) external onlyRole(POLICY_ROLE) {
        require(minReserveRatio >= BPS && minReserveRatio <= 50_000, "TOP-AI: reserve policy");
        require(maxValuationPremium >= BPS && maxValuationPremium <= 50_000, "TOP-AI: valuation policy");
        require(maxVolatility <= BPS && maxPegError <= BPS && maxBridgeImbalance <= BPS, "TOP-AI: risk range");
        require(minLiquidityCoverage <= BPS, "TOP-AI: coverage range");
        require(maxModelRisk <= 5_000 && maxCapitalRisk <= 3_000 && maxDeterioration <= 1_000, "TOP-AI: control range");
        minimumReserveRatioBps = minReserveRatio;
        maximumValuationPremiumBps = maxValuationPremium;
        maximumVolatilityBps = maxVolatility;
        maximumPegErrorBps = maxPegError;
        maximumBridgeImbalanceBps = maxBridgeImbalance;
        minimumLiquidityCoverageBps = minLiquidityCoverage;
        maximumModelRiskBps = maxModelRisk;
        maxCapitalAtRiskBps = maxCapitalRisk;
        maxStateDeteriorationBps = maxDeterioration;
        emit SystemPolicySet(
            minReserveRatio,
            maxValuationPremium,
            maxVolatility,
            maxPegError,
            maxBridgeImbalance,
            minLiquidityCoverage,
            maxModelRisk,
            maxCapitalRisk,
            maxDeterioration
        );
    }

    function _selector(bytes memory data) internal pure returns (bytes4 selector) {
        require(data.length >= 4, "TOP-AI: selector missing");
        assembly ("memory-safe") { selector := mload(add(data, 32)) }
    }

    function _bubbleRevert(bytes memory reason) internal pure {
        if (reason.length == 0) revert("TOP-AI: action failed");
        assembly ("memory-safe") { revert(add(reason, 32), mload(reason)) }
    }

    function getActionCount(bytes32 proposalId) external view returns (uint256) {
        return _actions[proposalId].length;
    }

    function getAction(bytes32 proposalId, uint256 index) external view returns (Action memory) {
        return _actions[proposalId][index];
    }

    function budgetUsedToday(address token) external view returns (uint256) {
        DailyBudget memory budget = _dailyBudget[token];
        return budget.day == uint64(block.timestamp / 1 days) ? budget.amount : 0;
    }

    function pause() external onlyRole(GUARDIAN_ROLE) { _pause(); }
    function unpause() external onlyRole(DEFAULT_ADMIN_ROLE) { _unpause(); }
    receive() external payable {}
}
