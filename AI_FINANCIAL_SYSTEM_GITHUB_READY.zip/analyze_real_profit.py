#!/usr/bin/env python3
"""
АНАЛИЗ РЕАЛЬНО ПРИБЫЛЬНОГО FLASH LOAN ЦИКЛА
Детальный разбор всех возможных стратегий
"""
import sys, io, os, json, time
from dotenv import load_dotenv
from web3 import Web3
from web3.middleware import ExtraDataToPOAMiddleware

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

load_dotenv()

w3 = Web3(Web3.HTTPProvider("https://polygon-bor-rpc.publicnode.com", request_kwargs={"timeout": 120}))
w3.middleware_onion.inject(ExtraDataToPOAMiddleware, layer=0)

WPOL = "0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270"

def C(a): return Web3.to_checksum_address(a)

with open("deployed_instant.json") as f:
    data = json.load(f)

print("=" * 70)
print("ЕДИНСТВЕННЫЙ 100% ПРИБЫЛЬНЫЙ FLASH LOAN СЦЕНАРИЙ")
print("=" * 70)

print("""
КЛЮЧЕВОЕ ПОНИМАНИЕ:
==================

Flash Loan сам по себе НЕ создаёт прибыль.
Flash Loan - это ИНСТРУМЕНТ для использования ВНЕШНЕГО источника прибыли.

ИСТОЧНИКИ ПРИБЫЛИ:
1. Арбитраж цен между площадками
2. Ликвидации (Aave, Compound)
3. Эмиссия/Rewards системы

ДЛЯ НАШЕЙ СИСТЕМЫ TROIKA:
=========================

Система TROIKA создаёт прибыль через:
- EmissionEngine: создаёт новые токены каждые 1000 блоков
- FeeRouter: распределяет комиссии LP провайдерам
- CBArbitrage: арбитраж между SYNC/SYNR

ПРОБЛЕМА: Эти контракты НЕ ЗАДЕПЛОЕНЫ!
""")

print("\n" + "=" * 70)
print("ПЛАН ДЕЙСТВИЙ")
print("=" * 70)

print("""
ВАРИАНТ 1: ЗАДЕПЛОИТЬ ВСЮ СИСТЕМУ TROIKA
----------------------------------------
Стоимость: ~15-20 POL (gas)
Остаток: ~9.45 POL

ЭТАПЫ:
1. Deploy TroikaVault (хранит LP, резервы)
2. Deploy TWAPOracle (цены)
3. Deploy DividendPool (дивиденды)
4. Deploy FeeRouter (распределение комиссий)
5. Deploy EmissionEngine (эмиссия)
6. Deploy CBArbitrage (арбитраж)
7. Deploy SelfReinforcingLoop (усиление)
8. Deploy TroikaCore (оркестратор)
9. Initialize всё
10. Grant roles

После этого:
- Каждый tick() генерирует доход
- LP провайдеры получают дивиденды
- Flash Loan позволяет стать мажоритарным LP
- Profit от эмиссии + комиссий


ВАРИАНТ 2: ПРОСТОЙ ARBITRAGE БЕЗ FLASH LOAN
-------------------------------------------
Используем оставшиеся 9.45 POL напрямую:

1. Добавить больше ликвидности в пулы
2. Торговать между пулами для генерации комиссий
3. Собирать комиссии как LP провайдер

Проблема: без Flash Loan объём маленький


ВАРИАНТ 3: НАЙТИ ВНЕШНИЙ АРБИТРАЖ
---------------------------------
Наши токены НОВЫЕ, на других DEX их нет.
Арбитраж невозможен.

""")

print("=" * 70)
print("РЕКОМЕНДАЦИЯ")
print("=" * 70)

print("""
С текущим балансом ~9.45 POL:

1. НЕДОСТАТОЧНО для деплоя всей системы TROIKA (~15-20 POL)

2. МОЖНО сделать простой тест:
   - Торговать между своими пулами
   - Проверить механику

3. НУЖНО пополнить баланс для полного деплоя

МАТЕМАТИКА ПРИБЫЛЬНОГО ЦИКЛА (после полного деплоя):
====================================================

При полностью развёрнутой системе:

1. Flash Loan 1000 POL
2. Add LP в 4 пула (по 250 POL) → доля ~95% в каждом пуле
3. TroikaCore.tick() запускает:
   - EmissionEngine: создаёт токены
   - CBArbitrage: делает арбитраж если gap > 1%
   - FeeRouter: распределяет комиссии
   - DividendPool: начисляет дивиденды
4. Claim дивиденды (~30% от эмиссии = основатель)
5. Remove LP
6. Repay 1000.5 POL
7. PROFIT = эмиссия + дивиденды - 0.5 POL

Оценка прибыли за цикл:
- Эмиссия: emitRate × totalSupply × 100 / 1e18
- При emitRate = 2e-6, supply = 10M SYNA:
  emission = 2e-6 × 10e6 × 100 = 2000 SYNA
- При цене 0.005 POL/SYNA = 10 POL в токенах
- Минус 0.5 POL Aave fee
- NET PROFIT ≈ 9.5 POL

НО! Это требует:
1. Полного деплоя системы
2. Первая эмиссия только через 1000 блоков
3. Нужно ждать или манипулировать lastEmitBlock
""")

print("\n" + "=" * 70)
print("ТЕСТ ПРОСТОГО СВАПА")
print("=" * 70)

# Проверим сколько можем заработать на простом свапе
PAIR_ABI = [
    {"name": "getReserves", "inputs": [], "outputs": [{"type": "uint112"}, {"type": "uint112"}, {"type": "uint32"}], "stateMutability": "view", "type": "function"},
    {"name": "token0", "inputs": [], "outputs": [{"type": "address"}], "stateMutability": "view", "type": "function"},
]

pools_info = {}
for name, pair_addr in data["pools"].items():
    try:
        pair = w3.eth.contract(address=C(pair_addr), abi=PAIR_ABI)
        r0, r1, _ = pair.functions.getReserves().call()
        token0 = pair.functions.token0().call()

        if token0.lower() == C(WPOL).lower():
            wpol = r0
            token = r1
        else:
            wpol = r1
            token = r0

        pools_info[name] = {"wpol": wpol, "token": token, "price": wpol/token if token > 0 else 0}
        print(f"{name}: {wpol/1e18:.4f} WPOL, price={wpol/token:.8f}")
    except Exception as e:
        print(f"{name}: Error - {e}")

# Симуляция: торговля 1 POL
print("\nСимуляция торговли 1 POL через SYNR:")
synr_pool = pools_info.get("SYNR_WPOL", {})
if synr_pool:
    wpol_in = int(1e18)
    wpol_res = synr_pool["wpol"]
    token_res = synr_pool["token"]

    # Купить SYNR
    fee = wpol_in * 3 // 1000
    amount_in_with_fee = wpol_in * 997
    tokens_out = amount_in_with_fee * token_res // (wpol_res * 1000 + amount_in_with_fee)

    new_wpol = wpol_res + wpol_in
    new_token = token_res - tokens_out

    print(f"  Купить: {wpol_in/1e18} POL → {tokens_out/1e18:.4f} SYNR")
    print(f"  Комиссия: {fee/1e18:.6f} POL")

    # Продать обратно
    fee2 = tokens_out * 3 // 1000
    amount_in_with_fee2 = tokens_out * 997
    pol_out = amount_in_with_fee2 * new_wpol // (new_token * 1000 + amount_in_with_fee2)

    print(f"  Продать: {tokens_out/1e18:.4f} SYNR → {pol_out/1e18:.6f} POL")
    print(f"  ИТОГО: {wpol_in/1e18} POL → {pol_out/1e18:.6f} POL")
    print(f"  ПОТЕРЯ: {(wpol_in - pol_out)/1e18:.6f} POL ({(wpol_in - pol_out)*100/wpol_in:.2f}%)")

print("\n" + "=" * 70)
print("ФИНАЛЬНЫЙ ВЫВОД")
print("=" * 70)
print("""
С ТЕКУЩИМИ 9.45 POL нет 100% прибыльного Flash Loan цикла.

ПРИЧИНЫ:
1. Токены НОВЫЕ - нет арбитража с другими DEX
2. Система TROIKA не развёрнута - нет эмиссии/дивидендов
3. Все пулы созданы нами - нет ценовых расхождений

ДЛЯ 100% ПРИБЫЛИ НУЖНО:
1. Пополнить баланс до ~25 POL
2. Задеплоить всю систему TROIKA
3. Тогда каждый tick() будет генерировать доход
4. Flash Loan позволит захватить 90%+ доли пулов
5. Получать 90%+ от эмиссии и комиссий

ИЛИ:
- Найти существующий арбитраж на рынке (не наши токены)
- Использовать Flash Loan для ликвидаций
- Это требует мониторинга и ботов
""")
