# Architecture

## 1. Trust boundaries

The design separates five powers:

1. **Policy administrator** — configures token, router, route, selector and risk limits.
2. **AI proposer** — may only create proposals that satisfy the on-chain score/risk and action allowlists.
3. **Executor** — may execute an approved proposal only after its delay and before expiry.
4. **Guardian** — may cancel proposals or pause critical modules.
5. **Bridge validators** — an M-of-N quorum signs a specific source transfer for a specific destination endpoint.

Production roles should be separate multisig or hardware-backed accounts. The deployer must not remain the sole administrator.

## 2. Bridge lifecycle

### Canonical to wrapped

`user/reserve → source bridge escrow → relay signatures → destination wrapped mint`

### Wrapped to canonical

`wrapped burn → relay signatures → canonical escrow release`

The destination stores two replay markers:

- the full EIP-712 message hash;
- an independent `(sourceChainId, sourceBridge, sourceNonce)` key.

The second marker prevents a source transfer from being processed again with a modified deadline.

## 3. QE bridge rebalancing

The reserve sends an approved amount to `SHTENCOBridgeQEAdapter`. The adapter can call only an approved route and recipient, and enforces max-per-transaction and daily limits. It does not mint and exposes no arbitrary approval function.

## 4. AI market maker

The market maker accepts inventory from the reserve and can perform:

- `executeSwap` — inventory rebalancing;
- `addLiquidity` — ratio-checked V2 liquidity addition with LP delivered to the treasury;
- `executeBuybackAndBurn` — atomic swap and burn of an allowlisted burnable token;
- `transferInventory` — return unused inventory to the configured treasury.

Every trading action is constrained by an independent price guard, token/router allowlists, daily notional limits, minimum output, short deadlines and pair cooldowns.

## 5. AI control loop

The Python engine performs deterministic beam search over:

- HOLD;
- market rebalance;
- add liquidity;
- bridge inventory rebalance;
- buyback and burn.

The model writes intents, not transactions. `materialize_ai_proposal.py` reads current contracts and quotes, inserts reserve allocations when necessary, encodes exact calldata and verifies the central bank's target, selector and budget policy before producing a materialized proposal.

## 6. No synthetic value assumption

The objective does not count:

- unbacked token issuance;
- wash volume;
- total LP reserves when the ecosystem owns only a fraction;
- spot-price changes as realized NAV growth;
- bridge liabilities as free assets.

The system may improve liquidity and capital efficiency, but it cannot guarantee profit or create external purchasing power from accounting alone.
