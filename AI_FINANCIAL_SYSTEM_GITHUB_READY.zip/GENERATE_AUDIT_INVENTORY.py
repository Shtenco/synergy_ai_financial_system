#!/usr/bin/env python3
"""Build a deterministic inventory of every project file for audit traceability."""

from __future__ import annotations

import ast
import csv
import hashlib
import json
import zipfile
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUTPUT_JSON = ROOT / "AUDIT_INVENTORY.json"
OUTPUT_CSV = ROOT / "AUDIT_SOURCE_FILES.csv"
EXCLUDED_OUTPUTS = {OUTPUT_JSON.name, OUTPUT_CSV.name}


def category(relative: Path) -> str:
    text = relative.as_posix()
    if text.startswith("node_modules/") or "/node_modules/" in f"/{text}":
        return "dependency"
    if text.startswith(("out/", "out_flash/", "out_qe_bridge/")) or any(part in {"artifacts", "cache"} for part in relative.parts):
        return "artifact"
    if relative.suffix.lower() == ".sol":
        return "solidity_source"
    if relative.suffix.lower() == ".py":
        return "python_source"
    if relative.suffix.lower() in {".md", ".txt"}:
        return "documentation"
    if relative.suffix.lower() in {".json", ".toml", ".env", ".example"}:
        return "configuration"
    if relative.suffix.lower() in {".exe", ".dll"}:
        return "binary"
    if relative.suffix.lower() == ".zip":
        return "archive"
    return "other"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def python_status(path: Path) -> str | None:
    if path.suffix.lower() != ".py":
        return None
    try:
        ast.parse(path.read_text(encoding="utf-8", errors="strict"), filename=str(path))
        return "ok"
    except (SyntaxError, UnicodeDecodeError) as exc:
        return f"error: {exc}"


def archive_entries(path: Path) -> int | None:
    if path.suffix.lower() != ".zip":
        return None
    try:
        with zipfile.ZipFile(path) as archive:
            return len(archive.infolist())
    except (zipfile.BadZipFile, OSError):
        return -1


def main() -> None:
    records = []
    dependency_roots = [ROOT / "node_modules", ROOT / "SHTENCO_QE_BRIDGE_AI" / "node_modules"]
    dependency_summary = []
    for dep_root in dependency_roots:
        if dep_root.exists():
            dep_files = [item for item in dep_root.rglob("*") if item.is_file()]
            dependency_summary.append({
                "path": dep_root.relative_to(ROOT).as_posix(),
                "file_count": len(dep_files),
                "total_bytes": sum(item.stat().st_size for item in dep_files),
                "note": "third-party dependency tree summarized; individual dependency hashes omitted",
            })

    for path in sorted(ROOT.rglob("*")):
        if not path.is_file() or path.name in EXCLUDED_OUTPUTS:
            continue
        relative = path.relative_to(ROOT)
        if "node_modules" in relative.parts:
            continue
        item = {
            "path": relative.as_posix(),
            "size_bytes": path.stat().st_size,
            "sha256": sha256(path),
            "category": category(relative),
        }
        status = python_status(path)
        if status is not None:
            item["python_ast"] = status
        entries = archive_entries(path)
        if entries is not None:
            item["zip_entries"] = entries
        records.append(item)

    categories = Counter(item["category"] for item in records)
    extensions = Counter(Path(item["path"]).suffix.lower() or "<none>" for item in records)
    python_errors = [item for item in records if item.get("python_ast", "ok") != "ok"]
    report = {
        "root": str(ROOT),
        "total_files": len(records),
        "total_bytes": sum(item["size_bytes"] for item in records),
        "categories": dict(sorted(categories.items())),
        "extensions": dict(sorted(extensions.items())),
        "python_ast_errors": len(python_errors),
        "dependency_summary": dependency_summary,
        "solidity_compile_command": "npm run check:contracts",
        "flash_compile_command": "npm run compile:flash",
        "qe_bridge_compile_command": "npm run compile:qe-bridge",
        "qe_bridge_test_command": "npm run test:qe-hardhat",
        "ai_test_command": "npm run test:ai",
        "top_ai_compile_command": "npm run compile:top-ai",
        "top_ai_contract_test_command": "npm run test:top-ai-contracts",
        "top_ai_econometric_test_command": "npm run test:top-ai-econometrics",
        "full_validation_log": "TOP_AI_TEST_LOG.txt",
        "records": records,
    }
    OUTPUT_JSON.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")

    source_records = [
        item for item in records
        if item["category"] in {"solidity_source", "python_source", "documentation", "configuration"}
    ]
    with OUTPUT_CSV.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=["path", "category", "size_bytes", "sha256", "python_ast"],
            extrasaction="ignore",
        )
        writer.writeheader()
        writer.writerows(source_records)

    print(json.dumps({key: report[key] for key in (
        "total_files", "total_bytes", "categories", "python_ast_errors"
    )}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
