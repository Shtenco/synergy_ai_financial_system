# Запуск SHTENCO DeFi TOP AI v3

## 1. Установка

Полный архив уже содержит зависимости. Для source-версии:

```powershell
cd D:\SYNA_FINANCIAL_SYSTEMS\FINAL\INSTANT_DEPLOY
npm install
cd SHTENCO_QE_BRIDGE_AI
npm install
cd ..\..
```

## 2. Полная локальная проверка

```powershell
npm run test:top-ai
```

Отдельно:

```powershell
python -m unittest defi_top_ai.test_econometrics -v
cd SHTENCO_QE_BRIDGE_AI\TOP_AI
node ..\node_modules\hardhat\internal\cli\cli.js test
```

## 3. Эконометрическая оптимизация

```powershell
python -m defi_top_ai.cli --scenarios 1000 --months 6 --output deployments\defi-top-ai-decision.json
```

Модель выдаёт allocation, QE fraction, flash search intensity, expected growth, CVaR и вероятность отрицательного сценария.

## 4. План одного value-cycle

```powershell
python -m defi_top_ai.proposal deployments\defi-top-ai-decision.json --profit-amount 100 --token USDC --output deployments\defi-top-ai-value-cycle.json
```

## 5. Контрактные переменные

```powershell
copy SHTENCO_QE_BRIDGE_AI\TOP_AI\.env.example SHTENCO_QE_BRIDGE_AI\TOP_AI\.env
```

Заполните отдельные адреса для:

- admin multisig;
- AI proposer;
- executor;
- guardian;
- 3+ независимых state reporters;
- существующих Flash Arbitrage, Market Maker, Bridge Reserve, Adapter и Relay Bridge.

## 6. Локальный deploy

```powershell
cd SHTENCO_QE_BRIDGE_AI\TOP_AI
node ..\node_modules\hardhat\internal\cli\cli.js run scripts\deploy_top_ai_contour.js --network hardhat
```

Polygon:

```powershell
node ..\node_modules\hardhat\internal\cli\cli.js run scripts\deploy_top_ai_contour.js --network polygon
```

Перед Polygon deployment обязательны multisig, реальные oracle feeds, reporter separation, fork test на фиксированном block number и независимый аудит.

## 7. Порядок production wiring

1. Deploy State Oracle, Value Treasury, TOP AI Controller, Harvester и Registry.
2. Grant Treasury `CONTROLLER_ROLE` TOP AI.
3. Grant Treasury `REVENUE_RECORDER_ROLE` Harvester.
4. Grant Harvester `CONTROLLER_ROLE` TOP AI.
5. Allowlist Flash source в Harvester.
6. При необходимости передать ownership FlashLoanArbitrage в Harvester через Ownable2Step.
7. Grant controller roles на Market Maker, Bridge Reserve и Bridge Adapter.
8. Allowlist targets/selectors и daily budgets в TOP AI.
9. Настроить token policy, reserve floor и разрешённые sinks.
10. Зарегистрировать все 9 модулей в Contour Registry и проверить `validateContour()`.
