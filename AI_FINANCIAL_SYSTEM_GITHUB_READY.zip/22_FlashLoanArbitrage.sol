// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/**
 * @title FlashLoanArbitrage
 * @notice Aave V3 flash-loan executor for atomic, pre-quoted arbitrage on
 *         whitelisted Uniswap-V2-compatible routers (QuickSwap V2, etc.).
 *
 * Profit is NOT created by the TROIKA emission/vault accounting. A transaction
 * succeeds only when the final balance of the borrowed asset can repay Aave and
 * still leaves at least `minProfit`. Otherwise the whole transaction reverts.
 */

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {Ownable2Step} from "@openzeppelin/contracts/access/Ownable2Step.sol";
import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";
import {Pausable} from "@openzeppelin/contracts/utils/Pausable.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";

interface IAavePoolFlash {
    function flashLoanSimple(
        address receiverAddress,
        address asset,
        uint256 amount,
        bytes calldata params,
        uint16 referralCode
    ) external;

    function FLASHLOAN_PREMIUM_TOTAL() external view returns (uint128);
}

interface IFlashLoanSimpleReceiverLike {
    function executeOperation(
        address asset,
        uint256 amount,
        uint256 premium,
        address initiator,
        bytes calldata params
    ) external returns (bool);
}

interface IUniswapV2RouterLike {
    function getAmountsOut(uint256 amountIn, address[] calldata path)
        external view returns (uint256[] memory amounts);

    function swapExactTokensForTokens(
        uint256 amountIn,
        uint256 amountOutMin,
        address[] calldata path,
        address to,
        uint256 deadline
    ) external returns (uint256[] memory amounts);

    function swapExactTokensForTokensSupportingFeeOnTransferTokens(
        uint256 amountIn,
        uint256 amountOutMin,
        address[] calldata path,
        address to,
        uint256 deadline
    ) external;
}

contract FlashLoanArbitrage is
    IFlashLoanSimpleReceiverLike,
    Ownable2Step,
    Pausable,
    ReentrancyGuard
{
    using SafeERC20 for IERC20;

    uint256 public constant MAX_STEPS = 4;
    uint256 public constant MAX_PATH_LENGTH = 5;
    uint256 public constant MAX_DEADLINE_WINDOW = 180;

    struct SwapStep {
        address router;
        address[] path;
        uint256 minAmountOut;
        bool supportFeeOnTransfer;
    }

    IAavePoolFlash public immutable AAVE_POOL;
    address public immutable WRAPPED_NATIVE;

    mapping(address => bool) public operators;
    mapping(address => bool) public allowedRouters;
    mapping(address => bool) public allowedTokens;

    uint256 public maxFlashAmount;
    mapping(address => uint256) public totalProfitByAsset;
    uint256 public successfulCycles;

    bool private _flashActive;
    bool private _callbackEntered;
    bytes32 private _activeParamsHash;
    address private _activeAsset;
    uint256 private _activeAmount;

    error NotOperator();
    error ZeroAddress();
    error ZeroAmount();
    error InvalidDeadline();
    error InvalidRoute();
    error RouterNotAllowed(address router);
    error TokenNotAllowed(address token);
    error FlashAlreadyActive();
    error InvalidFlashCallback();
    error FlashAmountTooLarge(uint256 requested, uint256 maximum);
    error QuoteBelowRequired(uint256 quotedOut, uint256 requiredOut);
    error BalanceDeltaTooSmall(address token, uint256 beforeBalance, uint256 afterBalance);
    error InsufficientFinalAmount(uint256 finalAmount, uint256 amountOwed, uint256 minProfit);
    error RescueDuringFlash();

    event OperatorSet(address indexed operator, bool allowed);
    event RouterSet(address indexed router, bool allowed);
    event TokenSet(address indexed token, bool allowed);
    event MaxFlashAmountSet(uint256 amount);
    event ArbitrageRequested(
        address indexed operator,
        address indexed asset,
        uint256 amount,
        uint256 quotedOut,
        uint256 minimumProfit
    );
    event SwapExecuted(
        uint256 indexed stepIndex,
        address indexed router,
        address indexed tokenOut,
        uint256 amountIn,
        uint256 amountOut
    );
    event ArbitrageExecuted(
        address indexed asset,
        uint256 borrowed,
        uint256 premium,
        uint256 profit
    );
    event ProfitWithdrawn(address indexed token, address indexed to, uint256 amount);

    modifier onlyOperator() {
        if (msg.sender != owner() && !operators[msg.sender]) revert NotOperator();
        _;
    }

    constructor(
        address initialOwner,
        address aavePool,
        address wrappedNative,
        uint256 initialMaxFlashAmount
    ) Ownable(initialOwner) {
        if (aavePool == address(0) || wrappedNative == address(0)) revert ZeroAddress();
        AAVE_POOL = IAavePoolFlash(aavePool);
        WRAPPED_NATIVE = wrappedNative;
        maxFlashAmount = initialMaxFlashAmount;

        allowedTokens[wrappedNative] = true;
        emit TokenSet(wrappedNative, true);
        emit MaxFlashAmountSet(initialMaxFlashAmount);
    }

    function setOperator(address operator, bool allowed) external onlyOwner {
        if (operator == address(0)) revert ZeroAddress();
        operators[operator] = allowed;
        emit OperatorSet(operator, allowed);
    }

    function setRouter(address router, bool allowed) external onlyOwner {
        if (router == address(0)) revert ZeroAddress();
        allowedRouters[router] = allowed;
        emit RouterSet(router, allowed);
    }

    function setToken(address token, bool allowed) external onlyOwner {
        if (token == address(0)) revert ZeroAddress();
        allowedTokens[token] = allowed;
        emit TokenSet(token, allowed);
    }

    function setMaxFlashAmount(uint256 amount) external onlyOwner {
        maxFlashAmount = amount;
        emit MaxFlashAmountSet(amount);
    }

    function pause() external onlyOwner { _pause(); }
    function unpause() external onlyOwner { _unpause(); }

    /**
     * @notice Quotes a sequence of router swaps without borrowing funds.
     * @dev Fee-on-transfer tokens can make this optimistic; the caller must apply
     *      an additional haircut and set strict per-step minAmountOut values.
     */
    function quoteRoute(uint256 amountIn, SwapStep[] calldata steps)
        public view returns (uint256 amountOut)
    {
        _validateRoute(address(0), steps, false);
        amountOut = amountIn;
        for (uint256 i; i < steps.length; ++i) {
            uint256[] memory amounts = IUniswapV2RouterLike(steps[i].router)
                .getAmountsOut(amountOut, steps[i].path);
            amountOut = amounts[amounts.length - 1];
        }
    }

    function flashPremiumBps() external view returns (uint256) {
        return uint256(AAVE_POOL.FLASHLOAN_PREMIUM_TOTAL());
    }

    /**
     * @notice Starts an atomic flash-loan arbitrage.
     * @param asset Borrowed asset. The first path must start with it and the last
     *              path must end with it.
     * @param amount Flash-loan principal.
     * @param steps One or more whitelisted router swaps.
     * @param minProfit Minimum profit denominated in `asset`, after Aave premium.
     *                  The off-chain bot should include gas and safety margin here.
     * @param deadline Unix timestamp, at most 180 seconds in the future.
     */
    function startArbitrage(
        address asset,
        uint256 amount,
        SwapStep[] calldata steps,
        uint256 minProfit,
        uint256 deadline
    ) external onlyOperator whenNotPaused {
        if (_flashActive) revert FlashAlreadyActive();
        if (asset == address(0)) revert ZeroAddress();
        if (amount == 0 || minProfit == 0) revert ZeroAmount();
        if (maxFlashAmount != 0 && amount > maxFlashAmount) {
            revert FlashAmountTooLarge(amount, maxFlashAmount);
        }
        if (deadline < block.timestamp || deadline > block.timestamp + MAX_DEADLINE_WINDOW) {
            revert InvalidDeadline();
        }

        _validateRoute(asset, steps, true);

        uint256 quotedOut = quoteRoute(amount, steps);
        uint256 premiumBps = uint256(AAVE_POOL.FLASHLOAN_PREMIUM_TOTAL());
        uint256 premium = (amount * premiumBps + 9_999) / 10_000;
        uint256 requiredOut = amount + premium + minProfit;
        if (quotedOut < requiredOut) revert QuoteBelowRequired(quotedOut, requiredOut);

        bytes memory params = abi.encode(steps, minProfit, deadline);
        _flashActive = true;
        _callbackEntered = false;
        _activeParamsHash = keccak256(params);
        _activeAsset = asset;
        _activeAmount = amount;

        emit ArbitrageRequested(msg.sender, asset, amount, quotedOut, minProfit);

        AAVE_POOL.flashLoanSimple(address(this), asset, amount, params, 0);

        _flashActive = false;
        _callbackEntered = false;
        _activeParamsHash = bytes32(0);
        _activeAsset = address(0);
        _activeAmount = 0;
    }

    /// @notice Aave V3 flash-loan callback.
    function executeOperation(
        address asset,
        uint256 amount,
        uint256 premium,
        address initiator,
        bytes calldata params
    ) external returns (bool) {
        if (
            msg.sender != address(AAVE_POOL) ||
            initiator != address(this) ||
            !_flashActive ||
            _callbackEntered ||
            asset != _activeAsset ||
            amount != _activeAmount ||
            keccak256(params) != _activeParamsHash
        ) revert InvalidFlashCallback();

        _callbackEntered = true;

        (SwapStep[] memory steps, uint256 minProfit, uint256 deadline) =
            abi.decode(params, (SwapStep[], uint256, uint256));

        if (deadline < block.timestamp) revert InvalidDeadline();

        uint256 currentAmount = amount;
        for (uint256 i; i < steps.length; ++i) {
            SwapStep memory step = steps[i];
            address tokenIn = step.path[0];
            address tokenOut = step.path[step.path.length - 1];

            IERC20(tokenIn).forceApprove(step.router, currentAmount);
            uint256 beforeOut = IERC20(tokenOut).balanceOf(address(this));

            if (step.supportFeeOnTransfer) {
                IUniswapV2RouterLike(step.router)
                    .swapExactTokensForTokensSupportingFeeOnTransferTokens(
                        currentAmount,
                        step.minAmountOut,
                        step.path,
                        address(this),
                        deadline
                    );
            } else {
                IUniswapV2RouterLike(step.router).swapExactTokensForTokens(
                    currentAmount,
                    step.minAmountOut,
                    step.path,
                    address(this),
                    deadline
                );
            }

            IERC20(tokenIn).forceApprove(step.router, 0);
            uint256 afterOut = IERC20(tokenOut).balanceOf(address(this));
            uint256 amountOut;
            if (tokenIn == tokenOut) {
                // The input transfer temporarily lowers the same-token balance.
                // Reconstruct the router output instead of treating only the
                // net profit as the next step's amount.
                if (afterOut + currentAmount <= beforeOut) {
                    revert BalanceDeltaTooSmall(tokenOut, beforeOut, afterOut);
                }
                amountOut = afterOut + currentAmount - beforeOut;
            } else {
                if (afterOut <= beforeOut) {
                    revert BalanceDeltaTooSmall(tokenOut, beforeOut, afterOut);
                }
                amountOut = afterOut - beforeOut;
            }
            emit SwapExecuted(i, step.router, tokenOut, currentAmount, amountOut);
            currentAmount = amountOut;
        }

        uint256 amountOwed = amount + premium;
        if (currentAmount < amountOwed + minProfit) {
            revert InsufficientFinalAmount(currentAmount, amountOwed, minProfit);
        }

        uint256 profit = currentAmount - amountOwed;
        totalProfitByAsset[asset] += profit;
        successfulCycles += 1;

        IERC20(asset).forceApprove(address(AAVE_POOL), amountOwed);
        emit ArbitrageExecuted(asset, amount, premium, profit);
        return true;
    }

    function withdrawProfit(address token, address to, uint256 amount)
        external onlyOwner nonReentrant
    {
        if (_flashActive) revert RescueDuringFlash();
        if (token == address(0) || to == address(0)) revert ZeroAddress();
        if (amount == 0) revert ZeroAmount();
        IERC20(token).safeTransfer(to, amount);
        emit ProfitWithdrawn(token, to, amount);
    }

    function rescueNative(address payable to, uint256 amount)
        external onlyOwner nonReentrant
    {
        if (_flashActive) revert RescueDuringFlash();
        if (to == address(0)) revert ZeroAddress();
        if (amount == 0) revert ZeroAmount();
        (bool ok,) = to.call{value: amount}("");
        require(ok, "NATIVE_TRANSFER_FAILED");
    }

    function _validateRoute(
        address expectedAsset,
        SwapStep[] calldata steps,
        bool requireCycle
    ) private view {
        if (steps.length == 0 || steps.length > MAX_STEPS) revert InvalidRoute();

        address previousOut;
        for (uint256 i; i < steps.length; ++i) {
            SwapStep calldata step = steps[i];
            if (!allowedRouters[step.router]) revert RouterNotAllowed(step.router);
            if (step.path.length < 2 || step.path.length > MAX_PATH_LENGTH) revert InvalidRoute();
            if (step.minAmountOut == 0) revert ZeroAmount();

            for (uint256 j; j < step.path.length; ++j) {
                address token = step.path[j];
                if (!allowedTokens[token]) revert TokenNotAllowed(token);
                if (j > 0 && step.path[j - 1] == token) revert InvalidRoute();
            }

            if (i == 0) {
                if (requireCycle && step.path[0] != expectedAsset) revert InvalidRoute();
            } else if (step.path[0] != previousOut) {
                revert InvalidRoute();
            }
            previousOut = step.path[step.path.length - 1];
        }

        if (requireCycle && previousOut != expectedAsset) revert InvalidRoute();
    }

    receive() external payable {}
}
