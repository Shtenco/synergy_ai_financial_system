# SINERGY TROIKA SYSTEM - INSTANT DEPLOY VERSION

## TIMELOCKS REMOVED

| Contract | Original Timelock | New Value |
|----------|-------------------|-----------|
| 03_TroikaVault.sol | TIMELOCK_DELAY = 2 days | 0 |
| 03_TroikaVault.sol | TIMELOCK_WINDOW = 7 days | type(uint256).max |
| 05_DividendPool.sol | FOUNDER_TIMELOCK = 2 days | 0 |
| 10_TroikaCore.sol | UNPAUSE_DELAY = 1 hours | 0 |
| 11_FounderControl.sol | START_TIMELOCK = 1 hours | 0 |
| 11_FounderControl.sol | RESCUE_TIMELOCK = 3 days | 0 |
| 11_FounderControl.sol | RESCUE_WINDOW = 7 days | type(uint256).max |

---

## CONTRACT STRUCTURE (21 contracts)

### Layer 0: Configuration & Interfaces
- **00_CircularInterfaces.sol** - All interfaces for circular system (ICircularALTN, ICircularVault, ICircularLoop, etc.)
- **01_PolygonConfig.sol** - Polygon mainnet addresses (QuickSwap, WPOL) + constants

### Layer 1: Tokens (3)
- **02_Tokens.sol** - SYNA, SYNC, SYNR tokens with AccessControl, Pausable, MINTER_ROLE, BURNER_ROLE

### Layer 2: Core Infrastructure (8)
- **03_TroikaVault.sol** - Central liquidity vault: LP tokens, reserves, lpBuf, syncFromChain()
- **04_TWAPOracle.sol** - 48-tick TWAP oracle for P_SYNR/P_SYNC price gap
- **05_DividendPool.sol** - Founder dividends (70%) + holders dividends (30%)
- **06_FeeRouter.sol** - Fee distribution: 35% LP, 30% traders, 15% CB, 10% div, 10% reserve
- **07_EmissionEngine.sol** - Token emission + Fix mechanism + Buyback SYNR
- **08_CBArbitrage.sol** - Central Bank arbitrage: gap > 1% triggers arb
- **09_SelfReinforcingLoop.sol** - Two skip-one rings (Ring A + Ring B) for amplification

### Layer 3: Orchestration (3)
- **10_TroikaCore.sol** - Main orchestrator: tick() calls all subsystems every block
- **11_FounderControl.sol** - Founder panel: stop/start, reinvest, withdraw, invest
- **12_TroikaDeployer.sol** - Factory deployer for entire SINERGY system

### Layer 4: Circular Deflation Extension (7)
- **13_CollateralEmission.sol** - ALTN collateral → SYNA minting → SYNR reserve
- **14_CircularHub_v2.sol** - Hub orchestrator: ALTN ⟷ SYNR/SYNA/SYNC
- **15_CircularDeployer.sol** - Factory deployer for Circular components
- **16_AltynCircularPatch.sol** - Patch for AltynToken: burn callbacks → Hub
- **17_EmissionCircular.sol** - Patch for EmissionEngine: external price signals
- **18_MutualPoolDeployer.sol** - Creates TOKEN/TOKEN pairs (ALTN/SYNR, etc.)
- **19_MutualPoolRouter.sol** - Routes liquidity across all 9 pools

### Layer 5: ALTN Token
- **19_Altyn_v1_original.sol** - 14-layer omega deflationary ALTN token

---

## CONTRACT INTERACTIONS

```
                        ┌─────────────────────────────┐
                        │    CircularHub_v2 (14)      │
                        │    tick() orchestrator      │
                        └─────────────┬───────────────┘
                                      │
      ┌─────────────┬─────────────────┼─────────────────┬─────────────┐
      │             │                 │                 │             │
      ▼             ▼                 ▼                 ▼             ▼
┌──────────┐  ┌──────────┐    ┌──────────────┐   ┌──────────┐  ┌──────────────┐
│ ALTN(19) │  │TroikaCore│    │CollateralEmit│   │ MutualPR │  │  DivPool(5)  │
│maintenance│  │  (10)    │    │    (13)      │   │   (19)   │  │ notifyFounder│
│triggerBB │  │  tick()  │    │processCircular│  │routeToAll│  └──────────────┘
└──────────┘  └────┬─────┘    └──────────────┘   └──────────┘
                   │
    ┌──────────────┼──────────────┬────────────────┬────────────┐
    │              │              │                │            │
    ▼              ▼              ▼                ▼            ▼
┌────────┐   ┌─────────┐   ┌──────────┐    ┌─────────────┐ ┌──────────┐
│TWAPOracle│ │FeeRouter│   │ CBArb(8) │    │EmissionEng(7)│ │Loop(9)  │
│update()  │ │routeFee │   │executeArb│    │executeEmission│ │flush()  │
│(4)       │ │(6)      │   │          │    │              │ │         │
└────────┘   └────┬────┘   └──────────┘    └──────────────┘ └─────────┘
                  │
                  ▼
         ┌───────────────┐
         │  Vault (3)    │
         │ LP balances   │
         │ reserves      │
         │ flushLpBuf    │
         └───────────────┘
                  │
                  ▼
         ┌───────────────┐
         │  QuickSwap    │
         │  LP Pools     │
         │ SYNA/SYNC/SYNR│
         └───────────────┘
```

---

## FLASH LOAN MECHANISM

From IMPORTANT_FLASH_LOAN_EDGE.md:

1. **Borrow** 1000 POL via Aave Flash Loan (0.05% fee = 0.5 POL)
2. **Add LP** with 60% of loan (600 POL) → Become fee earner!
3. **Trade** 40% (400 POL) through pools → 6 swaps × 0.3% = fees generated
4. **Remove LP** → Get back 600 POL + EARNED FEES (as LP provider we get 70% of swap fees)
5. **Repay** loan + 0.05% fee
6. **PROFIT** = LP fees earned - loan cost

**Edge Ratio**: 9.2x (80 POL cost → 740 POL fees → +660 POL net profit)

---

## DEPLOY ORDER

1. Deploy **02_Tokens.sol** (SYNA, SYNC, SYNR)
2. Deploy **03_TroikaVault.sol**
3. Deploy **04_TWAPOracle.sol**
4. Deploy **05_DividendPool.sol**
5. Deploy **08_CBArbitrage.sol**
6. Deploy **06_FeeRouter.sol**
7. Deploy **07_EmissionEngine.sol**
8. Deploy **09_SelfReinforcingLoop.sol**
9. Deploy **10_TroikaCore.sol**
10. Call Core.initialize()
11. Deploy **11_FounderControl.sol**
12. Call Core.setFounderControl()
13. Grant all roles
14. Transfer tokens + WPOL to Vault
15. Call Vault.initialize()
16. Call Core.linkOraclePairs()

For Circular extension:
17. Deploy **13_CollateralEmission.sol**
18. Deploy **14_CircularHub_v2.sol**
19. Deploy **18_MutualPoolDeployer.sol** (creates TOKEN/TOKEN pairs)
20. Deploy **19_MutualPoolRouter.sol**
21. Grant ALTN_ROLE, CORE_ROLE, EMIT_ROLE to Hub

---

## KEY PARAMETERS

### Fee Distribution (06_FeeRouter)
- alphaLP = 35% → LP pools
- alphaRES = 30% → trader reserve
- alphaCB = 15% → CB arbitrage fund
- alphaDIV = 10% → dividends (70% founder / 30% holders)
- remainder = 10% → reserveR (collateral)

### Emission (07_EmissionEngine)
- Emission every 1000 blocks (~33 min on Polygon)
- FOUNDER_EMIT_BPS = 30% of dlp → founder
- Buyback threshold = 0.005 WPOL

### CB Arbitrage (08_CBArbitrage)
- MIN_GAP_BPS = 100 (1%)
- ARB_SIZE_BPS = 50 (0.5% of LP_min)
- MAX_SINGLE_ARB = 50,000 WPOL

### Self-Reinforcing Loop (09_SelfReinforcingLoop)
- Ring A: 0.15% fee → traders→arb→emission→dividends→traders
- Ring B: 0.50% fee → fee_router→LP→reserves→CB/TWAP→fee_router
- Flush every 50 blocks
- Amplification factor ~1.6-2.0×

---

## INSTANT WITHDRAWALS NOW ENABLED

All timelocks set to 0 means:
- Emergency withdraw from Vault: INSTANT
- Founder change in DividendPool: INSTANT
- System unpause in TroikaCore: INSTANT
- System start in FounderControl: INSTANT
- Emergency rescue in FounderControl: INSTANT
