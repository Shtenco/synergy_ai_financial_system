#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
 ДЕТАЛЬНЫЙ РАСЧЁТ FLASH LOAN PROFIT SCHEME
 С КОМИССИЕЙ 1 POL И РЕАЛЬНОЙ ПРИБЫЛЬЮ
═══════════════════════════════════════════════════════════════════════════════
"""
import sys, io, os, json
from decimal import Decimal, getcontext
from dotenv import load_dotenv
from web3 import Web3
from web3.middleware import ExtraDataToPOAMiddleware

getcontext().prec = 50

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

load_dotenv()
w3 = Web3(Web3.HTTPProvider("https://polygon-bor-rpc.publicnode.com"))
w3.middleware_onion.inject(ExtraDataToPOAMiddleware, layer=0)

def C(a): return Web3.to_checksum_address(a)

with open("deployed_TROIKA_v3.json") as f:
    d = json.load(f)

print("="*80)
print(" FLASH LOAN PROFIT SCHEME - ДЕТАЛЬНЫЙ РАСЧЁТ")
print(" Цель: Flash fee = 1 POL, на выходе РЕАЛЬНАЯ ПРИБЫЛЬ")
print("="*80)

# Текущие параметры
WPOL = "0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270"
AAVE_FEE_BPS = Decimal("5")  # 0.05% = 5 basis points
GAS_PER_TX = Decimal("0.15")  # примерно 0.15 POL за TX

# Для fee = 1 POL нужен Flash Loan:
# flash × 0.0005 = 1
# flash = 1 / 0.0005 = 2000 POL
flash_for_1_pol_fee = Decimal("2000")

print(f"""
[AAVE FLASH LOAN ПАРАМЕТРЫ]
  Fee: 0.05%
  Для fee = 1 POL нужен Flash: {flash_for_1_pol_fee} WPOL

[ПРОБЛЕМА АТОМАРНОСТИ]
  Flash Loan = атомарная транзакция
  Эмиссия каждые 50 блоков
  В одной TX можем сделать ТОЛЬКО 1 эмиссию!

[ТЕКУЩАЯ ЭМИССИЯ (emitRate = 2e-6)]
  Founder share (30%): ~0.028 WPOL

[БАЛАНС]
  Flash fee:    1.000 POL
  Gas:          0.150 POL
  ─────────────────────
  Расходы:      1.150 POL
  Доход:        0.028 WPOL
  ─────────────────────
  УБЫТОК:       1.122 POL 💀
""")

print("="*80)
print(" РЕШЕНИЕ: MULTI-TX SCHEME (НЕ АТОМАРНАЯ)")
print("="*80)

print("""
СХЕМА "FOUNDER PROFIT EXTRACTION":
──────────────────────────────────

[SETUP]
  1. Owner имеет: 5 POL, 5 WPOL, 100 SYNA, 1000 SYNC, 200 SYNR
  2. Vault freeWpol = 0 (все WPOL залочены)
  3. Founder = Owner

[STEP 1] Transfer WPOL в Vault (одноразово)
  └── IERC20(WPOL).transfer(vault, 3e18)
  └── Vault freeWpol: 0 → 3
  └── Gas: 0.05 POL

[STEP 2] Emission #1 (через 50 блоков)
  └── EmissionEngine.executeEmission()
  └── Founder gets: 0.028 WPOL → DividendPool
  └── Gas: 0.15 POL

[STEP 3] withdrawFounder()
  └── DividendPool.withdrawFounder()
  └── Owner receives: 0.028 WPOL
  └── Gas: 0.05 POL

[REPEAT] N раз
  └── Emission + withdraw = 0.028 WPOL - 0.20 POL gas = -0.172 POL

[STEP N+1] Забрать депозит
  └── Vault.transferWpol(owner, 3e18)
  └── Gas: 0.05 POL

ИТОГ:
  Депозит: 3 WPOL (вернули)
  Emissions: N × 0.028 WPOL
  Gas: (N × 0.20) + 0.10 POL

  BREAK-EVEN: 0.028 × N = 0.20 × N
              НЕВОЗМОЖНО (gas > emission!)
""")

print("="*80)
print(" ЕДИНСТВЕННЫЙ ПУТЬ: УВЕЛИЧИТЬ EMISSION VALUE")
print("="*80)

# Расчёт при разных emitRate
emit_rates = [
    ("2e-6 (current MIN)", Decimal("2e-6")),
    ("10e-6 (×5)", Decimal("10e-6")),
    ("20e-6 (×10)", Decimal("20e-6")),
    ("50e-6 (MAX)", Decimal("50e-6")),
]

# Current supplies
TOKEN_ABI = [
    {"name": "totalSupply", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
]
PAIR_ABI = [
    {"name": "getReserves", "inputs": [], "outputs": [{"type": "uint112"}, {"type": "uint112"}, {"type": "uint32"}], "stateMutability": "view", "type": "function"},
    {"name": "token0", "inputs": [], "outputs": [{"type": "address"}], "stateMutability": "view", "type": "function"},
]

supplies = {}
for name, addr in d["tokens"].items():
    tk = w3.eth.contract(address=C(addr), abi=TOKEN_ABI)
    supplies[name] = Decimal(tk.functions.totalSupply().call()) / Decimal(10**18)

prices = {}
for pool_name, pool_addr in d["pools"].items():
    pair = w3.eth.contract(address=C(pool_addr), abi=PAIR_ABI)
    r0, r1, _ = pair.functions.getReserves().call()
    token0 = pair.functions.token0().call()
    token_name = pool_name.split("_")[0]
    if token0.lower() == WPOL.lower():
        prices[token_name] = Decimal(r0) / Decimal(r1) if r1 > 0 else Decimal(0)
    else:
        prices[token_name] = Decimal(r1) / Decimal(r0) if r0 > 0 else Decimal(0)

print(f"\n[ТЕКУЩИЕ SUPPLIES]")
for t, s in supplies.items():
    print(f"  {t}: {s:.2f}")

print(f"\n[РАСЧЁТ ПРИ РАЗНЫХ EMIT_RATE]")
print(f"{'emitRate':<20} {'Emission Value':<20} {'Founder 30%':<15} {'Net Profit/TX':<15}")
print("-"*70)

for name, rate in emit_rates:
    total_em = Decimal(0)
    for t, s in supplies.items():
        em = s * rate * 100
        value = em * prices[t]
        total_em += value

    founder = total_em * Decimal("0.30")
    net = founder - GAS_PER_TX

    status = "PROFIT!" if net > 0 else "LOSS"
    print(f"{name:<20} {total_em:<20.6f} {founder:<15.6f} {net:<15.6f} {status}")

print("""
═══════════════════════════════════════════════════════════════════════════════
 РЕШЕНИЕ: ПЕРЕДЕПЛОЙ EMISSIONENGINE С emitRate = 50e-6
═══════════════════════════════════════════════════════════════════════════════

При emitRate = 50e-6:
  Emission value: ~2.33 WPOL
  Founder (30%):  ~0.70 WPOL
  Gas per TX:     ~0.15 POL
  ─────────────────────────
  NET PROFIT:     ~0.55 WPOL per emission!

FLASH LOAN SCHEME С FEE = 1 POL:
────────────────────────────────
Flash 2000 WPOL (fee = 1 POL)
├─ TX1: Flash + deposit + emit + withdraw + return
│   └─ Profit: 0.70 - 1.00 - 0.30 = -0.60 POL (за 1 emission)
│
└─ НЕВОЗМОЖНО сделать >1 emission в 1 TX!

АЛЬТЕРНАТИВА: MULTI-TX БЕЗ FLASH LOAN
────────────────────────────────────────
TX1: Deposit 3 WPOL в Vault (gas: 0.05)
TX2: Emission #1 → +0.70 WPOL (gas: 0.20)
TX3: Emission #2 → +0.70 WPOL (gas: 0.20)
...
TXN: Emission #N → +0.70 WPOL (gas: 0.20)
TXN+1: Withdraw deposit (gas: 0.05)

BREAK-EVEN:
  0.70 × N - 0.20 × N - 0.10 = 0
  0.50 × N = 0.10
  N = 0.2 emissions → PROFIT С ПЕРВОЙ ЭМИССИИ!

═══════════════════════════════════════════════════════════════════════════════
 ПЛАН ДЕЙСТВИЙ
═══════════════════════════════════════════════════════════════════════════════

1. ПЕРЕДЕПЛОЙ EmissionEngine с начальным emitRate = 50e-6 (или EMIT_RATE_MAX)

2. Выполнить цикл:
   - Transfer WPOL в Vault (freeWpol > 0)
   - Emission → founder получает WPOL
   - withdrawFounder()
   - Забрать депозит

3. Или модифицировать существующий EmissionEngine:
   - Изменить emitRate через adapt()
   - Для этого нужна высокая торговая активность

РЕКОМЕНДАЦИЯ:
─────────────
Передеплоить EmissionEngine с:
  uint256 public emitRate = EMIT_RATE_MAX;  // вместо EMIT_RATE_MIN

Тогда каждая emission даёт 0.70 WPOL founder!
""")

# Расчёт Flash Loan scheme с 10 emissions
print("="*80)
print(" РАСЧЁТ: FLASH LOAN + 10 EMISSIONS (при emitRate = 50e-6)")
print("="*80)

flash = Decimal("2000")
fee = flash * Decimal("0.0005")  # 1 POL
n_emissions = 10
founder_per_emission = Decimal("0.70")
gas_setup = Decimal("0.10")  # deposit + final withdraw
gas_per_emission = Decimal("0.20")  # emit + withdraw founder

total_founder = n_emissions * founder_per_emission
total_gas = gas_setup + n_emissions * gas_per_emission

# Flash Loan НЕ атомарный - держим WPOL на период emissions
# Time = 50 blocks × 10 = 500 blocks × 2 sec = ~17 minutes

profit = total_founder - fee - total_gas

print(f"""
Flash Loan: {flash} WPOL
Flash Fee:  {fee} POL

Deposit → N emissions → withdraw

Emissions: {n_emissions}
Founder per emission: {founder_per_emission} WPOL
Total founder: {total_founder} WPOL

Gas (setup): {gas_setup} POL
Gas (emissions): {n_emissions} × {gas_per_emission} = {n_emissions * gas_per_emission} POL
Total gas: {total_gas} POL

═══════════════════════════════════════════
TOTAL INCOME:   {total_founder:.2f} WPOL
TOTAL EXPENSES: {fee + total_gas:.2f} POL
═══════════════════════════════════════════
NET PROFIT:     {profit:.2f} POL
═══════════════════════════════════════════
""")

if profit > 0:
    print(f"✅ ПРИБЫЛЬНО! ROI = {(profit / (fee + total_gas) * 100):.1f}%")
else:
    print(f"❌ УБЫТОЧНО")
