// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

// ═══════════════════════════════════════════════════════════════════════════
//  SINERGY DEFLATION SYSTEM — 19_MutualPoolRouter.sol
//  Умный роутинг ликвидности по всем 9 пулам (4 TOKEN/WPOL + 5 взаимных)
//
//  ЗАДАЧА:
//   Когда CircularHub или EmissionEngine инжектирует ликвидность,
//   MutualPoolRouter распределяет её ПРОПОРЦИОНАЛЬНО TVL всех пулов.
//   Больший пул получает больше — это поддерживает глубину там где нужна.
//
//  ИНТЕГРАЦИЯ:
//   CircularHub._flushPending()  → MutualPoolRouter.routeToAllPools(amount)
//   EmissionEngine (dlp 70%)     → MutualPoolRouter.routeLP(dlpTotal, splitBps)
//   CollateralEmission (repay)   → MutualPoolRouter.routeRepay(collToken, amount)
//
//  ЛОГИКА РАСПРЕДЕЛЕНИЯ:
//   1. Считаем TVL каждого пула в WPOL-эквиваленте
//   2. Рассчитываем долю каждого пула: share_i = TVL_i / totalTVL
//   3. Для TOKEN/WPOL пулов: inject через vault.addToLpBuf / vault.batchAddLP
//   4. Для TOKEN/TOKEN пулов: inject через addLiquidityFromRouter (своп 50/50)
//
//  СПЕЦИАЛЬНАЯ ЛОГИКА ДЛЯ TOKEN/TOKEN ПУЛОВ:
//   Получаем WPOL → свапаем 50% в tokenA → свапаем 50% в tokenB
//   → addLiquidity(tokenA, tokenB) → LP токены хранятся в Vault
// ═══════════════════════════════════════════════════════════════════════════

import {AccessControl}   from "@openzeppelin/contracts/access/AccessControl.sol";
import {Pausable}         from "@openzeppelin/contracts/utils/Pausable.sol";
import {ReentrancyGuard}  from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {IERC20}           from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20}        from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {Math}             from "@openzeppelin/contracts/utils/math/Math.sol";
import "./01_PolygonConfig.sol";

interface IVaultMPR {
    function addToLpBuf(uint256 a)                      external;
    function batchAddLP(uint256, uint256, uint256)       external;
    function addToReserveR(uint256 a)                   external;
    function lpR() external view returns (uint256);
    function lpT() external view returns (uint256);
    function lpP() external view returns (uint256);
}

interface IRouterMPR {
    function swapExactTokensForTokens(
        uint256 amountIn, uint256 amountOutMin,
        address[] calldata path, address to, uint256 deadline
    ) external returns (uint256[] memory);
    function addLiquidity(
        address tokenA, address tokenB,
        uint256 amountADesired, uint256 amountBDesired,
        uint256 amountAMin, uint256 amountBMin,
        address to, uint256 deadline
    ) external returns (uint256, uint256, uint256);
    function getAmountsOut(uint256, address[] calldata)
        external view returns (uint256[] memory);
}

interface IPairMPR {
    function getReserves() external view returns (uint112, uint112, uint32);
    function token0()      external view returns (address);
}

error MPR_ZeroAddress();
error MPR_ZeroAmount();
error MPR_NoPairs();

contract MutualPoolRouter is AccessControl, Pausable, ReentrancyGuard {
    using SafeERC20 for IERC20;

    bytes32 public constant CALLER_ROLE = keccak256("CALLER_ROLE"); // Hub, EmitEngine
    bytes32 public constant PAUSER_ROLE = keccak256("PAUSER_ROLE");

    IVaultMPR public immutable vault;
    IRouterMPR public immutable qsRouter;
    IERC20     public immutable WPOL;
    address    public immutable vaultAddr;

    // ── Зарегистрированные пулы ───────────────────────────────────────
    struct Pool {
        address pair;       // QuickSwap pair address
        address tokenA;     // первый токен
        address tokenB;     // второй токен (WPOL для /WPOL пулов)
        bool    isWPOL;     // true = TOKEN/WPOL, false = TOKEN/TOKEN
        uint256 weightBPS;  // начальный вес (адаптируется по TVL)
        bool    active;
    }
    Pool[] public pools;
    mapping(address => uint256) public pairIndex; // pair → index+1

    // ── Статистика ────────────────────────────────────────────────────
    uint256 public totalRouted;
    uint256 public totalRoutedMutual;  // только по TOKEN/TOKEN парам
    uint256 public routeCount;

    // ── Параметры ─────────────────────────────────────────────────────
    uint256 public minRouteAmount = 1e14;   // 0.0001 WPOL min
    uint256 public slippageBPS    = 100;    // 1% slippage на свапы
    uint256 public mutualBoostBPS = 200;    // +2% бонус к весу TOKEN/TOKEN пулов

    event PoolRegistered(address indexed pair, address tokenA, address tokenB, bool isWPOL);
    event Routed(uint256 total, uint256 toWPOL, uint256 toMutual, uint256 routeN);
    event MutualInject(address indexed pair, address tokenA, address tokenB, uint256 wpol);

    constructor(
        address vault_, address admin_
    ) {
        if (vault_ == address(0) || admin_ == address(0)) revert MPR_ZeroAddress();
        vault     = IVaultMPR(vault_);
        vaultAddr = vault_;
        qsRouter  = IRouterMPR(PolygonConfig.QS_ROUTER);
        WPOL      = IERC20(PolygonConfig.WPOL);
        WPOL.forceApprove(PolygonConfig.QS_ROUTER, type(uint256).max);
        _grantRole(DEFAULT_ADMIN_ROLE, admin_);
        _grantRole(CALLER_ROLE,        admin_);
        _grantRole(PAUSER_ROLE,        admin_);
    }

    // ── Зарегистрировать TOKEN/WPOL пул (уже существующий в Vault) ───
    function registerWPOLPool(address pair, address token, uint256 weightBPS)
        external onlyRole(DEFAULT_ADMIN_ROLE)
    {
        if (pair == address(0) || token == address(0)) revert MPR_ZeroAddress();
        _addPool(pair, token, PolygonConfig.WPOL, true, weightBPS);
    }

    // ── Зарегистрировать TOKEN/TOKEN взаимный пул ──────────────────────
    function registerMutualPool(address pair, address tokenA, address tokenB, uint256 weightBPS)
        external onlyRole(DEFAULT_ADMIN_ROLE)
    {
        if (pair == address(0)) revert MPR_ZeroAddress();
        _addPool(pair, tokenA, tokenB, false, weightBPS);
    }

    function _addPool(address pair, address tA, address tB, bool isWPOL_, uint256 w) private {
        // Approve router для обоих токенов
        if (tA != PolygonConfig.WPOL)
            IERC20(tA).forceApprove(PolygonConfig.QS_ROUTER, type(uint256).max);
        if (tB != PolygonConfig.WPOL)
            IERC20(tB).forceApprove(PolygonConfig.QS_ROUTER, type(uint256).max);
        pairIndex[pair] = pools.length + 1;
        pools.push(Pool(pair, tA, tB, isWPOL_, w, true));
        emit PoolRegistered(pair, tA, tB, isWPOL_);
    }

    // ═══════════════════════════════════════════════════════════════════
    //  ROUTE TO ALL POOLS — главная функция
    //  Принимает WPOL (уже на этом контракте) и распределяет
    // ═══════════════════════════════════════════════════════════════════
    function routeToAllPools(uint256 wpolAmount)
        external nonReentrant whenNotPaused onlyRole(CALLER_ROLE)
    {
        if (wpolAmount < minRouteAmount) return;
        if (pools.length == 0) revert MPR_NoPairs();
        uint256 bal = WPOL.balanceOf(address(this));
        if (bal < wpolAmount) wpolAmount = bal;

        // Считаем TVL и суммарный вес
        uint256[] memory tvls    = _getAllTVLs();
        uint256   totalTVL       = 0;
        for (uint256 i; i < tvls.length; i++) totalTVL += tvls[i];
        if (totalTVL == 0) {
            // Fallback: равномерно
            uint256 each = wpolAmount / pools.length;
            for (uint256 i; i < pools.length; i++) _injectToPool(i, each);
            return;
        }

        uint256 toWPOL   = 0;
        uint256 toMutual = 0;

        for (uint256 i; i < pools.length; i++) {
            if (!pools[i].active) continue;
            uint256 share   = Math.mulDiv(tvls[i], 1e18, totalTVL);
            // Взаимные пулы получают бонус +mutualBoostBPS
            uint256 boost   = pools[i].isWPOL ? 1e18 : 1e18 + mutualBoostBPS * 1e14;
            uint256 alloc   = Math.mulDiv(wpolAmount, share * boost / 1e18, 1e18);
            if (alloc < minRouteAmount) continue;
            _injectToPool(i, alloc);
            if (pools[i].isWPOL) toWPOL += alloc;
            else                 toMutual += alloc;
        }

        totalRouted       += wpolAmount;
        totalRoutedMutual += toMutual;
        routeCount++;
        emit Routed(wpolAmount, toWPOL, toMutual, routeCount);
    }

    // ── Инжект в конкретный пул ────────────────────────────────────────
    function _injectToPool(uint256 idx, uint256 wpolAlloc) private {
        Pool memory p = pools[idx];
        if (!p.active || wpolAlloc == 0) return;

        if (p.isWPOL) {
            // TOKEN/WPOL: передаём в Vault.addToLpBuf → флашит в QuickSwap
            WPOL.safeTransfer(vaultAddr, wpolAlloc);
            try vault.addToLpBuf(wpolAlloc) {} catch {}
        } else {
            // TOKEN/TOKEN: своп 50% WPOL→tokenA, 50% WPOL→tokenB, addLiquidity
            _injectMutualPool(p, wpolAlloc);
        }
    }

    function _injectMutualPool(Pool memory p, uint256 wpol) private {
        uint256 half  = wpol / 2;
        uint256 other = wpol - half;

        // Получить tokenA из WPOL
        address tA = p.tokenA;
        address tB = p.tokenB;
        uint256 gotA = _swapWPOLfor(tA, half);
        uint256 gotB = _swapWPOLfor(tB, other);

        if (gotA == 0 || gotB == 0) return;

        // addLiquidity(tokenA, tokenB)
        uint256 minA = gotA * (10_000 - slippageBPS) / 10_000;
        uint256 minB = gotB * (10_000 - slippageBPS) / 10_000;

        try qsRouter.addLiquidity(
            tA, tB, gotA, gotB, minA, minB,
            vaultAddr,                            // LP токены → Vault
            block.timestamp + PolygonConfig.SWAP_DEADLINE
        ) {} catch {}

        emit MutualInject(p.pair, tA, tB, wpol);
    }

    function _swapWPOLfor(address token, uint256 wpolIn) private returns (uint256 out) {
        if (token == PolygonConfig.WPOL || wpolIn == 0) return wpolIn;
        address[] memory path = new address[](2);
        path[0] = PolygonConfig.WPOL;
        path[1] = token;
        try qsRouter.getAmountsOut(wpolIn, path) returns (uint256[] memory amounts) {
            uint256 minOut = amounts[1] * (10_000 - slippageBPS) / 10_000;
            uint256[] memory res = qsRouter.swapExactTokensForTokens(
                wpolIn, minOut, path, address(this),
                block.timestamp + PolygonConfig.SWAP_DEADLINE
            );
            return res[1];
        } catch { return 0; }
    }

    // ═══════════════════════════════════════════════════════════════════
    //  ROUTE REPAY — из CollateralEmission при repay SYNA
    //  Часть освобождённого залога инжектится в взаимные пулы
    // ═══════════════════════════════════════════════════════════════════
    function routeRepay(address collToken, uint256 wpolEquiv)
        external whenNotPaused onlyRole(CALLER_ROLE)
    {
        if (wpolEquiv < minRouteAmount) return;
        // Найти все пулы содержащие collToken
        for (uint256 i; i < pools.length; i++) {
            Pool memory p = pools[i];
            if (!p.active || p.isWPOL) continue;
            if (p.tokenA == collToken || p.tokenB == collToken) {
                uint256 alloc = wpolEquiv / 2;
                WPOL.safeTransfer(vaultAddr, alloc);
                try vault.addToReserveR(alloc) {} catch {}
            }
        }
    }

    // ── TVL всех пулов в WPOL-эквиваленте ────────────────────────────
    function _getAllTVLs() private view returns (uint256[] memory tvls) {
        tvls = new uint256[](pools.length);
        // TOKEN/WPOL: используем Vault lpR/lpT/lpP (уже в WPOL)
        uint256 lpR = vault.lpR();
        uint256 lpT = vault.lpT();
        uint256 lpP = vault.lpP();

        for (uint256 i; i < pools.length; i++) {
            if (!pools[i].active) { tvls[i] = 0; continue; }
            if (pools[i].isWPOL) {
                // Определить какой из 3 Vault пулов
                // Упрощённо: используем среднее Vault LP как прокси
                tvls[i] = (lpR + lpT + lpP) / 3;
            } else {
                tvls[i] = _mutualTVLinWPOL(pools[i]);
            }
        }
    }

    function _mutualTVLinWPOL(Pool memory p) private view returns (uint256) {
        try IPairMPR(p.pair).getReserves() returns (uint112 r0, uint112 r1, uint32) {
            address t0 = IPairMPR(p.pair).token0();
            // Получить цену tokenA в WPOL для оценки
            address tA = p.tokenA;
            if (tA == PolygonConfig.WPOL) return uint256(r0) + uint256(r1);
            // Ищем WPOL цену tokenA через другой пул
            uint256 priceA = _getWPOLPrice(tA);
            uint256 priceB = _getWPOLPrice(p.tokenB);
            uint256 rA     = t0 == tA ? uint256(r0) : uint256(r1);
            uint256 rB     = t0 == tA ? uint256(r1) : uint256(r0);
            return (rA * priceA + rB * priceB) / 1e18;
        } catch { return 1e15; } // fallback минимальный TVL
    }

    function _getWPOLPrice(address token) private view returns (uint256) {
        if (token == PolygonConfig.WPOL) return 1e18;
        // Ищем TOKEN/WPOL пул в нашем списке
        for (uint256 i; i < pools.length; i++) {
            if (!pools[i].isWPOL) continue;
            if (pools[i].tokenA == token) {
                try IPairMPR(pools[i].pair).getReserves() returns (uint112 r0, uint112 r1, uint32) {
                    address t0 = IPairMPR(pools[i].pair).token0();
                    uint256 tR = t0 == token ? uint256(r0) : uint256(r1);
                    uint256 wR = t0 == token ? uint256(r1) : uint256(r0);
                    return tR > 0 ? wR * 1e18 / tR : 0;
                } catch {}
            }
        }
        return 1e15; // fallback очень маленькая цена
    }

    // ── VIEW ──────────────────────────────────────────────────────────
    function poolCount() external view returns (uint256) { return pools.length; }

    function getPoolTVLs() external view returns (uint256[] memory tvls) {
        return _getAllTVLs();
    }

    function totalTVL() external view returns (uint256 total) {
        uint256[] memory tvls = _getAllTVLs();
        for (uint256 i; i < tvls.length; i++) total += tvls[i];
    }

    // ── Admin ──────────────────────────────────────────────────────────
    function setPoolActive(address pair, bool active_) external onlyRole(DEFAULT_ADMIN_ROLE) {
        uint256 idx = pairIndex[pair];
        if (idx > 0) pools[idx-1].active = active_;
    }

    function setMutualBoost(uint256 bps) external onlyRole(DEFAULT_ADMIN_ROLE) {
        require(bps <= 1000, "max10%");
        mutualBoostBPS = bps;
    }

    function setSlippage(uint256 bps) external onlyRole(DEFAULT_ADMIN_ROLE) {
        require(bps <= 500, "max5%");
        slippageBPS = bps;
    }

    // Принять WPOL для роутинга
    receive() external payable {}

    function pause()   external onlyRole(PAUSER_ROLE) { _pause(); }
    function unpause() external onlyRole(PAUSER_ROLE) { _unpause(); }
}
