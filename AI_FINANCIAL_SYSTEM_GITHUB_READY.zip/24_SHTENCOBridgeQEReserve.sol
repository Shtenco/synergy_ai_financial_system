// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {AccessControl} from "@openzeppelin/contracts/access/AccessControl.sol";
import {Pausable} from "@openzeppelin/contracts/utils/Pausable.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";

/**
 * @title SHTENCOBridgeQEReserve
 * @notice Reserve-backed treasury allocator for bridge liquidity, market making,
 *         buybacks and emergency rebalancing. It never mints assets.
 */
contract SHTENCOBridgeQEReserve is AccessControl, Pausable, ReentrancyGuard {
    using SafeERC20 for IERC20;

    bytes32 public constant CONTROLLER_ROLE = keccak256("CONTROLLER_ROLE");
    bytes32 public constant POLICY_ROLE = keccak256("POLICY_ROLE");
    bytes32 public constant GUARDIAN_ROLE = keccak256("GUARDIAN_ROLE");

    struct TokenPolicy {
        bool enabled;
        uint256 minimumReserve;
        uint256 dailyAllocationLimit;
    }

    struct DailyAllocation {
        uint64 day;
        uint192 amount;
    }

    mapping(address => TokenPolicy) public tokenPolicy;
    mapping(address => bool) public allowedRecipient;
    mapping(address => DailyAllocation) private _daily;
    mapping(address => uint256) public totalAllocated;
    mapping(address => mapping(bytes32 => uint256)) public allocatedByPurpose;

    event TokenPolicySet(address indexed token, bool enabled, uint256 minimumReserve, uint256 dailyLimit);
    event RecipientSet(address indexed recipient, bool allowed);
    event CapitalReturned(address indexed token, address indexed from, uint256 amount);
    event ReserveAllocated(address indexed token, address indexed recipient, uint256 amount, bytes32 indexed purpose);

    constructor(address admin) {
        require(admin != address(0), "RESERVE: zero admin");
        _grantRole(DEFAULT_ADMIN_ROLE, admin);
        _grantRole(POLICY_ROLE, admin);
        _grantRole(GUARDIAN_ROLE, admin);
    }

    function allocate(address token, address recipient, uint256 amount, bytes32 purpose)
        external
        onlyRole(CONTROLLER_ROLE)
        nonReentrant
        whenNotPaused
    {
        TokenPolicy memory policy = tokenPolicy[token];
        require(policy.enabled, "RESERVE: token disabled");
        require(allowedRecipient[recipient], "RESERVE: recipient disabled");
        require(amount > 0, "RESERVE: zero amount");

        DailyAllocation storage daily = _daily[token];
        uint64 day = uint64(block.timestamp / 1 days);
        if (daily.day != day) {
            daily.day = day;
            daily.amount = 0;
        }
        uint256 next = uint256(daily.amount) + amount;
        require(policy.dailyAllocationLimit == 0 || next <= policy.dailyAllocationLimit, "RESERVE: daily limit");
        require(next <= type(uint192).max, "RESERVE: overflow");

        uint256 balance = IERC20(token).balanceOf(address(this));
        require(balance >= amount && balance - amount >= policy.minimumReserve, "RESERVE: reserve floor");

        daily.amount = uint192(next);
        totalAllocated[token] += amount;
        allocatedByPurpose[token][purpose] += amount;
        IERC20(token).safeTransfer(recipient, amount);
        emit ReserveAllocated(token, recipient, amount, purpose);
    }

    function returnCapital(address token, uint256 amount) external nonReentrant {
        require(amount > 0, "RESERVE: zero amount");
        IERC20(token).safeTransferFrom(msg.sender, address(this), amount);
        emit CapitalReturned(token, msg.sender, amount);
    }

    function setTokenPolicy(address token, TokenPolicy calldata policy) external onlyRole(POLICY_ROLE) {
        require(token != address(0), "RESERVE: zero token");
        if (policy.enabled) {
            require(policy.minimumReserve > 0, "RESERVE: zero reserve floor");
            require(policy.dailyAllocationLimit > 0, "RESERVE: zero daily limit");
        }
        tokenPolicy[token] = policy;
        emit TokenPolicySet(token, policy.enabled, policy.minimumReserve, policy.dailyAllocationLimit);
    }

    function setRecipient(address recipient, bool allowed) external onlyRole(POLICY_ROLE) {
        require(recipient != address(0), "RESERVE: zero recipient");
        allowedRecipient[recipient] = allowed;
        emit RecipientSet(recipient, allowed);
    }

    function allocationToday(address token) external view returns (uint256) {
        DailyAllocation memory daily = _daily[token];
        return daily.day == uint64(block.timestamp / 1 days) ? daily.amount : 0;
    }

    function pause() external onlyRole(GUARDIAN_ROLE) { _pause(); }
    function unpause() external onlyRole(DEFAULT_ADMIN_ROLE) { _unpause(); }
}
