const { ethers } = require("hardhat");
async function main() {
  const controllerAddress = process.env.TOP_AI_CONTROLLER_ADDRESS;
  const proposalId = process.env.PROPOSAL_ID;
  if (!controllerAddress || !proposalId) throw new Error("Set TOP_AI_CONTROLLER_ADDRESS and PROPOSAL_ID");
  const controller = await ethers.getContractAt("SHTENCOTopAIController", controllerAddress);
  const tx = await controller.execute(proposalId);
  const receipt = await tx.wait();
  console.log("executed:", receipt.hash);
}
main().catch(e => { console.error(e); process.exitCode = 1; });
