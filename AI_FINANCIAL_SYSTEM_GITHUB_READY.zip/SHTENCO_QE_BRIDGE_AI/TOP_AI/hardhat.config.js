const path = require("path");
const { subtask } = require("hardhat/config");
const { TASK_COMPILE_SOLIDITY_GET_SOLC_BUILD } = require("hardhat/builtin-tasks/task-names");
subtask(TASK_COMPILE_SOLIDITY_GET_SOLC_BUILD).setAction(async ({ solcVersion }) => ({
  compilerPath: require.resolve("solc/soljson.js"),
  isSolcJs: true,
  version: solcVersion,
  longVersion: require("solc").version(),
}));
require("@nomicfoundation/hardhat-ethers");
require("dotenv").config({ path: path.resolve(__dirname, ".env") });
const polygonUrl = process.env.POLYGON_RPC_URL || "";
module.exports = {
  solidity: { version: "0.8.26", settings: { optimizer: { enabled: true, runs: 300 }, viaIR: true, evmVersion: "cancun" } },
  paths: { sources: "./contracts", tests: "./test", cache: "./cache", artifacts: "./artifacts" },
  networks: {
    hardhat: { chainId: 31337, accounts: { count: 20, accountsBalance: "100000000000000000000000" } },
    polygon: {
      chainId: 137,
      url: polygonUrl || "http://127.0.0.1:8545",
      accounts: process.env.OWNER_PRIVATE_KEY ? [process.env.OWNER_PRIVATE_KEY] : []
    }
  },
  mocha: { timeout: 120000 }
};
