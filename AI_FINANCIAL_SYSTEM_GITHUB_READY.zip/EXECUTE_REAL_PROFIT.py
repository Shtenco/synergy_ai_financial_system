#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════
РЕАЛЬНЫЙ ПРИБЫЛЬНЫЙ ЦИКЛ - ДОКАЗАННАЯ ПРИБЫЛЬ

МЕХАНИКА:
1. SNAPSHOT START - все балансы OWNER + VAULT + POOLS
2. Wrap POL → WPOL
3. addLiquidity в пулы (WPOL + токены owner)
4. Wait 50 blocks
5. executeEmission() - эмиссия новых токенов
6. withdrawFounder() - 30% эмиссии в WPOL
7. removeLiquidity - забираем LP + прибыль
8. SNAPSHOT END
9. PROFIT = END - START (в ликвидном POL/WPOL)
═══════════════════════════════════════════════════════════════════════════
"""
import sys, io, os, json, time
from decimal import Decimal, getcontext
from dotenv import load_dotenv
from web3 import Web3
from web3.middleware import ExtraDataToPOAMiddleware

getcontext().prec = 50

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

load_dotenv()
w3 = Web3(Web3.HTTPProvider("https://polygon-bor-rpc.publicnode.com", request_kwargs={"timeout": 300}))
w3.middleware_onion.inject(ExtraDataToPOAMiddleware, layer=0)

PK = os.getenv("OWNER_PRIVATE_KEY")
OWNER = "0x6946999DBCE63b140B1bB9D475F7c357130909E5"
WPOL = "0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270"

def C(a): return Web3.to_checksum_address(a)

with open("deployed_TROIKA_v3.json") as f:
    d = json.load(f)

# ═══════════════════════════════════════════════════════════════════════════
# ABI
# ═══════════════════════════════════════════════════════════════════════════

TOKEN_ABI = [
    {"name": "balanceOf", "inputs": [{"type": "address"}], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "totalSupply", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "approve", "inputs": [{"name": "spender", "type": "address"}, {"name": "amount", "type": "uint256"}], "outputs": [{"type": "bool"}], "stateMutability": "nonpayable", "type": "function"},
]

PAIR_ABI = [
    {"name": "getReserves", "inputs": [], "outputs": [{"type": "uint112"}, {"type": "uint112"}, {"type": "uint32"}], "stateMutability": "view", "type": "function"},
    {"name": "token0", "inputs": [], "outputs": [{"type": "address"}], "stateMutability": "view", "type": "function"},
    {"name": "totalSupply", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "balanceOf", "inputs": [{"type": "address"}], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
]

EMIT_ABI = [
    {"name": "executeEmission", "inputs": [], "outputs": [], "stateMutability": "nonpayable", "type": "function"},
    {"name": "isEmissionDue", "inputs": [], "outputs": [{"type": "bool"}], "stateMutability": "view", "type": "function"},
    {"name": "lastEmitBlock", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "totalEmittedR", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "totalEmittedT", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "totalEmittedP", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
]

DIV_ABI = [
    {"name": "founderPending", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "withdrawFounder", "inputs": [], "outputs": [], "stateMutability": "nonpayable", "type": "function"},
]

VAULT_ABI = [
    {"name": "lpR", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "lpT", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "lpP", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "totalLP", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "reserveR", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "freeWpol", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
]

# ═══════════════════════════════════════════════════════════════════════════
# SNAPSHOT
# ═══════════════════════════════════════════════════════════════════════════

def get_snapshot():
    """Полный снимок системы"""
    snap = {"block": w3.eth.block_number}

    # Owner
    snap["owner_pol"] = Decimal(w3.eth.get_balance(C(OWNER))) / Decimal(10**18)
    wpol_c = w3.eth.contract(address=C(WPOL), abi=TOKEN_ABI)
    snap["owner_wpol"] = Decimal(wpol_c.functions.balanceOf(C(OWNER)).call()) / Decimal(10**18)

    snap["owner_tokens"] = {}
    for name, addr in d["tokens"].items():
        tk = w3.eth.contract(address=C(addr), abi=TOKEN_ABI)
        snap["owner_tokens"][name] = Decimal(tk.functions.balanceOf(C(OWNER)).call()) / Decimal(10**18)

    # Vault
    vault = w3.eth.contract(address=C(d["vault"]), abi=VAULT_ABI)
    snap["vault_lpR"] = Decimal(vault.functions.lpR().call()) / Decimal(10**18)
    snap["vault_lpT"] = Decimal(vault.functions.lpT().call()) / Decimal(10**18)
    snap["vault_lpP"] = Decimal(vault.functions.lpP().call()) / Decimal(10**18)
    snap["vault_totalLP"] = Decimal(vault.functions.totalLP().call()) / Decimal(10**18)
    snap["vault_reserveR"] = Decimal(vault.functions.reserveR().call()) / Decimal(10**18)
    snap["vault_wpol"] = Decimal(wpol_c.functions.balanceOf(C(d["vault"])).call()) / Decimal(10**18)

    snap["vault_tokens"] = {}
    for name, addr in d["tokens"].items():
        tk = w3.eth.contract(address=C(addr), abi=TOKEN_ABI)
        snap["vault_tokens"][name] = Decimal(tk.functions.balanceOf(C(d["vault"])).call()) / Decimal(10**18)

    # Pools
    snap["pools"] = {}
    for pool_name, pool_addr in d["pools"].items():
        pair = w3.eth.contract(address=C(pool_addr), abi=PAIR_ABI)
        r0, r1, _ = pair.functions.getReserves().call()
        token0 = pair.functions.token0().call()
        lp_supply = Decimal(pair.functions.totalSupply().call()) / Decimal(10**18)

        if token0.lower() == WPOL.lower():
            wpol_r = Decimal(r0) / Decimal(10**18)
            token_r = Decimal(r1) / Decimal(10**18)
        else:
            wpol_r = Decimal(r1) / Decimal(10**18)
            token_r = Decimal(r0) / Decimal(10**18)

        snap["pools"][pool_name] = {
            "wpol": wpol_r,
            "token": token_r,
            "price": wpol_r / token_r if token_r > 0 else Decimal(0),
            "lp_supply": lp_supply,
            "tvl": wpol_r * 2,
        }

    # Token supplies
    snap["supplies"] = {}
    for name, addr in d["tokens"].items():
        tk = w3.eth.contract(address=C(addr), abi=TOKEN_ABI)
        snap["supplies"][name] = Decimal(tk.functions.totalSupply().call()) / Decimal(10**18)

    # DividendPool
    divpool = w3.eth.contract(address=C(d["divPool"]), abi=DIV_ABI)
    snap["founder_pending"] = Decimal(divpool.functions.founderPending().call()) / Decimal(10**18)
    snap["divpool_wpol"] = Decimal(wpol_c.functions.balanceOf(C(d["divPool"])).call()) / Decimal(10**18)

    # EmissionEngine
    emit = w3.eth.contract(address=C(d["emitEngine_v2"]), abi=EMIT_ABI)
    snap["emission_due"] = emit.functions.isEmissionDue().call()
    snap["total_emitted_R"] = Decimal(emit.functions.totalEmittedR().call()) / Decimal(10**18)
    snap["total_emitted_T"] = Decimal(emit.functions.totalEmittedT().call()) / Decimal(10**18)
    snap["total_emitted_P"] = Decimal(emit.functions.totalEmittedP().call()) / Decimal(10**18)

    # TOTAL SYSTEM VALUE
    total_wpol = snap["owner_pol"] + snap["owner_wpol"] + snap["vault_wpol"] + snap["divpool_wpol"]
    for p in snap["pools"].values():
        total_wpol += p["wpol"]

    snap["total_liquid_wpol"] = total_wpol

    # MCAP
    mcap = Decimal(0)
    for t in ["SYNA", "SYNC", "SYNR"]:
        mcap += snap["supplies"][t] * snap["pools"][f"{t}_WPOL"]["price"]
    snap["mcap"] = mcap

    # LP NAV (value per LP token)
    snap["lp_nav"] = {}
    for pool_name, p in snap["pools"].items():
        if p["lp_supply"] > 0:
            snap["lp_nav"][pool_name] = p["tvl"] / p["lp_supply"]
        else:
            snap["lp_nav"][pool_name] = Decimal(0)

    return snap

def print_snapshot(s, label):
    print(f"\n{'='*70}")
    print(f" {label} (block {s['block']})")
    print('='*70)

    print(f"\n[OWNER]")
    print(f"  POL:  {s['owner_pol']:.10f}")
    print(f"  WPOL: {s['owner_wpol']:.10f}")
    for t, v in s["owner_tokens"].items():
        print(f"  {t}: {v:.10f}")

    print(f"\n[VAULT]")
    print(f"  WPOL: {s['vault_wpol']:.10f}")
    print(f"  LP: R={s['vault_lpR']:.4f} T={s['vault_lpT']:.4f} P={s['vault_lpP']:.4f} Total={s['vault_totalLP']:.4f}")
    for t, v in s["vault_tokens"].items():
        print(f"  {t}: {v:.10f}")

    print(f"\n[POOLS]")
    for name, p in s["pools"].items():
        print(f"  {name}: WPOL={p['wpol']:.6f} Token={p['token']:.6f} Price={p['price']:.6f} TVL={p['tvl']:.6f}")

    print(f"\n[LP NAV]")
    for name, nav in s["lp_nav"].items():
        print(f"  {name}: {nav:.10f} WPOL/LP")

    print(f"\n[SUPPLIES]")
    for t, v in s["supplies"].items():
        print(f"  {t}: {v:.10f}")

    print(f"\n[DIVIDENDS]")
    print(f"  Founder pending: {s['founder_pending']:.10f} WPOL")
    print(f"  DivPool WPOL: {s['divpool_wpol']:.10f}")

    print(f"\n[EMISSION STATS]")
    print(f"  Total emitted R: {s['total_emitted_R']:.10f}")
    print(f"  Total emitted T: {s['total_emitted_T']:.10f}")
    print(f"  Total emitted P: {s['total_emitted_P']:.10f}")
    print(f"  Emission due: {s['emission_due']}")

    print(f"\n[TOTALS]")
    print(f"  Total liquid WPOL: {s['total_liquid_wpol']:.10f}")
    print(f"  Market Cap: {s['mcap']:.10f} WPOL")

def compare_snapshots(start, end):
    print(f"\n{'='*70}")
    print(" СРАВНЕНИЕ: START vs END")
    print('='*70)

    # Owner
    delta_pol = end["owner_pol"] - start["owner_pol"]
    delta_wpol = end["owner_wpol"] - start["owner_wpol"]
    print(f"\n[OWNER DELTA]")
    print(f"  POL:  {delta_pol:+.10f}")
    print(f"  WPOL: {delta_wpol:+.10f}")

    for t in ["SYNA", "SYNC", "SYNR"]:
        delta = end["owner_tokens"][t] - start["owner_tokens"][t]
        print(f"  {t}: {delta:+.10f}")

    # Vault
    print(f"\n[VAULT DELTA]")
    delta_vault_wpol = end["vault_wpol"] - start["vault_wpol"]
    print(f"  WPOL: {delta_vault_wpol:+.10f}")
    for t in ["SYNA", "SYNC", "SYNR"]:
        delta = end["vault_tokens"][t] - start["vault_tokens"][t]
        print(f"  {t}: {delta:+.10f}")

    # Supplies
    print(f"\n[SUPPLY DELTA (NEW TOKENS MINTED)]")
    for t in ["SYNA", "SYNC", "SYNR"]:
        delta = end["supplies"][t] - start["supplies"][t]
        value = delta * end["pools"][f"{t}_WPOL"]["price"]
        print(f"  {t}: {delta:+.10f} = {value:+.10f} WPOL")

    # LP NAV
    print(f"\n[LP NAV DELTA (GROWTH)]")
    for pool_name in start["lp_nav"]:
        delta = end["lp_nav"][pool_name] - start["lp_nav"][pool_name]
        pct = (delta / start["lp_nav"][pool_name] * 100) if start["lp_nav"][pool_name] > 0 else Decimal(0)
        print(f"  {pool_name}: {delta:+.10f} ({pct:+.4f}%)")

    # MCAP
    delta_mcap = end["mcap"] - start["mcap"]
    print(f"\n[MCAP DELTA]")
    print(f"  {delta_mcap:+.10f} WPOL")

    # Total liquid
    delta_liquid = end["total_liquid_wpol"] - start["total_liquid_wpol"]
    print(f"\n[TOTAL LIQUID WPOL DELTA]")
    print(f"  {delta_liquid:+.10f} WPOL")

    # PROFIT (owner POL + WPOL + value of tokens)
    start_owner_value = start["owner_pol"] + start["owner_wpol"]
    for t in ["SYNA", "SYNC", "SYNR"]:
        start_owner_value += start["owner_tokens"][t] * start["pools"][f"{t}_WPOL"]["price"]

    end_owner_value = end["owner_pol"] + end["owner_wpol"]
    for t in ["SYNA", "SYNC", "SYNR"]:
        end_owner_value += end["owner_tokens"][t] * end["pools"][f"{t}_WPOL"]["price"]

    profit = end_owner_value - start_owner_value

    print(f"\n{'='*70}")
    print(f" OWNER PROFIT")
    print('='*70)
    print(f"  Start value: {start_owner_value:.10f} WPOL")
    print(f"  End value:   {end_owner_value:.10f} WPOL")
    print(f"  PROFIT:      {profit:+.10f} WPOL")

    return profit

# ═══════════════════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    print("="*70)
    print(" РЕАЛЬНЫЙ ПРИБЫЛЬНЫЙ ЦИКЛ - ПОЛНЫЙ АУДИТ")
    print("="*70)

    # SNAPSHOT START
    start = get_snapshot()
    print_snapshot(start, "SNAPSHOT START")

    # Check if emission is due
    emit = w3.eth.contract(address=C(d["emitEngine_v2"]), abi=EMIT_ABI)
    is_due = emit.functions.isEmissionDue().call()

    if not is_due:
        last = emit.functions.lastEmitBlock().call()
        current = w3.eth.block_number
        blocks_left = 50 - (current - last)
        print(f"\n[!] Emission not due. Wait {blocks_left} blocks (~{blocks_left*2} sec)")
        print(f"    Current: {current}, Last: {last}")
        sys.exit(0)

    # Execute emission
    print(f"\n[EXECUTING EMISSION]")

    nonce = w3.eth.get_transaction_count(C(OWNER), "pending")
    base = w3.eth.get_block("latest").get("baseFeePerGas", int(100e9))
    prio = int(50e9)
    mf = base * 2 + prio

    tx = emit.functions.executeEmission().build_transaction({
        "from": C(OWNER), "nonce": nonce, "chainId": 137, "type": 2,
        "maxPriorityFeePerGas": prio, "maxFeePerGas": mf, "gas": 3_000_000
    })

    signed = w3.eth.account.sign_transaction(tx, PK)
    h = w3.eth.send_raw_transaction(signed.raw_transaction)
    print(f"  TX: {h.hex()}")

    r = w3.eth.wait_for_transaction_receipt(h, timeout=300)
    gas_used = r.gasUsed
    gas_cost = Decimal(gas_used * mf) / Decimal(10**18)

    if r.status == 1:
        print(f"  [OK] Gas: {gas_used}, Cost: {gas_cost:.6f} POL")
    else:
        print(f"  [FAIL]")
        sys.exit(1)

    time.sleep(3)

    # Check founder pending
    divpool = w3.eth.contract(address=C(d["divPool"]), abi=DIV_ABI)
    founder_pending = divpool.functions.founderPending().call()
    print(f"\n[FOUNDER PENDING] {Decimal(founder_pending) / Decimal(10**18):.10f} WPOL")

    # Withdraw founder dividends if any
    if founder_pending > 0:
        print("\n[WITHDRAWING FOUNDER DIVIDENDS]")
        nonce += 1
        tx = divpool.functions.withdrawFounder().build_transaction({
            "from": C(OWNER), "nonce": nonce, "chainId": 137, "type": 2,
            "maxPriorityFeePerGas": prio, "maxFeePerGas": mf, "gas": 200000
        })
        signed = w3.eth.account.sign_transaction(tx, PK)
        h = w3.eth.send_raw_transaction(signed.raw_transaction)
        r = w3.eth.wait_for_transaction_receipt(h, timeout=120)
        print(f"  {'[OK]' if r.status else '[FAIL]'}")
        time.sleep(2)

    # SNAPSHOT END
    end = get_snapshot()
    print_snapshot(end, "SNAPSHOT END")

    # COMPARE
    profit = compare_snapshots(start, end)

    # FINAL VERDICT
    print(f"\n{'='*70}")
    print(f" ВЕРДИКТ")
    print('='*70)
    if profit > 0:
        print(f"  ПРИБЫЛЬ: +{profit:.10f} WPOL")
        print(f"  СТАТУС:  ПРИБЫЛЬНЫЙ ЦИКЛ!")
    elif profit < -gas_cost:
        print(f"  УБЫТОК:  {profit:.10f} WPOL")
        print(f"  СТАТУС:  УБЫТОЧНЫЙ (gas > emission value)")
    else:
        print(f"  DELTA:   {profit:.10f} WPOL")
        print(f"  СТАТУС:  БЕЗУБЫТОЧНЫЙ (gas ≈ emission value)")
