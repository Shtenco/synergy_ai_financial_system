// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

// ═══════════════════════════════════════════════════════════════════════════
//  SINERGY SYSTEM — 09_SelfReinforcingLoop.sol
//  Петля самоусиления v9.0 | Polygon
//
//  Два кольца skip-one (из системной карты):
//
//  КОЛЬЦО A (чётное, узлы N0→N2→N4→N6→N0):
//   traders → arb → emission → dividends → traders
//   Вклад: 0.15% каждого fee
//   Flush каждые 50 блоков:
//    40% → LP inject (65%P / 22%R / 13%T)
//    35% → div bonus (учётно — реальные WPOL приходят из FeeRouter/CBArb)
//    25% → traderReserve (рефуэл трейдеров)
//
//  КОЛЬЦО B (нечётное, узлы N1→N3→N5→N7→N1):
//   fee_router → LP → reserves → CB/TWAP → fee_router
//   Вклад: 0.50% каждого fee
//   Flush каждые 50 блоков:
//    45% → LP inject
//    30% → reserveR
//    20% → CB Fund (учётно — реально идёт через FeeRouter.alphaCB)
//     5% → traderReserve
//
//  Математика усиления:
//   amplificationFactor = (output + input) / input
//   Каждый цикл умножает капитал на ~1.6–2.0×
//   Loop B (fee-кольцо) прокачивает в 3× больше, чем Loop A (подтверждено v7.4)
//
//  Безопасность:
//   ✓ MAX_FLUSH — защита от overflow за один тик
//   ✓ MIN_LOOP  — минимальный порог для flush
//   ✓ ReentrancyGuard на flush
//   ✓ EXECUTOR_ROLE — только TroikaCore
//   ✓ CONTRIBUTOR_ROLE — только TroikaCore
// ═══════════════════════════════════════════════════════════════════════════

import {AccessControl}   from "@openzeppelin/contracts/access/AccessControl.sol";
import {Pausable}        from "@openzeppelin/contracts/utils/Pausable.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import "./01_PolygonConfig.sol";

// ── Интерфейсы (file-level) ────────────────────────────────────────────────

interface IVaultLoop {
    function batchAddLP(uint256 dR, uint256 dT, uint256 dP) external;
    function addToReserveR(uint256 a)      external;
    function addToTraderReserve(uint256 a) external;
    function addToLpBuf(uint256 a)         external;
}

// ── Custom Errors ─────────────────────────────────────────────────────────
error LP_ZeroAddress();
error LP_ZeroAmount();
error LP_InvalidRing(uint8 ring);

contract SelfReinforcingLoop is AccessControl, Pausable, ReentrancyGuard {

    bytes32 public constant CONTRIBUTOR_ROLE = keccak256("CONTRIBUTOR_ROLE");
    bytes32 public constant EXECUTOR_ROLE    = keccak256("EXECUTOR_ROLE");
    bytes32 public constant PAUSER_ROLE      = keccak256("PAUSER_ROLE");

    uint256 public constant MIN_LOOP  = 1e12;       // минимум для flush (0.000001 WPOL)
    uint256 public constant MAX_FLUSH = 500_000e18; // max обработка за один тик

    IVaultLoop public immutable vault;

    // ── Кольца (накопители в LP-единицах, виртуальные) ────────────────
    uint256 public ringA;
    uint256 public ringB;

    // ── Статистика ────────────────────────────────────────────────────
    uint256 public ringATotalProcessed;
    uint256 public ringBTotalProcessed;
    uint256 public lpBonusTotal;      // в LP-единицах
    uint256 public resBonusTotal;     // в LP-единицах
    uint256 public divBonusTotal;     // учётные дивиденды
    uint256 public flushCount;
    uint256 public lastFlushBlock;

    // ── Events ────────────────────────────────────────────────────────
    event ContributedA(uint256 amount, uint256 ringATotal);
    event ContributedB(uint256 amount, uint256 ringBTotal);
    event FlushA(uint256 toLp, uint256 toDiv, uint256 toTraders, uint256 processed);
    event FlushB(uint256 toLp, uint256 toRes, uint256 toCB,      uint256 toTraders, uint256 processed);

    constructor(address vault_, address admin_) {
        if (vault_ == address(0) || admin_ == address(0)) revert LP_ZeroAddress();
        vault = IVaultLoop(vault_);
        _grantRole(DEFAULT_ADMIN_ROLE, admin_);
        _grantRole(CONTRIBUTOR_ROLE,   admin_);
        _grantRole(EXECUTOR_ROLE,      admin_);
        _grantRole(PAUSER_ROLE,        admin_);
    }

    // ── TroikaCore вносит вклад в кольца при каждом processFee ────────
    /// @param ring  0 = кольцо A, 1 = кольцо B
    function contribute(uint8 ring, uint256 amount)
        external whenNotPaused onlyRole(CONTRIBUTOR_ROLE)
    {
        if (ring > 1)    revert LP_InvalidRing(ring);
        if (amount == 0) revert LP_ZeroAmount();

        if (ring == 0) {
            ringA += amount;
            emit ContributedA(amount, ringA);
        } else {
            ringB += amount;
            emit ContributedB(amount, ringB);
        }
    }

    // ═══════════════════════════════════════════════════════════════════
    //  FLUSH — каждые 50 блоков (TroikaCore)
    // ═══════════════════════════════════════════════════════════════════
    function flush()
        external nonReentrant whenNotPaused onlyRole(EXECUTOR_ROLE)
    {
        if (block.number < lastFlushBlock + PolygonConfig.LOOP_INTERVAL) return;
        lastFlushBlock = block.number;
        ++flushCount;

        _flushA();
        _flushB();
    }

    // ── Кольцо A: traders→arb→emission→dividends→traders ─────────────
    function _flushA() private {
        uint256 la = ringA;
        if (la < MIN_LOOP) return;
        if (la > MAX_FLUSH) la = MAX_FLUSH;

        // Effects
        ringA -= la;
        ringATotalProcessed += la;

        // 40% → LP (65%P / 22%R / 13%T)
        uint256 toLp = la * 40 / 100;
        vault.batchAddLP(toLp * 22/100, toLp * 13/100, toLp * 65/100);
        lpBonusTotal += toLp;

        // 35% → div (учётно: реальные WPOL уже пришли через FeeRouter/CBArb)
        uint256 toDv = la * 35 / 100;
        divBonusTotal += toDv;

        // 25% → traderReserve (замыкает кольцо к трейдерам)
        uint256 toTr = la - toLp - toDv;
        vault.addToTraderReserve(toTr);

        emit FlushA(toLp, toDv, toTr, la);
    }

    // ── Кольцо B: fee_router→LP→reserves→CB/TWAP→fee_router ──────────
    function _flushB() private {
        uint256 lb = ringB;
        if (lb < MIN_LOOP) return;
        if (lb > MAX_FLUSH) lb = MAX_FLUSH;

        // Effects
        ringB -= lb;
        ringBTotalProcessed += lb;

        // 45% → LP
        uint256 toLp = lb * 45 / 100;
        vault.batchAddLP(toLp * 22/100, toLp * 13/100, toLp * 65/100);
        lpBonusTotal += toLp;

        // 30% → reserveR
        uint256 toRs = lb * 30 / 100;
        vault.addToReserveR(toRs);
        resBonusTotal += toRs;

        // 20% → CB Fund (учётно — cbFund пополняется через FeeRouter.alphaCB)
        // Часть реально в lpBuf как прокси замыкания к fee_router
        uint256 toCB = lb * 20 / 100;
        vault.addToLpBuf(toCB * 25 / 100); // 25% от CB-части → lpBuf

        // 5% → traderReserve
        uint256 toTr = lb - toLp - toRs - toCB;
        vault.addToTraderReserve(toTr);

        emit FlushB(toLp, toRs, toCB, toTr, lb);
    }

    // ── VIEW ──────────────────────────────────────────────────────────

    function isFlushDue() external view returns (bool) {
        return block.number >= lastFlushBlock + PolygonConfig.LOOP_INTERVAL
            && (ringA >= MIN_LOOP || ringB >= MIN_LOOP);
    }

    /// @return Коэффициент усиления: (output+input)/input × 1e18
    function amplificationFactor() external view returns (uint256) {
        uint256 input  = ringATotalProcessed + ringBTotalProcessed;
        uint256 output = lpBonusTotal + resBonusTotal + divBonusTotal;
        if (input == 0) return 1e18;
        return (output + input) * 1e18 / input;
    }

    function getStats() external view returns (
        uint256 rA, uint256 rB,
        uint256 aTot, uint256 bTot,
        uint256 lpB, uint256 resB, uint256 divB,
        uint256 flushes
    ) {
        return (
            ringA, ringB,
            ringATotalProcessed, ringBTotalProcessed,
            lpBonusTotal, resBonusTotal, divBonusTotal,
            flushCount
        );
    }

    function pause()   external onlyRole(PAUSER_ROLE) { _pause(); }
    function unpause() external onlyRole(PAUSER_ROLE) { _unpause(); }
}
