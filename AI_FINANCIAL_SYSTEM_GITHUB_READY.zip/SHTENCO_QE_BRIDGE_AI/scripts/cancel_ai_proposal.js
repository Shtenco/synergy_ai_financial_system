const fs = require("fs");
const { ethers } = require("ethers");
const ABI = ["function cancel(bytes32 proposalId)"];
async function main() {
  const file = process.argv.find(x => x.endsWith(".json"));
  const broadcast = process.argv.includes("--broadcast");
  if (!file) throw new Error("Usage: node cancel_ai_proposal.js submitted.json [--broadcast]");
  const payload = JSON.parse(fs.readFileSync(file, "utf8"));
  const rpc = process.env.POLYGON_RPC_URL || process.env.RPC_URL;
  const key = process.env.GUARDIAN_PRIVATE_KEY;
  const centralBank = payload.centralBank || process.env.AI_CENTRAL_BANK_ADDRESS;
  if (!rpc || !key || !centralBank || !payload.proposalId) throw new Error("RPC, guardian key, central bank and proposalId required");
  const signer = new ethers.Wallet(key, new ethers.JsonRpcProvider(rpc));
  const contract = new ethers.Contract(centralBank, ABI, signer);
  const gas = await contract.cancel.estimateGas(payload.proposalId);
  console.log(JSON.stringify({ mode: broadcast ? "BROADCAST" : "DRY_RUN", proposalId: payload.proposalId, gas: gas.toString() }, null, 2));
  if (!broadcast) return;
  if (process.env.LIVE_EXECUTION !== "1") throw new Error("LIVE_EXECUTION=1 is required for broadcast");
  const tx = await contract.cancel(payload.proposalId, { gasLimit: gas * 120n / 100n });
  console.log(JSON.stringify({ txHash: tx.hash, receipt: await tx.wait() }, null, 2));
}
main().catch(e => { console.error(e); process.exitCode = 1; });
