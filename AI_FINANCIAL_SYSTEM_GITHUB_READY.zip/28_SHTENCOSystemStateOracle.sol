// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {AccessControl} from "@openzeppelin/contracts/access/AccessControl.sol";
import {Math} from "@openzeppelin/contracts/utils/math/Math.sol";

/**
 * @title SHTENCOSystemStateOracle
 * @notice M-of-N accounting oracle for the unified DeFi contour. Reporters
 *         submit the same economic snapshot on-chain. The contract computes
 *         backing NAV and a conservative fundamental value independently from
 *         the reported market price, so internal swaps cannot manufacture
 *         protocol value merely by moving a thin-pool price.
 *
 * All monetary values use one common 18-decimal accounting unit configured by
 * governance (for example USD 1e18 or WPOL 1e18).
 */
contract SHTENCOSystemStateOracle is AccessControl {
    using Math for uint256;

    bytes32 public constant REPORTER_ROLE = keccak256("REPORTER_ROLE");
    bytes32 public constant POLICY_ROLE = keccak256("POLICY_ROLE");
    uint256 public constant BPS = 10_000;
    uint256 public constant UNIT = 1e18;

    struct SnapshotInput {
        uint256 liquidReserves;
        uint256 liabilities;
        uint256 ownedLiquidityNav;
        uint256 bridgeCapital;
        uint256 circulatingSupply;
        uint256 protocolRevenue30d;
        uint256 marketPrice;
        uint16 volatilityBps;
        uint16 pegErrorBps;
        uint16 bridgeImbalanceBps;
        uint16 liquidityCoverageBps;
        bytes32 externalDataHash;
    }

    struct Snapshot {
        uint256 round;
        uint64 finalizedAt;
        bytes32 snapshotHash;
        bytes32 externalDataHash;
        uint256 liquidReserves;
        uint256 liabilities;
        uint256 ownedLiquidityNav;
        uint256 bridgeCapital;
        uint256 circulatingSupply;
        uint256 protocolRevenue30d;
        uint256 marketPrice;
        uint256 marketCap;
        uint256 backingNav;
        uint256 discountedRevenueValue;
        uint256 fundamentalMcap;
        uint256 fundamentalPrice;
        uint32 reserveRatioBps;
        uint32 valuationPremiumBps;
        uint16 volatilityBps;
        uint16 pegErrorBps;
        uint16 bridgeImbalanceBps;
        uint16 liquidityCoverageBps;
    }

    uint256 public nextRound = 1;
    uint256 public latestRound;
    uint256 public reporterCount;
    uint256 public threshold;

    uint16 public revenueHaircutBps = 5_000;
    uint8 public revenueHorizonMonths = 12;

    Snapshot private _latest;
    mapping(uint256 => mapping(bytes32 => uint256)) public approvals;
    mapping(uint256 => mapping(address => bool)) public voted;

    event ReporterSet(address indexed reporter, bool enabled);
    event ThresholdSet(uint256 threshold);
    event ValuationPolicySet(uint16 revenueHaircutBps, uint8 revenueHorizonMonths);
    event SnapshotVote(uint256 indexed round, bytes32 indexed snapshotHash, address indexed reporter, uint256 approvals);
    event SnapshotFinalized(
        uint256 indexed round,
        bytes32 indexed snapshotHash,
        uint256 backingNav,
        uint256 fundamentalMcap,
        uint256 fundamentalPrice,
        uint256 marketCap
    );
    event PendingRoundCancelled(uint256 indexed abandonedRound, uint256 indexed nextRound);

    constructor(address admin, address[] memory reporters, uint256 threshold_) {
        require(admin != address(0), "STATE: zero admin");
        _grantRole(DEFAULT_ADMIN_ROLE, admin);
        _grantRole(POLICY_ROLE, admin);
        for (uint256 i; i < reporters.length; ++i) {
            address reporter = reporters[i];
            require(reporter != address(0) && !hasRole(REPORTER_ROLE, reporter), "STATE: bad reporter");
            _grantRole(REPORTER_ROLE, reporter);
            ++reporterCount;
            emit ReporterSet(reporter, true);
        }
        _setThreshold(threshold_);
    }

    function submitSnapshot(SnapshotInput calldata input)
        external
        onlyRole(REPORTER_ROLE)
        returns (bytes32 snapshotHash)
    {
        _validateInput(input);
        uint256 round = nextRound;
        require(!voted[round][msg.sender], "STATE: reporter already voted");

        snapshotHash = keccak256(abi.encode(block.chainid, address(this), round, input));
        voted[round][msg.sender] = true;
        uint256 count = ++approvals[round][snapshotHash];
        emit SnapshotVote(round, snapshotHash, msg.sender, count);

        if (count >= threshold) {
            _finalize(round, snapshotHash, input);
        }
    }

    function _finalize(uint256 round, bytes32 snapshotHash, SnapshotInput calldata input) internal {
        require(round == nextRound, "STATE: stale round");

        uint256 grossAssets = input.liquidReserves + input.ownedLiquidityNav + input.bridgeCapital;
        uint256 backingNav = grossAssets - input.liabilities;
        uint256 discountedRevenueValue = Math.mulDiv(
            input.protocolRevenue30d,
            uint256(revenueHaircutBps) * uint256(revenueHorizonMonths),
            BPS
        );
        uint256 fundamentalMcap = backingNav + discountedRevenueValue;
        uint256 fundamentalPrice = Math.mulDiv(fundamentalMcap, UNIT, input.circulatingSupply);
        uint256 marketCap = Math.mulDiv(input.marketPrice, input.circulatingSupply, UNIT);

        uint256 reserveRatio = input.liabilities == 0
            ? type(uint32).max
            : Math.mulDiv(input.liquidReserves, BPS, input.liabilities);
        uint256 premium = fundamentalMcap == 0
            ? type(uint32).max
            : Math.mulDiv(marketCap, BPS, fundamentalMcap);

        _latest = Snapshot({
            round: round,
            finalizedAt: uint64(block.timestamp),
            snapshotHash: snapshotHash,
            externalDataHash: input.externalDataHash,
            liquidReserves: input.liquidReserves,
            liabilities: input.liabilities,
            ownedLiquidityNav: input.ownedLiquidityNav,
            bridgeCapital: input.bridgeCapital,
            circulatingSupply: input.circulatingSupply,
            protocolRevenue30d: input.protocolRevenue30d,
            marketPrice: input.marketPrice,
            marketCap: marketCap,
            backingNav: backingNav,
            discountedRevenueValue: discountedRevenueValue,
            fundamentalMcap: fundamentalMcap,
            fundamentalPrice: fundamentalPrice,
            reserveRatioBps: uint32(Math.min(reserveRatio, type(uint32).max)),
            valuationPremiumBps: uint32(Math.min(premium, type(uint32).max)),
            volatilityBps: input.volatilityBps,
            pegErrorBps: input.pegErrorBps,
            bridgeImbalanceBps: input.bridgeImbalanceBps,
            liquidityCoverageBps: input.liquidityCoverageBps
        });

        latestRound = round;
        nextRound = round + 1;
        emit SnapshotFinalized(round, snapshotHash, backingNav, fundamentalMcap, fundamentalPrice, marketCap);
    }

    function _validateInput(SnapshotInput calldata input) internal pure {
        require(input.circulatingSupply > 0, "STATE: zero supply");
        require(input.marketPrice > 0, "STATE: zero market price");
        require(
            input.liquidReserves + input.ownedLiquidityNav + input.bridgeCapital >= input.liabilities,
            "STATE: insolvent snapshot"
        );
        require(input.volatilityBps <= BPS, "STATE: volatility range");
        require(input.pegErrorBps <= BPS, "STATE: peg range");
        require(input.bridgeImbalanceBps <= BPS, "STATE: bridge range");
        require(input.liquidityCoverageBps <= BPS, "STATE: coverage range");
        require(input.externalDataHash != bytes32(0), "STATE: no evidence");
    }

    function getLatestSnapshot() external view returns (Snapshot memory) {
        return _latest;
    }

    function isFresh(uint256 maxAge) external view returns (bool) {
        return _latest.finalizedAt != 0 && block.timestamp - _latest.finalizedAt <= maxAge;
    }

    function setReporter(address reporter, bool enabled) external onlyRole(DEFAULT_ADMIN_ROLE) {
        require(reporter != address(0), "STATE: zero reporter");
        bool current = hasRole(REPORTER_ROLE, reporter);
        require(current != enabled, "STATE: unchanged");
        if (enabled) {
            _grantRole(REPORTER_ROLE, reporter);
            ++reporterCount;
        } else {
            require(reporterCount > 1 && reporterCount - 1 >= threshold, "STATE: threshold safety");
            _revokeRole(REPORTER_ROLE, reporter);
            --reporterCount;
        }
        emit ReporterSet(reporter, enabled);
    }

    function setThreshold(uint256 threshold_) external onlyRole(POLICY_ROLE) {
        _setThreshold(threshold_);
    }

    function _setThreshold(uint256 threshold_) internal {
        require(threshold_ > 0 && threshold_ <= reporterCount, "STATE: bad threshold");
        threshold = threshold_;
        emit ThresholdSet(threshold_);
    }

    function setValuationPolicy(uint16 haircutBps, uint8 horizonMonths) external onlyRole(POLICY_ROLE) {
        require(haircutBps <= BPS, "STATE: haircut range");
        require(horizonMonths > 0 && horizonMonths <= 24, "STATE: horizon range");
        revenueHaircutBps = haircutBps;
        revenueHorizonMonths = horizonMonths;
        emit ValuationPolicySet(haircutBps, horizonMonths);
    }

    function cancelPendingRound() external onlyRole(POLICY_ROLE) {
        uint256 abandoned = nextRound;
        ++nextRound;
        emit PendingRoundCancelled(abandoned, nextRound);
    }
}
