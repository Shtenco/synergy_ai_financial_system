from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

try:
    from eth_account import Account
    from eth_account.messages import encode_typed_data
    from web3 import Web3
except ImportError as exc:  # pragma: no cover - optional runtime dependency
    raise SystemExit("Install requirements_relay.txt before running the relayer") from exc


BRIDGE_ABI = [
    {
        "anonymous": False,
        "inputs": [
            {"indexed": True, "name": "messageId", "type": "bytes32"},
            {"indexed": True, "name": "sourceChainId", "type": "uint256"},
            {"indexed": True, "name": "targetChainId", "type": "uint256"},
            {"indexed": False, "name": "nonce", "type": "uint256"},
            {"indexed": False, "name": "sourceBridge", "type": "address"},
            {"indexed": False, "name": "targetBridge", "type": "address"},
            {"indexed": False, "name": "sourceToken", "type": "address"},
            {"indexed": False, "name": "targetToken", "type": "address"},
            {"indexed": False, "name": "sender", "type": "address"},
            {"indexed": False, "name": "recipient", "type": "address"},
            {"indexed": False, "name": "grossAmount", "type": "uint256"},
            {"indexed": False, "name": "netAmount", "type": "uint256"},
            {"indexed": False, "name": "fee", "type": "uint256"},
            {"indexed": False, "name": "validatorEpoch", "type": "uint256"}
        ],
        "name": "BridgeOutbound",
        "type": "event"
    },
    {
        "inputs": [
            {
                "components": [
                    {"name": "sourceChainId", "type": "uint256"},
                    {"name": "sourceBridge", "type": "address"},
                    {"name": "sourceNonce", "type": "uint256"},
                    {"name": "sourceToken", "type": "address"},
                    {"name": "targetChainId", "type": "uint256"},
                    {"name": "targetBridge", "type": "address"},
                    {"name": "targetToken", "type": "address"},
                    {"name": "recipient", "type": "address"},
                    {"name": "amount", "type": "uint256"},
                    {"name": "deadline", "type": "uint256"},
                    {"name": "validatorEpoch", "type": "uint256"}
                ],
                "name": "message",
                "type": "tuple"
            },
            {"name": "signatures", "type": "bytes[]"}
        ],
        "name": "completeInbound",
        "outputs": [{"name": "messageId", "type": "bytes32"}],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [], "name": "threshold", "outputs": [{"type": "uint256"}],
        "stateMutability": "view", "type": "function"
    },
    {
        "inputs": [{"name": "messageId", "type": "bytes32"}], "name": "processedMessage",
        "outputs": [{"type": "bool"}], "stateMutability": "view", "type": "function"
    }
]

TYPES = {
    "InboundMessage": [
        {"name": "sourceChainId", "type": "uint256"},
        {"name": "sourceBridge", "type": "address"},
        {"name": "sourceNonce", "type": "uint256"},
        {"name": "sourceToken", "type": "address"},
        {"name": "targetChainId", "type": "uint256"},
        {"name": "targetBridge", "type": "address"},
        {"name": "targetToken", "type": "address"},
        {"name": "recipient", "type": "address"},
        {"name": "amount", "type": "uint256"},
        {"name": "deadline", "type": "uint256"},
        {"name": "validatorEpoch", "type": "uint256"}
    ]
}


@dataclass(slots=True)
class RelayConfig:
    raw: dict[str, Any]
    root: Path

    @property
    def source_rpc(self) -> str:
        return os.environ[self.raw["source"]["rpc_env"]]

    @property
    def destination_rpc(self) -> str:
        return os.environ[self.raw["destination"]["rpc_env"]]

    @property
    def queue_dir(self) -> Path:
        path = Path(self.raw.get("queue_dir", "relay_queue"))
        return path if path.is_absolute() else self.root / path


def canonical_key(message: dict[str, Any]) -> str:
    payload = json.dumps(message, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(payload).hexdigest()


def build_message(event: Any, source_block_timestamp: int, lifetime: int) -> dict[str, Any]:
    args = event["args"]
    return {
        "sourceChainId": int(args["sourceChainId"]),
        "sourceBridge": Web3.to_checksum_address(args["sourceBridge"]),
        "sourceNonce": int(args["nonce"]),
        "sourceToken": Web3.to_checksum_address(args["sourceToken"]),
        "targetChainId": int(args["targetChainId"]),
        "targetBridge": Web3.to_checksum_address(args["targetBridge"]),
        "targetToken": Web3.to_checksum_address(args["targetToken"]),
        "recipient": Web3.to_checksum_address(args["recipient"]),
        "amount": int(args["netAmount"]),
        "deadline": int(source_block_timestamp + lifetime),
        "validatorEpoch": int(args["validatorEpoch"]),
    }


def sign_message(config: RelayConfig, message: dict[str, Any]) -> Path:
    key = os.environ[config.raw["validator_private_key_env"]]
    account = Account.from_key(key)
    destination_chain_id = int(config.raw["destination"]["chain_id"])
    domain = {
        "name": "SHTENCO SYNA Relay Bridge",
        "version": "2",
        "chainId": destination_chain_id,
        "verifyingContract": message["targetBridge"],
    }
    signable = encode_typed_data(domain_data=domain, message_types=TYPES, message_data=message)
    signed = Account.sign_message(signable, key)
    queue = config.queue_dir / canonical_key(message)
    queue.mkdir(parents=True, exist_ok=True)
    path = queue / f"{account.address.lower()}.json"
    path.write_text(json.dumps({
        "validator": account.address,
        "signature": signed.signature.hex(),
        "message": message,
        "domain": domain,
    }, indent=2), encoding="utf-8")
    return path


def submit_if_ready(config: RelayConfig, message: dict[str, Any], send: bool) -> dict[str, Any]:
    queue = config.queue_dir / canonical_key(message)
    rows = [json.loads(p.read_text(encoding="utf-8")) for p in queue.glob("*.json")]
    by_validator = {row["validator"].lower(): row for row in rows}
    rows = sorted(by_validator.values(), key=lambda row: row["validator"].lower())
    w3 = Web3(Web3.HTTPProvider(config.destination_rpc, request_kwargs={"timeout": 60}))
    bridge = w3.eth.contract(address=Web3.to_checksum_address(message["targetBridge"]), abi=BRIDGE_ABI)
    threshold = int(bridge.functions.threshold().call())
    result = {"threshold": threshold, "signatures": len(rows), "ready": len(rows) >= threshold, "sent": False}
    if len(rows) < threshold or not send:
        return result

    key = os.environ[config.raw["submitter_private_key_env"]]
    account = Account.from_key(key)
    signatures = [row["signature"] for row in rows[:threshold]]
    tx = bridge.functions.completeInbound((
        message["sourceChainId"], message["sourceBridge"], message["sourceNonce"],
        message["sourceToken"], message["targetChainId"], message["targetBridge"],
        message["targetToken"], message["recipient"], message["amount"],
        message["deadline"], message["validatorEpoch"]
    ), signatures).build_transaction({
        "from": account.address,
        "nonce": w3.eth.get_transaction_count(account.address),
        "chainId": w3.eth.chain_id,
        "gasPrice": w3.eth.gas_price,
    })
    tx["gas"] = int(w3.eth.estimate_gas(tx) * 1.2)
    signed = account.sign_transaction(tx)
    tx_hash = w3.eth.send_raw_transaction(signed.raw_transaction)
    result.update({"sent": True, "tx_hash": tx_hash.hex()})
    return result


def scan_once(config: RelayConfig, from_block: int, to_block: int | str, do_sign: bool, do_submit: bool) -> tuple[list[dict[str, Any]], int]:
    source_w3 = Web3(Web3.HTTPProvider(config.source_rpc, request_kwargs={"timeout": 60}))
    bridge = source_w3.eth.contract(address=Web3.to_checksum_address(config.raw["source"]["bridge"]), abi=BRIDGE_ABI)
    confirmations_required = int(config.raw.get("confirmations", 0))
    finalized = max(0, source_w3.eth.block_number - confirmations_required)
    requested_to = finalized if to_block == "latest" else min(int(to_block), finalized)
    if requested_to < from_block:
        return [], from_block
    events = bridge.events.BridgeOutbound().get_logs(from_block=from_block, to_block=requested_to)
    output = []
    for event in events:
        block = source_w3.eth.get_block(event["blockNumber"])
        message = build_message(event, int(block["timestamp"]), int(config.raw.get("message_lifetime_seconds", 86400)))
        expected_destination_chain = int(config.raw["destination"]["chain_id"])
        expected_destination_bridge = Web3.to_checksum_address(config.raw["destination"]["bridge"])
        if message["targetChainId"] != expected_destination_chain or message["targetBridge"] != expected_destination_bridge:
            continue
        row: dict[str, Any] = {"message": message, "source_tx": event["transactionHash"].hex()}
        if do_sign:
            row["signature_file"] = str(sign_message(config, message))
        if do_submit:
            row["submission"] = submit_if_ready(config, message, send=True)
        output.append(row)
    return output, requested_to + 1


def main() -> int:
    parser = argparse.ArgumentParser(description="SHTENCO M-of-N bridge relay")
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--from-block", type=int, default=None)
    parser.add_argument("--to-block", default="latest")
    parser.add_argument("--sign", action="store_true")
    parser.add_argument("--submit", action="store_true", help="broadcast destination transaction")
    parser.add_argument("--watch", action="store_true")
    parser.add_argument("--interval", type=int, default=30)
    args = parser.parse_args()

    raw = json.loads(args.config.read_text(encoding="utf-8"))
    config = RelayConfig(raw, args.config.parent.parent)
    start = args.from_block if args.from_block is not None else int(raw["source"].get("deployment_block", 0))
    while True:
        rows, next_start = scan_once(config, start, args.to_block, args.sign, args.submit)
        print(json.dumps(rows, indent=2))
        if not args.watch:
            return 0
        start = max(start, next_start)
        time.sleep(max(5, args.interval))


if __name__ == "__main__":
    raise SystemExit(main())
