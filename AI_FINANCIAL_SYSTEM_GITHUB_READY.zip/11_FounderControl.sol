// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

// ═══════════════════════════════════════════════════════════════════════════
//  SINERGY SYSTEM — 11_FounderControl.sol
//  Управляющий контракт основателя | Polygon
//
//  ╔══════════════════════════════════════════════════════════╗
//  ║           ПАНЕЛЬ УПРАВЛЕНИЯ ОСНОВАТЕЛЯ                   ║
//  ╠══════════════════════════════════════════════════════════╣
//  ║                                                          ║
//  ║  🔴 СТОП СИСТЕМЫ     systemStop()                        ║
//  ║     Кто: основатель или деплоер                          ║
//  ║     Действие: мгновенная пауза всех 8 контрактов         ║
//  ║                                                          ║
//  ║  🟢 ЗАПУСК СИСТЕМЫ   queueStart() + executeStart()       ║
//  ║     Кто: основатель или деплоер                          ║
//  ║     Защита: таймлок 1 час (нельзя разпаузить мгновенно)  ║
//  ║                                                          ║
//  ║  ♻️  РЕИНВЕСТ ВКЛ     enableReinvest()                   ║
//  ║     Кто: только основатель                               ║
//  ║     Действие: дивиденды → LP пулы QuickSwap              ║
//  ║     Эффект: система самоускоряется через петлю v9.0      ║
//  ║                                                          ║
//  ║  💸 РЕИНВЕСТ ВЫКЛ    disableReinvest(autoWithdraw)       ║
//  ║     Кто: только основатель                               ║
//  ║     autoWithdraw=true  → авто-вывод WPOL на кошелёк     ║
//  ║     autoWithdraw=false → только ручной withdrawNow()     ║
//  ║                                                          ║
//  ║  💰 ИНВЕСТИРОВАТЬ    investPOL(amount)                   ║
//  ║     Кто: только основатель                               ║
//  ║     Действие: добавить WPOL в систему из кошелька        ║
//  ║     Распределение: 60%→LP + 30%→reserveR + 10%→keeper   ║
//  ║     approve(founderCtl, amount) сначала!                 ║
//  ║                                                          ║
//  ╠══════════════════════════════════════════════════════════╣
//  ║  Ручные операции:                                        ║
//  ║  withdrawNow()  — вывести все pending дивиденды          ║
//  ║  reinvestNow()  — реинвестировать все pending            ║
//  ║  setFounderWallet(addr) — сменить кошелёк вывода         ║
//  ║  setKeeperTopup(bps)    — % дивидендов → keeper fund     ║
//  ║  systemSnapshot()       — полный статус системы          ║
//  ╚══════════════════════════════════════════════════════════╝
//
//  БЕЗОПАСНОСТЬ:
//   ✓ FOUNDER_ROLE — только дивиденды и инвестиции
//   ✓ DEPLOYER_ROLE — только стоп/старт и emergency
//   ✓ Founder НЕ может менять параметры системы
//   ✓ Deployer НЕ может трогать дивиденды founder
//   ✓ ReentrancyGuard на всех операциях с WPOL
//   ✓ investPOL: лимит MAX_SINGLE_INVEST = 100k WPOL за вызов
//   ✓ Emergency rescue: таймлок 3 дня, окно 7 дней
// ═══════════════════════════════════════════════════════════════════════════

import {AccessControl}    from "@openzeppelin/contracts/access/AccessControl.sol";
import {ReentrancyGuard}  from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {IERC20}           from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20}        from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import "./01_PolygonConfig.sol";

// ── Интерфейсы (file-level) ────────────────────────────────────────────────

interface ICoreFC {
    function pauseAll()     external;
    function queueUnpause() external;
    function unpauseAll()   external;
    function paused()       external view returns (bool);
    function keeperFund()   external view returns (uint256);
    function totalTicks()   external view returns (uint256);
    function totalFeeProcessed() external view returns (uint256);
    function initKeeperFund(uint256 amount) external;
    function systemState()  external view returns (
        uint256, uint256, uint256, uint256, uint256, uint256, uint256, bool
    );
}

interface IVaultFC {
    function totalLP()       external view returns (uint256);
    function totalMCap()     external view returns (uint256);
    function reserveR()      external view returns (uint256);
    function traderReserve() external view returns (uint256);
    function mcgFund()       external view returns (uint256);
    function freeWpol()      external view returns (uint256);
    function lpBuf()         external view returns (uint256);
    function buybackAccum()  external view returns (uint256);
    // Мутаторы для инвестиции
    function addToLpBuf(uint256 a)        external;
    function addToReserveR(uint256 a)     external;
}

interface IDivFC {
    function founderPending()          external view returns (uint256);
    function founderPaidToWallet()     external view returns (uint256);
    function founderReinvestedTotal()  external view returns (uint256);
    function founderEmissionAccum()    external view returns (uint256);
    function holdersPool()             external view returns (uint256);
    function dividendPerToken()        external view returns (uint256);
    function totalPaidHolders()        external view returns (uint256);
    function reinvestMode()            external view returns (bool);
    function setReinvestMode(bool)     external;
    function reinvestFounder(address)  external;
    function withdrawFounderTo(address) external;
}

interface ILoopFC {
    function getStats() external view returns (
        uint256, uint256, uint256, uint256, uint256, uint256, uint256, uint256
    );
    function amplificationFactor()     external view returns (uint256);
}

// ── Custom Errors ─────────────────────────────────────────────────────────
error FC_ZeroAddress();
error FC_ZeroAmount();
error FC_Unauthorized();
error FC_SystemAlreadyStopped();
error FC_SystemAlreadyRunning();
error FC_StartNotQueued();
error FC_StartTimelockActive(uint256 unlockAt, uint256 now_);
error FC_ReinvestAlreadyEnabled();
error FC_ReinvestAlreadyDisabled();
error FC_NothingToClaim();
error FC_InvestTooLarge(uint256 amount, uint256 max_);
error FC_InsufficientAllowance();
error FC_KeeperTopupTooHigh(uint256 bps, uint256 max_);
error FC_RescueAlreadyQueued();
error FC_RescueNotQueued();
error FC_RescueTimelockActive(uint256 unlockAt, uint256 now_);
error FC_RescueExpired();

contract FounderControl is AccessControl, ReentrancyGuard {
    using SafeERC20 for IERC20;

    bytes32 public constant FOUNDER_ROLE  = keccak256("FOUNDER_ROLE");
    bytes32 public constant DEPLOYER_ROLE = keccak256("DEPLOYER_ROLE");
    bytes32 public constant KEEPER_ROLE   = keccak256("KEEPER_ROLE"); // TroikaCore

    // ── Контракты системы ─────────────────────────────────────────────
    ICoreFC  public immutable core;
    IVaultFC public immutable vault;
    IDivFC   public immutable divPool;
    ILoopFC  public immutable loop_;
    IERC20   public immutable WPOL;

    address public immutable vaultAddr;
    address public immutable coreAddr;
    address public immutable divPoolAddr;

    // ── Состояние основателя ──────────────────────────────────────────
    address public founderWallet;        // кошелёк вывода WPOL
    bool    public reinvestEnabled;      // true = дивиденды → LP
    bool    public autoWithdrawEnabled;  // true = авто-вывод при tick
    uint256 public keeperTopupBps;       // % дивидендов → keeper fund

    // ── Лимиты ────────────────────────────────────────────────────────
    uint256 public constant MAX_SINGLE_INVEST   = 100_000e18; // 100k WPOL за раз
    uint256 public constant MAX_KEEPER_TOPUP_BPS = 1_000;     // max 10%

    // ── Статистика управления ─────────────────────────────────────────
    uint256 public totalReinvested;   // WPOL реинвестировано в LP
    uint256 public totalWithdrawn;    // WPOL выведено на кошелёк
    uint256 public totalInvested;     // WPOL добавлено основателем в систему
    uint256 public stopCount;
    uint256 public startCount;
    uint256 public investCount;

    // ── Start — INSTANT (no timelock) ────────────────────────────────
    uint256 public startQueuedAt;
    bool    public startQueued;
    uint256 public constant START_TIMELOCK = 0;

    // ── Emergency Rescue — INSTANT (no timelock) ─────────────────────
    address public rescueTo;
    uint256 public rescueAmount;
    uint256 public rescueQueuedAt;
    bool    public rescueQueued;
    uint256 public constant RESCUE_TIMELOCK = 0;
    uint256 public constant RESCUE_WINDOW   = type(uint256).max;

    // ── Events ────────────────────────────────────────────────────────
    event SystemStopped(address indexed by, uint256 blockN);
    event SystemStartQueued(address indexed by, uint256 unlockAt);
    event SystemStarted(address indexed by, uint256 blockN);
    event StartCancelled(address indexed by);

    event ReinvestEnabled(address indexed by);
    event ReinvestDisabled(address indexed by, bool autoWithdraw);
    event FounderReinvestedNow(uint256 amount, uint256 totalReinvested);
    event FounderWithdrawnNow(address indexed to, uint256 amount, uint256 totalWithdrawn);

    event POLInvested(
        address indexed by,
        uint256 amount,
        uint256 toLp,
        uint256 toReserveR,
        uint256 toKeeper,
        uint256 totalInvested
    );

    event FounderWalletChanged(address oldWallet, address newWallet);
    event KeeperTopupSet(uint256 bps);
    event AutoWithdrawSet(bool enabled);
    event RescueQueued(address indexed to, uint256 amount, uint256 unlockAt);
    event RescueExecuted(address indexed to, uint256 amount);

    // ── Modifier: основатель или деплоер ──────────────────────────────
    modifier founderOrDeployer() {
        if (!hasRole(FOUNDER_ROLE, msg.sender) && !hasRole(DEPLOYER_ROLE, msg.sender))
            revert FC_Unauthorized();
        _;
    }

    constructor(
        address core_,
        address vault_,
        address divPool_,
        address loop__,
        address founder_,
        address deployer_
    ) {
        if (core_    == address(0) || vault_    == address(0) ||
            divPool_ == address(0) || loop__    == address(0) ||
            founder_ == address(0) || deployer_ == address(0)) revert FC_ZeroAddress();

        core       = ICoreFC(core_);
        vault      = IVaultFC(vault_);
        divPool    = IDivFC(divPool_);
        loop_      = ILoopFC(loop__);
        WPOL       = IERC20(PolygonConfig.WPOL);
        vaultAddr  = vault_;
        coreAddr   = core_;
        divPoolAddr= divPool_;

        founderWallet   = founder_;
        reinvestEnabled = false; // по умолчанию: вывод на кошелёк

        _grantRole(DEFAULT_ADMIN_ROLE, deployer_);
        _grantRole(DEPLOYER_ROLE,      deployer_);
        _grantRole(FOUNDER_ROLE,       founder_);
        _grantRole(KEEPER_ROLE,        core_); // TroikaCore вызывает processFounderDividends
    }

    // ╔══════════════════════════════════════════════════════════════════╗
    // ║   КОМАНДА 1: 🔴 СТОП СИСТЕМЫ                                    ║
    // ║   Кто: основатель или деплоер                                   ║
    // ╚══════════════════════════════════════════════════════════════════╝
    function systemStop() external founderOrDeployer {
        if (core.paused()) revert FC_SystemAlreadyStopped();
        core.pauseAll();
        ++stopCount;
        if (startQueued) {
            startQueued   = false;
            startQueuedAt = 0;
            emit StartCancelled(msg.sender);
        }
        emit SystemStopped(msg.sender, block.number);
    }

    // ╔══════════════════════════════════════════════════════════════════╗
    // ║   КОМАНДА 2: 🟢 ЗАПУСК СИСТЕМЫ (2 шага, таймлок 1 час)         ║
    // ╚══════════════════════════════════════════════════════════════════╝

    /// @notice Шаг 1: поставить запуск в очередь
    function queueStart() external founderOrDeployer {
        if (!core.paused()) revert FC_SystemAlreadyRunning();
        if (startQueued)    revert("FC: start already queued");
        startQueuedAt = block.timestamp;
        startQueued   = true;
        core.queueUnpause();
        emit SystemStartQueued(msg.sender, block.timestamp + START_TIMELOCK);
    }

    /// @notice Шаг 2: запустить систему (через 1 час после queueStart)
    function executeStart() external founderOrDeployer {
        if (!startQueued) revert FC_StartNotQueued();
        if (block.timestamp < startQueuedAt + START_TIMELOCK)
            revert FC_StartTimelockActive(startQueuedAt + START_TIMELOCK, block.timestamp);
        startQueued   = false;
        startQueuedAt = 0;
        core.unpauseAll();
        ++startCount;
        emit SystemStarted(msg.sender, block.number);
    }

    /// @notice Отменить запуск в очереди
    function cancelStart() external founderOrDeployer {
        if (!startQueued) revert FC_StartNotQueued();
        startQueued   = false;
        startQueuedAt = 0;
        emit StartCancelled(msg.sender);
    }

    // ╔══════════════════════════════════════════════════════════════════╗
    // ║   КОМАНДА 3: ♻️  РЕИНВЕСТИРОВАНИЕ ДИВИДЕНДОВ — ВКЛЮЧИТЬ         ║
    // ║   Кто: только основатель                                        ║
    // ║   Эффект: дивиденды → LP → система самоускоряется               ║
    // ╚══════════════════════════════════════════════════════════════════╝
    function enableReinvest() external onlyRole(FOUNDER_ROLE) {
        if (reinvestEnabled) revert FC_ReinvestAlreadyEnabled();
        reinvestEnabled     = true;
        autoWithdrawEnabled = false;
        divPool.setReinvestMode(true);

        // Немедленно реинвестировать всё накопленное pending
        uint256 pending = divPool.founderPending();
        if (pending > 0) _doReinvest(pending);

        emit ReinvestEnabled(msg.sender);
    }

    // ╔══════════════════════════════════════════════════════════════════╗
    // ║   КОМАНДА 4: 💸 РЕИНВЕСТИРОВАНИЕ ДИВИДЕНДОВ — ВЫКЛЮЧИТЬ        ║
    // ║   autoWithdraw=true  → авто-вывод WPOL на кошелёк              ║
    // ║   autoWithdraw=false → только ручной withdrawNow()             ║
    // ╚══════════════════════════════════════════════════════════════════╝
    function disableReinvest(bool autoWithdraw) external onlyRole(FOUNDER_ROLE) {
        if (!reinvestEnabled) revert FC_ReinvestAlreadyDisabled();
        reinvestEnabled     = false;
        autoWithdrawEnabled = autoWithdraw;
        divPool.setReinvestMode(false);
        emit ReinvestDisabled(msg.sender, autoWithdraw);
        emit AutoWithdrawSet(autoWithdraw);
    }

    // ╔══════════════════════════════════════════════════════════════════╗
    // ║   КОМАНДА 5: 💰 ИНВЕСТИРОВАТЬ POL В СИСТЕМУ                    ║
    // ║   Кто: только основатель                                        ║
    // ║   Предусловие: WPOL.approve(founderCtlAddr, amount)             ║
    // ║                                                                  ║
    // ║   Распределение (из POL-депозита):                              ║
    // ║     60% → LP пулы QuickSwap (ускоряет рост)                    ║
    // ║     30% → reserveR (коллатеральный резерв)                     ║
    // ║     10% → keeper fund (оплата gas кипера)                      ║
    // ║                                                                  ║
    // ║   Максимум за раз: 100 000 WPOL (защита от ошибки)             ║
    // ╚══════════════════════════════════════════════════════════════════╝
    function investPOL(uint256 amount) external nonReentrant onlyRole(FOUNDER_ROLE) {
        if (amount == 0)                 revert FC_ZeroAmount();
        if (amount > MAX_SINGLE_INVEST)  revert FC_InvestTooLarge(amount, MAX_SINGLE_INVEST);

        // Проверить allowance (CEI: Checks)
        uint256 allowance = WPOL.allowance(msg.sender, address(this));
        if (allowance < amount) revert FC_InsufficientAllowance();

        // Расчёт долей
        uint256 toLp      = amount * 60 / 100;
        uint256 toReserve = amount * 30 / 100;
        uint256 toKeeper  = amount - toLp - toReserve; // 10%

        // Effects
        totalInvested += amount;
        ++investCount;

        // Interactions: перевести WPOL от основателя сюда
        WPOL.safeTransferFrom(msg.sender, address(this), amount);

        // Распределить в систему
        // LP buf → Vault (flush автоматически каждые 10 блоков через tick)
        if (toLp > 0) {
            WPOL.safeTransfer(vaultAddr, toLp);
            vault.addToLpBuf(toLp);
        }

        // reserveR → Vault
        if (toReserve > 0) {
            WPOL.safeTransfer(vaultAddr, toReserve);
            vault.addToReserveR(toReserve);
        }

        // Keeper fund → Core
        if (toKeeper > 0) {
            WPOL.safeTransfer(coreAddr, toKeeper);
            core.initKeeperFund(toKeeper);
        }

        emit POLInvested(msg.sender, amount, toLp, toReserve, toKeeper, totalInvested);
    }

    // ╔══════════════════════════════════════════════════════════════════╗
    // ║   РУЧНЫЕ ОПЕРАЦИИ С ДИВИДЕНДАМИ                                 ║
    // ╚══════════════════════════════════════════════════════════════════╝

    /// @notice Вывести все накопленные дивиденды прямо сейчас
    function withdrawNow() external nonReentrant onlyRole(FOUNDER_ROLE) {
        uint256 pending = divPool.founderPending();
        if (pending == 0) revert FC_NothingToClaim();
        _doWithdraw(pending);
    }

    /// @notice Реинвестировать все накопленные дивиденды прямо сейчас в LP
    function reinvestNow() external nonReentrant onlyRole(FOUNDER_ROLE) {
        uint256 pending = divPool.founderPending();
        if (pending == 0) revert FC_NothingToClaim();
        _doReinvest(pending);
    }

    // ── Авто-обработка при каждом tick (вызывает TroikaCore) ──────────
    function processFounderDividends() external nonReentrant onlyRole(KEEPER_ROLE) {
        uint256 pending = divPool.founderPending();
        if (pending == 0) return;
        if (reinvestEnabled) {
            _doReinvest(pending);
        } else if (autoWithdrawEnabled) {
            _doWithdraw(pending);
        }
    }

    function _doReinvest(uint256 amount) private {
        divPool.reinvestFounder(vaultAddr);
        try vault.addToLpBuf(amount) {} catch {}
        totalReinvested += amount;
        emit FounderReinvestedNow(amount, totalReinvested);
    }

    function _doWithdraw(uint256 amount) private {
        divPool.withdrawFounderTo(founderWallet);
        totalWithdrawn += amount;
        emit FounderWithdrawnNow(founderWallet, amount, totalWithdrawn);
    }

    // ╔══════════════════════════════════════════════════════════════════╗
    // ║   НАСТРОЙКИ (только FOUNDER_ROLE)                               ║
    // ╚══════════════════════════════════════════════════════════════════╝

    /// @notice Изменить кошелёк для вывода дивидендов
    function setFounderWallet(address newWallet) external onlyRole(FOUNDER_ROLE) {
        if (newWallet == address(0)) revert FC_ZeroAddress();
        address old   = founderWallet;
        founderWallet = newWallet;
        emit FounderWalletChanged(old, newWallet);
    }

    /// @notice % дивидендов → keeper fund (0 = выкл, max 10%)
    function setKeeperTopup(uint256 bps) external onlyRole(FOUNDER_ROLE) {
        if (bps > MAX_KEEPER_TOPUP_BPS)
            revert FC_KeeperTopupTooHigh(bps, MAX_KEEPER_TOPUP_BPS);
        keeperTopupBps = bps;
        emit KeeperTopupSet(bps);
    }

    function setAutoWithdraw(bool enabled) external onlyRole(FOUNDER_ROLE) {
        if (reinvestEnabled) revert("FC: disable reinvest first");
        autoWithdrawEnabled = enabled;
        emit AutoWithdrawSet(enabled);
    }

    // ╔══════════════════════════════════════════════════════════════════╗
    // ║   EMERGENCY RESCUE — Таймлок 3 дня (только DEPLOYER_ROLE)       ║
    // ╚══════════════════════════════════════════════════════════════════╝

    function queueRescue(address to, uint256 amount) external onlyRole(DEPLOYER_ROLE) {
        if (to == address(0))   revert FC_ZeroAddress();
        if (amount == 0)        revert FC_ZeroAmount();
        if (rescueQueued)       revert FC_RescueAlreadyQueued();
        if (WPOL.balanceOf(address(this)) < amount) revert FC_ZeroAmount();
        rescueTo       = to;
        rescueAmount   = amount;
        rescueQueuedAt = block.timestamp;
        rescueQueued   = true;
        emit RescueQueued(to, amount, block.timestamp + RESCUE_TIMELOCK);
    }

    function executeRescue() external nonReentrant onlyRole(DEPLOYER_ROLE) {
        if (!rescueQueued) revert FC_RescueNotQueued();
        if (block.timestamp < rescueQueuedAt + RESCUE_TIMELOCK)
            revert FC_RescueTimelockActive(rescueQueuedAt + RESCUE_TIMELOCK, block.timestamp);
        if (block.timestamp > rescueQueuedAt + RESCUE_TIMELOCK + RESCUE_WINDOW)
            revert FC_RescueExpired();
        address to     = rescueTo;
        uint256 amount = rescueAmount;
        rescueQueued   = false;
        rescueTo       = address(0);
        rescueAmount   = 0;
        WPOL.safeTransfer(to, amount);
        emit RescueExecuted(to, amount);
    }

    function cancelRescue() external onlyRole(DEPLOYER_ROLE) {
        rescueQueued   = false;
        rescueTo       = address(0);
        rescueAmount   = 0;
        rescueQueuedAt = 0;
    }

    // ╔══════════════════════════════════════════════════════════════════╗
    // ║   VIEW — Снапшот состояния системы одним вызовом                ║
    // ╚══════════════════════════════════════════════════════════════════╝

    struct SystemSnapshot {
        // ── Система ────────────────────────────────────────────────────
        bool    systemPaused;
        bool    startQueued_;
        uint256 startQueuedAt_;
        uint256 stopCount_;
        uint256 startCount_;
        // ── LP / Reserves ───────────────────────────────────────────────
        uint256 totalLP;
        uint256 totalMCap;
        uint256 reserveR;
        uint256 traderRes;
        uint256 mcgFund;
        uint256 freeWpol;
        uint256 lpBuf;
        // ── Keeper ──────────────────────────────────────────────────────
        uint256 keeperFund;
        uint256 totalTicks;
        // ── Дивиденды основателя ────────────────────────────────────────
        bool    isReinvest;
        bool    isAutoWithdraw;
        address founderWallet_;
        uint256 founderPending;
        uint256 founderPaidToWallet;
        uint256 founderReinvestedTotal;
        uint256 founderEmissionAccum;
        uint256 thisReinvested;
        uint256 thisWithdrawn;
        // ── Инвестиции основателя ───────────────────────────────────────
        uint256 totalInvested_;
        uint256 investCount_;
        // ── Holders ─────────────────────────────────────────────────────
        uint256 holdersPool;
        uint256 totalPaidHolders;
        // ── Петля усиления ──────────────────────────────────────────────
        uint256 loopATotal;
        uint256 loopBTotal;
        uint256 ampFactor;
    }

    function systemSnapshot() external view returns (SystemSnapshot memory s) {
        s.systemPaused    = core.paused();
        s.startQueued_    = startQueued;
        s.startQueuedAt_  = startQueuedAt;
        s.stopCount_      = stopCount;
        s.startCount_     = startCount;

        s.totalLP         = vault.totalLP();
        s.totalMCap       = vault.totalMCap();
        s.reserveR        = vault.reserveR();
        s.traderRes       = vault.traderReserve();
        s.mcgFund         = vault.mcgFund();
        s.freeWpol        = vault.freeWpol();
        s.lpBuf           = vault.lpBuf();

        s.keeperFund      = core.keeperFund();
        s.totalTicks      = core.totalTicks();

        s.isReinvest          = reinvestEnabled;
        s.isAutoWithdraw      = autoWithdrawEnabled;
        s.founderWallet_      = founderWallet;
        s.founderPending      = divPool.founderPending();
        s.founderPaidToWallet = divPool.founderPaidToWallet();
        s.founderReinvestedTotal = divPool.founderReinvestedTotal();
        s.founderEmissionAccum= divPool.founderEmissionAccum();
        s.thisReinvested      = totalReinvested;
        s.thisWithdrawn       = totalWithdrawn;

        s.totalInvested_  = totalInvested;
        s.investCount_    = investCount;

        s.holdersPool     = divPool.holdersPool();
        s.totalPaidHolders= divPool.totalPaidHolders();

        (,, uint256 aTot, uint256 bTot,,,,) = loop_.getStats();
        s.loopATotal      = aTot;
        s.loopBTotal      = bTot;
        s.ampFactor       = loop_.amplificationFactor();
    }

    /// @notice Текущий режим дивидендов основателя
    function founderMode() external view returns (string memory mode, uint256 pending) {
        mode    = reinvestEnabled ? "REINVEST"
                : (autoWithdrawEnabled ? "AUTO_WITHDRAW" : "MANUAL_WITHDRAW");
        pending = divPool.founderPending();
    }

    /// @notice Блоков до возможности executeStart()
    function blocksUntilStart() external view returns (uint256) {
        if (!startQueued) return type(uint256).max;
        uint256 unlock = startQueuedAt + START_TIMELOCK;
        if (block.timestamp >= unlock) return 0;
        return (unlock - block.timestamp) / 2; // ~2 сек/блок Polygon
    }

    /// @notice Максимум который можно вложить за одну транзакцию
    function maxSingleInvest() external pure returns (uint256) {
        return MAX_SINGLE_INVEST;
    }
}
