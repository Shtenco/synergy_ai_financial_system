// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

// ═══════════════════════════════════════════════════════════════════════════
//  SINERGY DEFLATION SYSTEM — 14_CircularHub_v2.sol
//  Главный оркестратор: ALTN ⟷ SYNR/SYNA/SYNC
//
//  tick() каждые ~8 сек:
//   [1] ALTN.maintenance()           — LP burn, buyback, elastic supply
//   [2] CrossPrice update            — α×P_ALTN + β×P_SYNR
//   [3] alpha adapt                  — тот кто быстрее растёт получает больший вес
//   [4] EmissionEngine.setExternalPriceSignal(crossPrice)
//   [5] TroikaCore.tick()            — EmissionEngine + CBArb + SRL + Div
//   [6] CollateralEmission.processCircular() — flush протокольного резерва
//   [7] _flushPending()              — применить накопленные потоки
//
//  Коллбеки (прямо в TX):
//   onALTNBurn(amount, burnType)     — ALTN уведомляет Hub при каждом burn
//   onFeeProcessed(amount, type)     — TroikaCore.processFee() → Hub
//   onPriceUpdate()                  — EmissionEngine → Hub после emit
// ═══════════════════════════════════════════════════════════════════════════

import {AccessControl}   from "@openzeppelin/contracts/access/AccessControl.sol";
import {Pausable}         from "@openzeppelin/contracts/utils/Pausable.sol";
import {ReentrancyGuard}  from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {IERC20}           from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "./01_PolygonConfig.sol";
import "./00_CircularInterfaces.sol";


interface IMPRouterHub {
    function routeToAllPools(uint256 amount) external;
}
error HUB_ZeroAddress();

error HUB_Unauthorized();
error HUB_TooEarly();

contract CircularHubV2 is AccessControl, Pausable, ReentrancyGuard {
    using SafeERC20 for IERC20;

    bytes32 public constant KEEPER_ROLE = keccak256("KEEPER_ROLE");
    bytes32 public constant ALTN_ROLE   = keccak256("ALTN_ROLE");   // AltynToken контракт
    bytes32 public constant CORE_ROLE   = keccak256("CORE_ROLE");   // TroikaCore
    bytes32 public constant EMIT_ROLE   = keccak256("EMIT_ROLE");   // EmissionEngine
    bytes32 public constant PAUSER_ROLE = keccak256("PAUSER_ROLE");

    // ── Контракты ─────────────────────────────────────────────────────
    ICircularALTN    public immutable altn;
    ICircularCore    public immutable core;
    ICircularVault   public immutable vault;
    ICircularLoop    public immutable loop_;
    ICircularEmit    public immutable emitEngine;
    ICircularCollEmit public immutable collEmit;
    ICircularDivPool  public immutable divPool;

    address public immutable altnPair;   // ALTN/WPOL QuickSwap pair
    address public immutable synrPair;   // SYNR/WPOL QuickSwap pair
    address public immutable synrAddr;   // SYNR token

    // ── Параметры распределения onALTNBurn (per 10000) ────────────────
    uint256 public burnToReserveR = 800;    // 8%  → SYNR reserveR
    uint256 public burnToRingA    = 1_500;  // 15% → Ring A
    uint256 public burnToFounder  = 500;    // 5%  → founder
    uint256 public burnToLpBuf    = 750;    // 7.5%→ ALTN pool lpBuf (взаимный inject)
    // оставшееся 68% — обычный burn ALTN дефляция

    // ── CrossPrice ────────────────────────────────────────────────────
    uint256 public alphaALTN = 450;  // /1000
    uint256 public alphaSYNR = 550;

    IMPRouterHub public mpRouter;
    address      public mpRouterAddr;

    // ── State ──────────────────────────────────────────────────────────
    uint256 public crossPrice;
    uint256 public lastCrossPrice;
    uint256 public lastTickBlock;
    uint256 public lastAlphaBlock;
    uint256 public tickInterval = 4;        // блоков (~8 сек)
    uint256 public collInterval = 33;       // тиков между processCircular

    uint256 public pendingReserveR;
    uint256 public pendingRingA;
    uint256 public pendingRingB;
    uint256 public pendingLpBuf;
    uint256 public pendingFounder;

    uint256 public totalTicks;
    uint256 public totalBurnCallbacks;
    uint256 public totalBurnNotified;   // сумма в токенах
    uint256 public totalFeeNotified;
    uint256 public totalEmitCallbacks;

    event Tick(uint256 n, uint256 crossPrice_, uint256 alphaALTN_);
    event BurnCallback(uint256 amount, uint8 burnType, uint256 polEquiv);
    event FeeCallback(uint256 amount, uint8 tokenType);
    event EmitCallback(uint256 newCrossPrice);
    event CrossPriceUpdated(uint256 old_, uint256 new_);
    event PendingFlushed(uint256 toR, uint256 toA, uint256 toLp, uint256 toF);

    constructor(
        address altn_,      address altnPair_,
        address core_,      address vault_,
        address loop__,     address emitEngine_,
        address collEmit_,  address divPool_,
        address synrPair_,  address synr_,
        address admin_
    ) {
        if (altn_ == address(0) || core_ == address(0)) revert HUB_ZeroAddress();

        altn       = ICircularALTN(altn_);
        core       = ICircularCore(core_);
        vault      = ICircularVault(vault_);
        loop_      = ICircularLoop(loop__);
        emitEngine = ICircularEmit(emitEngine_);
        collEmit   = ICircularCollEmit(collEmit_);
        divPool    = ICircularDivPool(divPool_);
        altnPair   = altnPair_;
        synrPair   = synrPair_;
        synrAddr   = synr_;

        _grantRole(DEFAULT_ADMIN_ROLE, admin_);
        _grantRole(KEEPER_ROLE,        admin_);
        _grantRole(ALTN_ROLE,          altn_);
        _grantRole(CORE_ROLE,          core_);
        _grantRole(EMIT_ROLE,          emitEngine_);
        _grantRole(PAUSER_ROLE,        admin_);

        lastTickBlock  = block.number;
        lastAlphaBlock = block.number;
    }

    // ═══════════════════════════════════════════════════════════════════
    //  tick() — главный оркестратор
    // ═══════════════════════════════════════════════════════════════════
    function tick() external onlyRole(KEEPER_ROLE) whenNotPaused nonReentrant {
        if (block.number < lastTickBlock + tickInterval) revert HUB_TooEarly();
        lastTickBlock = block.number;
        totalTicks++;

        // [1] ALTN maintenance (split-path: LP burn, buyback, elastic supply)
        try altn.maintenance()   {} catch {}
        try altn.triggerBuyback() {} catch {}

        // [2+3] CrossPrice update + weight adapt
        _updateCrossPrice();
        if (block.number >= lastAlphaBlock + 20) {
            _adaptWeights();
            lastAlphaBlock = block.number;
        }

        // [4] Ценовой сигнал → EmissionEngine
        if (crossPrice > 0) {
            try emitEngine.setExternalPriceSignal(crossPrice) {} catch {}
        }

        // [5] TroikaCore.tick() — весь SINERGY цикл
        if (!core.paused()) {
            try core.tick() {} catch {}
        }

        // [6] CollateralEmission.processCircular
        if (totalTicks % collInterval == 0) {
            try collEmit.processCircular() {} catch {}
        }

        // [7] Flush pending каждые 25 тиков
        if (totalTicks % 25 == 0) {
            _flushPending();
            try vault.syncFromChain() {} catch {}
        }

        emit Tick(totalTicks, crossPrice, alphaALTN);
    }

    // ═══════════════════════════════════════════════════════════════════
    //  onALTNBurn — коллбек от AltynToken (в той же транзакции!)
    //  burnType: 0=instant, 1=cascade, 2=velocity, 3=lpBurn, 4=buyback
    // ═══════════════════════════════════════════════════════════════════
    function onALTNBurn(uint256 amount, uint8 burnType)
        external whenNotPaused
    {
        if (!hasRole(ALTN_ROLE, msg.sender)) revert HUB_Unauthorized();
        if (amount == 0) return;

        totalBurnCallbacks++;
        totalBurnNotified += amount;

        // Пересчитать CrossPrice: цена ALTN выросла после burn
        _updateCrossPrice();

        // Конвертируем в POL-эквивалент
        uint256 polEquiv = amount * crossPrice / 1e18;
        if (polEquiv == 0) return;

        // Маршрутизация
        pendingReserveR += polEquiv * burnToReserveR / 10_000;
        pendingRingA    += polEquiv * burnToRingA    / 10_000;
        pendingFounder  += polEquiv * burnToFounder  / 10_000;
        pendingLpBuf    += polEquiv * burnToLpBuf    / 10_000;

        // Cascade (burnType=1) → усиление ×1.5
        if (burnType == 1) {
            pendingRingA += polEquiv * burnToRingA / 10_000 / 2;
        }

        // Немедленно сигнализируем EmissionEngine о новой цене
        if (crossPrice > 0) {
            try emitEngine.setExternalPriceSignal(crossPrice) {} catch {}
        }

        emit BurnCallback(amount, burnType, polEquiv);
    }

    // ═══════════════════════════════════════════════════════════════════
    //  onFeeProcessed — коллбек от TroikaCore.processFee()
    // ═══════════════════════════════════════════════════════════════════
    function onFeeProcessed(uint256 amount, uint8 tokenType)
        external whenNotPaused
    {
        if (!hasRole(CORE_ROLE, msg.sender)) revert HUB_Unauthorized();
        if (amount == 0) return;
        totalFeeNotified += amount;
        pendingRingA    += amount * 15  / 10_000;  // 0.15%
        pendingRingB    += amount * 50  / 10_000;  // 0.50%
        pendingReserveR += amount * 800 / 10_000;  // 8%
        emit FeeCallback(amount, tokenType);
    }

    // ═══════════════════════════════════════════════════════════════════
    //  onPriceUpdate — коллбек от EmissionEngine после executeEmission
    // ═══════════════════════════════════════════════════════════════════
    function onPriceUpdate() external whenNotPaused {
        if (!hasRole(EMIT_ROLE, msg.sender)) revert HUB_Unauthorized();
        totalEmitCallbacks++;
        _updateCrossPrice();
        emit EmitCallback(crossPrice);
    }

    // ── CrossPrice ────────────────────────────────────────────────────
    function _updateCrossPrice() private {
        uint256 pA  = CircularMath.pairPrice(altnPair, address(altn));
        uint256 pNR = CircularMath.pairPrice(synrPair, synrAddr);
        if (pA == 0 && pNR == 0) return;
        uint256 newP = CircularMath.crossPrice(pA, pNR, alphaALTN, alphaSYNR);
        if (newP == 0) return;
        lastCrossPrice = crossPrice;
        crossPrice     = newP;
        emit CrossPriceUpdated(lastCrossPrice, crossPrice);
    }

    function _adaptWeights() private {
        uint256 pA  = CircularMath.pairPrice(altnPair, address(altn));
        uint256 pNR = CircularMath.pairPrice(synrPair, synrAddr);
        if (pA == 0 || pNR == 0) return;
        if (pA > pNR) {
            alphaALTN = CircularMath.adaptWeight(alphaALTN, true);
        } else {
            alphaALTN = CircularMath.adaptWeight(alphaALTN, false);
        }
        alphaSYNR = 1000 - alphaALTN;
    }

    // ── Flush pending ──────────────────────────────────────────────────
    function _flushPending() private {
        uint256 r = pendingReserveR; pendingReserveR = 0;
        uint256 a = pendingRingA;    pendingRingA    = 0;
        uint256 b = pendingRingB;    pendingRingB    = 0;
        uint256 l = pendingLpBuf;    pendingLpBuf    = 0;
        uint256 f = pendingFounder;  pendingFounder  = 0;

        if (r > 1e12) try vault.addToReserveR(r)        {} catch {}
        if (a > 1e12) try loop_.contribute(0, a)         {} catch {}
        if (b > 1e12) try loop_.contribute(1, b)         {} catch {}
        if (l > 1e12) try vault.addToLpBuf(l)            {} catch {}
        if (f > 1e12) try divPool.notifyFounder(f)        {} catch {}

        if (l > 1e12 && address(mpRouter) != address(0)) {
            IERC20(PolygonConfig.WPOL).safeTransfer(mpRouterAddr, l);
            try mpRouter.routeToAllPools(l) {} catch {}
        }
        emit PendingFlushed(r, a, l, f);
    }


    function setMutualPoolRouter(address mpr_) external onlyRole(DEFAULT_ADMIN_ROLE) {
        mpRouter    = IMPRouterHub(mpr_);
        mpRouterAddr= mpr_;
    }

    function forceFlush() external onlyRole(KEEPER_ROLE) { _flushPending(); }

    // ── View ──────────────────────────────────────────────────────────
    function getCrossPrice() external view returns (uint256) { return crossPrice; }
    function getALTNPrice()  external view returns (uint256) {
        return CircularMath.pairPrice(altnPair, address(altn));
    }
    function getSYNRPrice()  external view returns (uint256) {
        return CircularMath.pairPrice(synrPair, synrAddr);
    }

    function callbackStats() external view returns (
        uint256 burnCBs_, uint256 burnAmt_, uint256 feeCBs_, uint256 emitCBs_
    ) {
        return (totalBurnCallbacks, totalBurnNotified, totalFeeNotified, totalEmitCallbacks);
    }

    // ── Admin ──────────────────────────────────────────────────────────
    function grantALTNRole(address a) external onlyRole(DEFAULT_ADMIN_ROLE) { _grantRole(ALTN_ROLE, a); }
    function grantCoreRole(address a) external onlyRole(DEFAULT_ADMIN_ROLE) { _grantRole(CORE_ROLE, a); }
    function grantEmitRole(address a) external onlyRole(DEFAULT_ADMIN_ROLE) { _grantRole(EMIT_ROLE, a); }

    function setBurnRouting(uint256 r, uint256 a, uint256 f, uint256 l)
        external onlyRole(DEFAULT_ADMIN_ROLE)
    { require(r+a+f+l<=4000,"max40%"); burnToReserveR=r;burnToRingA=a;burnToFounder=f;burnToLpBuf=l; }

    function setTickInterval(uint256 b) external onlyRole(DEFAULT_ADMIN_ROLE) { require(b>=2&&b<=100); tickInterval=b; }

    function pause()   external onlyRole(PAUSER_ROLE) { _pause(); }
    function unpause() external onlyRole(PAUSER_ROLE) { _unpause(); }

    receive() external payable {}
}
