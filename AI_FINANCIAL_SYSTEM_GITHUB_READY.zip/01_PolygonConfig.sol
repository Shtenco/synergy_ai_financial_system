// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

// ═══════════════════════════════════════════════════════════════════════════
//  SINERGY SYSTEM — 01_PolygonConfig.sol
//  Верифицированные адреса Polygon Mainnet (Chain ID: 137) + QuickSwap V2
//
//  QuickSwap V2 = форк Uniswap V2 (идентичные интерфейсы, 0 изменений кода)
//  Источники: polygonscan.com, github.com/QuickSwap/quickswap-core
// ═══════════════════════════════════════════════════════════════════════════

/// @title  PolygonConfig — константы сети и QuickSwap V2
/// @notice Все адреса верифицированы на polygonscan.com
library PolygonConfig {

    // ── Polygon Mainnet токены ─────────────────────────────────────────
    /// @dev Wrapped POL (бывш. WMATIC). ERC-20 обёртка нативного POL.
    address internal constant WPOL =
        0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270;

    // ── QuickSwap V2 ──────────────────────────────────────────────────
    /// @dev Router02 — верифицирован на polygonscan.com/address/0xa5E08...
    address internal constant QS_ROUTER  =
        0xa5E0829CaCEd8fFDD4De3c43696c57F7D7A678ff;

    /// @dev Factory — верифицирован на polygonscan.com/address/0x57573...
    address internal constant QS_FACTORY =
        0x5757371414417b8C6CAad45bAeF941aBc7d3Ab32;

    // ── Блочные интервалы (Polygon ≈ 2 сек/блок, 43 200 блоков/день) ─
    uint256 internal constant TWAP_INTERVAL    =    5;  //  ~10 с
    uint256 internal constant ARB_INTERVAL     =    5;  //  ~10 с
    uint256 internal constant LPB_INTERVAL     =   10;  //  ~20 с
    uint256 internal constant ADAPT_INTERVAL   =   20;  //  ~40 с
    uint256 internal constant LOOP_INTERVAL    =   50;  // ~100 с
    uint256 internal constant EMIT_INTERVAL    = 50; //  ~100 сек (быстрая эмиссия)
    uint256 internal constant DIV_INTERVAL     = 1_000; //  ~33 мин

    // ── QuickSwap параметры ────────────────────────────────────────────
    uint256 internal constant SLIPPAGE_BPS  =  50;  // 0.5%
    uint256 internal constant SWAP_DEADLINE = 300;  // 5 мин

    // ── Keeper reward ──────────────────────────────────────────────────
    uint256 internal constant KEEPER_REWARD = 5e14; // 0.0005 WPOL за тик
}

// ─────────────────────────────────────────────────────────────────────────
//  QuickSwap V2 INTERFACES  (идентичны Uniswap V2)
// ─────────────────────────────────────────────────────────────────────────

interface IQSFactory {
    function getPair(address tokenA, address tokenB)
        external view returns (address pair);
    function createPair(address tokenA, address tokenB)
        external returns (address pair);
}

interface IQSPair {
    function token0() external view returns (address);
    function token1() external view returns (address);
    function getReserves()
        external view
        returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
    function totalSupply()            external view returns (uint256);
    function balanceOf(address owner) external view returns (uint256);
    function approve(address spender, uint256 value) external returns (bool);
    function transfer(address to, uint256 value)     external returns (bool);
}

interface IQSRouter {
    /// @dev На Polygon WETH() возвращает адрес WPOL
    function WETH() external pure returns (address);

    function addLiquidity(
        address tokenA,      address tokenB,
        uint256 amountADesired, uint256 amountBDesired,
        uint256 amountAMin,  uint256 amountBMin,
        address to,          uint256 deadline
    ) external returns (uint256 amountA, uint256 amountB, uint256 liquidity);

    function removeLiquidity(
        address tokenA,  address tokenB,
        uint256 liquidity,
        uint256 amountAMin, uint256 amountBMin,
        address to, uint256 deadline
    ) external returns (uint256 amountA, uint256 amountB);

    function swapExactTokensForTokens(
        uint256 amountIn, uint256 amountOutMin,
        address[] calldata path,
        address to, uint256 deadline
    ) external returns (uint256[] memory amounts);

    function getAmountsOut(uint256 amountIn, address[] calldata path)
        external view returns (uint256[] memory amounts);
}
