#!/usr/bin/env python3
import sys, io, os, json
from dotenv import load_dotenv
from web3 import Web3
from web3.middleware import ExtraDataToPOAMiddleware

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

load_dotenv()
w3 = Web3(Web3.HTTPProvider("https://polygon-bor-rpc.publicnode.com"))
w3.middleware_onion.inject(ExtraDataToPOAMiddleware, layer=0)

OWNER = "0x6946999DBCE63b140B1bB9D475F7c357130909E5"

def C(a): return Web3.to_checksum_address(a)

with open("deployed_TROIKA_v3.json") as f:
    d = json.load(f)

div_abi = [
    {"name": "founderPending", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "withdrawFounder", "inputs": [], "outputs": [], "stateMutability": "nonpayable", "type": "function"},
]

divpool = w3.eth.contract(address=C(d["divPool"]), abi=div_abi)
founder_pending = divpool.functions.founderPending().call() / 1e18

print(f"DividendPool: {d['divPool']}")
print(f"Founder pending WPOL: {founder_pending:.10f}")

# Check Vault WPOL balance
WPOL = "0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270"
wpol_abi = [{"name": "balanceOf", "inputs": [{"type": "address"}], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"}]
wpol = w3.eth.contract(address=C(WPOL), abi=wpol_abi)

vault_wpol = wpol.functions.balanceOf(C(d["vault"])).call() / 1e18
div_wpol = wpol.functions.balanceOf(C(d["divPool"])).call() / 1e18

print(f"\nVault WPOL: {vault_wpol:.10f}")
print(f"DivPool WPOL: {div_wpol:.10f}")

# Check Vault's LP values
vault_abi = [
    {"name": "lpR", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "lpT", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "lpP", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "totalLP", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
]
vault = w3.eth.contract(address=C(d["vault"]), abi=vault_abi)
lpR = vault.functions.lpR().call() / 1e18
lpT = vault.functions.lpT().call() / 1e18
lpP = vault.functions.lpP().call() / 1e18
total = vault.functions.totalLP().call() / 1e18

print(f"\nVault LP values:")
print(f"  lpR: {lpR:.10f}")
print(f"  lpT: {lpT:.10f}")
print(f"  lpP: {lpP:.10f}")
print(f"  total: {total:.10f}")

# Check EmissionEngine stats
emit_abi = [
    {"name": "totalEmittedR", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "totalEmittedT", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "totalEmittedP", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "lastEmitBlock", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "isEmissionDue", "inputs": [], "outputs": [{"type": "bool"}], "stateMutability": "view", "type": "function"},
]
emit = w3.eth.contract(address=C(d["emitEngine_v2"]), abi=emit_abi)

emR = emit.functions.totalEmittedR().call() / 1e18
emT = emit.functions.totalEmittedT().call() / 1e18
emP = emit.functions.totalEmittedP().call() / 1e18
last = emit.functions.lastEmitBlock().call()
due = emit.functions.isEmissionDue().call()

print(f"\nEmissionEngine v2 stats:")
print(f"  totalEmittedR: {emR:.10f}")
print(f"  totalEmittedT: {emT:.10f}")
print(f"  totalEmittedP: {emP:.10f}")
print(f"  lastEmitBlock: {last}")
print(f"  current block: {w3.eth.block_number}")
print(f"  isEmissionDue: {due}")
