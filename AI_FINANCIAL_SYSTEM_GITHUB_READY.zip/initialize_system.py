#!/usr/bin/env python3
"""
ИНИЦИАЛИЗАЦИЯ СИСТЕМЫ TROIKA
Связать все контракты и выдать права
"""
import sys, io, os, json, time
from dotenv import load_dotenv
from web3 import Web3
from web3.middleware import ExtraDataToPOAMiddleware

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

load_dotenv()

w3 = Web3(Web3.HTTPProvider("https://polygon-bor-rpc.publicnode.com", request_kwargs={"timeout": 180}))
w3.middleware_onion.inject(ExtraDataToPOAMiddleware, layer=0)

PK = os.getenv("OWNER_PRIVATE_KEY")
OWNER = "0x6946999DBCE63b140B1bB9D475F7c357130909E5"
WPOL = "0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270"

def C(a): return Web3.to_checksum_address(a)

with open("deployed_instant.json") as f:
    data = json.load(f)

VAULT = data["troika_system"]["vault"]
DIVPOOL = data["troika_system"]["divPool"]
FEEROUTER = data["troika_system"]["feeRouter"]
EMITENGINE = data["troika_system"]["emitEngine"]
CORE = data["troika_system"]["core"]

SYNA = data["tokens"]["SYNA"]
SYNC = data["tokens"]["SYNC"]
SYNR = data["tokens"]["SYNR"]
ALTN = data["tokens"]["ALTN"]

PAIR_SYNA = data["pools"]["SYNA_WPOL"]
PAIR_SYNC = data["pools"]["SYNC_WPOL"]
PAIR_SYNR = data["pools"]["SYNR_WPOL"]
PAIR_ALTN = data["pools"]["ALTN_WPOL"]

print("=" * 70)
print("ИНИЦИАЛИЗАЦИЯ СИСТЕМЫ TROIKA")
print("=" * 70)
print(f"Vault: {VAULT}")
print(f"DivPool: {DIVPOOL}")
print(f"FeeRouter: {FEEROUTER}")
print(f"EmitEngine: {EMITENGINE}")
print(f"Core: {CORE}")
print(f"Баланс: {w3.eth.get_balance(C(OWNER)) / 1e18:.4f} POL")
print("=" * 70)

nonce = w3.eth.get_transaction_count(C(OWNER), "pending")

def send_tx(contract, func, label):
    global nonce
    print(f"\n[TX] {label}...", flush=True)

    base = w3.eth.get_block("latest").get("baseFeePerGas", int(100e9))
    prio = int(50e9)
    mf = base * 2 + prio

    try:
        tx = func.build_transaction({
            "from": C(OWNER),
            "nonce": nonce,
            "chainId": 137,
            "type": 2,
            "maxPriorityFeePerGas": prio,
            "maxFeePerGas": mf,
            "gas": 500000
        })

        signed = w3.eth.account.sign_transaction(tx, PK)
        tx_hash = w3.eth.send_raw_transaction(signed.raw_transaction)
        print(f"  TX: {tx_hash.hex()[:20]}...", flush=True)

        receipt = w3.eth.wait_for_transaction_receipt(tx_hash, timeout=300)
        gas_cost = receipt.gasUsed * mf / 1e18

        if receipt.status == 1:
            print(f"  [OK] gas: {gas_cost:.4f} POL", flush=True)
            nonce += 1
            return True
        else:
            print(f"  [FAIL] reverted", flush=True)
            nonce += 1
            return False
    except Exception as e:
        print(f"  [ERROR] {e}")
        return False

# ═══════════════════════════════════════════════════════════════════════════
# ABI функций
# ═══════════════════════════════════════════════════════════════════════════

VAULT_ABI = [
    {"name": "initialize", "inputs": [{"name": "pairR_", "type": "address"}, {"name": "pairT_", "type": "address"}, {"name": "pairP_", "type": "address"}], "outputs": [], "stateMutability": "nonpayable", "type": "function"},
    {"name": "setOperator", "inputs": [{"name": "op", "type": "address"}, {"name": "status", "type": "bool"}], "outputs": [], "stateMutability": "nonpayable", "type": "function"},
    {"name": "initialized", "inputs": [], "outputs": [{"type": "bool"}], "stateMutability": "view", "type": "function"},
]

DIVPOOL_ABI = [
    {"name": "setNotifier", "inputs": [{"name": "n", "type": "address"}, {"name": "status", "type": "bool"}], "outputs": [], "stateMutability": "nonpayable", "type": "function"},
]

FEEROUTER_ABI = [
    {"name": "setCaller", "inputs": [{"name": "c", "type": "address"}, {"name": "status", "type": "bool"}], "outputs": [], "stateMutability": "nonpayable", "type": "function"},
]

EMIT_ABI = [
    {"name": "setCaller", "inputs": [{"name": "c", "type": "address"}, {"name": "status", "type": "bool"}], "outputs": [], "stateMutability": "nonpayable", "type": "function"},
    {"name": "resetLastEmitBlock", "inputs": [], "outputs": [], "stateMutability": "nonpayable", "type": "function"},
    {"name": "isEmissionDue", "inputs": [], "outputs": [{"type": "bool"}], "stateMutability": "view", "type": "function"},
]

CORE_ABI = [
    {"name": "initialize", "inputs": [{"name": "vault_", "type": "address"}, {"name": "emit_", "type": "address"}, {"name": "div_", "type": "address"}, {"name": "feeR_", "type": "address"}], "outputs": [], "stateMutability": "nonpayable", "type": "function"},
    {"name": "initialized", "inputs": [], "outputs": [{"type": "bool"}], "stateMutability": "view", "type": "function"},
]

# ═══════════════════════════════════════════════════════════════════════════
# 1. Initialize TroikaVault
# ═══════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 50)
print("[1] Инициализация TroikaVault")
print("=" * 50)

vault_contract = w3.eth.contract(address=C(VAULT), abi=VAULT_ABI)

is_init = vault_contract.functions.initialized().call()
if is_init:
    print("  Vault уже инициализирован")
else:
    func = vault_contract.functions.initialize(C(PAIR_SYNA), C(PAIR_SYNC), C(PAIR_SYNR))
    send_tx(vault_contract, func, "Vault.initialize")
    time.sleep(3)

# Дать права Core, EmitEngine, FeeRouter
for op_addr, op_name in [(CORE, "Core"), (EMITENGINE, "EmitEngine"), (FEEROUTER, "FeeRouter")]:
    func = vault_contract.functions.setOperator(C(op_addr), True)
    send_tx(vault_contract, func, f"Vault.setOperator({op_name})")
    time.sleep(2)

# ═══════════════════════════════════════════════════════════════════════════
# 2. Set up DividendPool
# ═══════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 50)
print("[2] Настройка DividendPool")
print("=" * 50)

divpool_contract = w3.eth.contract(address=C(DIVPOOL), abi=DIVPOOL_ABI)

for notifier_addr, notifier_name in [(EMITENGINE, "EmitEngine"), (FEEROUTER, "FeeRouter"), (CORE, "Core")]:
    func = divpool_contract.functions.setNotifier(C(notifier_addr), True)
    send_tx(divpool_contract, func, f"DivPool.setNotifier({notifier_name})")
    time.sleep(2)

# ═══════════════════════════════════════════════════════════════════════════
# 3. Set up FeeRouter
# ═══════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 50)
print("[3] Настройка FeeRouter")
print("=" * 50)

feerouter_contract = w3.eth.contract(address=C(FEEROUTER), abi=FEEROUTER_ABI)

func = feerouter_contract.functions.setCaller(C(CORE), True)
send_tx(feerouter_contract, func, "FeeRouter.setCaller(Core)")
time.sleep(2)

# ═══════════════════════════════════════════════════════════════════════════
# 4. Set up EmissionEngine
# ═══════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 50)
print("[4] Настройка EmissionEngine")
print("=" * 50)

emit_contract = w3.eth.contract(address=C(EMITENGINE), abi=EMIT_ABI)

func = emit_contract.functions.setCaller(C(CORE), True)
send_tx(emit_contract, func, "EmitEngine.setCaller(Core)")
time.sleep(2)

# Сбросить lastEmitBlock для мгновенной эмиссии
func = emit_contract.functions.resetLastEmitBlock()
send_tx(emit_contract, func, "EmitEngine.resetLastEmitBlock")
time.sleep(2)

# ═══════════════════════════════════════════════════════════════════════════
# 5. Initialize TroikaCore
# ═══════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 50)
print("[5] Инициализация TroikaCore")
print("=" * 50)

core_contract = w3.eth.contract(address=C(CORE), abi=CORE_ABI)

is_core_init = core_contract.functions.initialized().call()
if is_core_init:
    print("  Core уже инициализирован")
else:
    func = core_contract.functions.initialize(C(VAULT), C(EMITENGINE), C(DIVPOOL), C(FEEROUTER))
    send_tx(core_contract, func, "Core.initialize")
    time.sleep(3)

# ═══════════════════════════════════════════════════════════════════════════
# 6. Проверка состояния
# ═══════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 70)
print("ПРОВЕРКА СОСТОЯНИЯ")
print("=" * 70)

is_vault_init = vault_contract.functions.initialized().call()
print(f"Vault initialized: {is_vault_init}")

is_core_init = core_contract.functions.initialized().call()
print(f"Core initialized: {is_core_init}")

is_due = emit_contract.functions.isEmissionDue().call()
print(f"Emission due: {is_due}")

print(f"\nБаланс: {w3.eth.get_balance(C(OWNER)) / 1e18:.4f} POL")

print("\n" + "=" * 70)
print("СИСТЕМА TROIKA ИНИЦИАЛИЗИРОВАНА!")
print("=" * 70)
