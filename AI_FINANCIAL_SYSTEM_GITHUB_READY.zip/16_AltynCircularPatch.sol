// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

// ═══════════════════════════════════════════════════════════════════════════
//  SINERGY DEFLATION SYSTEM — 16_AltynCircularPatch.sol
//  Патч для AltynToken: burn callbacks → CircularHub
//
//  Добавить в AltynToken:
//   1. storage: address public circularHub;
//   2. function setCircularHub(address) external onlyOwner
//   3. function _notifyCircularHub(uint256 amount, uint8 burnType) internal
//
//  Вызвать _notifyCircularHub() в:
//   _update()                    → после instant burn   (burnType=0)
//   _cascadeBurn()               → после cascade burn   (burnType=1)
//   _trackSellVelocity()         → после velocity burn  (burnType=2)
//   _executeLPBurnReinjection()  → после LP burn        (burnType=3)
//   buyback logic                → после buyback burn   (burnType=4)
//
//  Эффект: каждый burn в ALTN немедленно:
//   → обновляет CrossPrice в Hub
//   → маршрутизирует 8%→reserveR, 15%→ringA, 7.5%→lpBuf
//   → сигнализирует EmissionEngine: gP_new = gP×0.70 + crossPrice×0.30
// ═══════════════════════════════════════════════════════════════════════════

import "./00_CircularInterfaces.sol";

/// @notice Добавить эти переменные и функции в AltynToken
contract AltynCircularPatch {

    // ── Добавить в AltynToken storage ─────────────────────────────────
    address public circularHub;
    bool    public circularHubLocked;

    uint256 public totalBurnNotifiedToHub;
    uint256 public totalBurnCallbackCount;

    event CircularHubSet(address indexed hub);
    event CircularBurnNotified(uint256 amount, uint8 burnType, address hub);

    // ─────────────────────────────────────────────────────────────────
    /// @notice Установить CircularHub (только owner, только один раз)
    /// После установки заблокировать — нельзя изменить
    function setCircularHub(address hub_) external /* onlyOwner */ {
        require(!circularHubLocked, "Hub locked");
        require(hub_ != address(0), "Zero address");
        circularHub       = hub_;
        circularHubLocked = true;
        emit CircularHubSet(hub_);
    }

    // ─────────────────────────────────────────────────────────────────
    /// @notice Уведомить Hub о burn — вставить в каждое место где горит
    /// Non-reverting: сбой Hub не влияет на транзакцию ALTN
    ///
    /// burnType:
    ///   0 = instant burn (60% of buy/sell fee)
    ///   1 = cascade burn (price drop triggers)
    ///   2 = velocity burn (many sells in window)
    ///   3 = LP burn + reinjection
    ///   4 = buyback burn
    function _notifyCircularHub(uint256 amount, uint8 burnType) internal {
        address hub_ = circularHub;
        if (hub_ == address(0) || amount == 0) return;

        unchecked {
            totalBurnNotifiedToHub  += amount;
            totalBurnCallbackCount  += 1;
        }

        // try/catch: ни при каком исходе не revert основная TX
        try ICircularHub(hub_).onALTNBurn(amount, burnType) {
            emit CircularBurnNotified(amount, burnType, hub_);
        } catch {}
    }

    // ─────────────────────────────────────────────────────────────────
    /// @notice Инструкция по патчу AltynToken (куда вставить вызовы)
    ///
    /// В _update() найти:
    ///   if (burnAmt > 0) { _burn(from, burnAmt); emit InstantBurn(...); }
    /// Добавить строку ПОСЛЕ:
    ///   _notifyCircularHub(burnAmt, 0);
    ///
    /// В _cascadeBurn() в конце блока where burned > 0:
    ///   _notifyCircularHub(burned, 1);
    ///
    /// В _trackSellVelocity() после строки where extra > 0 и _burn():
    ///   _notifyCircularHub(extra, 2);
    ///
    /// В _executeLPBurnReinjection() после строки _burn(address(this), toburn):
    ///   _notifyCircularHub(toburn, 3);
    ///
    /// В buyback блоке после _burn:
    ///   _notifyCircularHub(burnedFromBuyback, 4);

    function circularPatchStats() external view returns (
        address hub_,
        bool locked_,
        uint256 totalNotified_,
        uint256 callbackCount_
    ) {
        return (circularHub, circularHubLocked, totalBurnNotifiedToHub, totalBurnCallbackCount);
    }
}
