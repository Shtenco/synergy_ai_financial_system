from __future__ import annotations

import math
import random
from dataclasses import asdict

from .models import Decision, Metrics, ModelPolicy, SystemState


def metrics(state: SystemState, policy: ModelPolicy) -> Metrics:
    net_revenue = (
        state.protocol_fee_revenue_30d
        + state.flash_profit_30d
        + state.yield_revenue_30d
        + state.bridge_fee_revenue_30d
        - state.operating_cost_30d
        - state.gas_cost_30d
    )
    backing_nav = max(
        state.liquid_reserves
        + state.owned_liquidity_nav
        + state.bridge_capital
        + state.insurance_fund
        - state.liabilities,
        0.0,
    )
    discounted_revenue_value = (
        max(net_revenue, 0.0)
        * max(policy.revenue_horizon_months, 0)
        * min(max(policy.revenue_haircut, 0.0), 1.0)
    )
    fundamental_mcap = backing_nav + discounted_revenue_value
    fundamental_price = fundamental_mcap / max(state.circulating_supply, 1e-12)
    market_mcap = max(state.market_price, 0.0) * max(state.circulating_supply, 0.0)
    reserve_ratio = state.liquid_reserves / max(state.liabilities, 1e-12)
    valuation_premium = market_mcap / max(fundamental_mcap, 1e-12)
    expected_sell_pressure = max(state.monthly_volume * 0.15, state.liabilities * 0.03, 1e-9)
    liquidity_coverage = state.liquidity_depth / expected_sell_pressure
    sustainable_growth = net_revenue / max(backing_nav, 1e-12)
    excess_reserves = max(state.liquid_reserves - policy.minimum_reserve_ratio * state.liabilities, 0.0)
    return Metrics(
        net_revenue_30d=net_revenue,
        backing_nav=backing_nav,
        discounted_revenue_value=discounted_revenue_value,
        fundamental_mcap=fundamental_mcap,
        fundamental_price=fundamental_price,
        market_mcap=market_mcap,
        reserve_ratio=reserve_ratio,
        valuation_premium=valuation_premium,
        liquidity_coverage=liquidity_coverage,
        sustainable_monthly_growth=sustainable_growth,
        excess_reserves=excess_reserves,
    )


def hard_policy_ok(state: SystemState, policy: ModelPolicy) -> tuple[bool, str]:
    m = metrics(state, policy)
    if m.reserve_ratio < 1.0:
        return False, "insolvent liquid reserve ratio"
    if m.valuation_premium > policy.maximum_valuation_premium:
        return False, "market valuation exceeds policy multiple"
    if state.peg_error_bps > policy.maximum_peg_error_bps:
        return False, "peg error exceeds policy"
    if state.bridge_imbalance_bps > policy.maximum_bridge_imbalance_bps:
        return False, "bridge imbalance exceeds policy"
    if state.volatility_bps > policy.maximum_volatility_bps:
        return False, "volatility exceeds policy"
    if m.liquidity_coverage < policy.minimum_liquidity_coverage:
        return False, "liquidity coverage below policy"
    return True, "policy checks passed"


def _bounded(value: float, lower: float, upper: float) -> float:
    return min(max(value, lower), upper)


def apply_month(
    state: SystemState,
    decision: Decision,
    policy: ModelPolicy,
    rng: random.Random,
) -> tuple[SystemState, dict[str, float]]:
    """Apply one stochastic month.

    The function does not book price impact as protocol value. Liquidity and
    bridge QE merely reclassify existing capital (minus execution costs).
    Fundamental value changes only through realized revenue, costs and losses.
    """

    decision.validate()
    before = metrics(state, policy)
    next_state = state.copy()

    demand_shock = math.exp(rng.gauss(-0.5 * 0.12**2, 0.12))
    yield_shock = _bounded(rng.gauss(1.0, 0.10), 0.55, 1.40)
    bridge_demand = _bounded(rng.gauss(1.0, 0.18), 0.35, 1.65)
    flash_opportunity = max(rng.gauss(1.0, 0.55), 0.0)
    adverse_execution = _bounded(rng.gauss(1.0, 0.20), 0.6, 1.8)

    protocol_fees = max(state.protocol_fee_revenue_30d * demand_shock, 0.0)
    yield_revenue = max(state.yield_revenue_30d * yield_shock, 0.0)
    bridge_fees = max(state.bridge_fee_revenue_30d * bridge_demand, 0.0)
    flash_profit = max(state.flash_profit_30d * flash_opportunity * decision.flash_search_intensity, 0.0)
    flash_gas = state.gas_cost_30d * (0.35 + 0.65 * decision.flash_search_intensity) * adverse_execution
    operating_cost = max(state.operating_cost_30d * rng.gauss(1.0, 0.04), 0.0)
    realized_revenue = protocol_fees + yield_revenue + bridge_fees + flash_profit - flash_gas - operating_cost

    # Cash revenue is received first. Negative monthly flow consumes reserves.
    next_state.liquid_reserves = max(next_state.liquid_reserves + realized_revenue, 0.0)
    distributable_revenue = max(realized_revenue, 0.0)
    a = decision.allocation

    liquidity_from_revenue = distributable_revenue * a.liquidity_bps / 10_000
    buyback_budget = distributable_revenue * a.buyback_bps / 10_000
    bridge_from_revenue = distributable_revenue * a.bridge_bps / 10_000
    insurance_from_revenue = distributable_revenue * a.insurance_bps / 10_000
    operations_budget = distributable_revenue * a.operations_bps / 10_000

    # Backed QE can use only excess reserves and cannot fund buybacks/operations.
    post_revenue_metrics = metrics(next_state, policy)
    qe_budget = min(
        post_revenue_metrics.excess_reserves * decision.qe_fraction_of_excess,
        policy.maximum_qe_per_month,
    )
    qe_liquidity = qe_budget * decision.qe_liquidity_share
    qe_bridge = qe_budget * decision.qe_bridge_share
    qe_insurance = qe_budget * decision.qe_insurance_share

    liquidity_budget = liquidity_from_revenue + qe_liquidity
    bridge_budget = bridge_from_revenue + qe_bridge
    insurance_budget = insurance_from_revenue + qe_insurance

    total_spend = liquidity_budget + buyback_budget + bridge_budget + insurance_budget + operations_budget
    total_spend = min(total_spend, next_state.liquid_reserves)
    if total_spend > 0:
        scale = min(1.0, next_state.liquid_reserves / total_spend)
        liquidity_budget *= scale
        buyback_budget *= scale
        bridge_budget *= scale
        insurance_budget *= scale
        operations_budget *= scale

    # Liquidity: value is transferred, not created. Only future fee capacity rises.
    liquidity_cost = liquidity_budget * policy.liquidity_slippage_bps / 10_000 * adverse_execution
    liquidity_value = max(liquidity_budget - liquidity_cost, 0.0)
    next_state.liquid_reserves -= liquidity_budget
    next_state.owned_liquidity_nav += liquidity_value
    next_state.liquidity_depth += liquidity_value * 1.8

    # Bridge QE: capital moves to bridge inventory and pays explicit relay cost.
    bridge_cost = bridge_budget * policy.bridge_cost_bps / 10_000 * adverse_execution
    bridge_value = max(bridge_budget - bridge_cost, 0.0)
    next_state.liquid_reserves -= bridge_budget
    next_state.bridge_capital += bridge_value
    imbalance_improvement = 1.0 - math.exp(-bridge_value / max(state.bridge_capital + 1.0, 1.0))
    next_state.bridge_imbalance_bps = max(
        state.bridge_imbalance_bps * (1.0 - 0.65 * imbalance_improvement), 0.0
    )

    next_state.liquid_reserves -= insurance_budget
    next_state.insurance_fund += insurance_budget
    next_state.liquid_reserves -= operations_budget

    # Buyback is allowed only when not materially above fundamental value.
    buyback_executed = 0.0
    retired_supply = 0.0
    fundamental_limit = before.fundamental_price * (1.0 + policy.maximum_buyback_premium_to_fundamental)
    if buyback_budget > 0 and state.market_price <= fundamental_limit and state.market_price > 0:
        execution_price = state.market_price * (1.0 + policy.buyback_slippage_bps / 10_000 * adverse_execution)
        retired_supply = min(buyback_budget / execution_price, next_state.circulating_supply * 0.02)
        buyback_executed = retired_supply * execution_price
        next_state.liquid_reserves -= buyback_executed
        next_state.circulating_supply -= retired_supply

    next_state.liquid_reserves = max(next_state.liquid_reserves, 0.0)

    # Explicit tail risks prevent the optimizer from treating DeFi income as
    # guaranteed. Losses are small in normal scenarios but non-zero under
    # bridge, smart-contract and liquidity stress.
    security_loss = 0.0
    lp_stress_loss = 0.0
    tail_probability = min(0.02 + state.volatility_bps / 250_000, 0.08)
    if rng.random() < tail_probability:
        at_risk_assets = next_state.liquid_reserves + next_state.bridge_capital + next_state.owned_liquidity_nav
        security_loss = at_risk_assets * rng.uniform(0.003, 0.035)
        remaining = security_loss
        liquid_hit = min(next_state.liquid_reserves, remaining * 0.45)
        next_state.liquid_reserves -= liquid_hit
        remaining -= liquid_hit
        bridge_hit = min(next_state.bridge_capital, remaining * 0.65)
        next_state.bridge_capital -= bridge_hit
        remaining -= bridge_hit
        next_state.owned_liquidity_nav = max(next_state.owned_liquidity_nav - remaining, 0.0)
    if rng.random() < min(0.05 + state.volatility_bps / 200_000, 0.12):
        lp_stress_loss = next_state.owned_liquidity_nav * rng.uniform(0.001, 0.02)
        next_state.owned_liquidity_nav = max(next_state.owned_liquidity_nav - lp_stress_loss, 0.0)
        next_state.liquidity_depth = max(next_state.liquidity_depth - lp_stress_loss * 1.5, 0.0)

    # Deployed liquidity/bridge capital adds future fee capacity, not instant NAV.
    next_state.protocol_fee_revenue_30d = max(
        protocol_fees + liquidity_value * policy.liquidity_monthly_revenue_yield * demand_shock,
        0.0,
    )
    next_state.bridge_fee_revenue_30d = max(
        bridge_fees + bridge_value * policy.bridge_monthly_revenue_yield * bridge_demand,
        0.0,
    )
    next_state.yield_revenue_30d = yield_revenue
    next_state.flash_profit_30d = max(
        state.flash_profit_30d * (0.85 + 0.15 * flash_opportunity),
        0.0,
    )
    next_state.operating_cost_30d = operating_cost
    next_state.gas_cost_30d = flash_gas
    next_state.monthly_volume = max(state.monthly_volume * demand_shock * (1.0 + 0.02 * bridge_demand), 0.0)

    after_pre_price = metrics(next_state, policy)
    convergence = _bounded(after_pre_price.fundamental_price / max(state.market_price, 1e-12) - 1.0, -0.50, 0.50)
    market_return = rng.gauss(0.0, max(state.volatility_bps / 10_000 / math.sqrt(12), 0.01)) + 0.08 * convergence
    next_state.market_price = max(state.market_price * math.exp(market_return), 1e-12)
    next_state.volatility_bps = _bounded(state.volatility_bps * rng.gauss(0.98, 0.05), 100.0, 10_000.0)
    next_state.peg_error_bps = max(state.peg_error_bps * rng.gauss(0.97, 0.05), 0.0)
    next_state.month += 1

    decomposition = {
        "realized_revenue": realized_revenue,
        "protocol_fees": protocol_fees,
        "flash_profit": flash_profit,
        "yield_revenue": yield_revenue,
        "bridge_fees": bridge_fees,
        "gas_cost": flash_gas,
        "operating_cost": operating_cost,
        "qe_budget": qe_budget,
        "liquidity_deployed": liquidity_value,
        "bridge_deployed": bridge_value,
        "insurance_deployed": insurance_budget,
        "buyback_spend": buyback_executed,
        "retired_supply": retired_supply,
        "execution_losses": liquidity_cost + bridge_cost,
        "security_loss": security_loss,
        "lp_stress_loss": lp_stress_loss,
    }
    return next_state, decomposition


def state_to_dict(state: SystemState) -> dict[str, float | int]:
    return asdict(state)
