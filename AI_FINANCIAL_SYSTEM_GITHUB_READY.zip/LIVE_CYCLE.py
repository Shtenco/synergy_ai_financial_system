#!/usr/bin/env python3
"""
LIVE ПРИБЫЛЬНЫЙ ЦИКЛ - запуск эмиссии напрямую через EmissionEngine v2
"""
import sys, io, os, json, time
from dotenv import load_dotenv
from web3 import Web3
from web3.middleware import ExtraDataToPOAMiddleware

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

load_dotenv()
w3 = Web3(Web3.HTTPProvider("https://polygon-bor-rpc.publicnode.com", request_kwargs={"timeout": 300}))
w3.middleware_onion.inject(ExtraDataToPOAMiddleware, layer=0)

PK = os.getenv("OWNER_PRIVATE_KEY")
OWNER = "0x6946999DBCE63b140B1bB9D475F7c357130909E5"

def C(a): return Web3.to_checksum_address(a)

with open("deployed_TROIKA_v3.json") as f:
    d = json.load(f)

NEW_EMIT = d.get("emitEngine_v2", "0x76f1CeD709BcaD98A387BBe356f8ce1C9F92cbc9")

print("=" * 70)
print("LIVE ПРИБЫЛЬНЫЙ ЦИКЛ")
print("=" * 70)

# ABI для EmissionEngine
emit_abi = [
    {"name": "isEmissionDue", "inputs": [], "outputs": [{"type": "bool"}], "stateMutability": "view", "type": "function"},
    {"name": "lastEmitBlock", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "executeEmission", "inputs": [], "outputs": [], "stateMutability": "nonpayable", "type": "function"},
    {"name": "CALLER_ROLE", "inputs": [], "outputs": [{"type": "bytes32"}], "stateMutability": "view", "type": "function"},
    {"name": "hasRole", "inputs": [{"name": "role", "type": "bytes32"}, {"name": "account", "type": "address"}], "outputs": [{"type": "bool"}], "stateMutability": "view", "type": "function"},
]

emit = w3.eth.contract(address=C(NEW_EMIT), abi=emit_abi)

# Check status
is_due = emit.functions.isEmissionDue().call()
last_block = emit.functions.lastEmitBlock().call()
current_block = w3.eth.block_number

print(f"EmissionEngine v2: {NEW_EMIT}")
print(f"isEmissionDue: {is_due}")
print(f"lastEmitBlock: {last_block}")
print(f"currentBlock: {current_block}")
print(f"blocks since last: {current_block - last_block}")

# Check if OWNER has CALLER_ROLE (needed to call emitAll directly)
CALLER_ROLE = emit.functions.CALLER_ROLE().call()
owner_is_caller = emit.functions.hasRole(CALLER_ROLE, C(OWNER)).call()
print(f"Owner has CALLER_ROLE: {owner_is_caller}")

# Token balances before
TOKEN_ABI = [
    {"name": "balanceOf", "inputs": [{"type": "address"}], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "totalSupply", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
]

print("\n[BALANCES BEFORE]")
for name, addr in d["tokens"].items():
    tk = w3.eth.contract(address=C(addr), abi=TOKEN_ABI)
    bal = tk.functions.balanceOf(C(OWNER)).call() / 1e18
    supply = tk.functions.totalSupply().call() / 1e18
    print(f"  {name}: owner={bal:.6f}, supply={supply:.6f}")

pol_before = w3.eth.get_balance(C(OWNER)) / 1e18
print(f"  POL: {pol_before:.6f}")

if not is_due:
    print("\n[!] Emission not due yet. Waiting...")
    sys.exit(0)

# Grant CALLER_ROLE to OWNER if not already
if not owner_is_caller:
    print("\n[0] Grant CALLER_ROLE to OWNER...")
    grant_abi = [
        {"name": "grantRole", "inputs": [{"name": "role", "type": "bytes32"}, {"name": "account", "type": "address"}], "outputs": [], "stateMutability": "nonpayable", "type": "function"},
    ]
    emit_g = w3.eth.contract(address=C(NEW_EMIT), abi=grant_abi)

    nonce = w3.eth.get_transaction_count(C(OWNER), "pending")
    base = w3.eth.get_block("latest").get("baseFeePerGas", int(100e9))
    prio = int(50e9)
    mf = base * 2 + prio

    tx = emit_g.functions.grantRole(CALLER_ROLE, C(OWNER)).build_transaction({
        "from": C(OWNER), "nonce": nonce, "chainId": 137, "type": 2,
        "maxPriorityFeePerGas": prio, "maxFeePerGas": mf, "gas": 100000
    })
    signed = w3.eth.account.sign_transaction(tx, PK)
    h = w3.eth.send_raw_transaction(signed.raw_transaction)
    r = w3.eth.wait_for_transaction_receipt(h, timeout=120)
    print(f"  {'OK' if r.status else 'FAIL'}")
    time.sleep(2)

# Call emitAll() directly on EmissionEngine v2
print("\n[1] Calling emitAll()...")

nonce = w3.eth.get_transaction_count(C(OWNER), "pending")
base = w3.eth.get_block("latest").get("baseFeePerGas", int(100e9))
prio = int(50e9)
mf = base * 2 + prio

tx = emit.functions.executeEmission().build_transaction({
    "from": C(OWNER), "nonce": nonce, "chainId": 137, "type": 2,
    "maxPriorityFeePerGas": prio, "maxFeePerGas": mf, "gas": 3_000_000
})

signed = w3.eth.account.sign_transaction(tx, PK)
h = w3.eth.send_raw_transaction(signed.raw_transaction)
print(f"  TX: {h.hex()}")

r = w3.eth.wait_for_transaction_receipt(h, timeout=300)
gas_used = r.gasUsed
gas_cost = gas_used * mf / 1e18

if r.status == 1:
    print(f"  [OK] Gas used: {gas_used}, cost: {gas_cost:.6f} POL")
else:
    print(f"  [FAIL] Gas used: {gas_used}")
    # Check revert reason
    print(f"  Receipt: {r}")
    sys.exit(1)

time.sleep(3)

# Token balances after
print("\n[BALANCES AFTER]")
for name, addr in d["tokens"].items():
    tk = w3.eth.contract(address=C(addr), abi=TOKEN_ABI)
    bal = tk.functions.balanceOf(C(OWNER)).call() / 1e18
    supply = tk.functions.totalSupply().call() / 1e18
    print(f"  {name}: owner={bal:.6f}, supply={supply:.6f}")

pol_after = w3.eth.get_balance(C(OWNER)) / 1e18
print(f"  POL: {pol_after:.6f}")

# Summary
print("\n" + "=" * 70)
print("РЕЗУЛЬТАТ")
print("=" * 70)
print(f"POL потрачено на gas: {pol_before - pol_after:.6f}")
print(f"Эмиссия выполнена: {'ДА' if r.status else 'НЕТ'}")
print("=" * 70)
