# Полный аудит INSTANT_DEPLOY и новый Flash Loan Arbitrage

**Дата:** 22 июля 2026 года  
**Объект:** `INSTANT_DEPLOY.zip`  
**Цель:** проверить все файлы и смарт-контракты, отделить реальную внешнюю прибыль от внутреннего перераспределения TROIKA и создать flash-loan алгоритм, который не допускает убыточного завершения на уровне смарт-контракта.

## 1. Итог

В архиве уже находились три попытки flash-profit, но ни одна из них не является готовым безопасным прибыльным арбитражем:

1. `20_FlashProfitCycle.sol` вызывает отсутствующие функции Vault.
2. `21_FlashProfitAtomic.sol` пытается вернуть principal привилегированным переводом из Vault и ошибочно рассматривает внутреннюю эмиссию как внешнюю прибыль.
3. `TroikaFlashProfit.sol` использует несовместимую ETH/WPOL механику, нулевые ограничения проскальзывания и подавляет ошибки.

Добавлена новая независимая система:

- `22_FlashLoanArbitrage.sol` — атомарный Aave V3 executor;
- `flash_arb_bot.py` — scanner/optimizer и опциональный live executor;
- `DEPLOY_FLASH_ARBITRAGE.py` — безопасный deployment/configuration;
- `flash_arb_config.json` — адреса, токены, маршруты и лимиты;
- `compile_flash.js` — воспроизводимая компиляция;
- `TEST_FLASH_ARBITRAGE_MATH.py` — регрессия критической математики;
- `RUN_FLASH_ARBITRAGE.md` — инструкция запуска;
- `AUDIT_INVENTORY.json` — SHA-256 и классификация каждого файла итогового проекта.

Новая система **не использует EmissionEngine, Vault, founder dividend или виртуальный LP как источник прибыли**. Прибыль должна возникнуть только из реальной разницы цен в AMM-парах.

## 2. Что означает «прибыльный» корректно

Flash loan не создаёт доход. Он только предоставляет principal на одну атомарную транзакцию. Сделка допустима, когда:

```text
quotedOutput - principal - AavePremium - gasReserve >= minimumNetProfit
```

На уровне контракта используется ещё более жёсткий инвариант:

```text
finalAssetBalance >= principal + actualPremium + minProfit
```

Если условие не выполнено, callback откатывается, Aave-транзакция целиком revert. Потерять principal Aave невозможно, но operator всё равно оплачивает газ неудачной транзакции. Поэтому бот выполняет предварительный `eth_call`, `estimate_gas`, safety multiplier и short deadline.

**Гарантированной прибыли нет.** Если реального ценового расхождения нет, правильный результат scanner — не отправлять транзакцию.

## 3. Объём проверки

Проведено:

- распаковка и классификация всех файлов;
- SHA-256 inventory итогового дерева;
- AST-проверка всех Python-исходников;
- поиск hardcoded private keys;
- компиляция всех Solidity-исходников;
- ручная проверка денежных потоков Vault/Emission/Dividend/Collateral/Arbitrage;
- проверка старых flash-контрактов;
- компиляция и тестирование нового flash-контракта;
- сверка адресов Aave V3 и QuickSwap V2 с официальными источниками.

После установки npm-зависимостей итоговое дерево содержит зависимости и build artifacts, поэтому число файлов больше исходных 555. Полный текущий список находится в `AUDIT_INVENTORY.json`; исходники и конфигурация отдельно перечислены в `AUDIT_SOURCE_FILES.csv`.

## 4. Критические находки

### C-01. `20_FlashProfitCycle.sol` несовместим с реальным Vault

Строки 152 и 167 вызывают:

```solidity
vault.deposit(amount);
vault.withdraw(lpMinted);
```

В `03_TroikaVault.sol` таких методов нет. Существующий Vault использует привилегированные служебные функции и реальные QuickSwap-пулы, а не пользовательские LP shares. Контракт не может реализовать заявленный цикл.

**Решение:** не деплоить; использовать `22_FlashLoanArbitrage.sol`.

### C-02. `21_FlashProfitAtomic.sol` извлекает существующую стоимость Vault

Principal переводится в Vault, затем контракт пытается забрать его через `vault.transferWpol()`. Этот метод защищён `OPERATOR_ROLE`. Эмиссия не создаёт WPOL; founder payout берётся из `freeWpol()` Vault. Это не внешний арбитражный yield, а перемещение уже существующего резерва.

Дополнительно:

- несколько emission intervals нельзя дождаться внутри одной транзакции;
- `withdrawFounder()` платит founder-адресу, а не flash-контракту;
- вычисление net profit не доказывает наличие средств для реального repayment.

**Решение:** не выдавать старому flash-контракту роли Vault/Emission и не использовать его адрес из старого deployment JSON без отдельной on-chain проверки.

### C-03. `TroikaFlashProfit.sol` использует неправильную WPOL/ETH схему

Контракт формирует путь от WPOL, но вызывает `swapExactTokensForETH()`. Router ожидает корректный wrapped-native flow и делает unwrap; код одновременно вручную wrap/unwrap и использует native liquidity methods. В нескольких местах `amountOutMin` и liquidity minimums равны нулю. Ошибки подавляются пустыми `catch`.

**Риск:** sandwich/MEV, неполные циклы, зависшие токены, невозможность доказать final repayment.

### C-04. Emission accounting может расходиться с фактическим mint

В `07_EmissionEngine.sol`:

```solidity
try token.mint(...) {} catch {}
totalEmitted += amount;
```

Счётчик увеличивается даже при revert mint. Это нарушает инвариант «учётная эмиссия = фактическая эмиссия».

**Решение:** увеличивать `totalEmitted*` только внутри успешной ветки; при ошибке emit отдельное событие и откатывать критический цикл.

### C-05. Виртуальный LP может быть уничтожен последующей синхронизацией

`batchAddLP()` увеличивает виртуальные `lpR/lpT/lpP`, но конец `executeEmission()` вызывает `vault.syncFromChain()`, который заменяет их значениями, рассчитанными по реальным QuickSwap reserves. Аналогичный риск есть у `flushLpBuf()` при нехватке реального WPOL.

**Решение:** разделить `realLPValue` и `pendingVirtualLP`; не смешивать их в одних state variables.

### C-06. Залог ALTN оценивается по spot reserves

`13_CollateralEmission.sol::_altnValuePOL()` использует одно текущее `getReserves()`. Такой spot можно временно сдвинуть крупным swap/flash liquidity, после чего открыть/ликвидировать позицию по искажённой цене.

**Решение:** Chainlink/другой независимый oracle либо устойчивый cumulative TWAP с длинным окном, freshness check и max deviation.

## 5. Высокие риски

### H-01. Массовое подавление ошибок

`10_TroikaCore.sol`, `14_CircularHub_v2.sol`, `15_CircularDeployer.sol` и другие файлы продолжают выполнение после пустого `catch`. Это допускает частичное обновление системы и тихое расхождение подсистем.

**Решение:** ошибки денежных переводов, mint/burn, выдачи ролей и sync должны либо откатывать транзакцию, либо записываться в явный failure-state с повторным исполнением.

### H-02. Нулевое проскальзывание

В ALTN, MutualPoolRouter и старом flash-контракте встречаются swaps/add/remove liquidity с minimums `0`. Это открывает возможность sandwich и исполнения по практически любой цене.

**Решение:** рассчитывать `amountOutMin`/`amountAMin`/`amountBMin` из свежей котировки и допустимого bps; short deadline.

### H-03. Административные timelock равны нулю

`11_FounderControl.sol` задаёт `START_TIMELOCK = 0` и `RESCUE_TIMELOCK = 0`.

**Решение:** multisig + ненулевой timelock + публичная очередь операций для rescue/смены критических адресов.

### H-04. Текущий deployment не подтверждает mutual pools

`deployed_instant.json` содержит только пары SYNA/WPOL, SYNC/WPOL, SYNR/WPOL и ALTN/WPOL. Треугольные маршруты требуют хотя бы одной TOKEN/TOKEN пары, например SYNA/SYNC. Scanner проверяет пары через Factory и автоматически пропускает отсутствующие.

**Важно:** создание собственного пустого пула не создаёт прибыль. Для арбитража нужна независимая ликвидность и реальное ценовое расхождение.

## 6. Новый on-chain executor

### Защиты `22_FlashLoanArbitrage.sol`

- Aave V3 `flashLoanSimple`;
- premium читается из Pool, а не хардкодится;
- whitelist операторов, роутеров и токенов;
- owner-set maximum flash amount;
- только замкнутый путь: первый token = borrowed asset, последний token = borrowed asset;
- 1–4 swap steps, до 5 токенов в path;
- обязательный `minAmountOut` на каждом шаге;
- short deadline до 180 секунд;
- проверка caller/initiator/asset/amount/params hash в callback;
- защита от повторного callback;
- безопасные approvals через `forceApprove` и reset;
- финальная проверка actual output после всех swaps;
- revert при недостаче principal, actual premium или `minProfit`;
- pause, ограниченный withdraw profit и запрет rescue во время flash cycle.

### Исправленный same-token balance accounting

Циклический путь часто выглядит как один router call:

```text
WPOL → SYNA → SYNC → WPOL
```

Входной и выходной токен одинаковы. Простая формула `afterBalance - beforeBalance` возвращает только net delta, а не полный router output. В новом контракте используется:

```text
amountOut = afterBalance + amountIn - beforeBalance
```

Регрессия зафиксирована тестом `test_same_token_cycle_returns_full_output_not_only_profit`.

## 7. Off-chain scanner и optimizer

`flash_arb_bot.py`:

1. подключается только к Polygon chain ID 137;
2. читает live `FLASHLOAN_PREMIUM_TOTAL()` на каждом цикле;
3. проверяет существование каждой пары через QuickSwap Factory;
4. перебирает principal от minimum до maximum геометрической сеткой;
5. получает `getAmountsOut()` для полного треугольного пути;
6. учитывает Aave premium с округлением вверх;
7. резервирует `gasUnits × maxFeePerGas × safetyMultiplier`;
8. требует дополнительную `minimum_net_profit_wpol`;
9. строит `minAmountOut` как максимум cost floor и slippage floor;
10. в live-режиме повторно оценивает gas, делает полный `eth_call`, подписывает только прошедшую simulation сделку;
11. пишет quotes и executions в `flash_arb_opportunities.jsonl`.

Live отправка намеренно требует одновременно `--live --yes`.

## 8. Конфигурация текущей системы

В `flash_arb_config.json` внесены адреса из `deployed_instant.json`:

- SYNA: `0x7E1627d28e903c57082d4145f0103B7227316E0A`
- SYNC: `0x8F959B119F4f39229950173f639A1688aD9D1647`
- SYNR: `0xF14DeB5855c90354FE31893f465648538e2d9d75`
- ALTN: `0xb3711EdE692ADEccB687F61eF59ca28E6eF753D6`

ALTN отключён в стандартном наборе из-за fee-on-transfer. Его нельзя включать без измерения реального налога и отдельного route simulation.

Официальные инфраструктурные адреса, проверенные 22 июля 2026 года:

- Aave V3 Polygon Pool: `0x794a61358D6845594F94dc1DB02A252b5b4814aD`
- QuickSwap V2 Router: `0xa5E0829CaCEd8fFDD4De3c43696c57F7D7A678ff`
- QuickSwap V2 Factory: `0x5757371414417b8C6CAad45bAeF941aBc7d3Ab32`
- WPOL: `0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270`

Контракт всё равно читает live Aave premium и не доверяет локальной оценке fee.

## 9. Результаты сборки и тестов

`npm test` выполняет три этапа:

1. `npm run check:contracts`
2. `npm run compile:flash`
3. `npm run test:flash-math`

Результат на момент выдачи:

- Solidity sources: 26;
- compiled contracts/interfaces/libraries: 140;
- fatal compiler errors: 0;
- новый bytecode: 8,839 bytes;
- математические тесты: 5/5 passed;
- Python AST errors: 0;
- hardcoded private keys в исходниках не найдены.

Сохранились предупреждения старого кода:

- совпадение имени local `totalTVL` и функции `totalTVL()`;
- unnamed return в `TroikaCore.checkUpkeep()`;
- unreachable increment в старом `21_FlashProfitAtomic.sol`;
- три unused local variables.

Полный вывод: `COMPILATION_REPORT.txt`.

## 10. Что не выполнялось

В среде аудита не было пользовательского Polygon RPC и private key, поэтому:

- mainnet deployment нового контракта не выполнялся;
- live flash loan не отправлялся;
- актуальные reserves пользовательских пар не читались;
- фактическая доходность не заявляется и не симулируется вымышленными цифрами.

Это намеренное ограничение безопасности. Dry-run и deployment scripts готовы и требуют явного пользовательского RPC/key.

## 11. Приоритетный план перед mainnet

1. Не использовать три старых flash-контракта.
2. Проверить, не выданы ли старому адресу `flash_profit` роли Vault/Emission; при наличии отозвать.
3. Исправить C-04, C-05 и C-06 до увеличения TVL.
4. Запустить `npm test` локально.
5. Запустить scanner `py flash_arb_bot.py --once`.
6. Убедиться, что необходимые TOKEN/TOKEN pairs реально существуют и имеют достаточную глубину.
7. Деплоить новый executor с маленьким cap.
8. Проверить bytecode/owner/whitelists на PolygonScan.
9. Несколько дней вести только dry-run журнал.
10. Для live использовать отдельный bot wallet с ограниченным POL balance и защищённую доставку транзакций.

## 12. Главный вывод

Новый алгоритм является **profit-protected**, а не «генератором гарантированной прибыли». Он не отправляет сделку без положительной текущей математики и не позволяет контракту завершить flash cycle ниже заданного final profit. Это корректная архитектура для flash-loan арбитража и принципиально безопаснее попытки извлекать «прибыль» из собственной эмиссии TROIKA.

---

## QE Bridge and AI Central Bank extension

The flash-loan arbitrage module is now isolated from the reserve-backed QE bridge and AI market maker. Flash-loan profit may be returned to the treasury only after repayment and minimum-profit checks; it must not be used as evidence that bridge issuance or internal AMM repricing creates external profit.

New modules `23`–`27` add bridge relays, reserve floors, oracle-guarded market making, timelocked AI proposals and a restricted bridge inventory adapter. See `RUN_AI_CENTROBANK_BRIDGE.md`.
