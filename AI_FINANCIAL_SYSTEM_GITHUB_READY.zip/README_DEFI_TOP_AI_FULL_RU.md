# SHTENCO DeFi TOP AI v3

## Полное техническое описание единого DeFi-контура, ИИ-центробанка, ИИ-маркетмейкера, flash-loan арбитража, QE, мостового QE и эконометрической модели фундаментальной стоимости

**Версия документа:** 1.0  
**Дата:** 22 июля 2026 года  
**Базовая сборка:** `INSTANT_DEPLOY_DEFI_TOP_AI_V3`  
**Статус:** локально скомпилированная и протестированная архитектура; публичный mainnet-деплой нового TOP AI-контура не выполнялся.

---

## 1. Назначение системы

SHTENCO DeFi TOP AI v3 — это единый контур управления капиталом DeFi-экосистемы SYNA/SYNC/SYNR/ALTN. Он объединяет:

- токены и исходную экономику TROIKA/SINERGY;
- QuickSwap-пулы и внутренние резервы;
- внешний Aave V3 flash-loan арбитраж;
- единое казначейство реального дохода;
- ИИ-маркетмейкер;
- обеспеченное количественное смягчение — QE;
- обеспеченное межсетевое количественное смягчение — Bridge QE;
- M-of-N relay-мост;
- независимый экономический M-of-N oracle;
- off-chain эконометрический ИИ-оптимизатор;
- on-chain timelock-контроллер, который ограничивает действия ИИ;
- страховой, резервный, ликвидностный, buyback и операционный контуры;
- симулятор внутреннего рынка с 20 ИИ-роботами.

Главная целевая переменная системы — **риск-скорректированная фундаментальная стоимость**, а не краткосрочное перемещение spot-цены в тонком пуле.

Система должна различать три разных показателя:

1. **Spot price** — текущая цена токена в конкретном AMM-пуле.
2. **Market capitalization** — spot price × circulating supply.
3. **Fundamental capitalization** — чистые обеспеченные активы плюс консервативная стоимость устойчивого денежного потока.

Рост первого и второго показателя сам по себе не доказывает создание стоимости. Внутренний swap может сильно сдвинуть цену при малой ликвидности, не добавив системе внешних активов.

---

## 2. Основной экономический принцип

Система считает созданной стоимостью только то, что увеличивает чистые активы или устойчивый чистый денежный поток.

```text
Внешний доход
  − газ
  − стоимость финансирования
  − проскальзывание
  − операционные расходы
  − реализованные потери
  = чистая реализованная прибыль

Чистая реализованная прибыль
  → резерв
  → принадлежащая системе ликвидность
  → мостовой капитал
  → страховой фонд
  → ограниченный buyback
  → будущие комиссии и доходность
```

Не считаются созданной фундаментальной стоимостью:

- principal flash loan;
- необеспеченная эмиссия;
- внутреннее перемещение денег между контрактами;
- рост spot-цены из-за собственного swap;
- wash trading;
- весь TVL пула, если системе принадлежит только часть LP;
- wrapped-токены без вычета соответствующего обязательства;
- перенос резерва в мост без будущего дохода;
- burn, профинансированный уничтожением критического резерва;
- виртуальная бухгалтерская запись, не подтверждённая реальным балансом токена.

---

## 3. Высокоуровневая архитектура

```mermaid
flowchart TD
    EXT[Внешние DEX и рынки] --> SCAN[Flash Arb Scanner]
    SCAN --> AAVE[Aave V3 Flash Loan]
    AAVE --> FLA[22 FlashLoanArbitrage]
    FLA --> H[32 FlashProfitHarvester]
    H --> T[29 ValueFlowTreasury]

    FEES[Protocol / DEX / Bridge / Yield Revenue] --> T

    T --> R[RESERVE]
    T --> L[LIQUIDITY]
    T --> B[BUYBACK]
    T --> BR[BRIDGE]
    T --> I[INSURANCE]
    T --> O[OPERATIONS]

    L --> MM[25 AI MarketMaker]
    B --> MM
    MM --> LP[Owned LP]
    MM --> BURN[Buyback and Burn]

    BR --> QER[24 Bridge QE Reserve]
    QER --> QEA[27 Bridge QE Adapter]
    QEA --> RELAY[23 Relay Bridge]
    RELAY --> REMOTE[Удалённая сеть]

    REPORTERS[Независимые reporters] --> ORACLE[28 System State Oracle]
    ORACLE --> AI[Off-chain TOP AI Optimizer]
    AI --> CTRL[30 TOP AI Controller]
    CTRL --> H
    CTRL --> T
    CTRL --> MM
    CTRL --> QER
    CTRL --> QEA

    GUARDIAN[Guardian] --> CTRL
    GOVERNANCE[Multisig / Governance] --> ORACLE
    GOVERNANCE --> CTRL
    GOVERNANCE --> T
    GOVERNANCE --> MM
    GOVERNANCE --> RELAY
```

---

## 4. Три логических уровня системы

### 4.1. Уровень A — исходная экономика TROIKA/SINERGY

Файлы `00`–`19` содержат токены, Vault, эмиссию, комиссии, дивиденды, арбитраж, залоговую эмиссию, ALTN, круговые callback-механизмы и взаимные пулы.

Этот уровень является историческим и функциональным основанием проекта, но часть его механизмов имеет технический долг. Новый TOP AI-контур не должен считать внутреннюю эмиссию, founder payout или виртуальные LP-записи внешней прибылью.

### 4.2. Уровень B — production-контур DeFi TOP AI

Канонический защищённый путь построен вокруг контрактов:

- `22_FlashLoanArbitrage.sol`;
- `23_SHTENCOBridgeRelayV2.sol`;
- `24_SHTENCOBridgeQEReserve.sol`;
- `25_SHTENCOMarketMaker.sol`;
- `27_SHTENCOBridgeQEAdapter.sol`;
- `28_SHTENCOSystemStateOracle.sol`;
- `29_SHTENCOValueFlowTreasury.sol`;
- `30_SHTENCOTopAIController.sol`;
- `31_SHTENCODeFiContourRegistry.sol`;
- `32_SHTENCOFlashProfitHarvester.sol`.

`26_SHTENCOAICentralBank.sol` сохранён как предыдущая версия AI-контроллера, однако в версии v3 главным управляющим слоем является `30_SHTENCOTopAIController.sol`.

### 4.3. Уровень C — off-chain ИИ и операционная инфраструктура

Python и JavaScript-слой:

- собирает состояние системы;
- рассчитывает fundamental metrics;
- генерирует варианты политики;
- проводит Monte Carlo/MPC-оценку;
- выбирает решение с максимальным risk-adjusted score;
- формирует человекочитаемый intent;
- материализует точный calldata по текущим балансам и котировкам;
- отправляет proposal в timelock-контроллер;
- исполняет его только после повторной on-chain проверки.

ИИ не должен иметь приватный ключ администратора и не должен напрямую менять политики контрактов.

---

# ЧАСТЬ I. ИСХОДНАЯ ЭКОНОМИКА TROIKA/SINERGY

## 5. Системные токены

### 5.1. SYNA

Файл: `02_Tokens.sol`, контракт `SYNA`.

- стандарт ERC-20;
- burnable;
- permit;
- pausable;
- role-based mint/burn;
- `MAX_SUPPLY = 1 000 000 000 SYNA`;
- `INITIAL_SUPPLY = 10 000 000 SYNA`;
- `MAX_SINGLE_MINT = 10 000 000 SYNA`.

Ключевые роли:

- `MINTER_ROLE`;
- `BURNER_ROLE`;
- `PAUSER_ROLE`.

Фундаментальная стоимость SYNA не возникает из самого факта mint. Эмиссия может быть нейтральной или разрушительной для стоимости, если ей не соответствует новый backing, revenue или полезность.

### 5.2. SYNC

Файл: `02_Tokens.sol`, контракт `SYNC`.

- `MAX_SUPPLY = 10 000 000 000 SYNC`;
- `INITIAL_SUPPLY = 19 SYNC`;
- `MAX_SINGLE_MINT = 50 000 000 SYNC`;
- те же роли mint/burn/pause.

### 5.3. SYNR

Файл: `02_Tokens.sol`, контракт `SYNR`.

- `MAX_SUPPLY = 1 000 000 000 SYNR`;
- `INITIAL_SUPPLY = 4 SYNR`;
- `MAX_SINGLE_MINT = 5 000 000 SYNR`;
- отдельная функция buyback burn;
- лимит buyback burn на одну операцию привязан к supply: `BUYBACK_BURN_CAP_BPS = 20`, то есть 0,2%.

### 5.4. ALTN

Файл: `19_Altyn_v1_original.sol`, контракт `AltynToken`.

ALTN — отдельный дефляционный токен с большой внутренней логикой:

- buy/sell fees;
- instant fee burn;
- transfer burn;
- progressive sell tax;
- cascade burn tiers;
- sell velocity burn;
- anti-whale cooldown;
- price-floor defense;
- LP burn и реинъекция;
- buyback and burn;
- staking;
- elastic burn/mint;
- adaptive optimizer;
- pool deepening;
- `maintenance()` как отдельный путь DEX-операций.

`MAX_SUPPLY = 110 500 000 ALTN`.

ALTN-контракт имеет большую поверхность риска. В исходнике встречаются слабые minimum-output параметры и сложные взаимодействия с DEX. Перед использованием его как крупного collateral или элемента TOP AI требуется отдельный формальный аудит.

---

## 6. Контракты `00`–`19`

### `00_CircularInterfaces.sol`

Общий интерфейсный слой и библиотека `CircularMath`.

Содержит интерфейсы для:

- ALTN;
- TroikaCore;
- Vault;
- EmissionEngine;
- SelfReinforcingLoop;
- DividendPool;
- CollateralEmission;
- CircularHub;
- AMM pair.

`CircularMath` рассчитывает:

- цену из резервов пары;
- cross-price;
- sqrt-based dLP;
- coverage ratio;
- адаптацию весов.

### `01_PolygonConfig.sol`

Содержит адреса Polygon/QuickSwap и интерфейсы Factory/Pair/Router.

Любой mainnet-деплой должен повторно проверять:

- chain ID;
- адрес WPOL;
- router;
- factory;
- наличие bytecode по адресам;
- соответствие router/factory ожидаемой версии протокола.

### `03_TroikaVault.sol`

Центральное хранилище исходной TROIKA-экономики.

Хранит:

- LP-токены SYNA/WPOL, SYNC/WPOL, SYNR/WPOL;
- `traderReserve`;
- `reserveR`;
- `mcgFund`;
- `lpBuf`;
- `buybackAccum`;
- виртуальные показатели `lpR`, `lpT`, `lpP`.

Показатели `lpR/lpT/lpP` рассчитываются как удвоенный WPOL-reserve соответствующей пары. Это модельная оценка двух сторон пула, а не независимая рыночная оценка токеновой стороны.

Важный риск: `syncFromChain()` заменяет виртуальные значения фактическими резервами пары. Если другие контракты предварительно увеличивали виртуальный dLP, такая прибавка может исчезнуть после синхронизации.

Несмотря на комментарий о двухдневном emergency timelock, в текущем исходнике:

```text
TIMELOCK_DELAY = 0
TIMELOCK_WINDOW = max uint256
```

То есть emergency withdrawal фактически не имеет задержки. Это должно быть исправлено до production TVL.

### `04_TWAPOracle.sol`

Хранит rolling buffer из 48 spot-наблюдений и усредняет отношение цен.

Это не классический Uniswap cumulative-price TWAP. Он может быть полезен как сглаживающий индикатор, но не должен быть единственным oracle для:

- collateral valuation;
- ликвидации;
- крупного buyback;
- мостового mint;
- определения фундаментальной стоимости.

### `05_DividendPool.sol`

Распределяет выплаты основателю и держателям SYNR.

При интеграции с fundamental accounting необходимо различать:

- реальный входящий доход;
- обязательство перед получателями;
- фактически переведённую сумму;
- бухгалтерское уведомление без перевода.

Дивиденды уменьшают активы системы и должны учитываться как distribution/expense, а не как новый доход.

### `06_FeeRouter.sol`

Маршрутизирует комиссии между:

- LP buffer;
- trader reserve;
- Central Bank fund;
- DividendPool;
- reserveR;
- внутренними циклами.

Фундаментальная стоимость растёт только на ту часть комиссии, которая:

1. реально поступила;
2. осталась собственностью системы;
3. не была одновременно записана в нескольких местах;
4. не является обязательством перед внешним получателем.

### `07_EmissionEngine.sol` и `07_EmissionEngine_MAX.sol`

Выполняют эмиссию, dLP-расчёты, адаптацию, founder payout, buyback и циклические сигналы.

Выявленный риск исходной версии: счётчики `totalEmitted*` могут увеличиваться даже при неуспешном mint. Кроме того, founder WPOL payout берётся из уже существующего Vault и не является внешней прибылью.

Для TOP AI-контура эти контракты не должны быть источниками `realized revenue` без подтверждения реальной положительной balance delta казначейства.

### `08_CBArbitrage.sol`

Внутренний арбитражный модуль на WPOL-буфере.

Это не flash loan. Его результат должен оцениваться после:

- DEX fee;
- gas;
- slippage;
- price impact;
- opportunity decay;
- возможного MEV.

### `09_SelfReinforcingLoop.sol`

Содержит два внутренних распределительных кольца.

Перемещение капитала по кольцу может менять доступность средств и параметры системы, но не создаёт внешнюю покупательную способность само по себе.

### `10_TroikaCore.sol`

Главный оркестратор `tick()` и `processFee()`.

Проблема исходной архитектуры — многочисленные пустые `catch`. Общий tick может завершиться, даже если отдельная подсистема не сработала. Для production необходимы:

- события ошибок по каждому шагу;
- health status;
- sequence number;
- invariant checks;
- fail-closed режим для денежных операций.

### `11_FounderControl.sol`

Административный запуск, остановка и rescue.

В исходнике start/rescue timelock равны нулю. Административные права должны быть переданы multisig и реальному timelock.

### `12_TroikaDeployer.sol`

Монолитный deployer исходной системы.

После деплоя необходимо отдельно проверять:

- адрес каждого контракта;
- bytecode hash;
- роли;
- владельцев;
- pauser;
- operator;
- router/factory;
- token decimals;
- созданные пары;
- фактические резервы.

### `13_CollateralEmission.sol`

Принимает ALTN как collateral и выпускает SYNA.

Критический риск: исходная оценка ALTN опирается на spot-reserves AMM. Тонкий пул может быть временно сдвинут flash loan, что искажает LTV и ликвидацию.

До использования необходимы:

- независимый oracle;
- TWAP достаточной длины;
- deviation guard;
- delay между оценкой и выпуском;
- cap на эмиссию;
- circuit breaker;
- стресс-тест ликвидаций.

### `14_CircularHub_v2.sol`

Связывает ALTN и TROIKA:

- принимает callback о burn;
- принимает callback о комиссиях;
- обновляет cross-price;
- адаптирует routing weights;
- передаёт сигнал EmissionEngine;
- накапливает pending allocations.

Пустые `catch` могут приводить к частичному исполнению.

### `15_CircularDeployer.sol`

Разворачивает CollateralEmission/CircularHub и выдаёт роли. Выдача ролей должна быть подтверждена отдельным post-deploy скриптом.

### `16_AltynCircularPatch.sol`

Callback-адаптер ALTN. Должен принимать сообщения только от доверенного ALTN-контракта.

### `17_EmissionCircular.sol`

Передаёт внешний cross-price сигнал EmissionEngine и callback после эмиссии. Сигнал должен иметь источник, timestamp и deviation limits.

### `18_MutualPoolDeployer.sol`

Создаёт TOKEN/TOKEN пары:

- ALTN/SYNR;
- ALTN/SYNA;
- SYNR/SYNA;
- SYNR/SYNC;
- ALTN/SYNC.

Такие пары расширяют граф арбитража и уменьшают зависимость от единственного WPOL-пути, но одновременно увеличивают число поверхностей для price manipulation.

### `19_MutualPoolRouter.sol`

Распределяет ликвидность по WPOL и взаимным пулам. Использует spot TVL и DEX-маршруты. Для production minimums должны рассчитываться из независимого oracle, а не быть нулевыми.

---

# ЧАСТЬ II. FLASH-LOAN КОНТУР

## 7. Запрещённые legacy flash-контракты

### `20_FlashProfitCycle.sol`

Не использовать. Он обращается к отсутствующим функциям Vault и экономически пытается считать внутреннюю эмиссию источником flash-прибыли.

### `21_FlashProfitAtomic.sol`

Не использовать. Для возврата principal зависит от привилегированного вывода существующего WPOL из Vault. Это не внешний арбитраж.

### `TroikaFlashProfit.sol`

Не использовать. В исходнике смешаны WPOL и native-ETH router-функции, присутствуют слабые minimums и подавление ошибок.

---

## 8. `22_FlashLoanArbitrage.sol`

Рекомендуемый flash-loan исполнитель.

### Назначение

Получить flash loan в Aave V3, выполнить циклический маршрут по разрешённым V2-совместимым роутерам и завершить транзакцию только тогда, когда итоговый баланс покрывает:

```text
principal + Aave premium + minProfit
```

### Основные ограничения

- максимум 4 swap-шага;
- максимум 5 токенов в одном path;
- deadline не дальше 180 секунд;
- allowlist токенов;
- allowlist роутеров;
- operator role;
- max flash amount;
- pause;
- запрет rescue во время активного flash callback;
- route validation;
- проверка callback от Aave Pool;
- quote precheck;
- balance-delta accounting;
- atomic revert при недостаточной прибыли.

### Источник прибыли

Только внешний ценовой дисбаланс между DEX-маршрутами.

### Что не считается прибылью

- borrowed principal;
- вывод из TroikaVault;
- mint системного токена;
- founder payout;
- внутренний transfer;
- старый баланс исполнителя.

### Важное ограничение

On-chain контракт проверяет `minProfit`, но gas оплачивается native-токеном транзакции. Поэтому off-chain scanner должен включать в `minProfit`:

- Aave premium;
- ожидаемый gas;
- priority fee;
- slippage reserve;
- MEV risk margin;
- minimum net margin.

---

## 9. `32_SHTENCOFlashProfitHarvester.sol`

Harvester связывает flash-arbitrage и ValueFlowTreasury.

Цикл:

1. TOP AI вызывает `harvest()`.
2. Harvester вызывает `withdrawProfit()` у разрешённого flash source.
3. Проверяется реальная balance delta Harvester.
4. Токены переводятся в Treasury.
5. Treasury вызывает `recordRevenue()` с уникальным `sourceId`.
6. Повторное использование `sourceId` отклоняется.

Harvester может принять ownership flash-source через отдельную policy-функцию. Это сильное право, поэтому `POLICY_ROLE` должен принадлежать multisig/timelock.

---

# ЧАСТЬ III. ЕДИНОЕ КАЗНАЧЕЙСТВО И QE

## 10. `29_SHTENCOValueFlowTreasury.sol`

Это главный бухгалтерский слой реального дохода.

### 10.1. Что он учитывает

- только поддерживаемые ERC-20;
- только реальную balance delta;
- только уникальный source ID;
- unallocated revenue;
- classified balance;
- total realized revenue;
- balances шести buckets;
- дневной release flow.

### 10.2. Buckets

| Bucket | Назначение |
|---|---|
| `RESERVE` | базовый backing и запас ликвидности |
| `LIQUIDITY` | капитал для owned LP и market making |
| `BUYBACK` | buyback-and-burn только из реализованного дохода |
| `BRIDGE` | обеспеченная межсетевая ликвидность |
| `INSURANCE` | покрытие bridge/security/LP tail-risk |
| `OPERATIONS` | газ, инфраструктура, аудит, обслуживание |

### 10.3. Жёсткие диапазоны распределения

| Направление | Минимум | Максимум |
|---|---:|---:|
| Reserve | 25% | 60% |
| Liquidity | 15% | 40% |
| Buyback | 0% | 20% |
| Bridge | 5% | 20% |
| Insurance | 5% | 20% |
| Operations | 0% | 10% |

Сумма всегда должна быть ровно 10 000 bps.

### 10.4. Reserve QE

`reclassifyReserveQE()` разрешает переместить часть уже классифицированного RESERVE только в:

- LIQUIDITY;
- BRIDGE;
- INSURANCE.

Запрещены:

- BUYBACK;
- OPERATIONS;
- произвольный внешний адрес;
- необеспеченный mint.

После reclassification резерв обязан оставаться выше `reserveFloor`.

### 10.5. Release

Каждый bucket может отправлять средства только в allowlisted sink. Все releases ограничены суточным лимитом токена.

### 10.6. Экономический смысл

Treasury не создаёт стоимость. Он предотвращает ложный учёт и направляет уже созданную стоимость в капитал, который может генерировать новый доход.

---

## 11. Что такое QE в этой системе

QE здесь не означает «напечатать токены и поднять цену».

**Обеспеченный QE** — это перенос части избыточного резерва в продуктивные, но ограниченные направления.

```text
ExcessReserve = LiquidReserves − MinimumReserveRatio × Liabilities

QE Budget ≤ ExcessReserve × QE Fraction
QE Budget ≤ Monthly QE Cap
```

Off-chain модель ограничивает долю excess reserve, используемую QE, диапазоном 0–25%. В текущем наборе кандидатов используются профили 0%, 5%, 10%, 15% и 20%.

Направления QE:

- увеличение owned LP;
- bridge liquidity;
- insurance.

QE не создаёт мгновенный NAV. При переносе:

```text
Liquid reserve уменьшается
Owned LP / Bridge capital / Insurance увеличивается
Execution costs уменьшают совокупный NAV
```

Положительный эффект возникает позже, если новый капитал создаёт дополнительные комиссии, yield, bridge fees или снижает ожидаемые потери.

---

# ЧАСТЬ IV. ИИ-МАРКЕТМЕЙКЕР

## 12. `25_SHTENCOMarketMaker.sol`

### 12.1. Функции

- `executeSwap()` — rebalance inventory;
- `addLiquidity()` — добавление V2 liquidity;
- `executeBuybackAndBurn()` — swap и burn;
- `transferInventory()` — возврат неиспользованного inventory в treasury.

### 12.2. Ограничения

- allowlist router;
- allowlist token;
- allowlist burnable token;
- независимый `priceGuard`;
- максимальное отклонение от oracle — по умолчанию 150 bps;
- максимальный возраст oracle — по умолчанию 30 минут;
- максимальный deadline window — 5 минут;
- pair cooldown — по умолчанию 60 секунд;
- daily notional limit по входному токену;
- ненулевой `minAmountOut`;
- ratio check для LP;
- LP-токены отправляются прямо в treasury;
- approvals обнуляются после операции.

### 12.3. Задачи ИИ-маркетмейкера

- уменьшать отклонение spot-цены от reference price;
- поддерживать двустороннюю ликвидность;
- снижать slippage;
- распределять inventory между токенами;
- увеличивать принадлежащую системе долю LP;
- выполнять buyback только в допустимом режиме.

### 12.4. Что market maker не должен делать

- wash trading;
- последовательные сделки ради volume KPI;
- торговать против собственного stale oracle;
- использовать тот же тонкий пул как единственный oracle;
- покупать токен существенно выше fundamental value;
- расходовать reserve floor;
- скрывать убыток за счёт старого inventory.

### 12.5. Важное архитектурное уточнение

Сам контракт MarketMaker проверяет oracle price и slippage, но **не вычисляет fundamental price**. Условие «buyback только около или ниже fundamental value» реализуется off-chain моделью и политикой proposal. Для полного fail-closed режима это условие желательно дополнительно закрепить отдельным on-chain valuation guard.

---

# ЧАСТЬ V. МОСТ И МОСТОВОЙ QE

## 13. `23_SHTENCOBridgeRelayV2.sol`

### 13.1. Два режима актива

1. `ESCROW`:
   - canonical token блокируется на source chain;
   - на обратном пути средства выпускаются из escrow.

2. `MINT_BURN`:
   - wrapped token сжигается на source;
   - mint выполняется на destination.

### 13.2. Wrapped SYNA

`SHTENCOWrappedSYNA`:

- ERC-20;
- capped supply;
- `BRIDGE_ROLE`;
- `PAUSER_ROLE`;
- mint/burn только bridge-ролью.

### 13.3. Защита сообщений

- EIP-712 typed message;
- M-of-N signatures;
- отсортированные уникальные подписи;
- validator epoch;
- source/target chain;
- source/target bridge;
- source nonce;
- token mapping;
- deadline;
- replay protection по полному hash;
- дополнительная replay protection по `(sourceChainId, sourceBridge, sourceNonce)`.

Двойная replay protection закрывает повторную обработку того же source transfer с изменённым deadline.

### 13.4. Лимиты

- fee не выше 1%;
- maximum future deadline — 7 дней;
- min transfer;
- max per transaction;
- daily outbound limit;
- daily inbound limit;
- pause всей системы;
- pause отдельной chain route;
- exact transfer check — fee-on-transfer токены отклоняются.

### 13.5. Backing health

Для escrow-token контракт может показать:

```text
balance
escrow liability
delta = balance − liability
```

Отрицательный delta должен блокировать inbound release и запускать аварийную процедуру.

---

## 14. `24_SHTENCOBridgeQEReserve.sol`

Отдельный операционный резерв для мостовой ликвидности.

Для каждого токена задаются:

- enabled;
- minimum reserve;
- daily allocation limit.

Капитал можно отправить только разрешённому recipient. Все выделения учитываются по `purpose`.

Контракт сам не mint-ит активы.

---

## 15. `27_SHTENCOBridgeQEAdapter.sol`

Adapter — ограниченный переход между BridgeQEReserve и RelayBridge.

Route policy задаёт:

- bridge;
- token;
- target chain;
- enabled;
- max per transaction;
- daily limit.

Recipient отдельно allowlisted для target chain.

Последовательность:

```text
Treasury BRIDGE bucket
  → BridgeQEReserve
  → BridgeQEAdapter inventory
  → approved bridgeOut
  → relay signatures
  → destination liquidity address
```

Adapter не предоставляет arbitrary approvals и после `bridgeOut()` обнуляет allowance.

---

## 16. Экономический смысл Bridge QE

Bridge QE предназначен для перемещения обеспеченного капитала в сеть, где:

- недостаточна ликвидность;
- выше реальный пользовательский спрос;
- ожидаются bridge fees;
- доступен дополнительный торговый объём;
- существует возможность безопасно увеличить owned LP;
- можно сократить price divergence между сетями.

### Bridge QE увеличивает фундаментальную стоимость только тогда, когда

```text
Дополнительные bridge fees
+ дополнительные LP fees
+ новый внешний спрос
+ экономия на арбитражных дисбалансах
> relay costs
+ gas
+ expected bridge loss
+ cost of idle capital
```

Сам перевод резерва между сетями фундаментальную стоимость не увеличивает.

---

# ЧАСТЬ VI. ЭКОНОМИЧЕСКИЙ ORACLE И УПРАВЛЕНИЕ ИИ

## 17. `28_SHTENCOSystemStateOracle.sol`

### 17.1. Задача

Независимые reporters отправляют одинаковый экономический snapshot. После достижения threshold snapshot финализируется on-chain.

### 17.2. Входные данные snapshot

- liquid reserves;
- liabilities;
- owned liquidity NAV;
- bridge capital;
- circulating supply;
- protocol revenue 30d;
- market price;
- volatility;
- peg error;
- bridge imbalance;
- liquidity coverage;
- external data hash.

Все денежные значения должны быть приведены к одной 18-decimal unit — например USD 1e18 или WPOL 1e18.

### 17.3. On-chain формулы

```text
GrossAssets = LiquidReserves + OwnedLiquidityNAV + BridgeCapital

BackingNAV = GrossAssets − Liabilities

DiscountedRevenueValue = ProtocolRevenue30d
                         × RevenueHaircutBps
                         × RevenueHorizonMonths
                         / 10 000

FundamentalMCap = BackingNAV + DiscountedRevenueValue

FundamentalPrice = FundamentalMCap / CirculatingSupply

MarketCap = MarketPrice × CirculatingSupply

ReserveRatio = LiquidReserves / Liabilities

ValuationPremium = MarketCap / FundamentalMCap
```

По умолчанию:

- revenue haircut — 50%;
- revenue horizon — 12 месяцев.

### 17.4. M-of-N свойства

- каждый reporter голосует один раз в round;
- финализируется только одинаковый `snapshotHash`;
- threshold не может превышать reporter count;
- удаление reporter не может нарушить threshold;
- governance может отменить зависший round;
- externalDataHash связывает snapshot с внешним набором доказательств.

### 17.5. Важное расхождение модели и контракта

Off-chain `defi_top_ai` включает `insurance_fund` отдельным компонентом BackingNAV:

```text
LiquidReserves + OwnedLP + BridgeCapital + Insurance − Liabilities
```

Текущий on-chain `SnapshotInput` отдельного поля `insuranceFund` не содержит.

Следовательно, до mainnet необходимо выбрать один из двух вариантов:

1. включать страховой фонд в `liquidReserves` с явной документацией; или
2. обновить `SystemStateOracle`, добавив отдельное поле `insuranceFund`.

Второй вариант прозрачнее и уменьшает риск двойного учёта.

---

## 18. `30_SHTENCOTopAIController.sol`

### 18.1. Роли

- `AI_PROPOSER_ROLE` — создаёт proposal;
- `EXECUTOR_ROLE` — исполняет после timelock;
- `POLICY_ROLE` — настраивает политики;
- `GUARDIAN_ROLE` — отменяет и ставит на pause;
- `DEFAULT_ADMIN_ROLE` — высшая административная роль.

Роли должны принадлежать разным ключам или multisig.

### 18.2. Action

Каждое действие содержит:

- target;
- native value;
- calldata;
- budget token;
- budget amount.

Максимум 12 действий в одном proposal.

### 18.3. Proposal metadata

- snapshot round;
- objective hash;
- expected NAV delta;
- max capital at risk;
- model risk bps;
- execute after;
- expires at.

### 18.4. Дефолтные ограничения исходника

| Параметр | Значение |
|---|---:|
| Minimum delay | 15 минут |
| Maximum delay | 3 дня |
| Execution window | 1 день |
| Maximum snapshot age | 30 минут |
| Maximum model risk | 25% |
| Maximum capital at risk | 10% liquid reserves |
| Maximum state deterioration | 2% |
| Minimum reserve ratio | 120% |
| Maximum valuation premium | 2,0× |
| Maximum volatility | 75% в шкале bps модели |
| Maximum peg error | 12% |
| Maximum bridge imbalance | 35% |
| Minimum liquidity coverage | 20% |

Это исходные технические defaults, а не автоматически оптимальные mainnet-параметры.

### 18.5. Проверка при propose

- snapshot существует и свежий;
- backing NAV положительный;
- fundamental mcap не ниже backing;
- risk indicators проходят политику;
- snapshot round совпадает;
- expected NAV delta > 0;
- model risk не превышен;
- capital at risk не превышает долю liquid reserves;
- target разрешён;
- selector разрешён;
- для risk-action указан budget;
- timelock и expiry находятся в допустимом диапазоне.

### 18.6. Повторная проверка при execute

- proposal существует;
- не исполнен и не отменён;
- timelock истёк;
- proposal не просрочен;
- oracle snapshot свежий;
- нет oracle rollback;
- backing NAV не ухудшился более чем на лимит;
- fundamental mcap не ухудшился более чем на лимит;
- target/selector всё ещё разрешены;
- дневной budget не превышен;
- все действия исполняются атомарно.

### 18.7. Граница ответственности

Контроллер подтверждает **допустимость** решения, но не доказывает математическую истинность ожидаемого NAV delta. Значения `expectedNavDelta`, `objectiveHash` и `modelRiskBps` формируются off-chain proposer.

Для усиления можно добавить:

- отдельный model-attestation quorum;
- on-chain post-condition по balance delta;
- action-specific minimum outcome;
- независимый simulation hash;
- optimistic challenge period;
- governance veto.

---

## 19. `31_SHTENCODeFiContourRegistry.sol`

Регистрирует девять обязательных production-модулей:

1. State Oracle;
2. TOP AI Controller;
3. Value Treasury;
4. Flash Arbitrage;
5. Market Maker;
6. Flash Harvester;
7. Bridge Reserve;
8. Bridge Adapter;
9. Relay Bridge.

`validateContour()` возвращает true только при наличии всех обязательных адресов.

`topologyHash()` позволяет зафиксировать конкретную конфигурацию системы и обнаруживать изменение адресов.

---

# ЧАСТЬ VII. OFF-CHAIN ИИ-ЦЕНТРОБАНК

## 20. Python-пакет `defi_top_ai`

### `models.py`

Определяет:

- `SystemState`;
- `RevenueAllocation`;
- `Decision`;
- `ModelPolicy`;
- `Metrics`;
- `SimulationResult`.

### `econometrics.py`

- рассчитывает фундаментальные показатели;
- применяет stochastic month;
- моделирует доходы, расходы и tail-risk;
- не считает internal price impact стоимостью;
- ограничивает buyback фундаментальной оценкой;
- моделирует QE как reclassification капитала.

### `optimizer.py`

Создаёт 90 candidate policies:

- 6 allocation-профилей;
- 5 QE-профилей;
- 3 уровня flash-search intensity.

Allocation-профили:

- DEFENSIVE;
- BALANCED;
- LIQUIDITY;
- BRIDGE;
- BUYBACK;
- RESERVE.

QE fractions:

- 0%;
- 5%;
- 10%;
- 15%;
- 20% excess reserve.

Flash intensity:

- 35%;
- 65%;
- 90%.

### `proposal.py`

Преобразует выбранное решение в человекочитаемый value-cycle plan:

- harvest flash profit;
- record revenue;
- allocate buckets;
- deploy liquidity;
- bridge rebalance;
- buyback;
- reserve QE;
- insurance.

### `cli.py`

Запускает optimizer и пишет JSON-решение.

Встроенный default state — демонстрационный и не является live mainnet snapshot.

---

## 21. Эконометрическая модель

### 21.1. Off-chain Backing NAV

```text
BackingNAV = LiquidReserves
           + OwnedLiquidityNAV
           + BridgeCapital
           + InsuranceFund
           − Liabilities
```

### 21.2. Чистый 30-дневный доход

```text
NetRevenue30d = ProtocolFeeRevenue
              + FlashProfit
              + YieldRevenue
              + BridgeFeeRevenue
              − OperatingCost
              − GasCost
              − RealizedLosses
```

В текущем Python `metrics()` realized losses не передаются отдельным полем, а уменьшают state assets в ходе stochastic simulation. Для бухгалтерского production pipeline их желательно хранить отдельно.

### 21.3. Дисконтированная стоимость дохода

```text
DiscountedRevenueValue = max(NetRevenue30d, 0)
                       × RevenueHorizonMonths
                       × RevenueHaircut
```

Default:

- horizon — 12 месяцев;
- haircut — 50%.

### 21.4. Fundamental mcap и price

```text
FundamentalMCap = BackingNAV + DiscountedRevenueValue

FundamentalPrice = FundamentalMCap / CirculatingSupply
```

### 21.5. Market metrics

```text
MarketMCap = MarketPrice × CirculatingSupply

ValuationPremium = MarketMCap / FundamentalMCap

ReserveRatio = LiquidReserves / Liabilities
```

### 21.6. Liquidity coverage

Off-chain модель оценивает ожидаемое давление продаж:

```text
ExpectedSellPressure = max(
    MonthlyVolume × 15%,
    Liabilities × 3%
)

LiquidityCoverage = LiquidityDepth / ExpectedSellPressure
```

### 21.7. Sustainable monthly growth

```text
SustainableMonthlyGrowth = NetRevenue30d / BackingNAV
```

Это более полезный KPI, чем изменение spot market cap.

---

## 22. Целевая функция ИИ

```text
Score = ExpectedFundamentalGrowth × 1.00
      + ExpectedBackingGrowth × 0.65
      + ExpectedFundamentalPriceGrowth × 0.20
      + LiquidityReward
      − ReserveDeficitPenalty
      − BridgeImbalancePenalty
      − LossProbabilityPenalty
      − CVaRDownsidePenalty
```

ИИ не выбирает действие по одному прогнозу доходности. Он учитывает:

- средний результат;
- tail result;
- вероятность убытка;
- reserve ratio;
- liquidity coverage;
- bridge imbalance;
- фундаментальную цену;
- капитал под риском.

Если hard policy не проходит, optimizer рассматривает только defensive candidates с QE = 0.

---

## 23. Stochastic-модель одного месяца

Моделируются:

- demand shock;
- yield shock;
- bridge demand shock;
- flash opportunity;
- adverse execution;
- gas;
- operating cost;
- liquidity slippage;
- relay cost;
- buyback slippage;
- security tail loss;
- bridge loss;
- LP stress loss;
- изменение рыночной цены;
- mean reversion к fundamental price.

Важный принцип:

```text
Liquidity deployment и Bridge QE не создают мгновенный NAV.
Они увеличивают будущую fee capacity.
```

---

# ЧАСТЬ VIII. ИСТОЧНИКИ РОСТА ФУНДАМЕНТАЛЬНОЙ СТОИМОСТИ

## 24. Карта источников стоимости

| Источник | Прямой рост Backing NAV | Рост будущего revenue | Снижение риска | Уменьшение supply |
|---|---:|---:|---:|---:|
| Protocol fees | Да | Да | Нет | Нет |
| Owned LP fees | Да | Да | Частично | Нет |
| Net flash arbitrage | Да | Да | Нет | Нет |
| Reserve yield | Да | Да | Частично | Нет |
| Bridge fees | Да | Да | Нет | Нет |
| Bridge QE | Нет мгновенно | Потенциально | Может снизить imbalance | Нет |
| Liquidity QE | Нет мгновенно | Потенциально | Снижает slippage | Нет |
| Insurance allocation | Переклассификация | Нет | Да | Нет |
| Buyback and burn | Обычно нет | Косвенно | Зависит от цены | Да |
| Снижение gas/ops | Да через меньшие расходы | Да | Нет | Нет |
| Погашение liabilities | Да | Да | Да | Нет |
| Предотвращение exploit/loss | Сохраняет NAV | Сохраняет revenue | Да | Нет |

---

## 25. Источник №1 — комиссии протокола

Реальные комиссии пользователей являются базовым источником денежного потока.

Фундаментальный эффект:

```text
User activity
  → protocol fee
  → exact receipt
  → Treasury revenue
  → reserve / LP / bridge / insurance
```

Комиссия создаёт стоимость только после фактического получения. Начисление без перевода не должно увеличивать revenue.

Ключевые KPI:

- gross protocol fees;
- fee collection success rate;
- net fees after rebates;
- fees retained by protocol;
- fee revenue per unit of TVL;
- fee revenue per gas unit;
- recurring vs one-off fees.

---

## 26. Источник №2 — DEX fees на принадлежащей системе LP-доле

Если система владеет LP-токенами, торговые комиссии увеличивают стоимость её доли.

Учитывать нужно только:

```text
OwnedLPShare × PoolNAV
```

Нельзя учитывать весь pool TVL.

LP NAV должен оцениваться по независимым reference prices, иначе внутренний swap может нарисовать рост NAV.

Факторы результата:

- торговый объём;
- fee tier;
- доля LP;
- impermanent loss;
- price range;
- токсичный order flow;
- MEV;
- gas ребалансировки.

---

## 27. Источник №3 — чистая внешняя flash-arbitrage прибыль

```text
NetFlashProfit = GrossArbitrageOutput
               − AavePremium
               − DEXFees
               − Gas
               − Slippage
               − MEVRiskMargin
```

Только `NetFlashProfit > 0` может быть записана как revenue.

Устойчивость источника зависит от:

- количества DEX;
- глубины пулов;
- конкуренции searchers;
- latency;
- private transaction routing;
- gas price;
- частоты дисбалансов;
- качества route optimizer.

Flash income не следует капитализировать агрессивно, потому что opportunities конкурентны и нестабильны.

---

## 28. Источник №4 — доходность ликвидных резервов

Резерв может приносить yield через разрешённые низкорисковые стратегии.

```text
NetReserveYield = GrossYield
                − ProtocolRiskCost
                − Gas
                − WithdrawalCost
                − ExpectedLoss
```

Доходность нельзя считать безрисковой. Для каждого yield source нужны:

- cap;
- liquidity window;
- oracle;
- withdrawal test;
- protocol exposure limit;
- counterparty risk;
- pause;
- emergency exit.

---

## 29. Источник №5 — bridge fees

Bridge fee является внешним доходом, когда пользователь платит за реальный межсетевой перевод.

```text
NetBridgeRevenue = BridgeFees
                 − RelayGas
                 − ValidatorOperations
                 − RebalancingCost
                 − ExpectedBridgeLoss
```

Рост bridge volume без достаточного страхования может повышать revenue и одновременно резко увеличивать tail-risk.

---

## 30. Источник №6 — рост будущих комиссий от Liquidity QE

Добавление owned LP не создаёт стоимость в момент операции, но может:

- увеличить долю будущих DEX fees;
- снизить slippage;
- увеличить допустимый размер сделок;
- привлечь арбитражный и пользовательский объём;
- уменьшить ценовые разрывы;
- повысить ликвидность выхода для держателей.

Положительный NPV:

```text
PV Additional LP Fees
> Slippage + Gas + Impermanent Loss + Capital Cost + Smart Contract Risk
```

---

## 31. Источник №7 — рост будущих комиссий от Bridge QE

Bridge QE может открыть новый рынок и увеличить:

- bridge fees;
- LP fees в удалённой сети;
- количество маршрутов;
- network utility;
- внешний спрос.

Однако эффект должен измеряться по cohort:

- capital deployed;
- additional net fees;
- payback period;
- bridge imbalance;
- loss rate;
- idle capital ratio.

---

## 32. Источник №8 — страховой фонд

Insurance не создаёт валовый доход, но повышает риск-скорректированную стоимость, потому что уменьшает ожидаемую потерю при:

- bridge incident;
- smart-contract exploit;
- LP stress;
- bad debt;
- oracle failure.

```text
RiskAdjustedValue = ExpectedValue − ExpectedLoss − TailRiskPenalty
```

Страховой фонд полезен только при чётких правилах использования. Иначе он превращается в общий резерв, который может быть изъят для других целей.

---

## 33. Источник №9 — buyback-and-burn

Buyback не создаёт новые активы. Он обменивает резервный актив на собственный токен и затем уничтожает токен.

Buyback может повысить **fundamental price per token**, если:

- токен куплен около или ниже fundamental price;
- средства взяты из реализованного revenue bucket;
- reserve ratio остаётся безопасным;
- ликвидность достаточна;
- buyback не вызывает чрезмерный price impact;
- уменьшение supply устойчиво.

Buyback может уничтожить фундаментальную стоимость, если система покупает сильно переоценённый токен за качественный резервный актив.

---

## 34. Источник №10 — снижение расходов

Каждая экономия напрямую увеличивает net revenue:

- gas optimization;
- batching;
- уменьшение failed transactions;
- оптимизация bridge routes;
- отказ от убыточных flash attempts;
- сокращение keeper overhead;
- снижение validator infrastructure cost;
- устранение дублирующего учёта.

```text
ΔFundamentalValue ≈ PV avoided future costs
```

---

## 35. Источник №11 — снижение liabilities

Если система имеет реальные обязательства, их погашение увеличивает Backing NAV при неизменных активах:

```text
BackingNAV = Assets − Liabilities
```

Важно: burn токена не всегда означает погашение обязательства. Необходимо определить, представляет ли конкретный токен юридическое/экономическое требование к резерву.

---

## 36. Источник №12 — предотвращение потерь

Security controls являются источником сохранённой стоимости:

- timelock;
- multisig;
- M-of-N oracle;
- bridge threshold;
- daily limits;
- reserve floor;
- selector allowlist;
- pause;
- stale oracle rejection;
- replay protection;
- exact balance accounting;
- minimum output;
- independent audit.

Предотвращённый exploit не отображается как revenue, но сохраняет Backing NAV.

---

## 37. Потенциальные источники, которых текущий код не доказывает

Следующие источники могут появиться в будущем, но текущая сборка не содержит достаточных данных, чтобы учитывать их как существующий revenue:

- lending spread;
- liquidation fees;
- stablecoin seigniorage;
- subscription revenue;
- SaaS/API fees;
- institutional market-making contracts;
- external staking rewards;
- RWA income;
- governance-service fees;
- data/oracle licensing.

Они должны добавляться в модель только после появления реальных контрактов, транзакций и проверяемой revenue history.

---

# ЧАСТЬ IX. ЧТО НЕ ЯВЛЯЕТСЯ ФУНДАМЕНТАЛЬНЫМ РОСТОМ

## 38. Internal price impact

Покупка токена из собственного резерва может поднять spot price и market cap, но уменьшить резерв. Если токен переоценён, fundamental NAV падает.

## 39. Wash volume

Wash volume генерирует комиссии внутри системы, но одновременно несёт gas, slippage и regulatory/reputation risk. Он не считается устойчивым внешним спросом.

## 40. Unbacked mint

Mint увеличивает supply. Без нового backing или utility он снижает fundamental price.

## 41. Flash principal

Flash principal возвращается в той же транзакции и никогда не входит в NAV.

## 42. Bridge mint без liability

Wrapped token должен сопровождаться escrow liability или burn на source chain. Иначе создаётся необеспеченное обязательство.

## 43. Полный TVL чужого пула

Система учитывает только owned share. Пользовательская LP-ликвидность не является активом казначейства.

## 44. Reclassification

Перемещение 100 WPOL из Reserve в Bridge не даёт +100 WPOL NAV. Совокупные активы остаются теми же за вычетом costs.

---

# ЧАСТЬ X. ВНУТРЕННИЙ РЫНОК И СИМУЛЯЦИЯ 20 ИИ-РОБОТОВ

## 45. Конфигурация симуляции

Проведён synthetic stress-test:

- 180 дней;
- 20 ИИ-роботов;
- 4 TOKEN/WPOL пула;
- 400 Monte Carlo trajectories;
- по 100 траекторий на 4 сценария;
- constant-product AMM;
- DEX fee 0,30%;
- моделируемая protocol fee 0,50%;
- AI MarketMaker;
- FeeRouter;
- ValueFlow Treasury;
- flash revenue;
- bridge fees;
- reserve yield;
- QE;
- insurance;
- tail-risk.

Protocol fee 0,50% — явное допущение симуляции, поскольку TroikaCore не фиксирует ставку в исходнике.

## 46. Типы роботов

- 5 noise;
- 4 momentum;
- 4 mean reversion;
- 3 arbitrage;
- 2 whale;
- 2 defensive.

Роботы имеют разные размеры сделок, направления и реакцию на отклонение spot/reference price.

## 47. Начальные пулы stress-test

Из deployment-скрипта:

| Пул | Token reserve | WPOL reserve |
|---|---:|---:|
| SYNA/WPOL | 800 | 4 |
| SYNC/WPOL | 8 000 | 4 |
| SYNR/WPOL | 400 | 4 |
| ALTN/WPOL | 2 000 | 4 |

Суммарная стартовая WPOL-сторона — около 16 WPOL. Это чрезвычайно тонкая ликвидность относительно supply.

Сценарий `capitalized` умножает обе стороны пулов на 25 при сохранении цены.

## 48. Результаты

| Сценарий | Средний Δ market cap | Средний Δ fundamental mcap | Средний max drawdown | Финальный reserve ratio | Valuation premium |
|---|---:|---:|---:|---:|---:|
| Текущая глубина + TOP AI | +97,52% | +5,10% | −25,72% | 1,658 | 940,9× |
| Текущая глубина без AI | +51,23% | +4,19% | −34,03% | 1,650 | 729,9× |
| Ликвидность ×25 + TOP AI | +3,34% | +4,04% | −10,31% | 1,661 | 282,4× |
| Ликвидность ×25 без AI | +12,73% | +3,24% | −12,70% | 1,653 | 311,1× |

Основная траектория `deployed_ai`:

- 5 294 сделки;
- оборот 225,841 WPOL;
- protocol fees 1,129 WPOL;
- DEX fees 0,703 WPOL;
- net flash-profit 4,427 WPOL;
- медианная доходность робота по reference prices −11,40%;
- прибыльных роботов 25%.

## 49. Интерпретация

Рост spot market cap при текущих пулах главным образом объясняется thin-liquidity price impact. Фундаментальная стоимость растёт значительно медленнее.

При глубине ×25 AI даёт меньший спекулятивный рост, но:

- уменьшает drawdown;
- удерживает цены ближе к reference;
- повышает фундаментальный результат;
- снижает риск неконтролируемого price impact.

Текущий valuation premium значительно выше policy limit 2×. Следовательно, production AI должен блокировать агрессивный buyback и QE до появления реального backing, revenue или более корректной market valuation.

Симуляция не является mainnet forecast, потому что архив не содержал свежего on-chain snapshot резервов.

---

# ЧАСТЬ XI. КАНОНИЧЕСКИЕ ОПЕРАЦИОННЫЕ ЦИКЛЫ

## 50. Цикл flash-profit

```text
1. Scanner получает live quotes.
2. Рассчитывает Aave premium, gas, slippage и margin.
3. Выбирает cyclic route.
4. Operator вызывает startArbitrage().
5. Aave выдаёт principal.
6. executeOperation() исполняет swaps.
7. Если final balance < principal + premium + minProfit — revert.
8. Aave получает principal + premium.
9. Остаток остаётся realized profit.
10. Timelocked proposal вызывает Harvester.
11. Harvester переводит exact profit в Treasury.
12. Treasury регистрирует unique sourceId.
13. TOP AI распределяет revenue.
```

## 51. Цикл revenue allocation

```text
Revenue received
  → recordRevenue
  → unallocatedRevenue
  → allocateRevenue
  → six buckets
  → releases only to allowed sinks
```

## 52. Цикл Liquidity QE

```text
Fresh economic snapshot
  → calculate excess reserves
  → AI compares LP NPV and risk
  → proposal
  → timelock
  → reclassify RESERVE to LIQUIDITY
  → release to MarketMaker
  → oracle-bounded addLiquidity
  → LP tokens to Treasury
  → future fees measured separately
```

## 53. Цикл Bridge QE

```text
Network liquidity deficit
  → verified bridge imbalance
  → AI evaluates fees/cost/risk
  → reclassify RESERVE or use BRIDGE revenue bucket
  → BridgeQEReserve
  → BridgeQEAdapter
  → bridgeOut
  → finalized source event
  → independent validator signatures
  → destination completeInbound
  → destination LP / reserve
```

## 54. Цикл buyback

```text
Realized revenue
  → BUYBACK bucket
  → market price vs fundamental price check
  → reserve and risk gates
  → oracle-bounded swap
  → burn
  → circulating supply update
```

## 55. Цикл AI proposal

```text
Reporters finalize snapshot
  → optimizer generates candidates
  → Monte Carlo evaluation
  → best risk-adjusted decision
  → intent JSON
  → calldata materialization using live balances/quotes
  → propose against exact snapshot round
  → timelock
  → new snapshot
  → recheck all policies
  → execute atomically or cancel
```

---

# ЧАСТЬ XII. РОЛИ И ГРАНИЦЫ ДОВЕРИЯ

## 56. Рекомендуемое разделение ролей

| Роль | Назначение | Рекомендуемый владелец |
|---|---|---|
| Default Admin | изменение ролей | Governance multisig + timelock |
| Policy | лимиты и allowlists | отдельный policy multisig |
| AI Proposer | создание proposal | изолированный AI service key |
| Executor | выполнение после delay | automation key / multisig |
| Guardian | pause/cancel | emergency multisig |
| State Reporter | economic snapshot | независимые data pipelines |
| Bridge Validator | подписи transfer | отдельные организации/ключи |
| Relay Submitter | отправка signatures | отдельный сервис без validator quorum |
| Revenue Recorder | запись подтверждённого revenue | Harvester/approved fee collector |
| Controller | денежные действия | TOP AI Controller |

Нельзя хранить несколько validator private keys в одном процессе.

---

# ЧАСТЬ XIII. FAIL-CLOSED ПОЛИТИКА

## 57. Система должна остановить действия, если

- нет M-of-N snapshot;
- snapshot устарел;
- backing NAV отрицателен;
- liabilities превышают gross assets;
- reserve ratio ниже минимума;
- valuation premium выше лимита;
- volatility выше лимита;
- peg error выше лимита;
- bridge imbalance выше лимита;
- liquidity coverage ниже лимита;
- state ухудшился после propose;
- proposal просрочен;
- timelock не истёк;
- target или selector запрещён;
- budget превышен;
- oracle stale;
- router quote ниже minimum;
- bridge route paused;
- validator epoch изменился;
- escrow backing недостаточен;
- exact balance delta не совпала;
- sourceId уже обработан;
- reserve floor нарушается.

---

# ЧАСТЬ XIV. ОСНОВНЫЕ KPI

## 58. Фундаментальные KPI

- Backing NAV;
- Fundamental MCap;
- Fundamental Price;
- Net Revenue 30d;
- Sustainable Monthly Growth;
- Liquid Reserve Ratio;
- Liabilities;
- Insurance Coverage;
- Owned LP NAV;
- Bridge Capital;
- Valuation Premium.

## 59. Доходные KPI

- protocol fee revenue;
- owned LP fees;
- flash net profit;
- reserve yield;
- bridge fees;
- revenue retention ratio;
- gas/revenue ratio;
- operations/revenue ratio.

## 60. Ликвидностные KPI

- liquidity depth;
- slippage at 1/5/10% reserve trade;
- owned LP share;
- LP utilization;
- volume/TVL;
- price deviation from reference;
- market-maker PnL;
- inventory imbalance.

## 61. Bridge KPI

- outbound/inbound volume;
- net bridge fees;
- capital deployed by network;
- imbalance;
- escrow backing delta;
- average finality;
- failed relay rate;
- validator availability;
- insurance/bridge exposure ratio.

## 62. AI KPI

- proposal acceptance rate;
- proposal cancellation rate;
- realized vs expected NAV delta;
- model forecast error;
- CVaR;
- probability of loss;
- capital at risk;
- policy block reasons;
- stale snapshot frequency.

---

# ЧАСТЬ XV. DEPLOYMENT И ЗАПУСК

## 63. Минимальный порядок production deployment

1. Зафиксировать accounting unit.
2. Получить live balances и liabilities.
3. Проверить token decimals.
4. Проверить router/factory/pool addresses.
5. Развернуть bridge endpoints.
6. Настроить validators и threshold.
7. Настроить peers и token routes.
8. Настроить caps и escrow.
9. Развернуть StateOracle.
10. Настроить независимых reporters.
11. Развернуть ValueFlowTreasury.
12. Настроить token policies, reserve floors и sinks.
13. Развернуть MarketMaker и independent price guard.
14. Развернуть BridgeQEReserve и Adapter.
15. Развернуть FlashLoanArbitrage и Harvester.
16. Развернуть TOP AI Controller.
17. Настроить target/selector allowlists.
18. Настроить daily budgets.
19. Развернуть Registry и проверить contour hash.
20. Передать admin multisig/timelock.
21. Выполнить pinned-block fork-test.
22. Запустить low-limit canary.
23. Увеличивать лимиты только после наблюдения.

---

## 64. Локальные команды

### Установка flash-модуля

```powershell
npm install
py -m pip install -r requirements_flash_arb.txt
Copy-Item .env.flash.example .env.flash
```

### Проверка flash scanner

```powershell
py flash_arb_bot.py --once --top 10
```

### TOP AI optimizer

```powershell
$env:PYTHONPATH="."
py -m defi_top_ai.cli --scenarios 500 --months 6
```

### Value-cycle plan

```powershell
py -m defi_top_ai.proposal deployments\defi-top-ai-decision.json `
  --profit-amount 10 `
  --token USDC
```

### AI + Bridge fork

```powershell
cd SHTENCO_QE_BRIDGE_AI
npm install
py -m pip install -r requirements_ai.txt
py -m pip install -r requirements_relay.txt
node node_modules\hardhat\internal\cli\cli.js compile
node node_modules\hardhat\internal\cli\cli.js test
```

### Mainnet broadcast safety

Submission scripts требуют отдельного `LIVE_EXECUTION=1` и `--broadcast`. До независимой проверки использовать только dry-run.

---

# ЧАСТЬ XVI. ТЕСТЫ И ТЕКУЩИЙ СТАТУС

## 65. Зафиксированные результаты сборки

- 36 основных Solidity source files;
- 160 contracts/interfaces/libraries;
- 0 fatal compiler errors;
- 58 Python files прошли AST parsing;
- 20 JavaScript files прошли `node --check`;
- 31 тест пройден.

Тестовая разбивка:

- 5 flash-loan math tests;
- 6 legacy AI economic tests;
- 7 bridge/AI Hardhat tests;
- 5 TOP AI integration tests;
- 8 TOP AI econometric tests.

Mainnet-транзакции нового unified contour не отправлялись.

---

# ЧАСТЬ XVII. ИЗВЕСТНЫЕ ОГРАНИЧЕНИЯ И ТЕХНИЧЕСКИЙ ДОЛГ

## 66. Legacy-контракты

- zero timelocks в части исходной системы;
- spot-based collateral valuation;
- rolling spot average вместо полноценного cumulative TWAP;
- пустые `catch`;
- слабые minimum outputs в ALTN/MutualPool logic;
- риск расхождения virtual LP и chain reserves;
- accounting counters, изменяемые при failed mint;
- privileged Vault transfers.

## 67. Unified TOP AI

- expected NAV delta формируется off-chain;
- отдельного on-chain insurance field пока нет;
- MarketMaker не знает fundamental price напрямую;
- protocol revenue snapshot агрегирован и зависит от reporters;
- oracle correctness зависит от независимости data pipelines;
- M-of-N bridge остаётся доверенной validator model;
- model calibration пока не основана на полной live history;
- liquidity simulation использовала deployment reserves, а не свежий chain snapshot.

## 68. Что обязательно сделать до крупного TVL

- независимый аудит;
- formal verification критических invariants;
- bug bounty;
- multisig;
- governance timelock;
- отдельные ключи ролей;
- независимые oracle reporters;
- полноценный liabilities ledger;
- on-chain insurance accounting;
- action-specific postconditions;
- live Polygon fork на фиксированном блоке;
- MEV/private routing plan;
- canary limits;
- emergency drills.

---

# ЧАСТЬ XVIII. ИНВАРИАНТЫ

## 69. Treasury invariants

```text
ActualTokenBalance ≥ ClassifiedBalance

ClassifiedBalance =
  UnallocatedRevenue
  + Σ BucketBalances

Processed sourceId cannot be reused

Reserve after release ≥ ReserveFloor
```

## 70. Bridge invariants

```text
ESCROW balance ≥ EscrowLiability

Each source transfer processed at most once

Inbound amount requires M-of-N signatures

Wrapped minted amount corresponds to source lock/burn
```

## 71. Flash invariants

```text
FinalAssetBalance ≥ Principal + Premium + MinProfit

No active flash rescue

Route starts and ends in borrowed asset
```

## 72. AI invariants

```text
Every action target is allowlisted
Every selector is allowlisted
Every budgeted action stays inside daily limit
Fresh snapshot at propose and execute
Proposal executes once or is cancelled
```

## 73. Fundamental accounting invariants

```text
Flash principal = 0 contribution to NAV
Internal transfer = 0 contribution to NAV
Bridge reclassification = 0 gross contribution before costs
Only owned LP share is an asset
Market price change is not realized revenue
```

---

# ЧАСТЬ XIX. РЕКОМЕНДУЕМАЯ СТРАТЕГИЯ РОСТА

## 74. Этап 1 — бухгалтерская достоверность

- единая unit;
- live balances;
- liabilities ledger;
- owned LP shares;
- external reference prices;
- realized revenue history;
- exact costs;
- insurance accounting.

## 75. Этап 2 — безопасность резервов

- reserve ratio ≥ policy;
- insurance target;
- daily limits;
- multisig/timelock;
- pause tests;
- bridge backing health.

## 76. Этап 3 — реальный доход

Приоритет:

1. protocol fees;
2. owned LP fees;
3. reserve yield;
4. net flash arbitrage;
5. bridge fees.

Не следует начинать с buyback, пока valuation premium экстремально высок.

## 77. Этап 4 — глубокая ликвидность

- увеличить owned LP;
- создавать TOKEN/TOKEN маршруты только с независимым oracle;
- измерять marginal fee yield;
- не масштабировать капитал, если LP NPV отрицателен.

## 78. Этап 5 — межсетевое расширение

- одна canary chain;
- один токен;
- малый cap;
- отдельные validators;
- страховое покрытие;
- измеримый net bridge revenue;
- затем постепенное расширение.

## 79. Этап 6 — buyback

Buyback включать только после выполнения одновременно:

- достаточный reserve ratio;
- valuation около fundamental;
- положительный net revenue;
- нормальная liquidity coverage;
- низкая volatility;
- допустимый bridge risk;
- отдельный revenue-funded BUYBACK bucket.

---

# ЧАСТЬ XX. СТРУКТУРА ПРОЕКТА

## 80. Ключевые файлы

```text
INSTANT_DEPLOY/
├── 00_CircularInterfaces.sol
├── 01_PolygonConfig.sol
├── 02_Tokens.sol
├── 03_TroikaVault.sol
├── 04_TWAPOracle.sol
├── 05_DividendPool.sol
├── 06_FeeRouter.sol
├── 07_EmissionEngine.sol
├── 08_CBArbitrage.sol
├── 09_SelfReinforcingLoop.sol
├── 10_TroikaCore.sol
├── 11_FounderControl.sol
├── 12_TroikaDeployer.sol
├── 13_CollateralEmission.sol
├── 14_CircularHub_v2.sol
├── 15_CircularDeployer.sol
├── 16_AltynCircularPatch.sol
├── 17_EmissionCircular.sol
├── 18_MutualPoolDeployer.sol
├── 19_Altyn_v1_original.sol
├── 19_MutualPoolRouter.sol
├── 22_FlashLoanArbitrage.sol
├── 23_SHTENCOBridgeRelayV2.sol
├── 24_SHTENCOBridgeQEReserve.sol
├── 25_SHTENCOMarketMaker.sol
├── 26_SHTENCOAICentralBank.sol
├── 27_SHTENCOBridgeQEAdapter.sol
├── 28_SHTENCOSystemStateOracle.sol
├── 29_SHTENCOValueFlowTreasury.sol
├── 30_SHTENCOTopAIController.sol
├── 31_SHTENCODeFiContourRegistry.sol
├── 32_SHTENCOFlashProfitHarvester.sol
├── flash_arb_bot.py
├── defi_top_ai/
│   ├── models.py
│   ├── econometrics.py
│   ├── optimizer.py
│   ├── proposal.py
│   └── cli.py
└── SHTENCO_QE_BRIDGE_AI/
    ├── scripts/
    ├── test/
    ├── config/
    └── relay infrastructure
```

---

# ЧАСТЬ XXI. ГЛОССАРИЙ

## 81. Основные термины

**Backing NAV** — чистая стоимость обеспеченных активов после вычета обязательств.

**Fundamental MCap** — Backing NAV плюс консервативная стоимость положительного денежного потока.

**Market MCap** — spot price × circulating supply.

**Valuation Premium** — Market MCap / Fundamental MCap.

**Owned LP NAV** — стоимость только той LP-доли, которая принадлежит системе.

**Realized Revenue** — фактически полученный доход с подтверждённой balance delta.

**QE** — обеспеченное перераспределение excess reserve в продуктивные направления.

**Bridge QE** — перенос обеспеченного капитала в утверждённую удалённую сеть.

**AI Market Maker** — ограниченный исполнитель swaps, LP и buyback.

**TOP AI Controller** — on-chain policy/timelock слой, а не сама ML-модель.

**M-of-N** — threshold, при котором требуется минимум M подписей из N участников.

**CVaR** — средний результат в худшей части распределения.

**Tail risk** — редкая, но крупная потеря.

---

# 82. Итог

SHTENCO DeFi TOP AI v3 построен как система, в которой ИИ не получает неограниченного доступа к капиталу. ИИ:

- анализирует;
- прогнозирует;
- сравнивает сценарии;
- предлагает пакет действий.

Но фактическое действие проходит через:

- независимый M-of-N state oracle;
- hard policy;
- target allowlist;
- selector allowlist;
- budget limits;
- reserve floor;
- timelock;
- повторную проверку состояния;
- guardian cancellation;
- atomic execution.

Устойчивая фундаментальная стоимость может расти только через:

1. реальный внешний доход;
2. рост принадлежащих системе активов;
3. рост устойчивого net revenue;
4. разумное управление supply;
5. снижение liabilities;
6. снижение расходов;
7. снижение вероятности катастрофической потери.

Ни flash loan, ни QE, ни bridge, ни buyback не создают внешнюю стоимость автоматически. Они являются инструментами. Положительный эффект возникает только тогда, когда их дисконтированный будущий доход превышает execution cost, capital cost и риск потери.

---

## 83. Источники, использованные для этого README

Документ составлен по фактическим файлам сборки:

- `DEFI_TOP_AI_FINAL_REPORT.md`;
- `DEFI_TOP_AI_ECONOMETRIC_MODEL.md`;
- `DEFI_TOP_AI_ARCHITECTURE.md`;
- `DEFI_TOP_AI_CONTRACT_MAP.md`;
- `SMART_CONTRACT_MAP.md`;
- `TOP_AI_SECURITY_REPORT.md`;
- `RUN_DEFI_TOP_AI.md`;
- `QE_BRIDGE_AI_FINAL_REPORT.md`;
- `RUN_AI_CENTROBANK_BRIDGE.md`;
- `SHTENCO_QE_BRIDGE_AI/ARCHITECTURE.md`;
- `SHTENCO_QE_BRIDGE_AI/SECURITY_AND_DEPLOYMENT.md`;
- Solidity-контрактам `00`–`32`;
- Python-пакету `defi_top_ai`;
- `defi_internal_market_sim.py`;
- `SIMULATION_REPORT_RU.md`;
- CSV-результатам внутренней симуляции.

Документ не является обещанием доходности, юридическим заключением или заменой независимого аудита.
