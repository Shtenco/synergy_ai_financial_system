// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";

contract MockV2Router {
    using SafeERC20 for IERC20;
    mapping(address => mapping(address => uint256)) public numerator;
    mapping(address => mapping(address => uint256)) public denominator;

    function setRate(address a, address b, uint256 n, uint256 d) external {
        require(n > 0 && d > 0, "bad rate");
        numerator[a][b] = n; denominator[a][b] = d;
    }

    function getAmountsOut(uint256 amountIn, address[] calldata path) external view returns (uint256[] memory amounts) {
        amounts = new uint256[](path.length); amounts[0] = amountIn;
        for (uint256 i = 1; i < path.length; ++i) {
            amounts[i] = amounts[i-1] * numerator[path[i-1]][path[i]] / denominator[path[i-1]][path[i]];
        }
    }

    function swapExactTokensForTokens(uint256 amountIn, uint256 minOut, address[] calldata path, address to, uint256)
        external returns (uint256[] memory amounts)
    {
        amounts = new uint256[](path.length); amounts[0] = amountIn;
        IERC20(path[0]).safeTransferFrom(msg.sender, address(this), amountIn);
        for (uint256 i = 1; i < path.length; ++i) {
            amounts[i] = amounts[i-1] * numerator[path[i-1]][path[i]] / denominator[path[i-1]][path[i]];
        }
        require(amounts[path.length-1] >= minOut, "minOut");
        IERC20(path[path.length-1]).safeTransfer(to, amounts[path.length-1]);
    }

    function addLiquidity(
        address tokenA, address tokenB,
        uint256 amountADesired, uint256 amountBDesired,
        uint256 amountAMin, uint256 amountBMin,
        address, uint256
    ) external returns (uint256 amountA, uint256 amountB, uint256 liquidity) {
        require(amountADesired >= amountAMin && amountBDesired >= amountBMin, "mins");
        IERC20(tokenA).safeTransferFrom(msg.sender, address(this), amountADesired);
        IERC20(tokenB).safeTransferFrom(msg.sender, address(this), amountBDesired);
        return (amountADesired, amountBDesired, amountADesired < amountBDesired ? amountADesired : amountBDesired);
    }
}
