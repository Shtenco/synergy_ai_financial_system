// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {AccessControl} from "@openzeppelin/contracts/access/AccessControl.sol";
import {Pausable} from "@openzeppelin/contracts/utils/Pausable.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";

interface ISHTENCOBridgeEndpoint {
    function bridgeOut(address token, uint256 amount, uint256 targetChainId, address recipient)
        external returns (bytes32 messageId, uint256 nonce);
}

/**
 * @title SHTENCOBridgeQEAdapter
 * @notice Bounded inventory adapter between the reserve and relay bridge. The
 *         reserve can allocate assets to this contract; the AI Central Bank can
 *         then rebalance only explicitly approved bridge/token/chain/recipient
 *         routes. No arbitrary approvals or arbitrary destinations are exposed.
 */
contract SHTENCOBridgeQEAdapter is AccessControl, Pausable, ReentrancyGuard {
    using SafeERC20 for IERC20;

    bytes32 public constant CONTROLLER_ROLE = keccak256("CONTROLLER_ROLE");
    bytes32 public constant POLICY_ROLE = keccak256("POLICY_ROLE");
    bytes32 public constant GUARDIAN_ROLE = keccak256("GUARDIAN_ROLE");

    struct RoutePolicy {
        bool enabled;
        uint256 maxPerTx;
        uint256 dailyLimit;
    }

    struct DailyFlow {
        uint64 day;
        uint192 amount;
    }

    address public treasury;
    mapping(address => mapping(address => mapping(uint256 => RoutePolicy))) public routePolicy;
    mapping(uint256 => mapping(address => bool)) public allowedRecipient;
    mapping(bytes32 => DailyFlow) private _dailyFlow;

    event TreasurySet(address indexed treasury);
    event RouteSet(address indexed bridge, address indexed token, uint256 indexed chainId, bool enabled, uint256 maxPerTx, uint256 dailyLimit);
    event RecipientSet(uint256 indexed chainId, address indexed recipient, bool allowed);
    event BridgeQEExecuted(bytes32 indexed routeKey, bytes32 indexed messageId, uint256 nonce, address token, uint256 amount, uint256 chainId, address recipient, bytes32 reason);
    event InventoryReturned(address indexed token, uint256 amount);

    constructor(address admin, address treasury_) {
        require(admin != address(0) && treasury_ != address(0), "QE-ADAPTER: bad init");
        treasury = treasury_;
        _grantRole(DEFAULT_ADMIN_ROLE, admin);
        _grantRole(POLICY_ROLE, admin);
        _grantRole(GUARDIAN_ROLE, admin);
    }

    function executeRebalance(
        address bridge,
        address token,
        uint256 amount,
        uint256 targetChainId,
        address recipient,
        bytes32 reason
    ) external onlyRole(CONTROLLER_ROLE) nonReentrant whenNotPaused
        returns (bytes32 messageId, uint256 nonce)
    {
        RoutePolicy memory policy = routePolicy[bridge][token][targetChainId];
        require(policy.enabled, "QE-ADAPTER: route disabled");
        require(allowedRecipient[targetChainId][recipient], "QE-ADAPTER: recipient disabled");
        require(amount > 0 && amount <= policy.maxPerTx, "QE-ADAPTER: tx limit");
        require(bridge.code.length > 0 && token.code.length > 0, "QE-ADAPTER: invalid contract");

        bytes32 routeKey = keccak256(abi.encode(bridge, token, targetChainId));
        _consumeFlow(routeKey, amount, policy.dailyLimit);
        uint256 beforeBalance = IERC20(token).balanceOf(address(this));
        require(beforeBalance >= amount, "QE-ADAPTER: insufficient inventory");
        IERC20(token).forceApprove(bridge, amount);
        (messageId, nonce) = ISHTENCOBridgeEndpoint(bridge).bridgeOut(token, amount, targetChainId, recipient);
        IERC20(token).forceApprove(bridge, 0);
        uint256 afterBalance = IERC20(token).balanceOf(address(this));
        require(beforeBalance - afterBalance == amount, "QE-ADAPTER: inventory mismatch");
        emit BridgeQEExecuted(routeKey, messageId, nonce, token, amount, targetChainId, recipient, reason);
    }

    function returnInventory(address token, uint256 amount)
        external onlyRole(CONTROLLER_ROLE) nonReentrant whenNotPaused
    {
        require(amount > 0, "QE-ADAPTER: zero amount");
        IERC20(token).safeTransfer(treasury, amount);
        emit InventoryReturned(token, amount);
    }

    function _consumeFlow(bytes32 routeKey, uint256 amount, uint256 limit) internal {
        DailyFlow storage flow = _dailyFlow[routeKey];
        uint64 day = uint64(block.timestamp / 1 days);
        if (flow.day != day) {
            flow.day = day;
            flow.amount = 0;
        }
        uint256 next = uint256(flow.amount) + amount;
        require(limit > 0 && next <= limit, "QE-ADAPTER: daily limit");
        require(next <= type(uint192).max, "QE-ADAPTER: overflow");
        flow.amount = uint192(next);
    }

    function setRoute(
        address bridge,
        address token,
        uint256 targetChainId,
        RoutePolicy calldata policy
    ) external onlyRole(POLICY_ROLE) {
        require(bridge != address(0) && token != address(0) && targetChainId != 0, "QE-ADAPTER: bad route");
        if (policy.enabled) {
            require(bridge.code.length > 0 && token.code.length > 0, "QE-ADAPTER: invalid contract");
            require(policy.maxPerTx > 0 && policy.dailyLimit >= policy.maxPerTx, "QE-ADAPTER: bad limits");
        }
        routePolicy[bridge][token][targetChainId] = policy;
        emit RouteSet(bridge, token, targetChainId, policy.enabled, policy.maxPerTx, policy.dailyLimit);
    }

    function setRecipient(uint256 targetChainId, address recipient, bool allowed) external onlyRole(POLICY_ROLE) {
        require(targetChainId != 0 && recipient != address(0), "QE-ADAPTER: bad recipient");
        allowedRecipient[targetChainId][recipient] = allowed;
        emit RecipientSet(targetChainId, recipient, allowed);
    }

    function setTreasury(address treasury_) external onlyRole(POLICY_ROLE) {
        require(treasury_ != address(0), "QE-ADAPTER: zero treasury");
        treasury = treasury_;
        emit TreasurySet(treasury_);
    }

    function flowToday(address bridge, address token, uint256 targetChainId) external view returns (uint256) {
        bytes32 routeKey = keccak256(abi.encode(bridge, token, targetChainId));
        DailyFlow memory flow = _dailyFlow[routeKey];
        return flow.day == uint64(block.timestamp / 1 days) ? flow.amount : 0;
    }

    function pause() external onlyRole(GUARDIAN_ROLE) { _pause(); }
    function unpause() external onlyRole(DEFAULT_ADMIN_ROLE) { _unpause(); }
}
