const fs = require("fs");
const path = require("path");
const { spawnSync } = require("child_process");

const project = path.join(__dirname, "SHTENCO_QE_BRIDGE_AI");
const cli = path.join(project, "node_modules", "hardhat", "internal", "cli", "cli.js");
const artifact = path.join(project, "artifacts", "contracts", "23_SHTENCOBridgeRelayV2.sol", "SHTENCOBridgeRelayV2.json");
const args = [cli, "test"];
if (fs.existsSync(artifact)) args.push("--no-compile");
const result = spawnSync(process.execPath, args, { cwd: project, stdio: "inherit" });
process.exit(result.status === null ? 1 : result.status);
