'use strict';
const fs = require('fs');
const path = require('path');
const solc = require('solc');

const root = __dirname;
const entries = [
  '23_SHTENCOBridgeRelayV2.sol',
  '24_SHTENCOBridgeQEReserve.sol',
  '25_SHTENCOMarketMaker.sol',
  '26_SHTENCOAICentralBank.sol',
  '27_SHTENCOBridgeQEAdapter.sol',
];
const sources = Object.fromEntries(entries.map(file => [file, { content: fs.readFileSync(path.join(root, file), 'utf8') }]));

function findImports(importPath) {
  for (const candidate of [path.join(root, importPath), path.join(root, 'node_modules', importPath)]) {
    if (fs.existsSync(candidate)) return { contents: fs.readFileSync(candidate, 'utf8') };
  }
  return { error: `Import not found: ${importPath}` };
}

const input = {
  language: 'Solidity',
  sources,
  settings: {
    optimizer: { enabled: true, runs: 500 },
    viaIR: true,
    outputSelection: { '*': { '*': ['abi', 'metadata', 'evm.bytecode.object', 'evm.deployedBytecode.object', 'evm.gasEstimates'] } },
  },
};
const output = JSON.parse(solc.compile(JSON.stringify(input), { import: findImports }));
for (const item of output.errors || []) {
  (item.severity === 'error' ? process.stderr : process.stdout).write(`${item.severity.toUpperCase()}: ${item.formattedMessage}\n`);
}
const errors = (output.errors || []).filter(item => item.severity === 'error');
if (errors.length) process.exit(1);

const outDir = path.join(root, 'out_qe_bridge');
fs.mkdirSync(outDir, { recursive: true });
let artifacts = 0;
for (const [sourceName, contracts] of Object.entries(output.contracts || {})) {
  if (!entries.includes(sourceName)) continue;
  for (const [contractName, contract] of Object.entries(contracts)) {
    if (!contract.evm?.bytecode?.object) continue;
    const artifact = {
      contractName,
      sourceName,
      compiler: solc.version(),
      abi: contract.abi,
      bytecode: `0x${contract.evm.bytecode.object}`,
      deployedBytecode: `0x${contract.evm.deployedBytecode.object}`,
      gasEstimates: contract.evm.gasEstimates,
    };
    fs.writeFileSync(path.join(outDir, `${contractName}.json`), JSON.stringify(artifact, null, 2));
    console.log(`${contractName}: bytecode ${(artifact.bytecode.length - 2) / 2} bytes`);
    artifacts += 1;
  }
}
console.log(`QE/Bridge artifacts: ${artifacts}`);
console.log(`Compiler: ${solc.version()}`);
