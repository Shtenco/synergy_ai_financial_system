# Security and deployment checklist

## Mandatory before any public deployment

- Commission an independent smart-contract audit.
- Use at least a 2-of-3 or stronger validator quorum with geographically and operationally separate keys.
- Put `DEFAULT_ADMIN_ROLE` and `POLICY_ROLE` behind a multisig plus governance timelock.
- Use separate AI proposer, executor, guardian, validator and submitter keys.
- Configure non-zero max-per-transaction and daily limits for every token and route.
- Use a manipulation-resistant price guard with freshness checks. Do not use the same thin pool being traded as the sole oracle.
- Verify wrapped-token cap and bridge mint/burn role assignment.
- Fund escrow before enabling inbound canonical releases.
- Set central-bank daily budgets for every budget token.
- Test pause, validator rotation, stale epoch, replay, reserve floor, stale oracle, slippage and route-disable procedures.
- Run fork preflight at a pinned block and repeat it immediately before deployment.

## Relay operations

Each validator should run its own relay instance and store its key separately. The daemon scans only finalized blocks and advances the cursor only through the finalized range, avoiding loss of events that have not yet reached the configured confirmation count.

Use a message lifetime long enough to cover confirmations, validator coordination and destination inclusion, while remaining at or below the bridge contract's seven-day maximum.

## Deployment order

1. Deploy canonical/wrapped token endpoints.
2. Deploy relay bridges with validators and threshold.
3. Configure symmetric peers and token routes.
4. Configure asset policies and fund canonical escrow.
5. Deploy QE reserve, market maker, bridge adapter and AI central bank.
6. Configure roles and exact selectors.
7. Configure tokens, routers, price guard, burnable token, route recipients and budgets.
8. Run tests and fork preflight.
9. Transfer administration to multisig/timelock.
10. Enable one low-limit canary route before broader activation.

## Emergency response

- Guardian pauses the affected module.
- Validators stop signing the affected route.
- Policy administrator disables the route/router/token.
- Guardian cancels pending AI proposals.
- Inventory is returned to the reserve where safe.
- A post-incident state reconciliation is completed before unpausing.

## Explicit exclusions

The production module does not import historical scripts intended to pump price, generate wash volume, suppress errors, or execute unreviewed live cycles. Those patterns are unsuitable for a secure bridge or market-making controller.
