// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

contract MockPriceGuard {
    struct Rate { uint256 numerator; uint256 denominator; uint256 updatedAt; }
    mapping(bytes32 => Rate) public rates;

    function setRate(address tokenIn, address tokenOut, uint256 numerator, uint256 denominator) external {
        require(numerator > 0 && denominator > 0, "bad rate");
        rates[keccak256(abi.encode(tokenIn, tokenOut))] = Rate(numerator, denominator, block.timestamp);
    }

    function quote(address tokenIn, address tokenOut, uint256 amountIn)
        external view returns (uint256 expectedOut, uint256 updatedAt)
    {
        Rate memory rate = rates[keccak256(abi.encode(tokenIn, tokenOut))];
        expectedOut = amountIn * rate.numerator / rate.denominator;
        updatedAt = rate.updatedAt;
    }
}
