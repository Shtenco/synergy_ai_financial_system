#!/usr/bin/env python3
"""Deploy and configure 22_FlashLoanArbitrage.sol on Polygon Mainnet.

Safety properties:
- refuses to run on a chain other than 137;
- private key is read only from environment;
- requires explicit --yes;
- saves the deployed address and transaction hashes.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
from decimal import Decimal
from pathlib import Path
from typing import Any

from dotenv import load_dotenv
from web3 import Web3
from web3.contract import Contract

ROOT = Path(__file__).resolve().parent
ARTIFACT_PATH = ROOT / "out_flash" / "FlashLoanArbitrage.json"
CONFIG_PATH = ROOT / "flash_arb_config.json"
OUTPUT_PATH = ROOT / "deployed_flash_arbitrage.json"


def checksum(w3: Web3, value: str) -> str:
    return w3.to_checksum_address(value)




def require_contract(w3: Web3, label: str, address: str) -> None:
    if not w3.eth.get_code(address):
        raise RuntimeError(f"{label} has no bytecode at {address}")


def fee_fields(w3: Web3, priority_gwei: Decimal = Decimal("35")) -> dict[str, int]:
    latest = w3.eth.get_block("latest")
    base_fee = int(latest.get("baseFeePerGas", w3.eth.gas_price))
    priority = int(priority_gwei * Decimal(10**9))
    return {
        "maxPriorityFeePerGas": priority,
        "maxFeePerGas": base_fee * 2 + priority,
        "type": 2,
    }


def send_function(
    w3: Web3,
    account: Any,
    function: Any,
    nonce: int,
    gas_multiplier: Decimal = Decimal("1.20"),
) -> tuple[str, int]:
    tx_base = {
        "from": account.address,
        "nonce": nonce,
        "chainId": 137,
        **fee_fields(w3),
    }
    estimated = function.estimate_gas(tx_base)
    tx = function.build_transaction(
        {**tx_base, "gas": max(100_000, int(Decimal(estimated) * gas_multiplier))}
    )
    signed = account.sign_transaction(tx)
    tx_hash = w3.eth.send_raw_transaction(signed.raw_transaction)
    receipt = w3.eth.wait_for_transaction_receipt(tx_hash, timeout=300)
    if receipt.status != 1:
        raise RuntimeError(f"Transaction reverted: {tx_hash.hex()}")
    return tx_hash.hex(), nonce + 1


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--yes", action="store_true", help="confirm live deployment")
    parser.add_argument(
        "--max-flash-wpol",
        default="100",
        help="on-chain maximum WPOL principal; 0 disables the cap",
    )
    args = parser.parse_args()

    if not args.yes:
        print("Refusing live deployment without --yes")
        return 2

    load_dotenv(ROOT / ".env")
    load_dotenv(ROOT / ".env.flash", override=True)
    rpc_url = os.getenv("POLYGON_RPC_URL") or os.getenv("RPC_URL")
    private_key = os.getenv("OWNER_PRIVATE_KEY")
    if not rpc_url or not private_key:
        print("POLYGON_RPC_URL and OWNER_PRIVATE_KEY are required", file=sys.stderr)
        return 2

    artifact = json.loads(ARTIFACT_PATH.read_text(encoding="utf-8"))
    config = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))

    w3 = Web3(Web3.HTTPProvider(rpc_url, request_kwargs={"timeout": 60}))
    if not w3.is_connected():
        raise RuntimeError("Cannot connect to Polygon RPC")
    if w3.eth.chain_id != 137:
        raise RuntimeError(f"Wrong chain ID: {w3.eth.chain_id}; expected 137")

    account = w3.eth.account.from_key(private_key)
    configured_owner = os.getenv("OWNER_ADDRESS")
    if configured_owner and checksum(w3, configured_owner) != account.address:
        raise RuntimeError("OWNER_ADDRESS does not match OWNER_PRIVATE_KEY")

    addresses = config["contracts"]
    aave_pool = checksum(w3, addresses["aave_pool"])
    wpol = checksum(w3, addresses["wpol"])
    router = checksum(w3, addresses["quickswap_v2_router"])
    require_contract(w3, "Aave Pool", aave_pool)
    require_contract(w3, "WPOL", wpol)
    require_contract(w3, "QuickSwap Router", router)
    max_flash = int(Decimal(args.max_flash_wpol) * Decimal(10**18))

    factory = w3.eth.contract(abi=artifact["abi"], bytecode=artifact["bytecode"])
    nonce = w3.eth.get_transaction_count(account.address, "pending")
    constructor = factory.constructor(account.address, aave_pool, wpol, max_flash)

    base = {
        "from": account.address,
        "nonce": nonce,
        "chainId": 137,
        **fee_fields(w3),
    }
    gas_estimate = constructor.estimate_gas(base)
    tx = constructor.build_transaction({**base, "gas": int(gas_estimate * 1.20)})
    signed = account.sign_transaction(tx)
    deploy_hash = w3.eth.send_raw_transaction(signed.raw_transaction)
    deploy_receipt = w3.eth.wait_for_transaction_receipt(deploy_hash, timeout=300)
    if deploy_receipt.status != 1 or not deploy_receipt.contractAddress:
        raise RuntimeError(f"Deployment failed: {deploy_hash.hex()}")

    contract_address = checksum(w3, deploy_receipt.contractAddress)
    contract: Contract = w3.eth.contract(address=contract_address, abi=artifact["abi"])
    nonce += 1
    tx_hashes: list[str] = [deploy_hash.hex()]

    txh, nonce = send_function(w3, account, contract.functions.setRouter(router, True), nonce)
    tx_hashes.append(txh)

    for symbol in config["enabled_tokens"]:
        token = checksum(w3, config["tokens"][symbol])
        if token == wpol:
            continue
        txh, nonce = send_function(w3, account, contract.functions.setToken(token, True), nonce)
        tx_hashes.append(txh)

    bot_address = os.getenv("BOT_ADDRESS")
    if bot_address:
        txh, nonce = send_function(
            w3,
            account,
            contract.functions.setOperator(checksum(w3, bot_address), True),
            nonce,
        )
        tx_hashes.append(txh)

    result = {
        "network": "Polygon Mainnet",
        "chain_id": 137,
        "contract": contract_address,
        "owner": account.address,
        "aave_pool": aave_pool,
        "wpol": wpol,
        "router": router,
        "max_flash_wpol": str(args.max_flash_wpol),
        "deployed_at_unix": int(time.time()),
        "transactions": tx_hashes,
        "compiler": artifact.get("compiler"),
    }
    OUTPUT_PATH.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
