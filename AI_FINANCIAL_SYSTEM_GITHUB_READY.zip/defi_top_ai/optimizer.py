from __future__ import annotations

import math
import random
import statistics
from dataclasses import asdict

from .econometrics import apply_month, hard_policy_ok, metrics
from .models import (
    Decision,
    ModelPolicy,
    RevenueAllocation,
    SimulationResult,
    SystemState,
)


def candidate_decisions() -> list[Decision]:
    allocations = [
        ("DEFENSIVE", RevenueAllocation(5000, 2000, 500, 750, 1250, 500)),
        ("BALANCED", RevenueAllocation(3500, 3000, 1250, 1000, 750, 500)),
        ("LIQUIDITY", RevenueAllocation(3000, 4000, 750, 1000, 750, 500)),
        ("BRIDGE", RevenueAllocation(3500, 2500, 750, 2000, 750, 500)),
        ("BUYBACK", RevenueAllocation(3500, 2500, 2000, 750, 750, 500)),
        ("RESERVE", RevenueAllocation(6000, 1500, 500, 750, 750, 500)),
    ]
    qe_profiles = [
        (0.00, 0.50, 0.30, 0.20),
        (0.05, 0.55, 0.30, 0.15),
        (0.10, 0.60, 0.25, 0.15),
        (0.15, 0.45, 0.40, 0.15),
        (0.20, 0.55, 0.30, 0.15),
    ]
    intensities = (0.35, 0.65, 0.90)
    rows: list[Decision] = []
    for name, allocation in allocations:
        for qef, qel, qeb, qei in qe_profiles:
            for intensity in intensities:
                rows.append(Decision(
                    name=f"{name}_QE{int(qef * 100):02d}_FLASH{int(intensity * 100):02d}",
                    allocation=allocation,
                    qe_fraction_of_excess=qef,
                    qe_liquidity_share=qel,
                    qe_bridge_share=qeb,
                    qe_insurance_share=qei,
                    flash_search_intensity=intensity,
                ))
    return rows


def _mean(values: list[float]) -> float:
    return statistics.fmean(values) if values else 0.0


def evaluate_decision(
    initial: SystemState,
    decision: Decision,
    policy: ModelPolicy,
    scenarios: int = 500,
    horizon_months: int = 6,
    seed: int = 137,
) -> SimulationResult:
    decision.validate()
    baseline = metrics(initial, policy)
    fundamental_growth: list[float] = []
    backing_growth: list[float] = []
    price_growth: list[float] = []
    reserve_ratios: list[float] = []
    liquidity_coverage: list[float] = []
    bridge_imbalances: list[float] = []
    terminal_fundamental: list[float] = []

    for i in range(max(1, scenarios)):
        rng = random.Random(seed + i * 7919)
        state = initial.copy()
        for _ in range(max(1, horizon_months)):
            state, _ = apply_month(state, decision, policy, rng)
        terminal = metrics(state, policy)
        fundamental_growth.append(terminal.fundamental_mcap / max(baseline.fundamental_mcap, 1e-12) - 1.0)
        backing_growth.append(terminal.backing_nav / max(baseline.backing_nav, 1e-12) - 1.0)
        price_growth.append(terminal.fundamental_price / max(baseline.fundamental_price, 1e-12) - 1.0)
        reserve_ratios.append(terminal.reserve_ratio)
        liquidity_coverage.append(terminal.liquidity_coverage)
        bridge_imbalances.append(state.bridge_imbalance_bps)
        terminal_fundamental.append(terminal.fundamental_mcap)

    ordered = sorted(fundamental_growth)
    tail_count = max(1, int(len(ordered) * policy.cvar_alpha))
    cvar = _mean(ordered[:tail_count])
    loss_probability = sum(x < 0 for x in fundamental_growth) / len(fundamental_growth)
    expected_fundamental = _mean(fundamental_growth)
    expected_backing = _mean(backing_growth)
    expected_price = _mean(price_growth)
    expected_reserve = _mean(reserve_ratios)
    expected_coverage = _mean(liquidity_coverage)
    expected_bridge = _mean(bridge_imbalances)

    reserve_penalty = max(policy.minimum_reserve_ratio - expected_reserve, 0.0) * 3.0
    bridge_penalty = max(expected_bridge - policy.maximum_bridge_imbalance_bps, 0.0) / 10_000 * 2.0
    loss_penalty = loss_probability * 0.75
    cvar_penalty = max(-cvar, 0.0) * 2.5
    liquidity_reward = min(expected_coverage, 3.0) * 0.03
    score = (
        expected_fundamental * 1.00
        + expected_backing * 0.65
        + expected_price * 0.20
        + liquidity_reward
        - reserve_penalty
        - bridge_penalty
        - loss_penalty
        - cvar_penalty
    )

    return SimulationResult(
        decision=decision,
        expected_fundamental_growth=expected_fundamental,
        expected_backing_growth=expected_backing,
        expected_price_growth=expected_price,
        cvar_fundamental_growth=cvar,
        probability_of_loss=loss_probability,
        expected_reserve_ratio=expected_reserve,
        expected_liquidity_coverage=expected_coverage,
        expected_bridge_imbalance_bps=expected_bridge,
        score=score,
        scenarios=len(fundamental_growth),
        terminal_metrics={
            "mean_fundamental_mcap": _mean(terminal_fundamental),
            "median_fundamental_growth": statistics.median(fundamental_growth),
            "p10_fundamental_growth": ordered[tail_count - 1],
            "p90_fundamental_growth": ordered[min(len(ordered) - 1, int(len(ordered) * 0.90))],
        },
    )


def optimize(
    initial: SystemState,
    policy: ModelPolicy | None = None,
    scenarios: int = 500,
    horizon_months: int = 6,
    seed: int = 137,
) -> tuple[SimulationResult, list[SimulationResult]]:
    cfg = policy or ModelPolicy()
    ok, reason = hard_policy_ok(initial, cfg)
    if not ok:
        # In a hard-risk state, only defensive candidates are evaluated and QE
        # is disabled. This mirrors the on-chain controller's fail-closed mode.
        candidates = [d for d in candidate_decisions() if d.name.startswith("DEFENSIVE_QE00")]
    else:
        candidates = candidate_decisions()
    results = [
        evaluate_decision(initial, decision, cfg, scenarios, horizon_months, seed)
        for decision in candidates
    ]
    results.sort(key=lambda row: row.score, reverse=True)
    return results[0], results


def build_report(
    initial: SystemState,
    best: SimulationResult,
    ranked: list[SimulationResult],
    policy: ModelPolicy,
) -> dict:
    current = metrics(initial, policy)
    return {
        "model": "SHTENCO DeFi TOP AI Econometric Controller v3",
        "objective": "maximize risk-adjusted fundamental value, backing NAV and durable liquidity",
        "non_goals": [
            "wash trading",
            "unbacked minting",
            "counting internal price impact as protocol value",
            "guaranteeing market capitalization or token price",
        ],
        "current_metrics": current.to_dict(),
        "policy": asdict(policy),
        "best": best.to_dict(),
        "top_10": [row.to_dict() for row in ranked[:10]],
        "value_generation_identity": {
            "backing_nav": "liquid reserves + owned LP NAV + bridge capital + insurance - liabilities",
            "net_revenue_30d": "protocol fees + flash arbitrage + reserve yield + bridge fees - gas - operating cost",
            "fundamental_mcap": "backing NAV + haircut × revenue horizon × positive net revenue",
            "delta_backing_nav": "realized net revenue - execution losses - operating extraction",
            "bridge_qe": "reallocation of backed excess reserves; no immediate value creation",
            "buyback": "realized-revenue funded and permitted only near/below fundamental price",
        },
    }
