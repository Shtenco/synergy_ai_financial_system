from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any


@dataclass(slots=True)
class SystemState:
    """One-period state in a common quote unit (for example USD or WPOL)."""

    liquid_reserves: float
    liabilities: float
    owned_liquidity_nav: float
    bridge_capital: float
    insurance_fund: float
    circulating_supply: float
    market_price: float
    liquidity_depth: float
    monthly_volume: float
    protocol_fee_revenue_30d: float
    flash_profit_30d: float
    yield_revenue_30d: float
    bridge_fee_revenue_30d: float
    operating_cost_30d: float
    gas_cost_30d: float
    volatility_bps: float
    peg_error_bps: float
    bridge_imbalance_bps: float
    month: int = 0

    def copy(self) -> "SystemState":
        return SystemState(**asdict(self))


@dataclass(frozen=True, slots=True)
class RevenueAllocation:
    reserve_bps: int
    liquidity_bps: int
    buyback_bps: int
    bridge_bps: int
    insurance_bps: int
    operations_bps: int

    def validate(self) -> None:
        values = (
            self.reserve_bps,
            self.liquidity_bps,
            self.buyback_bps,
            self.bridge_bps,
            self.insurance_bps,
            self.operations_bps,
        )
        if sum(values) != 10_000:
            raise ValueError("revenue allocation must sum to 10,000 bps")
        if not 2_500 <= self.reserve_bps <= 6_000:
            raise ValueError("reserve allocation outside policy")
        if not 1_500 <= self.liquidity_bps <= 4_000:
            raise ValueError("liquidity allocation outside policy")
        if not 0 <= self.buyback_bps <= 2_000:
            raise ValueError("buyback allocation outside policy")
        if not 500 <= self.bridge_bps <= 2_000:
            raise ValueError("bridge allocation outside policy")
        if not 500 <= self.insurance_bps <= 2_000:
            raise ValueError("insurance allocation outside policy")
        if not 0 <= self.operations_bps <= 1_000:
            raise ValueError("operations allocation outside policy")


@dataclass(frozen=True, slots=True)
class Decision:
    name: str
    allocation: RevenueAllocation
    qe_fraction_of_excess: float
    qe_liquidity_share: float
    qe_bridge_share: float
    qe_insurance_share: float
    flash_search_intensity: float

    def validate(self) -> None:
        self.allocation.validate()
        if not 0.0 <= self.qe_fraction_of_excess <= 0.25:
            raise ValueError("QE fraction exceeds hard cap")
        shares = self.qe_liquidity_share + self.qe_bridge_share + self.qe_insurance_share
        if abs(shares - 1.0) > 1e-9:
            raise ValueError("QE shares must sum to one")
        if min(self.qe_liquidity_share, self.qe_bridge_share, self.qe_insurance_share) < 0:
            raise ValueError("negative QE share")
        if not 0.0 <= self.flash_search_intensity <= 1.0:
            raise ValueError("flash intensity outside [0, 1]")


@dataclass(frozen=True, slots=True)
class ModelPolicy:
    revenue_horizon_months: int = 12
    revenue_haircut: float = 0.50
    minimum_reserve_ratio: float = 1.20
    maximum_valuation_premium: float = 2.00
    maximum_peg_error_bps: float = 1_200.0
    maximum_bridge_imbalance_bps: float = 3_500.0
    maximum_volatility_bps: float = 7_500.0
    minimum_liquidity_coverage: float = 0.20
    maximum_buyback_premium_to_fundamental: float = 0.05
    maximum_qe_per_month: float = 250.0
    liquidity_monthly_revenue_yield: float = 0.015
    bridge_monthly_revenue_yield: float = 0.006
    liquidity_slippage_bps: float = 35.0
    bridge_cost_bps: float = 15.0
    buyback_slippage_bps: float = 50.0
    insurance_target_ratio: float = 0.08
    cvar_alpha: float = 0.10


@dataclass(slots=True)
class Metrics:
    net_revenue_30d: float
    backing_nav: float
    discounted_revenue_value: float
    fundamental_mcap: float
    fundamental_price: float
    market_mcap: float
    reserve_ratio: float
    valuation_premium: float
    liquidity_coverage: float
    sustainable_monthly_growth: float
    excess_reserves: float

    def to_dict(self) -> dict[str, float]:
        return asdict(self)


@dataclass(slots=True)
class SimulationResult:
    decision: Decision
    expected_fundamental_growth: float
    expected_backing_growth: float
    expected_price_growth: float
    cvar_fundamental_growth: float
    probability_of_loss: float
    expected_reserve_ratio: float
    expected_liquidity_coverage: float
    expected_bridge_imbalance_bps: float
    score: float
    scenarios: int
    terminal_metrics: dict[str, float]

    def to_dict(self) -> dict[str, Any]:
        return {
            "decision": {
                "name": self.decision.name,
                "allocation": asdict(self.decision.allocation),
                "qe_fraction_of_excess": self.decision.qe_fraction_of_excess,
                "qe_liquidity_share": self.decision.qe_liquidity_share,
                "qe_bridge_share": self.decision.qe_bridge_share,
                "qe_insurance_share": self.decision.qe_insurance_share,
                "flash_search_intensity": self.decision.flash_search_intensity,
            },
            "expected_fundamental_growth": self.expected_fundamental_growth,
            "expected_backing_growth": self.expected_backing_growth,
            "expected_price_growth": self.expected_price_growth,
            "cvar_fundamental_growth": self.cvar_fundamental_growth,
            "probability_of_loss": self.probability_of_loss,
            "expected_reserve_ratio": self.expected_reserve_ratio,
            "expected_liquidity_coverage": self.expected_liquidity_coverage,
            "expected_bridge_imbalance_bps": self.expected_bridge_imbalance_bps,
            "score": self.score,
            "scenarios": self.scenarios,
            "terminal_metrics": self.terminal_metrics,
        }
