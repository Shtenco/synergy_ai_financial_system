#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
 ПРИБЫЛЬНЫЙ FLASH LOAN ЦИКЛ - ПОЛНЫЙ АУДИТ

 МЕХАНИКА:
 1. SNAPSHOT START (все балансы)
 2. Transfer WPOL в Vault (увеличить freeWpol)
 3. executeEmission() → founder gets 30% dlp в WPOL
 4. withdrawFounder() → получаем WPOL
 5. Забираем депозит из Vault
 6. SNAPSHOT END
 7. PROFIT = END - START
═══════════════════════════════════════════════════════════════════════════════
"""
import sys, io, os, json, time
from decimal import Decimal, getcontext
from dotenv import load_dotenv
from web3 import Web3
from web3.middleware import ExtraDataToPOAMiddleware

getcontext().prec = 50

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

load_dotenv()
w3 = Web3(Web3.HTTPProvider("https://polygon-bor-rpc.publicnode.com", request_kwargs={"timeout": 300}))
w3.middleware_onion.inject(ExtraDataToPOAMiddleware, layer=0)

PK = os.getenv("OWNER_PRIVATE_KEY")
OWNER = "0x6946999DBCE63b140B1bB9D475F7c357130909E5"
WPOL = "0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270"

def C(a): return Web3.to_checksum_address(a)

with open("deployed_TROIKA_v3.json") as f:
    d = json.load(f)

# Используем новый EmissionEngine v3 с MAX emitRate
EMIT_V3 = d.get("emitEngine_v3", "0xB462E85ACB82d05A50388BF666124165011d8876")

# ABIs
TOKEN_ABI = [
    {"name": "balanceOf", "inputs": [{"type": "address"}], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "totalSupply", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "transfer", "inputs": [{"name": "to", "type": "address"}, {"name": "amount", "type": "uint256"}], "outputs": [{"type": "bool"}], "stateMutability": "nonpayable", "type": "function"},
]

WPOL_ABI = TOKEN_ABI + [
    {"name": "deposit", "inputs": [], "outputs": [], "stateMutability": "payable", "type": "function"},
    {"name": "withdraw", "inputs": [{"name": "amount", "type": "uint256"}], "outputs": [], "stateMutability": "nonpayable", "type": "function"},
]

VAULT_ABI = [
    {"name": "freeWpol", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "transferWpol", "inputs": [{"name": "to", "type": "address"}, {"name": "amount", "type": "uint256"}], "outputs": [], "stateMutability": "nonpayable", "type": "function"},
    {"name": "lpR", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "lpT", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "lpP", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
]

EMIT_ABI = [
    {"name": "executeEmission", "inputs": [], "outputs": [], "stateMutability": "nonpayable", "type": "function"},
    {"name": "isEmissionDue", "inputs": [], "outputs": [{"type": "bool"}], "stateMutability": "view", "type": "function"},
    {"name": "lastEmitBlock", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "getParams", "inputs": [], "outputs": [{"type": "uint256"}, {"type": "uint256"}], "stateMutability": "view", "type": "function"},
]

DIV_ABI = [
    {"name": "founderPending", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "withdrawFounder", "inputs": [], "outputs": [], "stateMutability": "nonpayable", "type": "function"},
]

def get_snapshot():
    """Полный снимок всех балансов"""
    snap = {"block": w3.eth.block_number}

    wpol_c = w3.eth.contract(address=C(WPOL), abi=TOKEN_ABI)
    snap["owner_pol"] = Decimal(w3.eth.get_balance(C(OWNER))) / Decimal(10**18)
    snap["owner_wpol"] = Decimal(wpol_c.functions.balanceOf(C(OWNER)).call()) / Decimal(10**18)

    vault = w3.eth.contract(address=C(d["vault"]), abi=VAULT_ABI)
    snap["vault_wpol"] = Decimal(wpol_c.functions.balanceOf(C(d["vault"])).call()) / Decimal(10**18)
    snap["vault_free"] = Decimal(vault.functions.freeWpol().call()) / Decimal(10**18)

    divpool = w3.eth.contract(address=C(d["divPool"]), abi=DIV_ABI)
    snap["founder_pending"] = Decimal(divpool.functions.founderPending().call()) / Decimal(10**18)
    snap["divpool_wpol"] = Decimal(wpol_c.functions.balanceOf(C(d["divPool"])).call()) / Decimal(10**18)

    snap["total_liquid"] = snap["owner_pol"] + snap["owner_wpol"] + snap["vault_wpol"] + snap["divpool_wpol"]

    return snap

def print_snapshot(s, label):
    print(f"\n{'='*70}")
    print(f" {label} (block {s['block']})")
    print('='*70)
    print(f"  Owner POL:  {s['owner_pol']:.10f}")
    print(f"  Owner WPOL: {s['owner_wpol']:.10f}")
    print(f"  Vault WPOL: {s['vault_wpol']:.10f}")
    print(f"  Vault free: {s['vault_free']:.10f}")
    print(f"  DivPool WPOL: {s['divpool_wpol']:.10f}")
    print(f"  Founder pending: {s['founder_pending']:.10f}")
    print(f"  Total liquid: {s['total_liquid']:.10f}")

# ═══════════════════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════════════════

print("="*70)
print(" ПРИБЫЛЬНЫЙ FLASH LOAN ЦИКЛ (EmissionEngine v3 MAX)")
print("="*70)

emit = w3.eth.contract(address=C(EMIT_V3), abi=EMIT_ABI)
gP, emitRate = emit.functions.getParams().call()
print(f"\nEmissionEngine v3: {EMIT_V3}")
print(f"  emitRate: {emitRate / 1e18:.10f} (должен быть 0.00005)")
print(f"  gP: {gP / 1e18:.10f}")

# SNAPSHOT START
start = get_snapshot()
print_snapshot(start, "SNAPSHOT START")

# Check emission due
is_due = emit.functions.isEmissionDue().call()
last_block = emit.functions.lastEmitBlock().call()
current_block = w3.eth.block_number

print(f"\n[EMISSION STATUS]")
print(f"  isEmissionDue: {is_due}")
print(f"  lastEmitBlock: {last_block}")
print(f"  currentBlock: {current_block}")

if not is_due:
    blocks_left = 50 - (current_block - last_block)
    print(f"\n[!] Emission not due. Wait {blocks_left} blocks (~{blocks_left*2} sec)")
    sys.exit(0)

# Setup TX params
nonce = w3.eth.get_transaction_count(C(OWNER), "pending")
base = w3.eth.get_block("latest").get("baseFeePerGas", int(100e9))
prio = int(50e9)
mf = base * 2 + prio

# [1] Transfer WPOL в Vault
print("\n[1] Transfer WPOL в Vault...")
deposit_amount = int(3e18)  # 3 WPOL

wpol_c = w3.eth.contract(address=C(WPOL), abi=TOKEN_ABI)
owner_wpol = wpol_c.functions.balanceOf(C(OWNER)).call()

if owner_wpol >= deposit_amount:
    tx = wpol_c.functions.transfer(C(d["vault"]), deposit_amount).build_transaction({
        "from": C(OWNER), "nonce": nonce, "chainId": 137, "type": 2,
        "maxPriorityFeePerGas": prio, "maxFeePerGas": mf, "gas": 100000
    })
    signed = w3.eth.account.sign_transaction(tx, PK)
    h = w3.eth.send_raw_transaction(signed.raw_transaction)
    r = w3.eth.wait_for_transaction_receipt(h, timeout=120)
    print(f"  {'[OK]' if r.status else '[FAIL]'} TX: {h.hex()[:20]}...")
    nonce += 1
    time.sleep(2)
else:
    print(f"  [SKIP] Not enough WPOL ({owner_wpol/1e18:.4f})")

# Check vault freeWpol now
vault = w3.eth.contract(address=C(d["vault"]), abi=VAULT_ABI)
free_now = vault.functions.freeWpol().call() / 1e18
print(f"  Vault freeWpol now: {free_now:.10f}")

# [2] Execute Emission
print("\n[2] Execute Emission (EmissionEngine v3 MAX)...")
tx = emit.functions.executeEmission().build_transaction({
    "from": C(OWNER), "nonce": nonce, "chainId": 137, "type": 2,
    "maxPriorityFeePerGas": prio, "maxFeePerGas": mf, "gas": 3_000_000
})
signed = w3.eth.account.sign_transaction(tx, PK)
h = w3.eth.send_raw_transaction(signed.raw_transaction)
print(f"  TX: {h.hex()}")
r = w3.eth.wait_for_transaction_receipt(h, timeout=300)
gas_cost1 = r.gasUsed * mf / 1e18
print(f"  {'[OK]' if r.status else '[FAIL]'} Gas: {r.gasUsed}, Cost: {gas_cost1:.6f} POL")
nonce += 1
time.sleep(2)

# [3] Check founder pending
divpool = w3.eth.contract(address=C(d["divPool"]), abi=DIV_ABI)
founder_pending = divpool.functions.founderPending().call() / 1e18
print(f"\n[3] Founder Pending: {founder_pending:.10f} WPOL")

# [4] Withdraw Founder
if founder_pending > 0:
    print("\n[4] Withdraw Founder Dividends...")
    tx = divpool.functions.withdrawFounder().build_transaction({
        "from": C(OWNER), "nonce": nonce, "chainId": 137, "type": 2,
        "maxPriorityFeePerGas": prio, "maxFeePerGas": mf, "gas": 200000
    })
    signed = w3.eth.account.sign_transaction(tx, PK)
    h = w3.eth.send_raw_transaction(signed.raw_transaction)
    r = w3.eth.wait_for_transaction_receipt(h, timeout=120)
    gas_cost2 = r.gasUsed * mf / 1e18
    print(f"  {'[OK]' if r.status else '[FAIL]'} Gas: {gas_cost2:.6f} POL")
    nonce += 1
    time.sleep(2)
else:
    gas_cost2 = 0
    print("\n[4] No founder pending to withdraw")

# [5] Withdraw deposit from Vault (if we deposited)
print("\n[5] Checking if we can withdraw deposit from Vault...")
free_now = vault.functions.freeWpol().call()
if free_now >= deposit_amount:
    print(f"  Vault freeWpol: {free_now/1e18:.6f}, withdrawing {deposit_amount/1e18} WPOL")
    tx = vault.functions.transferWpol(C(OWNER), deposit_amount).build_transaction({
        "from": C(OWNER), "nonce": nonce, "chainId": 137, "type": 2,
        "maxPriorityFeePerGas": prio, "maxFeePerGas": mf, "gas": 100000
    })
    signed = w3.eth.account.sign_transaction(tx, PK)
    h = w3.eth.send_raw_transaction(signed.raw_transaction)
    r = w3.eth.wait_for_transaction_receipt(h, timeout=120)
    gas_cost3 = r.gasUsed * mf / 1e18
    print(f"  {'[OK]' if r.status else '[FAIL]'} Gas: {gas_cost3:.6f} POL")
    nonce += 1
    time.sleep(2)
else:
    gas_cost3 = 0
    print(f"  [SKIP] Vault freeWpol ({free_now/1e18:.6f}) < deposit ({deposit_amount/1e18})")

# SNAPSHOT END
end = get_snapshot()
print_snapshot(end, "SNAPSHOT END")

# CALCULATE PROFIT
print(f"\n{'='*70}")
print(" PROFIT CALCULATION")
print('='*70)

delta_pol = end["owner_pol"] - start["owner_pol"]
delta_wpol = end["owner_wpol"] - start["owner_wpol"]
delta_founder = end["founder_pending"] - start["founder_pending"]
delta_total = end["total_liquid"] - start["total_liquid"]

print(f"\n[DELTAS]")
print(f"  Owner POL:  {delta_pol:+.10f}")
print(f"  Owner WPOL: {delta_wpol:+.10f}")
print(f"  Founder pending: {delta_founder:+.10f}")
print(f"  Total liquid: {delta_total:+.10f}")

# Net profit = WPOL gained - gas spent
gas_total = Decimal(str(gas_cost1)) + Decimal(str(gas_cost2)) + Decimal(str(gas_cost3))
net_profit = delta_wpol - gas_total

print(f"\n[SUMMARY]")
print(f"  WPOL gained: {delta_wpol:+.10f}")
print(f"  Gas spent:   {gas_total:.10f} POL")
print(f"  NET PROFIT:  {net_profit:+.10f} POL")

print(f"\n{'='*70}")
if net_profit > 0:
    print(f" ✅ ПРИБЫЛЬНО! +{net_profit:.6f} POL")
else:
    print(f" ❌ УБЫТОЧНО: {net_profit:.6f} POL")
print('='*70)
