#!/usr/bin/env python3
"""
ДЕПЛОЙ ЧЕРЕЗ TROIKA DEPLOYER
Разворачивает ВСЮ систему за одну транзакцию
"""
import sys, io, os, json, time, subprocess
from dotenv import load_dotenv
from web3 import Web3
from web3.middleware import ExtraDataToPOAMiddleware

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

load_dotenv()

w3 = Web3(Web3.HTTPProvider("https://polygon-bor-rpc.publicnode.com", request_kwargs={"timeout": 300}))
w3.middleware_onion.inject(ExtraDataToPOAMiddleware, layer=0)

PK = os.getenv("OWNER_PRIVATE_KEY")
OWNER = "0x6946999DBCE63b140B1bB9D475F7c357130909E5"
WPOL = "0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270"

def C(a): return Web3.to_checksum_address(a)

bal = w3.eth.get_balance(C(OWNER)) / 1e18
print("=" * 70)
print("ДЕПЛОЙ ЧЕРЕЗ TROIKA DEPLOYER")
print("=" * 70)
print(f"Баланс POL: {bal:.4f}")

# Проверить баланс WPOL
WPOL_ABI = [
    {"name": "balanceOf", "inputs": [{"name": "account", "type": "address"}], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "deposit", "inputs": [], "outputs": [], "stateMutability": "payable", "type": "function"},
    {"name": "approve", "inputs": [{"name": "spender", "type": "address"}, {"name": "amount", "type": "uint256"}], "outputs": [{"type": "bool"}], "stateMutability": "nonpayable", "type": "function"},
]

wpol = w3.eth.contract(address=C(WPOL), abi=WPOL_ABI)
wpol_bal = wpol.functions.balanceOf(C(OWNER)).call() / 1e18
print(f"Баланс WPOL: {wpol_bal:.4f}")
print("=" * 70)

# Параметры деплоя (уменьшенные)
# Оригинал: 300 POL
# У нас: ~36 POL, нужно ~25 POL для деплоя + gas
# Минимальный сетап:

# Ликвидность (минимум):
wpolR = int(3e18)   # 3 POL для SYNA/WPOL
tokR = int(2e18)    # 2 SYNA
wpolT = int(3e18)   # 3 POL для SYNC/WPOL
tokT = int(19e18)   # 19 SYNC
wpolP = int(3e18)   # 3 POL для SYNR/WPOL
tokP = int(4e18)    # 4 SYNR

# Резервы:
trRes = int(2e18)   # 2 POL trader reserve
rrRes = int(3e18)   # 3 POL reserveR
mcgRes = int(1e18)  # 1 POL MCG fund
keeperSeed = int(1e18)  # 1 POL keeper

totalWpol = wpolR + wpolT + wpolP + trRes + rrRes + mcgRes + keeperSeed
print(f"\nНеобходимо WPOL: {totalWpol / 1e18:.4f}")

if wpol_bal * 1e18 < totalWpol:
    needed = totalWpol / 1e18 - wpol_bal
    print(f"Нужно wrap ещё: {needed:.4f} POL в WPOL")

    # Wrap POL -> WPOL
    nonce = w3.eth.get_transaction_count(C(OWNER), "pending")
    base = w3.eth.get_block("latest").get("baseFeePerGas", int(100e9))
    prio = int(50e9)
    mf = base * 2 + prio

    wrap_amount = int((needed + 1) * 1e18)  # +1 для запаса

    tx = wpol.functions.deposit().build_transaction({
        "from": C(OWNER), "nonce": nonce, "chainId": 137, "type": 2,
        "maxPriorityFeePerGas": prio, "maxFeePerGas": mf,
        "gas": 100000, "value": wrap_amount
    })

    signed = w3.eth.account.sign_transaction(tx, PK)
    tx_hash = w3.eth.send_raw_transaction(signed.raw_transaction)
    print(f"Wrap TX: {tx_hash.hex()[:20]}...")
    receipt = w3.eth.wait_for_transaction_receipt(tx_hash, timeout=120)
    if receipt.status == 1:
        print(f"  [OK] Wrapped {wrap_amount / 1e18:.4f} POL -> WPOL")
    else:
        print("  [FAIL] Wrap failed")
        sys.exit(1)

    time.sleep(3)
    wpol_bal = wpol.functions.balanceOf(C(OWNER)).call() / 1e18
    print(f"Новый баланс WPOL: {wpol_bal:.4f}")

print("\n" + "=" * 70)
print("КОМПИЛЯЦИЯ TROIKA DEPLOYER")
print("=" * 70)

# Проверить forge
try:
    result = subprocess.run(["forge", "--version"], capture_output=True, text=True)
    print(f"Forge: {result.stdout.strip()}")
except:
    print("ОШИБКА: Forge не установлен!")
    print("Установите: curl -L https://foundry.paradigm.xyz | bash && foundryup")
    sys.exit(1)

# Создать foundry.toml если нет
if not os.path.exists("foundry.toml"):
    with open("foundry.toml", "w") as f:
        f.write("""[profile.default]
src = "."
out = "out"
libs = ["node_modules"]
remappings = ["@openzeppelin/=node_modules/@openzeppelin/"]
optimizer = true
optimizer_runs = 200
solc = "0.8.20"
""")

# npm install если нет
if not os.path.exists("node_modules/@openzeppelin"):
    print("\nУстановка OpenZeppelin...")
    os.system("npm init -y 2>NUL")
    os.system("npm install @openzeppelin/contracts@5.0.0 2>NUL")

# Компилировать
print("\nКомпиляция...")
result = subprocess.run(
    ["forge", "build", "--contracts", "12_TroikaDeployer.sol"],
    capture_output=True, text=True, cwd="."
)

if result.returncode != 0:
    print(f"ОШИБКА компиляции:")
    print(result.stderr)
    sys.exit(1)

print("  [OK] Скомпилировано")

# Загрузить ABI и bytecode
import json as json_lib
with open("out/12_TroikaDeployer.sol/TroikaDeployer.json") as f:
    artifact = json_lib.load(f)
    deployer_abi = artifact["abi"]
    deployer_bytecode = artifact["bytecode"]["object"]

print(f"  Bytecode size: {len(deployer_bytecode) // 2} bytes")

# ═══════════════════════════════════════════════════════════════════════════
# ДЕПЛОЙ
# ═══════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 70)
print("ДЕПЛОЙ TROIKA DEPLOYER")
print("=" * 70)

nonce = w3.eth.get_transaction_count(C(OWNER), "pending")
base = w3.eth.get_block("latest").get("baseFeePerGas", int(100e9))
prio = int(50e9)
mf = base * 2 + prio

# Deploy TroikaDeployer
contract = w3.eth.contract(abi=deployer_abi, bytecode=deployer_bytecode)

tx = contract.constructor().build_transaction({
    "from": C(OWNER), "nonce": nonce, "chainId": 137, "type": 2,
    "maxPriorityFeePerGas": prio, "maxFeePerGas": mf, "gas": 15_000_000
})

print("[TX] Deploying TroikaDeployer...")
signed = w3.eth.account.sign_transaction(tx, PK)
tx_hash = w3.eth.send_raw_transaction(signed.raw_transaction)
print(f"  TX: {tx_hash.hex()[:20]}...")

receipt = w3.eth.wait_for_transaction_receipt(tx_hash, timeout=600)
gas_cost = receipt.gasUsed * mf / 1e18

if receipt.status == 1:
    deployer_addr = receipt.contractAddress
    print(f"  [OK] TroikaDeployer: {deployer_addr} (gas: {gas_cost:.4f} POL)")
    nonce += 1
else:
    print("  [FAIL] Deploy failed")
    sys.exit(1)

time.sleep(5)

# ═══════════════════════════════════════════════════════════════════════════
# APPROVE WPOL для TroikaDeployer
# ═══════════════════════════════════════════════════════════════════════════
print("\n[TX] Approve WPOL...")

approve_func = wpol.functions.approve(C(deployer_addr), int(1e30))
tx = approve_func.build_transaction({
    "from": C(OWNER), "nonce": nonce, "chainId": 137, "type": 2,
    "maxPriorityFeePerGas": prio, "maxFeePerGas": mf, "gas": 100000
})
signed = w3.eth.account.sign_transaction(tx, PK)
tx_hash = w3.eth.send_raw_transaction(signed.raw_transaction)
print(f"  TX: {tx_hash.hex()[:20]}...")

receipt = w3.eth.wait_for_transaction_receipt(tx_hash, timeout=120)
if receipt.status == 1:
    print("  [OK] Approved")
    nonce += 1
else:
    print("  [FAIL]")
    sys.exit(1)

time.sleep(3)

# ═══════════════════════════════════════════════════════════════════════════
# ВЫЗОВ deploy()
# ═══════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 70)
print("ВЫЗОВ TroikaDeployer.deploy()")
print("=" * 70)
print(f"Founder: {OWNER}")
print(f"wpolR={wpolR/1e18}, tokR={tokR/1e18}")
print(f"wpolT={wpolT/1e18}, tokT={tokT/1e18}")
print(f"wpolP={wpolP/1e18}, tokP={tokP/1e18}")
print(f"trRes={trRes/1e18}, rrRes={rrRes/1e18}, mcgRes={mcgRes/1e18}, keeper={keeperSeed/1e18}")

deployer = w3.eth.contract(address=C(deployer_addr), abi=deployer_abi)

deploy_func = deployer.functions.deploy(
    C(OWNER),  # founder
    wpolR, tokR,
    wpolT, tokT,
    wpolP, tokP,
    trRes, rrRes, mcgRes, keeperSeed
)

# Estimate gas
try:
    est = deploy_func.estimate_gas({"from": C(OWNER)})
    print(f"Estimated gas: {est:,}")
except Exception as e:
    print(f"Estimate failed: {e}")
    est = 30_000_000

tx = deploy_func.build_transaction({
    "from": C(OWNER), "nonce": nonce, "chainId": 137, "type": 2,
    "maxPriorityFeePerGas": prio, "maxFeePerGas": mf, "gas": min(est + 1_000_000, 30_000_000)
})

print("\n[TX] deploy()...")
signed = w3.eth.account.sign_transaction(tx, PK)
tx_hash = w3.eth.send_raw_transaction(signed.raw_transaction)
print(f"  TX: {tx_hash.hex()}")

receipt = w3.eth.wait_for_transaction_receipt(tx_hash, timeout=600)
gas_cost = receipt.gasUsed * mf / 1e18

if receipt.status == 1:
    print(f"  [OK] СИСТЕМА РАЗВЁРНУТА! (gas: {gas_cost:.4f} POL)")
else:
    print(f"  [FAIL] Deploy reverted")
    sys.exit(1)

# ═══════════════════════════════════════════════════════════════════════════
# ПОЛУЧИТЬ ВСЕ АДРЕСА
# ═══════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 70)
print("АДРЕСА СИСТЕМЫ")
print("=" * 70)

addrs = deployer.functions.allAddresses().call()
names = ["core", "syna", "sync", "synr", "vault", "oracle",
         "divPool", "cbArb", "feeRouter", "emitEngine", "loop", "founderCtl"]

result = {"deployed_at": time.strftime("%Y-%m-%d %H:%M:%S"), "owner": OWNER, "deployer": deployer_addr}

for name, addr in zip(names, addrs):
    print(f"  {name}: {addr}")
    result[name] = addr

# Получить адреса пулов из Vault
VAULT_ABI = [
    {"name": "pairR", "inputs": [], "outputs": [{"type": "address"}], "stateMutability": "view", "type": "function"},
    {"name": "pairT", "inputs": [], "outputs": [{"type": "address"}], "stateMutability": "view", "type": "function"},
    {"name": "pairP", "inputs": [], "outputs": [{"type": "address"}], "stateMutability": "view", "type": "function"},
]

vault_contract = w3.eth.contract(address=C(result["vault"]), abi=VAULT_ABI)
result["pools"] = {
    "SYNA_WPOL": vault_contract.functions.pairR().call(),
    "SYNC_WPOL": vault_contract.functions.pairT().call(),
    "SYNR_WPOL": vault_contract.functions.pairP().call(),
}

print("\nПулы:")
for name, addr in result["pools"].items():
    print(f"  {name}: {addr}")

with open("deployed_TROIKA_FULL.json", "w") as f:
    json.dump(result, f, indent=2)

print(f"\nБаланс: {w3.eth.get_balance(C(OWNER)) / 1e18:.4f} POL")
print("\n" + "=" * 70)
print("СИСТЕМА TROIKA ПОЛНОСТЬЮ РАЗВЁРНУТА!")
print("=" * 70)
