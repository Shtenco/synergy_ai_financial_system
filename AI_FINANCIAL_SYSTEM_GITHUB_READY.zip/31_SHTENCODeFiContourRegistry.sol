// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {AccessControl} from "@openzeppelin/contracts/access/AccessControl.sol";

/**
 * @title SHTENCODeFiContourRegistry
 * @notice Canonical registry for the modules that form the production DeFi
 *         TOP AI contour. It has no custody and no execution authority.
 */
contract SHTENCODeFiContourRegistry is AccessControl {
    bytes32 public constant POLICY_ROLE = keccak256("POLICY_ROLE");

    bytes32 public constant STATE_ORACLE = keccak256("STATE_ORACLE");
    bytes32 public constant TOP_AI_CONTROLLER = keccak256("TOP_AI_CONTROLLER");
    bytes32 public constant VALUE_TREASURY = keccak256("VALUE_TREASURY");
    bytes32 public constant FLASH_ARBITRAGE = keccak256("FLASH_ARBITRAGE");
    bytes32 public constant MARKET_MAKER = keccak256("MARKET_MAKER");
    bytes32 public constant FLASH_HARVESTER = keccak256("FLASH_HARVESTER");
    bytes32 public constant BRIDGE_RESERVE = keccak256("BRIDGE_RESERVE");
    bytes32 public constant BRIDGE_ADAPTER = keccak256("BRIDGE_ADAPTER");
    bytes32 public constant RELAY_BRIDGE = keccak256("RELAY_BRIDGE");

    bytes32[9] private _requiredIds = [
        STATE_ORACLE,
        TOP_AI_CONTROLLER,
        VALUE_TREASURY,
        FLASH_ARBITRAGE,
        FLASH_HARVESTER,
        MARKET_MAKER,
        BRIDGE_RESERVE,
        BRIDGE_ADAPTER,
        RELAY_BRIDGE
    ];

    mapping(bytes32 => address) public module;
    uint256 public configurationNonce;
    string public contourVersion;

    event ModuleSet(bytes32 indexed moduleId, address indexed implementation, uint256 configurationNonce);
    event VersionSet(string version, uint256 configurationNonce);

    constructor(address admin, string memory version_) {
        require(admin != address(0), "REGISTRY: zero admin");
        _grantRole(DEFAULT_ADMIN_ROLE, admin);
        _grantRole(POLICY_ROLE, admin);
        contourVersion = version_;
    }

    function setModule(bytes32 moduleId, address implementation) external onlyRole(POLICY_ROLE) {
        require(_isRequired(moduleId), "REGISTRY: unknown module");
        require(implementation != address(0) && implementation.code.length > 0, "REGISTRY: invalid implementation");
        module[moduleId] = implementation;
        ++configurationNonce;
        emit ModuleSet(moduleId, implementation, configurationNonce);
    }

    function setVersion(string calldata version_) external onlyRole(POLICY_ROLE) {
        require(bytes(version_).length > 0, "REGISTRY: empty version");
        contourVersion = version_;
        ++configurationNonce;
        emit VersionSet(version_, configurationNonce);
    }

    function validateContour() external view returns (bool) {
        for (uint256 i; i < _requiredIds.length; ++i) {
            address implementation = module[_requiredIds[i]];
            if (implementation == address(0) || implementation.code.length == 0) return false;
        }
        return true;
    }

    function topologyHash() external view returns (bytes32 hash) {
        hash = keccak256(abi.encode(block.chainid, address(this), contourVersion, configurationNonce));
        for (uint256 i; i < _requiredIds.length; ++i) {
            hash = keccak256(abi.encode(hash, _requiredIds[i], module[_requiredIds[i]]));
        }
    }

    function requiredModule(uint256 index) external view returns (bytes32) {
        return _requiredIds[index];
    }

    function _isRequired(bytes32 moduleId) internal view returns (bool) {
        for (uint256 i; i < _requiredIds.length; ++i) {
            if (_requiredIds[i] == moduleId) return true;
        }
        return false;
    }
}
