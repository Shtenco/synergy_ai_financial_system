const fs = require("fs");
const path = require("path");
const { ethers } = require("hardhat");

function required(name) {
  const value = (process.env[name] || "").trim();
  if (!value) throw new Error(`Missing ${name}`);
  return value;
}
function jsonSafe(value) {
  return JSON.parse(JSON.stringify(value, (_, v) => typeof v === "bigint" ? v.toString() : v));
}

async function main() {
  const controllerAddress = required("TOP_AI_CONTROLLER_ADDRESS");
  const harvesterAddress = required("FLASH_HARVESTER_ADDRESS");
  const treasuryAddress = required("VALUE_TREASURY_ADDRESS");
  const flashAddress = required("FLASH_ARBITRAGE_ADDRESS");
  const tokenAddress = required("PROFIT_TOKEN_ADDRESS");
  const amount = BigInt(required("PROFIT_AMOUNT_WEI"));
  const accountingRisk = BigInt(required("MAX_CAPITAL_AT_RISK_ACCOUNTING_WEI"));
  const expectedDelta = BigInt(process.env.EXPECTED_NAV_DELTA_WEI || "1");
  const riskBps = Number(process.env.MODEL_RISK_BPS || "800");
  const decisionPath = path.resolve(process.env.DECISION_JSON || "../../../deployments/defi-top-ai-decision.json");
  const decisionRaw = JSON.parse(fs.readFileSync(decisionPath, "utf8"));
  const decision = decisionRaw.best ? decisionRaw.best.decision : decisionRaw.decision;
  const allocation = decision.allocation;

  const controller = await ethers.getContractAt("SHTENCOTopAIController", controllerAddress);
  const oracleAddress = await controller.stateOracle();
  const oracle = await ethers.getContractAt("SHTENCOSystemStateOracle", oracleAddress);
  const snapshot = await oracle.getLatestSnapshot();
  if (snapshot.round === 0n) throw new Error("No finalized state snapshot");

  const harvester = await ethers.getContractAt("SHTENCOFlashProfitHarvester", harvesterAddress);
  const treasury = await ethers.getContractAt("SHTENCOValueFlowTreasury", treasuryAddress);
  const sourceText = process.env.SOURCE_ID_TEXT || `flash-profit-${Date.now()}`;
  const sourceId = ethers.id(sourceText);
  const actions = [
    {
      target: harvesterAddress,
      value: 0n,
      data: harvester.interface.encodeFunctionData("harvest", [flashAddress, tokenAddress, amount, sourceId]),
      budgetToken: tokenAddress,
      budgetAmount: amount,
    },
    {
      target: treasuryAddress,
      value: 0n,
      data: treasury.interface.encodeFunctionData("allocateRevenue", [tokenAddress, amount, {
        reserveBps: allocation.reserve_bps,
        liquidityBps: allocation.liquidity_bps,
        buybackBps: allocation.buyback_bps,
        bridgeBps: allocation.bridge_bps,
        insuranceBps: allocation.insurance_bps,
        operationsBps: allocation.operations_bps,
      }]),
      budgetToken: ethers.ZeroAddress,
      budgetAmount: 0n,
    },
  ];
  const block = await ethers.provider.getBlock("latest");
  const delay = Number(process.env.PROPOSAL_DELAY_SECONDS || "900");
  const window = Number(process.env.PROPOSAL_WINDOW_SECONDS || "3600");
  const request = {
    snapshotRound: snapshot.round,
    objectiveHash: ethers.id(`realized-profit-to-fundamental-value:${decision.name}:${sourceText}`),
    expectedNavDelta: expectedDelta,
    maxCapitalAtRisk: accountingRisk,
    modelRiskBps: riskBps,
    executeAfter: block.timestamp + delay,
    expiresAt: block.timestamp + delay + window,
  };
  const payload = jsonSafe({
    controller: controllerAddress,
    oracle: oracleAddress,
    snapshotHash: snapshot.snapshotHash,
    decision: decision.name,
    sourceId,
    sourceText,
    actions,
    request,
  });
  const out = path.resolve(process.env.PROPOSAL_PAYLOAD || "../../../deployments/top-ai-proposal-payload.json");
  fs.mkdirSync(path.dirname(out), { recursive: true });
  fs.writeFileSync(out, JSON.stringify(payload, null, 2));
  console.log(`Saved ${out}`);
  console.log(JSON.stringify(payload, null, 2));
}
main().catch(e => { console.error(e); process.exitCode = 1; });
