#!/usr/bin/env python3
"""Dependency-free regression tests for flash-arbitrage accounting."""

from __future__ import annotations

import unittest

BPS = 10_000


def reconstruct_amount_out(
    before_out: int,
    after_out: int,
    amount_in: int,
    same_token: bool,
) -> int:
    if same_token:
        if after_out + amount_in <= before_out:
            raise ValueError("balance delta too small")
        return after_out + amount_in - before_out
    if after_out <= before_out:
        raise ValueError("balance delta too small")
    return after_out - before_out


def premium_ceil(amount: int, premium_bps: int) -> int:
    return (amount * premium_bps + BPS - 1) // BPS


def eligible(quote: int, amount: int, premium_bps: int, gas: int, net: int) -> bool:
    return quote >= amount + premium_ceil(amount, premium_bps) + gas + net


class FlashArbitrageMathTests(unittest.TestCase):
    def test_same_token_cycle_returns_full_output_not_only_profit(self) -> None:
        retained = 7
        principal = 1_000
        router_output = 1_025
        before = retained + principal
        after = retained + router_output
        self.assertEqual(
            reconstruct_amount_out(before, after, principal, same_token=True),
            router_output,
        )

    def test_different_token_uses_positive_balance_delta(self) -> None:
        self.assertEqual(reconstruct_amount_out(20, 145, 100, False), 125)

    def test_non_positive_delta_rejected(self) -> None:
        with self.assertRaises(ValueError):
            reconstruct_amount_out(100, 99, 50, False)

    def test_premium_rounds_up_off_chain(self) -> None:
        self.assertEqual(premium_ceil(1, 5), 1)
        self.assertEqual(premium_ceil(10_000, 5), 5)

    def test_quote_must_cover_every_cost(self) -> None:
        self.assertTrue(eligible(1_021, 1_000, 5, 10, 10))
        self.assertFalse(eligible(1_020, 1_000, 5, 10, 10))


if __name__ == '__main__':
    unittest.main(verbosity=2)
