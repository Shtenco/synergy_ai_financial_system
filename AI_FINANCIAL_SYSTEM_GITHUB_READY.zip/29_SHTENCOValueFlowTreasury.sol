// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {AccessControl} from "@openzeppelin/contracts/access/AccessControl.sol";
import {Pausable} from "@openzeppelin/contracts/utils/Pausable.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";

/**
 * @title SHTENCOValueFlowTreasury
 * @notice Accounting and distribution layer for realized protocol revenue.
 *         Buybacks can be funded only from recorded revenue. Reserve QE can
 *         reclassify backed excess reserves into liquidity, bridge inventory
 *         or insurance, never into buybacks or operating extraction.
 */
contract SHTENCOValueFlowTreasury is AccessControl, Pausable, ReentrancyGuard {
    using SafeERC20 for IERC20;

    bytes32 public constant CONTROLLER_ROLE = keccak256("CONTROLLER_ROLE");
    bytes32 public constant POLICY_ROLE = keccak256("POLICY_ROLE");
    bytes32 public constant GUARDIAN_ROLE = keccak256("GUARDIAN_ROLE");
    bytes32 public constant REVENUE_RECORDER_ROLE = keccak256("REVENUE_RECORDER_ROLE");
    uint256 public constant BPS = 10_000;

    enum Bucket { RESERVE, LIQUIDITY, BUYBACK, BRIDGE, INSURANCE, OPERATIONS }

    struct Allocation {
        uint16 reserveBps;
        uint16 liquidityBps;
        uint16 buybackBps;
        uint16 bridgeBps;
        uint16 insuranceBps;
        uint16 operationsBps;
    }

    struct TokenPolicy {
        bool enabled;
        uint256 reserveFloor;
        uint256 dailyReleaseLimit;
    }

    struct DailyFlow {
        uint64 day;
        uint192 amount;
    }

    mapping(address => TokenPolicy) public tokenPolicy;
    mapping(address => uint256) public unallocatedRevenue;
    mapping(address => uint256) public classifiedBalance;
    mapping(address => uint256) public totalRealizedRevenue;
    mapping(address => mapping(uint8 => uint256)) public bucketBalance;
    mapping(uint8 => mapping(address => bool)) public allowedSink;
    mapping(address => DailyFlow) private _dailyRelease;
    mapping(bytes32 => bool) public processedRevenue;

    event TokenPolicySet(address indexed token, bool enabled, uint256 reserveFloor, uint256 dailyReleaseLimit);
    event SinkSet(Bucket indexed bucket, address indexed sink, bool allowed);
    event RevenueRecorded(address indexed token, uint256 amount, bytes32 indexed sourceId, address indexed recorder);
    event RevenueAllocated(address indexed token, uint256 amount, Allocation allocation);
    event ReserveQEReclassified(address indexed token, Bucket indexed targetBucket, uint256 amount, bytes32 reason);
    event BucketReleased(address indexed token, Bucket indexed bucket, address indexed sink, uint256 amount, bytes32 reason);
    event UnclassifiedRescued(address indexed token, address indexed to, uint256 amount);

    constructor(address admin) {
        require(admin != address(0), "VALUE: zero admin");
        _grantRole(DEFAULT_ADMIN_ROLE, admin);
        _grantRole(POLICY_ROLE, admin);
        _grantRole(GUARDIAN_ROLE, admin);
    }

    function depositRevenue(address token, uint256 amount, bytes32 sourceId)
        external
        nonReentrant
        whenNotPaused
    {
        TokenPolicy memory policy = tokenPolicy[token];
        require(policy.enabled && amount > 0, "VALUE: token or amount");
        uint256 beforeBalance = IERC20(token).balanceOf(address(this));
        IERC20(token).safeTransferFrom(msg.sender, address(this), amount);
        uint256 received = IERC20(token).balanceOf(address(this)) - beforeBalance;
        require(received == amount, "VALUE: unsupported transfer token");
        _recordRevenue(token, amount, sourceId, msg.sender);
    }

    function recordRevenue(address token, uint256 amount, bytes32 sourceId)
        external
        onlyRole(REVENUE_RECORDER_ROLE)
        whenNotPaused
    {
        _recordRevenue(token, amount, sourceId, msg.sender);
    }

    function _recordRevenue(address token, uint256 amount, bytes32 sourceId, address recorder) internal {
        require(tokenPolicy[token].enabled && amount > 0, "VALUE: token or amount");
        require(sourceId != bytes32(0) && !processedRevenue[sourceId], "VALUE: revenue replay");
        require(IERC20(token).balanceOf(address(this)) >= classifiedBalance[token] + amount, "VALUE: funds not received");
        processedRevenue[sourceId] = true;
        classifiedBalance[token] += amount;
        unallocatedRevenue[token] += amount;
        totalRealizedRevenue[token] += amount;
        emit RevenueRecorded(token, amount, sourceId, recorder);
    }

    function allocateRevenue(address token, uint256 amount, Allocation calldata allocation)
        external
        onlyRole(CONTROLLER_ROLE)
        whenNotPaused
    {
        require(tokenPolicy[token].enabled && amount > 0 && amount <= unallocatedRevenue[token], "VALUE: unavailable revenue");
        _validateAllocation(allocation);
        unallocatedRevenue[token] -= amount;

        uint256 liquidity = amount * allocation.liquidityBps / BPS;
        uint256 buyback = amount * allocation.buybackBps / BPS;
        uint256 bridge = amount * allocation.bridgeBps / BPS;
        uint256 insurance = amount * allocation.insuranceBps / BPS;
        uint256 operations = amount * allocation.operationsBps / BPS;
        uint256 reserve = amount - liquidity - buyback - bridge - insurance - operations;

        bucketBalance[token][uint8(Bucket.RESERVE)] += reserve;
        bucketBalance[token][uint8(Bucket.LIQUIDITY)] += liquidity;
        bucketBalance[token][uint8(Bucket.BUYBACK)] += buyback;
        bucketBalance[token][uint8(Bucket.BRIDGE)] += bridge;
        bucketBalance[token][uint8(Bucket.INSURANCE)] += insurance;
        bucketBalance[token][uint8(Bucket.OPERATIONS)] += operations;
        emit RevenueAllocated(token, amount, allocation);
    }

    function reclassifyReserveQE(address token, Bucket targetBucket, uint256 amount, bytes32 reason)
        external
        onlyRole(CONTROLLER_ROLE)
        whenNotPaused
    {
        require(
            targetBucket == Bucket.LIQUIDITY || targetBucket == Bucket.BRIDGE || targetBucket == Bucket.INSURANCE,
            "VALUE: QE target forbidden"
        );
        require(amount > 0, "VALUE: zero amount");
        uint256 reserve = bucketBalance[token][uint8(Bucket.RESERVE)];
        require(reserve >= amount, "VALUE: reserve balance");
        require(reserve - amount >= tokenPolicy[token].reserveFloor, "VALUE: reserve floor");
        bucketBalance[token][uint8(Bucket.RESERVE)] = reserve - amount;
        bucketBalance[token][uint8(targetBucket)] += amount;
        emit ReserveQEReclassified(token, targetBucket, amount, reason);
    }

    function release(address token, Bucket bucket, address sink, uint256 amount, bytes32 reason)
        external
        onlyRole(CONTROLLER_ROLE)
        nonReentrant
        whenNotPaused
    {
        require(tokenPolicy[token].enabled && allowedSink[uint8(bucket)][sink], "VALUE: forbidden sink");
        require(amount > 0 && bucketBalance[token][uint8(bucket)] >= amount, "VALUE: bucket balance");
        if (bucket == Bucket.RESERVE) {
            require(
                bucketBalance[token][uint8(bucket)] - amount >= tokenPolicy[token].reserveFloor,
                "VALUE: reserve floor"
            );
        }
        _consumeRelease(token, amount);
        bucketBalance[token][uint8(bucket)] -= amount;
        classifiedBalance[token] -= amount;
        IERC20(token).safeTransfer(sink, amount);
        emit BucketReleased(token, bucket, sink, amount, reason);
    }

    function _validateAllocation(Allocation calldata a) internal pure {
        uint256 sum = uint256(a.reserveBps) + a.liquidityBps + a.buybackBps + a.bridgeBps + a.insuranceBps + a.operationsBps;
        require(sum == BPS, "VALUE: allocation sum");
        require(a.reserveBps >= 2_500 && a.reserveBps <= 6_000, "VALUE: reserve range");
        require(a.liquidityBps >= 1_500 && a.liquidityBps <= 4_000, "VALUE: liquidity range");
        require(a.buybackBps <= 2_000, "VALUE: buyback range");
        require(a.bridgeBps >= 500 && a.bridgeBps <= 2_000, "VALUE: bridge range");
        require(a.insuranceBps >= 500 && a.insuranceBps <= 2_000, "VALUE: insurance range");
        require(a.operationsBps <= 1_000, "VALUE: operations range");
    }

    function _consumeRelease(address token, uint256 amount) internal {
        DailyFlow storage flow = _dailyRelease[token];
        uint64 day = uint64(block.timestamp / 1 days);
        if (flow.day != day) {
            flow.day = day;
            flow.amount = 0;
        }
        uint256 next = uint256(flow.amount) + amount;
        uint256 limit = tokenPolicy[token].dailyReleaseLimit;
        require(limit > 0 && next <= limit, "VALUE: daily release");
        require(next <= type(uint192).max, "VALUE: flow overflow");
        flow.amount = uint192(next);
    }

    function setTokenPolicy(address token, TokenPolicy calldata policy) external onlyRole(POLICY_ROLE) {
        require(token != address(0) && (!policy.enabled || token.code.length > 0), "VALUE: invalid token");
        require(!policy.enabled || policy.dailyReleaseLimit > 0, "VALUE: zero daily limit");
        tokenPolicy[token] = policy;
        emit TokenPolicySet(token, policy.enabled, policy.reserveFloor, policy.dailyReleaseLimit);
    }

    function setSink(Bucket bucket, address sink, bool allowed) external onlyRole(POLICY_ROLE) {
        require(sink != address(0) && (!allowed || sink.code.length > 0), "VALUE: invalid sink");
        allowedSink[uint8(bucket)][sink] = allowed;
        emit SinkSet(bucket, sink, allowed);
    }

    function releaseToday(address token) external view returns (uint256) {
        DailyFlow memory flow = _dailyRelease[token];
        return flow.day == uint64(block.timestamp / 1 days) ? flow.amount : 0;
    }

    function unclassifiedSurplus(address token) public view returns (uint256) {
        uint256 balance = IERC20(token).balanceOf(address(this));
        return balance > classifiedBalance[token] ? balance - classifiedBalance[token] : 0;
    }

    function rescueUnclassified(address token, address to, uint256 amount)
        external
        onlyRole(GUARDIAN_ROLE)
        nonReentrant
    {
        require(to != address(0) && amount <= unclassifiedSurplus(token), "VALUE: classified funds");
        IERC20(token).safeTransfer(to, amount);
        emit UnclassifiedRescued(token, to, amount);
    }

    function pause() external onlyRole(GUARDIAN_ROLE) { _pause(); }
    function unpause() external onlyRole(DEFAULT_ADMIN_ROLE) { _unpause(); }
}
