// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

// ═══════════════════════════════════════════════════════════════════════════
//  SINERGY DEFLATION SYSTEM — 13_CollateralEmission.sol
//  Залоговая эмиссия: ALTN → SYNA → SYNR reserve
//
//  МЕХАНИКА:
//   Пользователь закладывает ALTN (LTV=50%, CR_MINT=200%)
//   → получает SYNA (долговой токен)
//   → SYNR reserve растёт (залог обеспечивает SYNR)
//   → EmissionEngine видит больший LP → emit больше → dlp→ALTN pool
//   → ALTN цена↑ → залог дороже → можно залоговать больше → ∞
//
//  РАСПРЕДЕЛЕНИЕ при repay:
//   40% collValue → lpBuf (inject ALTN pool)
//   30% → reserveR (SYNR backing)
//   20% → traderReserve
//   10% → founder
//
//  РАСПРЕДЕЛЕНИЕ при liquidation:
//   10% → бонус ликвидатору
//   50% → reserveR (SYNR reserve — усиление при падении)
//   30% → reserveR (доп)
//   20% → SRL Ring A+B
// ═══════════════════════════════════════════════════════════════════════════

import {AccessControl}    from "@openzeppelin/contracts/access/AccessControl.sol";
import {Pausable}          from "@openzeppelin/contracts/utils/Pausable.sol";
import {ReentrancyGuard}   from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {IERC20}            from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20}         from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {Math}              from "@openzeppelin/contracts/utils/math/Math.sol";
import "./01_PolygonConfig.sol";
import "./00_CircularInterfaces.sol";

error CE_ZeroAddress();
error CE_ZeroAmount();
error CE_InsufficientCR(uint256 cr, uint256 required);
error CE_NoPosition(address user);
error CE_PositionHealthy(uint256 cr, uint256 liqThreshold);
error CE_ExceedsMaxCollateral(uint256 amount, uint256 max);

interface ISYNAToken {
    function mint(address to, uint256 amount)       external;
    function forceBurn(address from, uint256 amount) external;
    function totalSupply() external view returns (uint256);
    function balanceOf(address) external view returns (uint256);
}

interface IALTNPairCE {
    function getReserves() external view returns (uint112,uint112,uint32);
    function token0()      external view returns (address);
}

contract CollateralEmission is AccessControl, Pausable, ReentrancyGuard {
    using SafeERC20 for IERC20;

    bytes32 public constant KEEPER_ROLE     = keccak256("KEEPER_ROLE");
    bytes32 public constant LIQUIDATOR_ROLE = keccak256("LIQUIDATOR_ROLE");
    bytes32 public constant PAUSER_ROLE     = keccak256("PAUSER_ROLE");

    // ── Параметры залога ──────────────────────────────────────────────
    uint256 public constant LTV_BPS        = 5_000;   // 50%
    uint256 public constant CR_MINT_BPS    = 20_000;  // 200%
    uint256 public constant CR_LIQ_BPS     = 15_000;  // 150%
    uint256 public constant LIQ_BONUS_BPS  = 1_000;   // 10%
    uint256 public constant R_CUT_BPS      = 1_000;   // 10% → протокол
    uint256 public constant MAX_COLL_BPS   = 500;     // 5% supply за вызов
    uint256 public constant YEAR_BLOCKS    = 15_768_000;
    uint256 public constant STABILITY_FEE  = 50;      // 0.5%/год

    // ── Круговые BPS ──────────────────────────────────────────────────
    uint256 public repayToLpBuf   = 4_000; // 40% repay → lpBuf (ALTN pool)
    uint256 public repayToReserve = 3_000; // 30% → reserveR (SYNR)
    uint256 public repayToTrader  = 2_000; // 20% → traderReserve
    uint256 public repayToFounder = 1_000; // 10% → founder

    // ── Зависимости ───────────────────────────────────────────────────
    ISYNAToken       public immutable syna;
    ICircularVault   public immutable vault;
    ICircularLoop    public immutable loop_;
    ICircularDivPool public immutable divPool;
    IERC20           public immutable altn;
    address          public immutable altnPair;
    address          public immutable vaultAddr;
    address          public immutable divPoolAddr;

    // ── Позиции ───────────────────────────────────────────────────────
    struct Position {
        uint256 collALTN;
        uint256 debtSYNA;
        uint256 openedAt;
        uint256 lastFeeBlock;
    }
    mapping(address => Position) public positions;
    address[] public positionHolders;
    mapping(address => bool) private _hasPosition;

    // ── Статистика ────────────────────────────────────────────────────
    uint256 public totalCollALTN;
    uint256 public totalDebtSYNA;
    uint256 public protocolReserve;
    uint256 public totalMinted;
    uint256 public totalRepaid;
    uint256 public totalLiquidated;
    uint256 public totalInjectedALTN;
    uint256 public totalInjectedSYNR;

    event PositionOpened(address indexed user, uint256 altnIn, uint256 synaMinted, uint256 pricePOL);
    event PositionRepaid(address indexed user, uint256 synaRepaid, uint256 altnReleased);
    event PositionLiquidated(address indexed user, address indexed keeper, uint256 debt, uint256 bonus);
    event CircularInject(uint256 toLpBuf, uint256 toReserve, uint256 toTrader, uint256 toFounder);
    event SYNREmitRebalance(uint256 dlpTotal, uint256 newCollValue);

    // ─────────────────────────────────────────────────────────────────
    constructor(
        address syna_,  address altn_,  address altnPair_,
        address vault_, address loop__, address divPool_,
        address admin_
    ) {
        if (syna_ == address(0) || altn_ == address(0) || vault_ == address(0))
            revert CE_ZeroAddress();
        syna      = ISYNAToken(syna_);
        altn      = IERC20(altn_);
        altnPair  = altnPair_;
        vault     = ICircularVault(vault_);
        loop_     = ICircularLoop(loop__);
        divPool   = ICircularDivPool(divPool_);
        vaultAddr = vault_;
        divPoolAddr = divPool_;
        _grantRole(DEFAULT_ADMIN_ROLE, admin_);
        _grantRole(KEEPER_ROLE,        admin_);
        _grantRole(LIQUIDATOR_ROLE,    admin_);
        _grantRole(PAUSER_ROLE,        admin_);
    }

    // ═══════════════════════════════════════════════════════════════════
    //  MINT SYNA — залог ALTN → mint SYNA
    // ═══════════════════════════════════════════════════════════════════
    function mintSYNA(uint256 altnAmount, uint256 synaAmount)
        external nonReentrant whenNotPaused
    {
        if (altnAmount == 0 || synaAmount == 0) revert CE_ZeroAmount();
        uint256 maxColl = altn.totalSupply() * MAX_COLL_BPS / 10_000;
        if (altnAmount > maxColl) revert CE_ExceedsMaxCollateral(altnAmount, maxColl);

        uint256 collPOL = _altnValuePOL(altnAmount);
        uint256 safeV   = collPOL * (10_000 - 5_000) / 10_000; // haircut 50%
        uint256 cr      = safeV * 10_000 / synaAmount;
        if (cr < CR_MINT_BPS) revert CE_InsufficientCR(cr, CR_MINT_BPS);

        altn.safeTransferFrom(msg.sender, address(this), altnAmount);

        uint256 rCut   = synaAmount * R_CUT_BPS / 10_000;
        uint256 toUser = synaAmount - rCut;
        protocolReserve += rCut;

        Position storage pos = positions[msg.sender];
        if (!_hasPosition[msg.sender]) {
            positionHolders.push(msg.sender);
            _hasPosition[msg.sender] = true;
        }
        pos.collALTN     += altnAmount;
        pos.debtSYNA     += synaAmount;
        pos.openedAt      = pos.openedAt == 0 ? block.timestamp : pos.openedAt;
        pos.lastFeeBlock  = block.number;

        totalCollALTN += altnAmount;
        totalDebtSYNA += synaAmount;
        totalMinted   += toUser;

        syna.mint(msg.sender, toUser);

        // SYNR reserve backing: 2% collValue → reserveR
        uint256 synrBoost = collPOL * 200 / 10_000;
        if (synrBoost > 0) try vault.addToReserveR(synrBoost) {} catch {}

        // SRL contrib
        try loop_.contribute(0, synaAmount * 15 / 10_000) {} catch {}
        try loop_.contribute(1, synaAmount * 50 / 10_000) {} catch {}

        emit PositionOpened(msg.sender, altnAmount, toUser, collPOL);
    }

    // ═══════════════════════════════════════════════════════════════════
    //  REPAY SYNA → release ALTN + circular inject
    // ═══════════════════════════════════════════════════════════════════
    function repaySYNA(uint256 synaAmount) external nonReentrant whenNotPaused {
        Position storage pos = positions[msg.sender];
        if (pos.debtSYNA == 0) revert CE_NoPosition(msg.sender);
        if (synaAmount  == 0) revert CE_ZeroAmount();

        // Stability fee
        uint256 fee = _accrueStabilityFee(pos);
        if (fee > 0) { syna.forceBurn(msg.sender, fee); protocolReserve += fee; }

        uint256 repay      = synaAmount > pos.debtSYNA ? pos.debtSYNA : synaAmount;
        uint256 altnReturn = pos.collALTN * repay / pos.debtSYNA;

        pos.debtSYNA  -= repay;
        pos.collALTN  -= altnReturn;
        totalDebtSYNA -= repay;
        totalCollALTN -= altnReturn;
        totalRepaid   += repay;

        syna.forceBurn(msg.sender, repay);

        // Circular inject
        uint256 collPOL = _altnValuePOL(altnReturn);
        uint256 toLpBuf  = collPOL * repayToLpBuf   / 10_000;
        uint256 toResR   = collPOL * repayToReserve  / 10_000;
        uint256 toTrader = collPOL * repayToTrader   / 10_000;
        uint256 toFounder= collPOL * repayToFounder  / 10_000;

        altn.safeTransfer(msg.sender, altnReturn);

        if (toLpBuf  > 0) try vault.addToLpBuf(toLpBuf)           {} catch {}
        if (toResR   > 0) try vault.addToReserveR(toResR)         {} catch {}
        if (toTrader > 0) try vault.addToTraderReserve(toTrader)   {} catch {}
        if (toFounder> 0) try divPool.notifyFounder(toFounder)     {} catch {}

        try loop_.contribute(1, collPOL * 50 / 10_000) {} catch {}

        totalInjectedALTN += toLpBuf;
        totalInjectedSYNR += toResR;

        emit PositionRepaid(msg.sender, repay, altnReturn);
        emit CircularInject(toLpBuf, toResR, toTrader, toFounder);
    }

    // ═══════════════════════════════════════════════════════════════════
    //  LIQUIDATE
    // ═══════════════════════════════════════════════════════════════════
    function liquidate(address user)
        external nonReentrant whenNotPaused onlyRole(LIQUIDATOR_ROLE)
    {
        Position storage pos = positions[user];
        if (pos.debtSYNA == 0) revert CE_NoPosition(user);

        uint256 collPOL = _altnValuePOL(pos.collALTN);
        uint256 safeV   = collPOL * 5_000 / 10_000;
        uint256 cr      = safeV * 10_000 / Math.max(pos.debtSYNA, 1);
        if (cr >= CR_LIQ_BPS) revert CE_PositionHealthy(cr, CR_LIQ_BPS);

        uint256 debt    = pos.debtSYNA;
        uint256 seized  = pos.collALTN;
        totalDebtSYNA  -= debt;
        totalCollALTN  -= seized;
        totalLiquidated+= debt;
        delete positions[user];

        syna.forceBurn(msg.sender, debt);

        uint256 bonus    = seized * LIQ_BONUS_BPS / 10_000;
        uint256 rem      = seized - bonus;
        altn.safeTransfer(msg.sender, bonus);
        altn.safeTransfer(vaultAddr,  rem);

        // 50% seized value → SYNR reserve (усиление при ликвидации)
        uint256 remPOL = _altnValuePOL(rem);
        try vault.addToReserveR(remPOL * 8_000 / 10_000)         {} catch {}
        try loop_.contribute(0, remPOL * 15 / 10_000)             {} catch {}
        try loop_.contribute(1, remPOL * 50 / 10_000)             {} catch {}

        totalInjectedSYNR += remPOL * 8_000 / 10_000;
        emit PositionLiquidated(user, msg.sender, debt, bonus);
    }

    // ═══════════════════════════════════════════════════════════════════
    //  CALLBACKS
    // ═══════════════════════════════════════════════════════════════════

    /// @notice Вызывается CircularHub (KEEPER_ROLE) — flush protocolReserve
    function processCircular() external onlyRole(KEEPER_ROLE) whenNotPaused {
        uint256 r = protocolReserve;
        if (r < 1e15) return;
        protocolReserve = 0;
        try vault.addToReserveR(r * 4_000 / 10_000)          {} catch {}
        try vault.addToLpBuf(r * 3_000 / 10_000)             {} catch {}
        try loop_.contribute(0, r * 2_000 / 10_000 * 15/100) {} catch {}
        try loop_.contribute(1, r * 2_000 / 10_000 * 50/100) {} catch {}
        try divPool.notifyFounder(r * 1_000 / 10_000)         {} catch {}
    }

    /// @notice Вызывается EmissionEngine после executeEmission
    /// При росте SYNR → залоги ALTN дорожают → CR растёт → можно залоговать больше
    function onSYNREmit(uint256 dlpTotal) external {
        if (dlpTotal == 0) return;
        // Просто логируем; при высоком CR Hub может авто-инициировать новые позиции
        emit SYNREmitRebalance(dlpTotal, _altnValuePOL(totalCollALTN));
    }

    // ═══════════════════════════════════════════════════════════════════
    //  HELPERS
    // ═══════════════════════════════════════════════════════════════════
    function _altnValuePOL(uint256 altnAmt) private view returns (uint256) {
        if (altnPair == address(0) || altnAmt == 0) return 0;
        try IALTNPairCE(altnPair).getReserves() returns (uint112 r0, uint112 r1, uint32) {
            address t0 = IALTNPairCE(altnPair).token0();
            uint256 tR = t0 == address(altn) ? uint256(r0) : uint256(r1);
            uint256 pR = t0 == address(altn) ? uint256(r1) : uint256(r0);
            if (tR == 0) return 0;
            return altnAmt * pR / tR;
        } catch { return 0; }
    }

    function _accrueStabilityFee(Position storage pos) private returns (uint256 fee) {
        uint256 blocks = block.number - pos.lastFeeBlock;
        if (blocks == 0 || pos.debtSYNA == 0) return 0;
        fee = pos.debtSYNA * STABILITY_FEE * blocks / (10_000 * YEAR_BLOCKS);
        pos.lastFeeBlock = block.number;
    }

    // ── VIEW ──────────────────────────────────────────────────────────
    function getPosition(address user) external view returns (
        uint256 collALTN_, uint256 debtSYNA_,
        uint256 collValuePOL_, uint256 crBPS_
    ) {
        Position memory p = positions[user];
        collALTN_    = p.collALTN;
        debtSYNA_    = p.debtSYNA;
        collValuePOL_= _altnValuePOL(p.collALTN);
        uint256 sv   = collValuePOL_ * 5_000 / 10_000;
        crBPS_       = p.debtSYNA > 0 ? sv * 10_000 / p.debtSYNA : type(uint256).max;
    }

    function isLiquidatable(address user) external view returns (bool) {
        Position memory p = positions[user];
        if (p.debtSYNA == 0) return false;
        uint256 sv = _altnValuePOL(p.collALTN) * 5_000 / 10_000;
        return sv * 10_000 / p.debtSYNA < CR_LIQ_BPS;
    }

    function systemStats() external view returns (
        uint256 collALTN_, uint256 debtSYNA_,
        uint256 protoReserve_, uint256 injALTN_, uint256 injSYNR_,
        uint256 minted_, uint256 liquidated_
    ) {
        return (totalCollALTN, totalDebtSYNA, protocolReserve,
                totalInjectedALTN, totalInjectedSYNR, totalMinted, totalLiquidated);
    }

    function positionCount() external view returns (uint256) { return positionHolders.length; }

    function pause()   external onlyRole(PAUSER_ROLE) { _pause(); }
    function unpause() external onlyRole(PAUSER_ROLE) { _unpause(); }
}
