// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

contract MockActionTarget {
    uint256 public value;
    bytes32 public reason;
    event ValueSet(uint256 value, bytes32 reason);
    function setValue(uint256 value_, bytes32 reason_) external payable returns (uint256) {
        value = value_;
        reason = reason_;
        emit ValueSet(value_, reason_);
        return value_ + 1;
    }
}
