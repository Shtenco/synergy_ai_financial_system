#!/usr/bin/env python3
"""
ДЕПЛОЙ EmissionEngine с MAX emitRate для прибыльности
"""
import sys, io, json, os, time
from dotenv import load_dotenv
from web3 import Web3
from web3.middleware import ExtraDataToPOAMiddleware

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

load_dotenv()
w3 = Web3(Web3.HTTPProvider("https://polygon-bor-rpc.publicnode.com", request_kwargs={"timeout": 300}))
w3.middleware_onion.inject(ExtraDataToPOAMiddleware, layer=0)

PK = os.getenv("OWNER_PRIVATE_KEY")
OWNER = "0x6946999DBCE63b140B1bB9D475F7c357130909E5"

def C(a): return Web3.to_checksum_address(a)

with open("deployed_TROIKA_v3.json") as f:
    d = json.load(f)

print("="*70)
print("DEPLOY EmissionEngineMAX (emitRate = 50e-6)")
print("="*70)

pol_bal = w3.eth.get_balance(C(OWNER)) / 1e18
print(f"Owner POL: {pol_bal:.4f}")

# Load compiled contract
with open("out/07_EmissionEngine_MAX.sol/EmissionEngineMAX.json", encoding="utf-8") as f:
    artifact = json.load(f)

abi = artifact["abi"]
bytecode = artifact["bytecode"]["object"]

nonce = w3.eth.get_transaction_count(C(OWNER), "pending")
base = w3.eth.get_block("latest").get("baseFeePerGas", int(100e9))
prio = int(50e9)
mf = base * 2 + prio

print(f"\n[1] Deploying EmissionEngineMAX...")
contract = w3.eth.contract(abi=abi, bytecode=bytecode)

tx = contract.constructor(
    C(d["vault"]),
    C(d["tokens"]["SYNA"]),
    C(d["tokens"]["SYNC"]),
    C(d["tokens"]["SYNR"]),
    C(d["divPool"]),
    C(OWNER)
).build_transaction({
    "from": C(OWNER), "nonce": nonce, "chainId": 137, "type": 2,
    "maxPriorityFeePerGas": prio, "maxFeePerGas": mf, "gas": 5_000_000
})

signed = w3.eth.account.sign_transaction(tx, PK)
h = w3.eth.send_raw_transaction(signed.raw_transaction)
print(f"  TX: {h.hex()[:20]}...")

r = w3.eth.wait_for_transaction_receipt(h, timeout=300)
if r.status == 1:
    new_emit = r.contractAddress
    print(f"  [OK] {new_emit}")
    nonce += 1
else:
    print("  [FAIL]")
    sys.exit(1)

time.sleep(3)

# Grant roles
token_abi = [
    {"name": "MINTER_ROLE", "inputs": [], "outputs": [{"type": "bytes32"}], "stateMutability": "view", "type": "function"},
    {"name": "BURNER_ROLE", "inputs": [], "outputs": [{"type": "bytes32"}], "stateMutability": "view", "type": "function"},
    {"name": "grantRole", "inputs": [{"name": "role", "type": "bytes32"}, {"name": "account", "type": "address"}], "outputs": [], "stateMutability": "nonpayable", "type": "function"},
]

vault_abi = [
    {"name": "OPERATOR_ROLE", "inputs": [], "outputs": [{"type": "bytes32"}], "stateMutability": "view", "type": "function"},
    {"name": "grantRole", "inputs": [{"name": "role", "type": "bytes32"}, {"name": "account", "type": "address"}], "outputs": [], "stateMutability": "nonpayable", "type": "function"},
]

div_abi = [
    {"name": "NOTIFIER_ROLE", "inputs": [], "outputs": [{"type": "bytes32"}], "stateMutability": "view", "type": "function"},
    {"name": "grantRole", "inputs": [{"name": "role", "type": "bytes32"}, {"name": "account", "type": "address"}], "outputs": [], "stateMutability": "nonpayable", "type": "function"},
]

def send_tx(func, label):
    global nonce
    print(f"  {label}...", end=" ", flush=True)
    tx = func.build_transaction({
        "from": C(OWNER), "nonce": nonce, "chainId": 137, "type": 2,
        "maxPriorityFeePerGas": prio, "maxFeePerGas": mf, "gas": 100000
    })
    signed = w3.eth.account.sign_transaction(tx, PK)
    h = w3.eth.send_raw_transaction(signed.raw_transaction)
    r = w3.eth.wait_for_transaction_receipt(h, timeout=120)
    print("OK" if r.status else "FAIL")
    nonce += 1
    time.sleep(1)
    return r.status

print(f"\n[2] Grant MINTER_ROLE to tokens...")
for name, addr in d["tokens"].items():
    tk = w3.eth.contract(address=C(addr), abi=token_abi)
    MINTER = tk.functions.MINTER_ROLE().call()
    send_tx(tk.functions.grantRole(MINTER, C(new_emit)), f"{name} MINTER")

print(f"\n[3] Grant BURNER_ROLE for SYNR...")
synr = w3.eth.contract(address=C(d["tokens"]["SYNR"]), abi=token_abi)
BURNER = synr.functions.BURNER_ROLE().call()
send_tx(synr.functions.grantRole(BURNER, C(new_emit)), "SYNR BURNER")

print(f"\n[4] Grant OPERATOR_ROLE in Vault...")
vault = w3.eth.contract(address=C(d["vault"]), abi=vault_abi)
OP = vault.functions.OPERATOR_ROLE().call()
send_tx(vault.functions.grantRole(OP, C(new_emit)), "Vault OPERATOR")

print(f"\n[5] Grant NOTIFIER_ROLE in DividendPool...")
divpool = w3.eth.contract(address=C(d["divPool"]), abi=div_abi)
NOT = divpool.functions.NOTIFIER_ROLE().call()
send_tx(divpool.functions.grantRole(NOT, C(new_emit)), "DivPool NOTIFIER")

print(f"\n[6] Grant CALLER_ROLE to Owner...")
emit_contract = w3.eth.contract(address=C(new_emit), abi=abi)
CALLER = emit_contract.functions.CALLER_ROLE().call()
send_tx(emit_contract.functions.grantRole(CALLER, C(OWNER)), "EmitEngine CALLER")

# Save
d["emitEngine_v3"] = new_emit
d["emitEngine_v3_rate"] = "50e-6 (MAX)"
with open("deployed_TROIKA_v3.json", "w") as f:
    json.dump(d, f, indent=2)

# Check params
gP, emitRate = emit_contract.functions.getParams().call()

print("\n" + "="*70)
print("EMISSIONENGINE MAX DEPLOYED!")
print("="*70)
print(f"  Address: {new_emit}")
print(f"  emitRate: {emitRate / 1e18:.10f} (должен быть 50e-6)")
print(f"  gP: {gP / 1e18:.10f}")
print(f"  POL remaining: {w3.eth.get_balance(C(OWNER)) / 1e18:.4f}")
print("="*70)
