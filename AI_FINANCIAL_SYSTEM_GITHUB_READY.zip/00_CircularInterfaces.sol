// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

// ═══════════════════════════════════════════════════════════════════════════
//  SINERGY DEFLATION SYSTEM — 00_CircularInterfaces.sol
//  Единый файл интерфейсов для связки ALTN ⟷ SYNR/SYNA/SYNC
//  Polygon 137 | QuickSwap V2
//
//  Система: 4 токена в круге
//   ALTN  — дефляционный (14 слоёв, Altyn.sol, deployed)
//   SYNR  — Sinergy Rise  (EmissionEngine, sqrt-AMM dlp)
//   SYNA  — Sinergy Anchor (залоговый стабильный)
//   SYNC  — Sinergy Cycle  (CBArbitrage торговый)
//
//  Коллбеки (глубокая связка):
//   ALTN._update()     → CircularHub.onALTNBurn(amount, burnType)
//   TroikaCore.processFee() → CircularHub.onFeeProcessed(amount, type)
//   EmissionEngine.executeEmission() → CircularHub.onPriceUpdate()
//   EmissionEngine.executeEmission() → CollateralEmission.onSYNREmit(dlp)
// ═══════════════════════════════════════════════════════════════════════════

import "./01_PolygonConfig.sol";

// ── ALTN интерфейс ────────────────────────────────────────────────────────
interface ICircularALTN {
    function maintenance()              external;
    function triggerBuyback()           external;
    function getCurrentPrice()          external view returns (uint256);
    function totalSupply()              external view returns (uint256);
    function balanceOf(address)         external view returns (uint256);
    function ethAccumulatedBuyback()    external view returns (uint256);
    function buybackThreshold()         external view returns (uint256);
    function setCircularHub(address)    external;
    function circularHub()              external view returns (address);
}

// ── SINERGY: TroikaCore ───────────────────────────────────────────────────
interface ICircularCore {
    function tick()                     external;
    function processFee(uint256, uint8) external;
    function paused()                   external view returns (bool);
    function totalTicks()               external view returns (uint256);
    function setCircularHub(address)    external;
}

// ── SINERGY: TroikaVault ──────────────────────────────────────────────────
interface ICircularVault {
    function addToReserveR(uint256)         external;
    function addToLpBuf(uint256)            external;
    function addToTraderReserve(uint256)    external;
    function batchAddLP(uint256,uint256,uint256) external;
    function totalLP()                      external view returns (uint256);
    function reserveR()                     external view returns (uint256);
    function lpP()                          external view returns (uint256);
    function lpR()                          external view returns (uint256);
    function lpT()                          external view returns (uint256);
    function syncFromChain()                external;
    function flushLpBuf()                   external;
    // Circular inject: распределяет как flushLpBuf (55%P/28%R/17%T)
    function circularInject(uint256 polAmount) external;
}

// ── SINERGY: EmissionEngine ───────────────────────────────────────────────
interface ICircularEmit {
    function adapt()                        external;
    function executeEmission()              external;
    function recordFee(uint256)             external;
    function setAlphaLP(uint256)            external;
    function isEmissionDue()                external view returns (bool);
    function gP()                           external view returns (uint256);
    function emitRate()                     external view returns (uint256);
    // Новый: внешний ценовой сигнал от CrossPrice
    // gP_new = gP×0.70 + crossPrice×0.30
    function setExternalPriceSignal(uint256 crossPricePOL) external;
    function totalEmittedP()                external view returns (uint256);
}

// ── SINERGY: SelfReinforcingLoop ──────────────────────────────────────────
interface ICircularLoop {
    function contribute(uint8, uint256)     external;
    function flush()                        external;
    function isFlushDue()                   external view returns (bool);
    function ringA()                        external view returns (uint256);
    function ringB()                        external view returns (uint256);
    function amplificationFactor()          external view returns (uint256);
}

// ── SINERGY: DividendPool ─────────────────────────────────────────────────
interface ICircularDivPool {
    function notifyFounder(uint256)         external;
    function notifyHolders(uint256)         external;
    function notifyFounderEmission(uint256) external;
    function founderPending()               external view returns (uint256);
}

// ── CollateralEmission ────────────────────────────────────────────────────
interface ICircularCollEmit {
    function processCircular()              external;
    // Вызывается EmissionEngine после executeEmission
    function onSYNREmit(uint256 dlpTotal)   external;
    function totalDebtSYNA()                external view returns (uint256);
    function totalCollateralALTN()          external view returns (uint256);
    function totalInjectedSYNR()            external view returns (uint256);
    function totalInjectedALTN()            external view returns (uint256);
    function protocolReserve()              external view returns (uint256);
}

// ── CircularHub ───────────────────────────────────────────────────────────
interface ICircularHub {
    function tick()                         external;
    // Коллбек от ALTN при каждом burn (burnType: 0=instant,1=cascade,2=velocity,3=lpBurn,4=buyback)
    function onALTNBurn(uint256, uint8)     external;
    // Коллбек от TroikaCore.processFee()
    function onFeeProcessed(uint256, uint8) external;
    // Коллбек от EmissionEngine после executeEmission
    function onPriceUpdate()                external;
    function getCrossPrice()                external view returns (uint256);
    function getALTNPrice()                 external view returns (uint256);
    function getSYNRPrice()                 external view returns (uint256);
}

// ── AMM пара ──────────────────────────────────────────────────────────────
interface ICircularPair {
    function getReserves() external view returns (uint112,uint112,uint32);
    function token0()      external view returns (address);
}

// ── Общая математика ──────────────────────────────────────────────────────
library CircularMath {
    uint256 internal constant PRECISION = 1e18;

    /// @notice Spot цена токена из AMM пары (POL per token, 1e18)
    function pairPrice(address pair, address token) internal view returns (uint256) {
        if (pair == address(0)) return 0;
        try ICircularPair(pair).getReserves() returns (uint112 r0, uint112 r1, uint32) {
            address t0 = ICircularPair(pair).token0();
            uint256 tR = t0 == token ? uint256(r0) : uint256(r1);
            uint256 pR = t0 == token ? uint256(r1) : uint256(r0);
            return tR > 0 ? pR * PRECISION / tR : 0;
        } catch { return 0; }
    }

    /// @notice CrossPrice = alphaALTN/1000 × P_ALTN + alphaSYNR/1000 × P_SYNR
    function crossPrice(uint256 pA, uint256 pNR, uint256 aA, uint256 aNR)
        internal pure returns (uint256)
    { return (pA * aA + pNR * aNR) / 1000; }

    /// @notice sqrt-AMM dlp = LP × (√((S+em)/S) − 1) × 0.997, cap 10% LP
    function sqrtAmmDlp(uint256 lpV, uint256 em, uint256 S)
        internal pure returns (uint256)
    {
        if (S == 0 || em == 0 || lpV == 0) return 0;
        uint256 dlp = lpV * em * 997 / (2 * S * 1000);
        return dlp > lpV / 10 ? lpV / 10 : dlp;
    }

    /// @notice CR (BPS) для залоговой позиции
    function coverageRatio(uint256 collPOL, uint256 haircutBPS, uint256 debt)
        internal pure returns (uint256)
    {
        if (debt == 0) return type(uint256).max;
        return collPOL * (10_000 - haircutBPS) / 10_000 * 10_000 / debt;
    }

    /// @notice Адаптация weight ±10, кэп [300, 700]
    function adaptWeight(uint256 cur, bool up) internal pure returns (uint256) {
        if (up) return cur < 700 ? cur + 10 : 700;
        return cur > 300 ? cur - 10 : 300;
    }
}
