// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

// ═══════════════════════════════════════════════════════════════════════════
//  SINERGY SYSTEM — 10_TroikaCore.sol
//  Главный оркестратор | Polygon + QuickSwap V2
//
//  TICK() — вызывается кипером каждый блок (~2 сек на Polygon):
//   1. TWAP update    (каждые 5 блоков)
//   2. Alpha adapt    (каждые 20 блоков)
//   3. LP buf flush   (каждые 10 блоков)
//   4. CB Arb         (каждые 5 блоков)
//   5. Loop flush     (каждые 50 блоков)
//   6. Emission+Fix+Buyback (каждые 1000 блоков)
//   7. Holders payout (каждые 1000 блоков)
//   8. FounderControl processFounder (если задан)
//   9. MCap Guard     (каждый блок при просадке)
//  10. Chain sync     (каждые 50 тиков)
//  11. Keeper reward  (из keeperFund)
//
//  PROCESS_FEE() — точка входа для торговых комиссий:
//   Трейдер: approve WPOL for TroikaCore → processFee()
//   Core: safeTransferFrom → FeeRouter.routeFee()
//   + вклад в петлю + запись в EmissionEngine + MCG + keeper
//
//  Chainlink Automation: checkUpkeep/performUpkeep совместимы
//
//  Безопасность:
//   ✓ try/catch на ВСЕХ внешних вызовах в tick() — ни один модуль не
//     блокирует всю систему
//   ✓ Pause мгновенный (pauseAll), Unpause с таймлоком 1 час
//   ✓ FC_ROLE — только для FounderControl (setFounderControl)
//   ✓ Нет selfdestruct, delegatecall, tx.origin
// ═══════════════════════════════════════════════════════════════════════════

import {IERC20}          from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20}       from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {AccessControl}   from "@openzeppelin/contracts/access/AccessControl.sol";
import {Pausable}        from "@openzeppelin/contracts/utils/Pausable.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import "./01_PolygonConfig.sol";

// ── Интерфейсы (file-level) ────────────────────────────────────────────────

interface IVaultCore {
    function totalLP()        external view returns (uint256);
    function totalMCap()      external view returns (uint256);
    function priceP()         external view returns (uint256);
    function priceT()         external view returns (uint256);
    function priceR()         external view returns (uint256);
    function traderReserve()  external view returns (uint256);
    function mcgFund()        external view returns (uint256);
    function initialized()    external view returns (bool);
    function pairPAddress()   external view returns (address);
    function pairTAddress()   external view returns (address);
    function addToMcgFund(uint256)   external;
    function subFromMcgFund(uint256) external;
    function batchAddLP(uint256, uint256, uint256) external;
    function flushLpBuf()    external;
    function syncFromChain() external;
    function pause()  external;
    function unpause() external;
    function mcgRecycle() external;
}

interface IOracleCore {
    function update() external returns (uint256);
    function setPairs(address, address) external;
    function needsUpdate() external view returns (bool);
    function pause()  external;
    function unpause() external;
}

interface IFeeRouterCore {
    function routeFee(uint256, uint8) external;
    function pause()  external;
    function unpause() external;
}

interface ICBArbCore {
    function executeArb() external returns (uint256);
    function pause()  external;
    function unpause() external;
}

interface IEmitCore {
    function adapt()           external;
    function executeEmission() external;
    function recordFee(uint256) external;
    function setAlphaLP(uint256) external;
    function setFixBase(uint256) external;
    function isEmissionDue()    external view returns (bool);
    function pause()  external;
    function unpause() external;
}

interface IDivCore {
    function executeHoldersPayout() external;
    function pause()  external;
    function unpause() external;
}

interface ILoopCore {
    function contribute(uint8, uint256) external;
    function flush()         external;
    function isFlushDue()    external view returns (bool);
    function pause()  external;
    function unpause() external;
}

interface IFounderCtl {
    function processFounderDividends() external;
    function autoWithdrawEnabled()     external view returns (bool);
    function reinvestEnabled()         external view returns (bool);
}

// ── Custom Errors ─────────────────────────────────────────────────────────
error CR_ZeroAddress();
error CR_AlreadyInitialized();
error CR_NotInitialized();
error CR_InvalidTokenType(uint8 t);
error CR_ZeroAmount();
error CR_UnpauseTimelockActive(uint256 unlockAt, uint256 now_);
error CR_UnpauseNotQueued();

contract TroikaCore is AccessControl, Pausable, ReentrancyGuard {
    using SafeERC20 for IERC20;

    bytes32 public constant ADMIN_ROLE  = keccak256("ADMIN_ROLE");
    bytes32 public constant PAUSER_ROLE = keccak256("PAUSER_ROLE");
    bytes32 public constant FC_ROLE     = keccak256("FC_ROLE");       // FounderControl

    // ── Модули ────────────────────────────────────────────────────────
    IVaultCore     public vault;
    IOracleCore    public oracle;
    IFeeRouterCore public feeRouter;
    ICBArbCore     public cbArb;
    IEmitCore      public emitEngine;
    IDivCore       public divPool;
    ILoopCore      public loop;
    IFounderCtl    public founderCtl;  // опциональный
    IERC20         public WPOL;

    address public feeRouterAddr;

    bool    public systemInitialized;

    // ── MCap Guard ────────────────────────────────────────────────────
    uint256 public prevMCap;

    // ── Keeper ────────────────────────────────────────────────────────
    uint256 public keeperFund;
    uint256 public lastTickBlock;
    uint256 public totalTicks;
    uint256 public totalFeeProcessed;

    // ── Unpause — INSTANT (no timelock) ──────────────────────────────
    uint256 public unpauseAt;
    uint256 public constant UNPAUSE_DELAY = 0;

    // ── Events ────────────────────────────────────────────────────────
    event SystemInitialized(uint256 blockN);
    event FounderCtlLinked(address fcAddr);
    event OraclePairsLinked(address pairP, address pairT);
    event TickDone(address indexed keeper, uint256 blockN, uint256 reward);
    event FeeProcessed(address indexed trader, uint256 amount, uint8 tokenType);
    event MCGFired(uint256 injected, uint256 mcNow, uint256 mcPrev);
    event KeeperFunded(uint256 amount, uint256 total);
    event UnpauseQueued(uint256 unlockAt);

    modifier onlyReady() {
        if (!systemInitialized) revert CR_NotInitialized();
        _;
    }

    constructor(address admin_) {
        if (admin_ == address(0)) revert CR_ZeroAddress();
        _grantRole(DEFAULT_ADMIN_ROLE, admin_);
        _grantRole(ADMIN_ROLE,         admin_);
        _grantRole(PAUSER_ROLE,        admin_);
    }

    // ═══════════════════════════════════════════════════════════════════
    //  INITIALIZE — один раз из TroikaDeployer
    // ═══════════════════════════════════════════════════════════════════

    struct Addresses {
        address vault;
        address oracle;
        address feeRouter;
        address cbArb;
        address emitEngine;
        address divPool;
        address loop;
    }

    function initialize(Addresses calldata a) external onlyRole(ADMIN_ROLE) {
        if (systemInitialized) revert CR_AlreadyInitialized();
        if (a.vault      == address(0) || a.oracle    == address(0) ||
            a.feeRouter  == address(0) || a.cbArb     == address(0) ||
            a.emitEngine == address(0) || a.divPool   == address(0) ||
            a.loop       == address(0)) revert CR_ZeroAddress();

        vault        = IVaultCore(a.vault);
        oracle       = IOracleCore(a.oracle);
        feeRouter    = IFeeRouterCore(a.feeRouter);
        feeRouterAddr= a.feeRouter;
        cbArb        = ICBArbCore(a.cbArb);
        emitEngine   = IEmitCore(a.emitEngine);
        divPool      = IDivCore(a.divPool);
        loop         = ILoopCore(a.loop);
        WPOL         = IERC20(PolygonConfig.WPOL);
        systemInitialized = true;
        emit SystemInitialized(block.number);
    }

    /// @notice Привязать FounderControl (после его деплоя)
    function setFounderControl(address fcAddr)
        external onlyRole(ADMIN_ROLE) onlyReady
    {
        if (fcAddr == address(0)) revert CR_ZeroAddress();
        founderCtl = IFounderCtl(fcAddr);
        _grantRole(FC_ROLE, fcAddr);
        emit FounderCtlLinked(fcAddr);
    }

    /// @notice Привязать Oracle к QuickSwap парам + инициализировать fixBase
    function linkOraclePairs() external onlyRole(ADMIN_ROLE) onlyReady {
        address pP = vault.pairPAddress();
        address pT = vault.pairTAddress();
        if (pP == address(0) || pT == address(0)) revert CR_ZeroAddress();
        oracle.setPairs(pP, pT);
        emitEngine.setFixBase(vault.totalLP());
        prevMCap = vault.totalMCap();
        emit OraclePairsLinked(pP, pT);
    }

    // ═══════════════════════════════════════════════════════════════════
    //  TICK — главная автоматическая функция (кипер / Chainlink)
    // ═══════════════════════════════════════════════════════════════════
    function tick() external nonReentrant whenNotPaused onlyReady {
        require(block.number > lastTickBlock, "Core: tick too soon");
        lastTickBlock = block.number;
        ++totalTicks;

        // 1. TWAP (каждые 5 блоков)
        if (oracle.needsUpdate()) {
            try oracle.update() {} catch {}
        }

        // 2. Alpha adapt (каждые 20 блоков)
        try emitEngine.adapt() {} catch {}

        // 3. LP buf flush → QuickSwap (каждые 10 блоков)
        if (totalTicks % PolygonConfig.LPB_INTERVAL == 0) {
            try vault.flushLpBuf() {} catch {}
        }

        // 4. CB Arb (каждые 5 блоков)
        try cbArb.executeArb() {} catch {}

        // 5. Loop flush (каждые 50 блоков)
        if (loop.isFlushDue()) {
            try loop.flush() {} catch {}
        }

        // 6. Emission + Fix + Buyback (каждые 1000 блоков)
        if (emitEngine.isEmissionDue()) {
            try emitEngine.executeEmission() {} catch {}
        }

        // 7. Holders payout (каждые 1000 блоков)
        try divPool.executeHoldersPayout() {} catch {}

        // 8. FounderControl: авто-обработка дивидендов основателя
        if (address(founderCtl) != address(0)) {
            try founderCtl.processFounderDividends() {} catch {}
        }

        // 9. MCap Guard
        _mcapGuard();

        // 10. Sync каждые 50 тиков
        if (totalTicks % 50 == 0) {
            try vault.syncFromChain() {} catch {}
        }

        // 11. Keeper reward
        _payKeeper();
    }

    function _mcapGuard() private {
        uint256 mcNow = vault.totalMCap();
        if (mcNow < prevMCap) {
            uint256 fund = vault.mcgFund();
            if (fund > PolygonConfig.KEEPER_REWARD * 10) {
                uint256 inj = fund * 10 / 10_000; // 0.1% MCG fund
                vault.subFromMcgFund(inj);
                vault.batchAddLP(inj * 22/100, inj * 13/100, inj * 65/100);
                emit MCGFired(inj, mcNow, prevMCap);
            }
        }
        // [v3] MCG Recycler: excess MCG → 50%RR + 30%LP + 20%BB
        try vault.mcgRecycle() {} catch {}
        prevMCap = mcNow;
    }

    function _payKeeper() private {
        uint256 r = PolygonConfig.KEEPER_REWARD;
        if (keeperFund < r) return;
        keeperFund -= r;
        WPOL.safeTransfer(msg.sender, r);
        emit TickDone(msg.sender, block.number, r);
    }

    // ═══════════════════════════════════════════════════════════════════
    //  PROCESS FEE — точка входа для торговых комиссий
    //  Трейдер approve WPOL → Core → FeeRouter
    //  tokenType: 0=SYNA, 1=SYNC, 2=SYNR
    // ═══════════════════════════════════════════════════════════════════
    function processFee(uint256 feeAmount, uint8 tokenType)
        external nonReentrant whenNotPaused onlyReady
    {
        if (feeAmount == 0) revert CR_ZeroAmount();
        if (tokenType > 2)  revert CR_InvalidTokenType(tokenType);

        // Перевести WPOL от трейдера в FeeRouter (CEI: Interactions последним)
        WPOL.safeTransferFrom(msg.sender, feeRouterAddr, feeAmount);

        // Записать fee в EmissionEngine для адаптации
        try emitEngine.recordFee(feeAmount) {} catch {}

        // Keeper fund: 0.02% от fee
        keeperFund += feeAmount * 2 / 10_000;

        // MCap Guard fund: 0.02% от fee
        try vault.addToMcgFund(feeAmount * 2 / 10_000) {} catch {}

        // Вклад в петлю усиления v9.0:
        // ring A (traders): 0.15% fee → N0 → N2 → ...
        // ring B (fee-кольцо): 0.50% fee → N1 → N3 → ...
        try loop.contribute(0, feeAmount * 15 / 10_000) {} catch {}
        try loop.contribute(1, feeAmount * 50 / 10_000) {} catch {}

        // Маршрутизация через FeeRouter
        feeRouter.routeFee(feeAmount, tokenType);

        totalFeeProcessed += feeAmount;
        emit FeeProcessed(msg.sender, feeAmount, tokenType);
    }

    // ═══════════════════════════════════════════════════════════════════
    //  PAUSE / UNPAUSE — системный
    //  pauseAll: мгновенно (PAUSER_ROLE или FC_ROLE)
    //  unpauseAll: таймлок 1 час
    // ═══════════════════════════════════════════════════════════════════

    function pauseAll() external {
        if (!hasRole(PAUSER_ROLE, msg.sender) && !hasRole(FC_ROLE, msg.sender))
            revert("Core: unauthorized");
        _pause();
        try vault.pause()       {} catch {}
        try oracle.pause()      {} catch {}
        try feeRouter.pause()   {} catch {}
        try cbArb.pause()       {} catch {}
        try emitEngine.pause()  {} catch {}
        try divPool.pause()     {} catch {}
        try loop.pause()        {} catch {}
    }

    function queueUnpause() external {
        if (!hasRole(PAUSER_ROLE, msg.sender) && !hasRole(FC_ROLE, msg.sender))
            revert("Core: unauthorized");
        if (!paused()) revert("Core: not paused");
        unpauseAt = block.timestamp + UNPAUSE_DELAY;
        emit UnpauseQueued(unpauseAt);
    }

    function unpauseAll() external {
        if (!hasRole(PAUSER_ROLE, msg.sender) && !hasRole(FC_ROLE, msg.sender))
            revert("Core: unauthorized");
        if (unpauseAt == 0) revert CR_UnpauseNotQueued();
        if (block.timestamp < unpauseAt) revert CR_UnpauseTimelockActive(unpauseAt, block.timestamp);
        unpauseAt = 0;
        _unpause();
        try vault.unpause()       {} catch {}
        try oracle.unpause()      {} catch {}
        try feeRouter.unpause()   {} catch {}
        try cbArb.unpause()       {} catch {}
        try emitEngine.unpause()  {} catch {}
        try divPool.unpause()     {} catch {}
        try loop.unpause()        {} catch {}
    }

    // ── Keeper fund ───────────────────────────────────────────────────
    function fundKeeper(uint256 amount)
        external nonReentrant onlyReady
    {
        if (amount == 0) revert CR_ZeroAmount();
        WPOL.safeTransferFrom(msg.sender, address(this), amount);
        keeperFund += amount;
        emit KeeperFunded(amount, keeperFund);
    }

    /// @dev Только для TroikaDeployer: WPOL уже на этом контракте
    function initKeeperFund(uint256 amount)
        external onlyRole(ADMIN_ROLE) onlyReady
    {
        if (WPOL.balanceOf(address(this)) < amount) revert CR_ZeroAmount();
        keeperFund += amount;
        emit KeeperFunded(amount, keeperFund);
    }

    // ── Chainlink Automation ──────────────────────────────────────────
    function checkUpkeep(bytes calldata)
        external view returns (bool upkeepNeeded, bytes memory)
    {
        upkeepNeeded = !paused() && systemInitialized && block.number > lastTickBlock;
    }

    function performUpkeep(bytes calldata) external {
        this.tick();
    }

    // ── VIEW ──────────────────────────────────────────────────────────
    function systemState() external view returns (
        uint256 totalLp_,  uint256 totalMcap_,
        uint256 priceP_,   uint256 priceT_,
        uint256 priceR_,   uint256 keeperFund_,
        uint256 ticks_,    bool    paused_
    ) {
        if (!systemInitialized) return (0,0,0,0,0,0,0,true);
        return (
            vault.totalLP(),  vault.totalMCap(),
            vault.priceP(),   vault.priceT(),
            vault.priceR(),   keeperFund,
            totalTicks,       paused()
        );
    }
}
