#!/usr/bin/env python3
import sys, io, json, os, time
from dotenv import load_dotenv
from web3 import Web3
from web3.middleware import ExtraDataToPOAMiddleware

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

load_dotenv()
w3 = Web3(Web3.HTTPProvider("https://polygon-bor-rpc.publicnode.com", request_kwargs={"timeout": 300}))
w3.middleware_onion.inject(ExtraDataToPOAMiddleware, layer=0)

PK = os.getenv("OWNER_PRIVATE_KEY")
OWNER = "0x6946999DBCE63b140B1bB9D475F7c357130909E5"

def C(a): return Web3.to_checksum_address(a)

with open("deployed_TROIKA_v3.json") as f:
    d = json.load(f)

print("=" * 70)
print("REDEPLOY EmissionEngine (EMIT_INTERVAL=50)")
print("=" * 70)
print(f"POL: {w3.eth.get_balance(C(OWNER)) / 1e18:.4f}")

with open("out/07_EmissionEngine.sol/EmissionEngine.json", encoding="utf-8") as f:
    artifact = json.load(f)

abi = artifact["abi"]
bytecode = artifact["bytecode"]["object"]

nonce = w3.eth.get_transaction_count(C(OWNER), "pending")
base = w3.eth.get_block("latest").get("baseFeePerGas", int(100e9))
prio = int(50e9)
mf = base * 2 + prio

print("\n[1] Deploy EmissionEngine...")
contract = w3.eth.contract(abi=abi, bytecode=bytecode)

tx = contract.constructor(
    C(d["vault"]), C(d["tokens"]["SYNA"]), C(d["tokens"]["SYNC"]),
    C(d["tokens"]["SYNR"]), C(d["divPool"]), C(OWNER)
).build_transaction({
    "from": C(OWNER), "nonce": nonce, "chainId": 137, "type": 2,
    "maxPriorityFeePerGas": prio, "maxFeePerGas": mf, "gas": 5_000_000
})

signed = w3.eth.account.sign_transaction(tx, PK)
h = w3.eth.send_raw_transaction(signed.raw_transaction)
print(f"  TX: {h.hex()[:20]}...")

r = w3.eth.wait_for_transaction_receipt(h, timeout=300)
if r.status == 1:
    new_emit = r.contractAddress
    print(f"  [OK] {new_emit}")
    nonce += 1
else:
    print("  [FAIL]")
    sys.exit(1)

time.sleep(3)

# Grant roles
token_abi = [
    {"name": "MINTER_ROLE", "inputs": [], "outputs": [{"type": "bytes32"}], "stateMutability": "view", "type": "function"},
    {"name": "BURNER_ROLE", "inputs": [], "outputs": [{"type": "bytes32"}], "stateMutability": "view", "type": "function"},
    {"name": "grantRole", "inputs": [{"name": "role", "type": "bytes32"}, {"name": "account", "type": "address"}], "outputs": [], "stateMutability": "nonpayable", "type": "function"},
]

print("\n[2] Grant MINTER_ROLE...")
for name, addr in d["tokens"].items():
    tk = w3.eth.contract(address=C(addr), abi=token_abi)
    MINTER = tk.functions.MINTER_ROLE().call()
    tx = tk.functions.grantRole(MINTER, C(new_emit)).build_transaction({
        "from": C(OWNER), "nonce": nonce, "chainId": 137, "type": 2,
        "maxPriorityFeePerGas": prio, "maxFeePerGas": mf, "gas": 100000
    })
    signed = w3.eth.account.sign_transaction(tx, PK)
    h = w3.eth.send_raw_transaction(signed.raw_transaction)
    r = w3.eth.wait_for_transaction_receipt(h, timeout=120)
    status = "OK" if r.status else "FAIL"
    print(f"  {name}: {status}")
    nonce += 1
    time.sleep(1)

print("\n[3] Grant BURNER_ROLE for SYNR...")
synr = w3.eth.contract(address=C(d["tokens"]["SYNR"]), abi=token_abi)
BURNER = synr.functions.BURNER_ROLE().call()
tx = synr.functions.grantRole(BURNER, C(new_emit)).build_transaction({
    "from": C(OWNER), "nonce": nonce, "chainId": 137, "type": 2,
    "maxPriorityFeePerGas": prio, "maxFeePerGas": mf, "gas": 100000
})
signed = w3.eth.account.sign_transaction(tx, PK)
h = w3.eth.send_raw_transaction(signed.raw_transaction)
r = w3.eth.wait_for_transaction_receipt(h, timeout=120)
status = "OK" if r.status else "FAIL"
print(f"  {status}")
nonce += 1
time.sleep(1)

print("\n[4] Grant OPERATOR_ROLE in Vault...")
vault_abi = [
    {"name": "OPERATOR_ROLE", "inputs": [], "outputs": [{"type": "bytes32"}], "stateMutability": "view", "type": "function"},
    {"name": "grantRole", "inputs": [{"name": "role", "type": "bytes32"}, {"name": "account", "type": "address"}], "outputs": [], "stateMutability": "nonpayable", "type": "function"},
]
vault = w3.eth.contract(address=C(d["vault"]), abi=vault_abi)
OP = vault.functions.OPERATOR_ROLE().call()
tx = vault.functions.grantRole(OP, C(new_emit)).build_transaction({
    "from": C(OWNER), "nonce": nonce, "chainId": 137, "type": 2,
    "maxPriorityFeePerGas": prio, "maxFeePerGas": mf, "gas": 100000
})
signed = w3.eth.account.sign_transaction(tx, PK)
h = w3.eth.send_raw_transaction(signed.raw_transaction)
r = w3.eth.wait_for_transaction_receipt(h, timeout=120)
status = "OK" if r.status else "FAIL"
print(f"  {status}")
nonce += 1
time.sleep(1)

print("\n[5] Grant NOTIFIER_ROLE in DividendPool...")
div_abi = [
    {"name": "NOTIFIER_ROLE", "inputs": [], "outputs": [{"type": "bytes32"}], "stateMutability": "view", "type": "function"},
    {"name": "grantRole", "inputs": [{"name": "role", "type": "bytes32"}, {"name": "account", "type": "address"}], "outputs": [], "stateMutability": "nonpayable", "type": "function"},
]
divpool = w3.eth.contract(address=C(d["divPool"]), abi=div_abi)
NOT = divpool.functions.NOTIFIER_ROLE().call()
tx = divpool.functions.grantRole(NOT, C(new_emit)).build_transaction({
    "from": C(OWNER), "nonce": nonce, "chainId": 137, "type": 2,
    "maxPriorityFeePerGas": prio, "maxFeePerGas": mf, "gas": 100000
})
signed = w3.eth.account.sign_transaction(tx, PK)
h = w3.eth.send_raw_transaction(signed.raw_transaction)
r = w3.eth.wait_for_transaction_receipt(h, timeout=120)
status = "OK" if r.status else "FAIL"
print(f"  {status}")
nonce += 1
time.sleep(1)

print("\n[6] Grant CALLER_ROLE to Core...")
emit_contract = w3.eth.contract(address=C(new_emit), abi=abi)
CALLER = emit_contract.functions.CALLER_ROLE().call()
tx = emit_contract.functions.grantRole(CALLER, C(d["core"])).build_transaction({
    "from": C(OWNER), "nonce": nonce, "chainId": 137, "type": 2,
    "maxPriorityFeePerGas": prio, "maxFeePerGas": mf, "gas": 100000
})
signed = w3.eth.account.sign_transaction(tx, PK)
h = w3.eth.send_raw_transaction(signed.raw_transaction)
r = w3.eth.wait_for_transaction_receipt(h, timeout=120)
status = "OK" if r.status else "FAIL"
print(f"  {status}")
nonce += 1

# Save
d["emitEngine_v2"] = new_emit
d["emitEngine_v2_interval"] = 50
with open("deployed_TROIKA_v3.json", "w") as f:
    json.dump(d, f, indent=2)

print("\n" + "=" * 70)
print(f"NEW EmissionEngine: {new_emit}")
print(f"EMIT_INTERVAL: 50 blocks (~100 sec)")
print(f"POL: {w3.eth.get_balance(C(OWNER)) / 1e18:.4f}")
print("=" * 70)
