from __future__ import annotations

import argparse
import copy
import csv
import json
import math
import random
import statistics
from collections import deque
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd

TOKENS = ("SYNA", "SYNC", "SYNR", "ALTN")
INITIAL_TOKEN_RESERVES = {"SYNA": 800.0, "SYNC": 8000.0, "SYNR": 400.0, "ALTN": 2000.0}
INITIAL_SPOT_PRICES = {"SYNA": 0.005, "SYNC": 0.0005, "SYNR": 0.01, "ALTN": 0.002}
INITIAL_SUPPLY = {"SYNA": 10_000_000.0, "SYNC": 100_000_000.0, "SYNR": 21_000_000.0, "ALTN": 110_500_000.0}


@dataclass
class Pool:
    token: str
    token_reserve: float
    wpol_reserve: float
    fee_bps: float = 30.0
    system_lp_share: float = 1.0

    def price(self) -> float:
        return self.wpol_reserve / max(self.token_reserve, 1e-18)

    def k(self) -> float:
        return self.token_reserve * self.wpol_reserve

    def swap_wpol_for_token(self, amount_in: float) -> Tuple[float, float]:
        if amount_in <= 0:
            return 0.0, 0.0
        fee = amount_in * self.fee_bps / 10_000.0
        effective = amount_in - fee
        amount_out = self.token_reserve * effective / (self.wpol_reserve + effective)
        amount_out = min(amount_out, self.token_reserve * 0.999999)
        self.wpol_reserve += amount_in
        self.token_reserve -= amount_out
        return amount_out, fee

    def swap_token_for_wpol(self, amount_in: float) -> Tuple[float, float]:
        if amount_in <= 0:
            return 0.0, 0.0
        fee_token = amount_in * self.fee_bps / 10_000.0
        effective = amount_in - fee_token
        amount_out = self.wpol_reserve * effective / (self.token_reserve + effective)
        amount_out = min(amount_out, self.wpol_reserve * 0.999999)
        self.token_reserve += amount_in
        self.wpol_reserve -= amount_out
        fee_wpol_equiv = fee_token * self.price()
        return amount_out, fee_wpol_equiv

    def add_liquidity(self, token_amount: float, wpol_amount: float, system_owned: bool = True) -> Tuple[float, float]:
        if token_amount <= 0 or wpol_amount <= 0:
            return 0.0, 0.0
        ratio_token = self.token_reserve / max(self.wpol_reserve, 1e-18)
        used_wpol = min(wpol_amount, token_amount / max(ratio_token, 1e-18))
        used_token = used_wpol * ratio_token
        old_k_sqrt = math.sqrt(max(self.k(), 1e-18))
        old_system_units = old_k_sqrt * self.system_lp_share
        self.wpol_reserve += used_wpol
        self.token_reserve += used_token
        new_k_sqrt = math.sqrt(max(self.k(), 1e-18))
        minted_units = max(new_k_sqrt - old_k_sqrt, 0.0)
        if system_owned:
            self.system_lp_share = (old_system_units + minted_units) / max(new_k_sqrt, 1e-18)
        return used_token, used_wpol


@dataclass
class Bot:
    bot_id: int
    style: str
    wpol: float
    tokens: Dict[str, float]
    initial_nav: float
    trades: int = 0
    fees_paid: float = 0.0


@dataclass
class ContractState:
    liquid_reserves: float = 1500.0
    liabilities: float = 1000.0
    bridge_capital: float = 300.0
    insurance_fund: float = 80.0
    trader_reserve: float = 50.0
    reserve_r: float = 100.0
    cb_fund: float = 10.0
    lp_buffer: float = 0.0
    buyback_bucket: float = 0.0
    treasury_unallocated: float = 0.0
    operations_spent: float = 0.0
    dividends_paid: float = 0.0
    bridge_imbalance_bps: float = 800.0
    alpha_lp_bps: float = 3500.0
    alpha_res_bps: float = 3000.0
    cumulative_protocol_fees: float = 0.0
    cumulative_dex_fees: float = 0.0
    cumulative_flash_profit: float = 0.0
    cumulative_bridge_fees: float = 0.0
    cumulative_yield: float = 0.0
    cumulative_buyback: float = 0.0
    cumulative_burned: Dict[str, float] = field(default_factory=lambda: {t: 0.0 for t in TOKENS})
    mm_inventory: Dict[str, float] = field(default_factory=lambda: {t: 0.0 for t in TOKENS})
    treasury_token_inventory: Dict[str, float] = field(default_factory=lambda: {t: 0.0 for t in TOKENS})


@dataclass
class SimulationConfig:
    days: int = 180
    bots: int = 20
    seed: int = 137
    liquidity_scale: float = 1.0
    ai_enabled: bool = True
    protocol_fee_bps: float = 50.0  # Explicit modeling assumption; Core does not fix the rate.
    dex_fee_bps: float = 30.0
    trades_per_bot_day: float = 2.2
    max_trade_pool_fraction: float = 0.018
    max_whale_trade_pool_fraction: float = 0.045
    oracle_deviation_bps: float = 150.0
    reserve_yield_apy: float = 0.03
    bridge_fee_bps: float = 10.0
    revenue_horizon_months: int = 12
    revenue_haircut: float = 0.50
    min_reserve_ratio: float = 1.20
    max_valuation_premium: float = 2.0
    max_qe_per_month: float = 250.0
    qe_fraction_excess: float = 0.20
    tail_risk_enabled: bool = True
    record_trades: bool = True


class MarketSimulation:
    def __init__(self, cfg: SimulationConfig):
        self.cfg = cfg
        self.rng = np.random.default_rng(cfg.seed)
        self.py_rng = random.Random(cfg.seed)
        self.pools = {
            t: Pool(t, INITIAL_TOKEN_RESERVES[t] * cfg.liquidity_scale, 4.0 * cfg.liquidity_scale, cfg.dex_fee_bps)
            for t in TOKENS
        }
        self.reference_prices = dict(INITIAL_SPOT_PRICES)
        self.reference_anchor = dict(INITIAL_SPOT_PRICES)
        self.supply = dict(INITIAL_SUPPLY)
        self.contracts = ContractState()
        # MM gets a small pre-funded inventory from the owner. It is included in backing NAV.
        self.contracts.mm_inventory = {t: self.pools[t].token_reserve * 0.08 for t in TOKENS}
        self.bots = self._build_bots()
        self.price_history = {t: deque([self.pools[t].price()], maxlen=30) for t in TOKENS}
        self.daily_revenue_window = deque(maxlen=30)
        self.daily_rows: List[dict] = []
        self.trade_rows: List[dict] = []
        self.daily_volume = 0.0
        self.daily_protocol_fees = 0.0
        self.daily_dex_fees = 0.0
        self.daily_external_revenue = 0.0
        self.daily_flash_profit = 0.0
        self.daily_bridge_fees = 0.0
        self.daily_mm_notional = 0.0
        self.daily_trade_count = 0
        self.rejected_trades = 0

    def _build_bots(self) -> List[Bot]:
        styles = ["noise"] * 5 + ["momentum"] * 4 + ["mean_reversion"] * 4 + ["arbitrage"] * 3 + ["whale"] * 2 + ["defensive"] * 2
        self.py_rng.shuffle(styles)
        if self.cfg.liquidity_scale <= 1.5:
            wpol_start, token_value_total = 0.8, 0.30
        else:
            wpol_start, token_value_total = 5.0, 2.0
        bots: List[Bot] = []
        for i in range(self.cfg.bots):
            style = styles[i % len(styles)]
            tokens = {}
            for t in TOKENS:
                value = token_value_total / len(TOKENS) * self.py_rng.uniform(0.75, 1.25)
                tokens[t] = value / self.reference_prices[t]
            wpol = wpol_start * self.py_rng.uniform(0.8, 1.2)
            initial_nav = wpol + sum(tokens[t] * self.reference_prices[t] for t in TOKENS)
            bots.append(Bot(i, style, wpol, tokens, initial_nav))
        return bots

    def _spot_prices(self) -> Dict[str, float]:
        return {t: self.pools[t].price() for t in TOKENS}

    def _bot_nav(self, bot: Bot, use_reference: bool = True) -> float:
        prices = self.reference_prices if use_reference else self._spot_prices()
        return bot.wpol + sum(bot.tokens[t] * prices[t] for t in TOKENS)

    def _update_reference_prices(self) -> None:
        # Independent reference prices: slow mean reversion around deployment prices.
        common = float(self.rng.normal(0.0, 0.0045))
        for t in TOKENS:
            idio = float(self.rng.normal(0.0, 0.006))
            mean_reversion = 0.015 * math.log(self.reference_anchor[t] / max(self.reference_prices[t], 1e-18))
            shock = common + idio + mean_reversion
            self.reference_prices[t] *= math.exp(shock - 0.5 * (0.0075**2))

    def _select_trade(self, bot: Bot) -> Tuple[str, str]:
        spots = self._spot_prices()
        deviations = {t: spots[t] / max(self.reference_prices[t], 1e-18) - 1.0 for t in TOKENS}
        returns = {}
        for t in TOKENS:
            h = self.price_history[t]
            returns[t] = h[-1] / h[max(0, len(h) - 5)] - 1.0 if len(h) > 1 else 0.0

        if bot.style == "momentum":
            token = max(TOKENS, key=lambda t: abs(returns[t]) + self.py_rng.random() * 0.01)
            side = "buy" if returns[token] >= 0 else "sell"
            if self.py_rng.random() < 0.25:
                side = "sell" if side == "buy" else "buy"
        elif bot.style in ("mean_reversion", "arbitrage"):
            token = max(TOKENS, key=lambda t: abs(deviations[t]) + self.py_rng.random() * 0.005)
            side = "sell" if deviations[token] > 0 else "buy"
            flip = 0.18 if bot.style == "mean_reversion" else 0.08
            if self.py_rng.random() < flip:
                side = "sell" if side == "buy" else "buy"
        elif bot.style == "defensive":
            token = min(TOKENS, key=lambda t: abs(deviations[t]) + self.py_rng.random() * 0.01)
            side = "sell" if self.py_rng.random() < 0.62 else "buy"
        else:
            token = self.py_rng.choice(TOKENS)
            side = "buy" if self.py_rng.random() < 0.5 else "sell"
        return token, side

    def _trade_size_wpol(self, bot: Bot, token: str) -> float:
        pool = self.pools[token]
        nav = max(self._bot_nav(bot), 0.0)
        if bot.style == "whale":
            frac = math.exp(float(self.rng.normal(math.log(0.09), 0.45)))
            cap_frac = self.cfg.max_whale_trade_pool_fraction
        elif bot.style == "arbitrage":
            frac = math.exp(float(self.rng.normal(math.log(0.05), 0.35)))
            cap_frac = self.cfg.max_trade_pool_fraction * 1.25
        else:
            frac = math.exp(float(self.rng.normal(math.log(0.035), 0.40)))
            cap_frac = self.cfg.max_trade_pool_fraction
        return max(0.0005, min(nav * frac, pool.wpol_reserve * cap_frac))

    def _route_protocol_fee(self, fee: float) -> None:
        if fee <= 0:
            return
        c = self.contracts
        # FeeRouter: LP 35%, reserve 30%, CB 15%, dividends 10%, reserveR remainder.
        to_lp = fee * c.alpha_lp_bps / 10_000.0
        to_res = fee * c.alpha_res_bps / 10_000.0
        to_cb = fee * 0.15
        to_div = fee * 0.10
        to_rr = fee - to_lp - to_res - to_cb - to_div
        # Dividend subrouting: 35% buyback, 10.5% LP reinvest, 54.5% cash payout of the dividend slice.
        founder_total = to_div * 0.70
        holder_total = to_div - founder_total
        founder_cash = founder_total * 0.50
        founder_buyback = founder_total - founder_cash
        founder_reinvest = founder_cash * 0.30
        founder_net = founder_cash - founder_reinvest
        c.lp_buffer += to_lp + founder_reinvest
        c.trader_reserve += to_res
        c.cb_fund += to_cb
        c.reserve_r += to_rr
        c.buyback_bucket += founder_buyback
        c.dividends_paid += founder_net + holder_total
        c.cumulative_protocol_fees += fee
        self.daily_protocol_fees += fee

    def _execute_bot_trade(self, day: int, bot: Bot) -> None:
        token, side = self._select_trade(bot)
        pool = self.pools[token]
        size_wpol = self._trade_size_wpol(bot, token)
        protocol_fee = size_wpol * self.cfg.protocol_fee_bps / 10_000.0
        pre_price = pool.price()

        if side == "buy":
            total_need = size_wpol + protocol_fee
            if bot.wpol < total_need:
                size_wpol = max(bot.wpol / (1 + self.cfg.protocol_fee_bps / 10_000.0), 0.0)
                protocol_fee = size_wpol * self.cfg.protocol_fee_bps / 10_000.0
            if size_wpol < 0.0002:
                self.rejected_trades += 1
                return
            out, dex_fee = pool.swap_wpol_for_token(size_wpol)
            if out <= 0:
                self.rejected_trades += 1
                return
            bot.wpol -= size_wpol + protocol_fee
            bot.tokens[token] += out
            notional = size_wpol
        else:
            token_amount = size_wpol / max(pre_price, 1e-18)
            token_amount = min(token_amount, bot.tokens[token])
            if token_amount <= 1e-12:
                self.rejected_trades += 1
                return
            out, dex_fee = pool.swap_token_for_wpol(token_amount)
            protocol_fee = out * self.cfg.protocol_fee_bps / 10_000.0
            bot.tokens[token] -= token_amount
            bot.wpol += max(out - protocol_fee, 0.0)
            notional = out
        self._route_protocol_fee(protocol_fee)
        self.contracts.cumulative_dex_fees += dex_fee
        self.daily_dex_fees += dex_fee
        self.daily_volume += notional
        self.daily_trade_count += 1
        bot.trades += 1
        bot.fees_paid += protocol_fee + dex_fee
        if self.cfg.record_trades:
            self.trade_rows.append({
                "day": day, "bot": bot.bot_id, "style": bot.style, "token": token, "side": side,
                "notional_wpol": notional, "protocol_fee_wpol": protocol_fee, "dex_fee_wpol_equiv": dex_fee,
                "price_before": pre_price, "price_after": pool.price(),
            })

    def _adapt_fee_router(self) -> None:
        c = self.contracts
        if c.trader_reserve < 25.0:
            c.alpha_res_bps = min(c.alpha_res_bps + 80.0, 4000.0)
            c.alpha_lp_bps = max(c.alpha_lp_bps - 80.0, 2800.0)
        elif c.trader_reserve > 150.0:
            step = 48.0
            c.alpha_res_bps = max(c.alpha_res_bps - step, 2200.0)
            c.alpha_lp_bps = min(c.alpha_lp_bps + step, 4800.0)

    def _flush_lp_buffer(self) -> None:
        c = self.contracts
        if c.lp_buffer < 0.01:
            return
        budget = c.lp_buffer
        c.lp_buffer = 0.0
        weights = {t: 1.0 / max(self.pools[t].wpol_reserve, 1e-9) for t in TOKENS}
        wsum = sum(weights.values())
        for t in TOKENS:
            alloc = budget * weights[t] / wsum
            if alloc <= 0:
                continue
            # Buy token with half, pair it with the other half. This is capital reclassification.
            acquired, fee = self.pools[t].swap_wpol_for_token(alloc * 0.5)
            self.contracts.cumulative_dex_fees += fee
            used_token, used_wpol = self.pools[t].add_liquidity(acquired, alloc * 0.5, system_owned=True)
            leftover_token = max(acquired - used_token, 0.0)
            c.treasury_token_inventory[t] += leftover_token
            # Unused WPOL remains liquid.
            unused_wpol = max(alloc * 0.5 - used_wpol, 0.0)
            c.liquid_reserves += unused_wpol

    def _ai_market_maker(self) -> None:
        if not self.cfg.ai_enabled:
            return
        c = self.contracts
        daily_limit = sum(p.wpol_reserve for p in self.pools.values()) * 0.02
        for t in TOKENS:
            pool = self.pools[t]
            spot = pool.price()
            ref = self.reference_prices[t]
            deviation = spot / max(ref, 1e-18) - 1.0
            threshold = self.cfg.oracle_deviation_bps / 10_000.0
            remaining = max(daily_limit - self.daily_mm_notional, 0.0)
            if remaining <= 1e-9:
                break
            if deviation < -threshold and c.cb_fund > 0:
                # Buy underpriced token. Bounded by 1.2% pool notional and CB fund.
                amount = min(c.cb_fund, remaining, pool.wpol_reserve * 0.012, abs(deviation) * pool.wpol_reserve * 0.25)
                if amount > 0.0005:
                    out, fee = pool.swap_wpol_for_token(amount)
                    c.cb_fund -= amount
                    c.mm_inventory[t] += out
                    c.cumulative_dex_fees += fee
                    self.daily_mm_notional += amount
            elif deviation > threshold and c.mm_inventory[t] > 0:
                token_value_cap = min(remaining, pool.wpol_reserve * 0.012, abs(deviation) * pool.wpol_reserve * 0.25)
                token_amount = min(c.mm_inventory[t], token_value_cap / max(spot, 1e-18))
                if token_amount > 1e-9:
                    out, fee = pool.swap_token_for_wpol(token_amount)
                    c.mm_inventory[t] -= token_amount
                    c.cb_fund += out
                    c.cumulative_dex_fees += fee
                    self.daily_mm_notional += out

    def _flash_and_bridge_revenue(self) -> None:
        c = self.contracts
        # External flash arbitrage is modeled only as net realized profit after financing/gas.
        flash_profit = 0.0
        if self.cfg.ai_enabled:
            for t in TOKENS:
                pool = self.pools[t]
                deviation = abs(pool.price() / max(self.reference_prices[t], 1e-18) - 1.0)
                if deviation > 0.012 and self.py_rng.random() < min(0.18 + deviation, 0.65):
                    gross = pool.wpol_reserve * max(deviation - 0.012, 0.0) ** 2 * 0.10
                    net = max(gross - 0.0015 * self.cfg.liquidity_scale ** 0.35, 0.0)
                    flash_profit += min(net, pool.wpol_reserve * 0.002)
        bridge_volume = self.daily_volume * (0.04 + 0.04 * self.py_rng.random())
        bridge_fees = bridge_volume * self.cfg.bridge_fee_bps / 10_000.0
        reserve_yield = max(c.liquid_reserves, 0.0) * self.cfg.reserve_yield_apy / 365.0
        c.cumulative_flash_profit += flash_profit
        c.cumulative_bridge_fees += bridge_fees
        c.cumulative_yield += reserve_yield
        c.treasury_unallocated += flash_profit + bridge_fees + reserve_yield
        self.daily_flash_profit = flash_profit
        self.daily_bridge_fees = bridge_fees
        self.daily_external_revenue = flash_profit + bridge_fees + reserve_yield
        # Organic imbalance shock.
        c.bridge_imbalance_bps = min(max(c.bridge_imbalance_bps + float(self.rng.normal(0.0, 45.0)), 0.0), 6000.0)

    def _backing_nav(self) -> float:
        c = self.contracts
        lp_nav = 0.0
        for t, pool in self.pools.items():
            lp_nav += pool.system_lp_share * (pool.wpol_reserve + pool.token_reserve * self.reference_prices[t])
        inventory_nav = sum((c.mm_inventory[t] + c.treasury_token_inventory[t]) * self.reference_prices[t] for t in TOKENS)
        liquid = c.liquid_reserves + c.trader_reserve + c.reserve_r + c.cb_fund + c.lp_buffer + c.buyback_bucket + c.treasury_unallocated
        return max(liquid + lp_nav + c.bridge_capital + c.insurance_fund + inventory_nav - c.liabilities, 0.0)

    def _fundamental_metrics(self) -> dict:
        backing = self._backing_nav()
        net_30d = sum(self.daily_revenue_window)
        discounted = max(net_30d, 0.0) * self.cfg.revenue_horizon_months * self.cfg.revenue_haircut
        fundamental = backing + discounted
        market_mcap = sum(self.supply[t] * self.pools[t].price() for t in TOKENS)
        reserve_assets = self.contracts.liquid_reserves + self.contracts.trader_reserve + self.contracts.reserve_r
        reserve_ratio = reserve_assets / max(self.contracts.liabilities, 1e-18)
        valuation_premium = market_mcap / max(fundamental, 1e-18)
        liquidity_depth = sum(2.0 * p.wpol_reserve for p in self.pools.values())
        return {
            "backing_nav": backing, "net_revenue_30d": net_30d, "fundamental_mcap": fundamental,
            "market_mcap": market_mcap, "reserve_ratio": reserve_ratio,
            "valuation_premium": valuation_premium, "liquidity_depth": liquidity_depth,
        }

    def _monthly_top_ai(self, day: int) -> None:
        if not self.cfg.ai_enabled or day % 30 != 0:
            return
        c = self.contracts
        metrics = self._fundamental_metrics()
        distributable = max(c.treasury_unallocated, 0.0)
        c.treasury_unallocated = 0.0
        # LIQUIDITY_QE20_FLASH65 allocation from the archive's optimizer output.
        reserve = distributable * 0.30
        liquidity = distributable * 0.40
        buyback = distributable * 0.075
        bridge = distributable * 0.10
        insurance = distributable * 0.075
        operations = distributable * 0.05
        c.liquid_reserves += reserve
        c.lp_buffer += liquidity
        c.buyback_bucket += buyback
        c.bridge_capital += bridge * (1.0 - 0.0015)
        c.insurance_fund += insurance
        c.operations_spent += operations

        hard_ok = (
            metrics["reserve_ratio"] >= self.cfg.min_reserve_ratio
            and metrics["valuation_premium"] <= self.cfg.max_valuation_premium
            and c.bridge_imbalance_bps <= 3500.0
        )
        if hard_ok:
            excess = max(c.liquid_reserves - self.cfg.min_reserve_ratio * c.liabilities, 0.0)
            qe = min(excess * self.cfg.qe_fraction_excess, self.cfg.max_qe_per_month)
            c.liquid_reserves -= qe
            c.lp_buffer += qe * 0.55
            c.bridge_capital += qe * 0.30 * (1.0 - 0.0015)
            c.insurance_fund += qe * 0.15
            improvement = 1.0 - math.exp(-(qe * 0.30) / max(c.bridge_capital, 1.0))
            c.bridge_imbalance_bps *= max(1.0 - 0.65 * improvement, 0.0)

        # Revenue-funded buyback only when market price is near/below fundamental allocation.
        total_supply = sum(self.supply.values())
        fundamental_unit = metrics["fundamental_mcap"] / max(total_supply, 1e-18)
        target = "SYNR"
        if c.buyback_bucket > 0 and self.pools[target].price() <= fundamental_unit * 1.05:
            spend = min(c.buyback_bucket, self.pools[target].wpol_reserve * 0.01)
            out, fee = self.pools[target].swap_wpol_for_token(spend)
            burn_cap = self.supply[target] * 0.002
            burned = min(out, burn_cap)
            self.supply[target] -= burned
            c.cumulative_burned[target] += burned
            c.cumulative_buyback += spend
            c.buyback_bucket -= spend
            c.cumulative_dex_fees += fee

    def _tail_risk(self) -> float:
        if not self.cfg.tail_risk_enabled:
            return 0.0
        c = self.contracts
        loss = 0.0
        # Daily probabilities calibrated to low but non-zero annual tail risk.
        if self.py_rng.random() < 0.00012:
            at_risk = c.liquid_reserves + c.bridge_capital + c.insurance_fund
            gross = at_risk * self.py_rng.uniform(0.005, 0.04)
            insurance_cover = min(c.insurance_fund, gross * 0.55)
            c.insurance_fund -= insurance_cover
            remaining = gross - insurance_cover
            hit_bridge = min(c.bridge_capital, remaining * 0.55)
            c.bridge_capital -= hit_bridge
            remaining -= hit_bridge
            c.liquid_reserves = max(c.liquid_reserves - remaining, 0.0)
            loss += gross
        if self.py_rng.random() < 0.00020:
            bridge_loss = c.bridge_capital * self.py_rng.uniform(0.002, 0.025)
            cover = min(c.insurance_fund, bridge_loss * 0.65)
            c.insurance_fund -= cover
            c.bridge_capital -= max(bridge_loss - cover, 0.0)
            loss += bridge_loss
        return loss

    def _record_day(self, day: int, tail_loss: float) -> None:
        c = self.contracts
        # Realized revenue attributable to external/bot capital, net of dividends/operations/tail loss.
        day_net = self.daily_protocol_fees + self.daily_external_revenue - tail_loss
        self.daily_revenue_window.append(day_net)
        m = self._fundamental_metrics()
        spots = self._spot_prices()
        row = {
            "day": day, **{f"price_{t}": spots[t] for t in TOKENS},
            **{f"reference_{t}": self.reference_prices[t] for t in TOKENS},
            **m, "daily_volume": self.daily_volume, "daily_trades": self.daily_trade_count,
            "protocol_fees": self.daily_protocol_fees, "dex_fees": self.daily_dex_fees,
            "flash_profit": self.daily_flash_profit, "bridge_fees": self.daily_bridge_fees,
            "external_revenue": self.daily_external_revenue, "mm_notional": self.daily_mm_notional,
            "tail_loss": tail_loss, "bridge_imbalance_bps": c.bridge_imbalance_bps,
            "liquid_reserves": c.liquid_reserves, "bridge_capital": c.bridge_capital,
            "insurance_fund": c.insurance_fund, "cb_fund": c.cb_fund,
            "trader_reserve": c.trader_reserve, "reserve_r": c.reserve_r,
            "buyback_bucket": c.buyback_bucket, "alpha_lp_bps": c.alpha_lp_bps,
            "alpha_res_bps": c.alpha_res_bps,
        }
        self.daily_rows.append(row)
        for t in TOKENS:
            self.price_history[t].append(spots[t])

    def run(self) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, dict]:
        for day in range(1, self.cfg.days + 1):
            self.daily_volume = self.daily_protocol_fees = self.daily_dex_fees = 0.0
            self.daily_external_revenue = self.daily_flash_profit = self.daily_bridge_fees = 0.0
            self.daily_mm_notional = 0.0
            self.daily_trade_count = 0
            self._update_reference_prices()
            for bot in self.bots:
                n = int(self.rng.poisson(self.cfg.trades_per_bot_day))
                for _ in range(n):
                    self._execute_bot_trade(day, bot)
            self._adapt_fee_router()
            self._ai_market_maker()
            self._flash_and_bridge_revenue()
            self._monthly_top_ai(day)
            self._flush_lp_buffer()
            tail_loss = self._tail_risk()
            self._record_day(day, tail_loss)

        daily = pd.DataFrame(self.daily_rows)
        trades = pd.DataFrame(self.trade_rows)
        robot_rows = []
        for bot in self.bots:
            terminal_ref = self._bot_nav(bot, use_reference=True)
            terminal_spot = self._bot_nav(bot, use_reference=False)
            robot_rows.append({
                "bot": bot.bot_id, "style": bot.style, "initial_nav_wpol": bot.initial_nav,
                "terminal_nav_reference_wpol": terminal_ref, "terminal_nav_spot_wpol": terminal_spot,
                "return_reference": terminal_ref / max(bot.initial_nav, 1e-18) - 1.0,
                "return_spot": terminal_spot / max(bot.initial_nav, 1e-18) - 1.0,
                "trades": bot.trades, "fees_paid_wpol": bot.fees_paid,
            })
        robots = pd.DataFrame(robot_rows)
        initial_market_mcap = sum(INITIAL_SUPPLY[t] * INITIAL_SPOT_PRICES[t] for t in TOKENS)
        final = daily.iloc[-1].to_dict()
        peak = daily["market_mcap"].cummax()
        drawdown = daily["market_mcap"] / peak - 1.0
        report = {
            "model": "SHTENCO DeFi TOP AI v3 internal market agent simulation",
            "input_basis": {
                "pools": "deployed create_pools.py ratios: 4 WPOL against 800/8000/400/2000 tokens, scaled by liquidity_scale",
                "supplies": INITIAL_SUPPLY,
                "contracts": "FeeRouter allocation, MarketMaker 150 bps guard, ValueFlow/TOP AI allocation and reserve constraints",
                "warning": "No fresh Polygon reserves were present in the archive; this is a reproducible synthetic stress test, not a mainnet forecast.",
            },
            "config": asdict(self.cfg),
            "initial": {
                "market_mcap_wpol": initial_market_mcap,
                "pool_wpol_total": sum(4.0 * self.cfg.liquidity_scale for _ in TOKENS),
                "bot_count": len(self.bots),
            },
            "terminal": final,
            "statistics": {
                "total_trades": int(sum(bot.trades for bot in self.bots)),
                "rejected_trades": int(self.rejected_trades),
                "total_volume_wpol": float(daily["daily_volume"].sum()),
                "market_mcap_change": float(final["market_mcap"] / daily.iloc[0]["market_mcap"] - 1.0),
                "fundamental_mcap_change": float(final["fundamental_mcap"] / daily.iloc[0]["fundamental_mcap"] - 1.0),
                "backing_nav_change": float(final["backing_nav"] / daily.iloc[0]["backing_nav"] - 1.0),
                "max_market_mcap_drawdown": float(drawdown.min()),
                "annualized_market_volatility": float(daily["market_mcap"].pct_change().std(ddof=0) * math.sqrt(365)),
                "median_robot_return_reference": float(robots["return_reference"].median()),
                "profitable_robot_share_reference": float((robots["return_reference"] > 0).mean()),
                "protocol_fees_wpol": float(self.contracts.cumulative_protocol_fees),
                "dex_fees_wpol_equiv": float(self.contracts.cumulative_dex_fees),
                "flash_profit_wpol": float(self.contracts.cumulative_flash_profit),
                "bridge_fees_wpol": float(self.contracts.cumulative_bridge_fees),
                "reserve_yield_wpol": float(self.contracts.cumulative_yield),
                "buyback_spend_wpol": float(self.contracts.cumulative_buyback),
                "burned": self.contracts.cumulative_burned,
            },
            "final_contract_state": asdict(self.contracts),
        }
        return daily, trades, robots, report


def run_monte_carlo(base_cfg: SimulationConfig, scenarios: int) -> pd.DataFrame:
    rows = []
    for i in range(scenarios):
        cfg = copy.deepcopy(base_cfg)
        cfg.seed = base_cfg.seed + i * 1009
        cfg.record_trades = False
        sim = MarketSimulation(cfg)
        daily, trades, robots, report = sim.run()
        s = report["statistics"]
        final = report["terminal"]
        rows.append({
            "scenario": i, "seed": cfg.seed, "ai_enabled": cfg.ai_enabled,
            "liquidity_scale": cfg.liquidity_scale,
            "terminal_market_mcap": final["market_mcap"],
            "terminal_fundamental_mcap": final["fundamental_mcap"],
            "terminal_backing_nav": final["backing_nav"],
            "terminal_reserve_ratio": final["reserve_ratio"],
            "terminal_valuation_premium": final["valuation_premium"],
            "terminal_liquidity_depth": final["liquidity_depth"],
            "market_mcap_change": s["market_mcap_change"],
            "fundamental_mcap_change": s["fundamental_mcap_change"],
            "backing_nav_change": s["backing_nav_change"],
            "max_drawdown": s["max_market_mcap_drawdown"],
            "annualized_volatility": s["annualized_market_volatility"],
            "total_volume": s["total_volume_wpol"],
            "protocol_fees": s["protocol_fees_wpol"],
            "flash_profit": s["flash_profit_wpol"],
            "profitable_robot_share": s["profitable_robot_share_reference"],
        })
    return pd.DataFrame(rows)


def summarize_mc(df: pd.DataFrame) -> dict:
    result = {}
    for col in [
        "market_mcap_change", "fundamental_mcap_change", "backing_nav_change", "max_drawdown",
        "annualized_volatility", "terminal_reserve_ratio", "terminal_valuation_premium",
        "terminal_liquidity_depth", "total_volume", "protocol_fees", "flash_profit",
        "profitable_robot_share",
    ]:
        s = df[col]
        result[col] = {
            "mean": float(s.mean()), "median": float(s.median()), "p05": float(s.quantile(0.05)),
            "p10": float(s.quantile(0.10)), "p90": float(s.quantile(0.90)), "p95": float(s.quantile(0.95)),
            "min": float(s.min()), "max": float(s.max()),
        }
    result["probability_market_mcap_loss"] = float((df["market_mcap_change"] < 0).mean())
    result["probability_fundamental_loss"] = float((df["fundamental_mcap_change"] < 0).mean())
    result["probability_reserve_below_1_2"] = float((df["terminal_reserve_ratio"] < 1.2).mean())
    return result


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--output", default="/mnt/data/defi_internal_market_results")
    p.add_argument("--days", type=int, default=180)
    p.add_argument("--scenarios", type=int, default=100)
    p.add_argument("--seed", type=int, default=137)
    args = p.parse_args()
    out = Path(args.output)
    out.mkdir(parents=True, exist_ok=True)

    scenario_specs = [
        ("deployed_ai", 1.0, True),
        ("deployed_no_ai", 1.0, False),
        ("capitalized_ai", 25.0, True),
        ("capitalized_no_ai", 25.0, False),
    ]
    master_summary = {"days": args.days, "monte_carlo_scenarios_per_case": args.scenarios, "cases": {}}
    representative = {}

    for name, scale, ai in scenario_specs:
        cfg = SimulationConfig(days=args.days, seed=args.seed, liquidity_scale=scale, ai_enabled=ai)
        sim = MarketSimulation(cfg)
        daily, trades, robots, report = sim.run()
        daily.to_csv(out / f"{name}_daily.csv", index=False)
        trades.to_csv(out / f"{name}_trades.csv", index=False)
        robots.to_csv(out / f"{name}_robots.csv", index=False)
        (out / f"{name}_report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        mc = run_monte_carlo(cfg, args.scenarios)
        mc.to_csv(out / f"{name}_monte_carlo.csv", index=False)
        master_summary["cases"][name] = {
            "representative": report,
            "monte_carlo": summarize_mc(mc),
        }
        representative[name] = daily

    (out / "master_summary.json").write_text(json.dumps(master_summary, ensure_ascii=False, indent=2), encoding="utf-8")

    # Compact comparison table.
    rows = []
    for name, block in master_summary["cases"].items():
        mc = block["monte_carlo"]
        rep = block["representative"]
        rows.append({
            "case": name,
            "mean_market_mcap_change": mc["market_mcap_change"]["mean"],
            "p10_market_mcap_change": mc["market_mcap_change"]["p10"],
            "p90_market_mcap_change": mc["market_mcap_change"]["p90"],
            "mean_fundamental_mcap_change": mc["fundamental_mcap_change"]["mean"],
            "probability_market_loss": mc["probability_market_mcap_loss"],
            "probability_fundamental_loss": mc["probability_fundamental_loss"],
            "mean_max_drawdown": mc["max_drawdown"]["mean"],
            "mean_terminal_reserve_ratio": mc["terminal_reserve_ratio"]["mean"],
            "mean_terminal_valuation_premium": mc["terminal_valuation_premium"]["mean"],
            "representative_total_trades": rep["statistics"]["total_trades"],
            "representative_total_volume": rep["statistics"]["total_volume_wpol"],
        })
    pd.DataFrame(rows).to_csv(out / "comparison_summary.csv", index=False)
    print(json.dumps({r["case"]: r for r in rows}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
