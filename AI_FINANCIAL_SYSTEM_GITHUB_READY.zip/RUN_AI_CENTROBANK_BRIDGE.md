# Running SHTENCO AI Central Bank + Bridge QE

## Install

```powershell
cd D:\SYNA_FINANCIAL_SYSTEMS\FINAL\INSTANT_DEPLOY\SHTENCO_QE_BRIDGE_AI
npm install
py -m pip install -r requirements_ai.txt
py -m pip install -r requirements_relay.txt
Copy-Item .env.example .env
```

## Compile and test

```powershell
node node_modules\hardhat\internal\cli\cli.js compile
node node_modules\hardhat\internal\cli\cli.js test
$env:PYTHONPATH="."
py -m unittest ai_centrobank_sinergy.test_engine -v
```

## Fork mode

Set `POLYGON_RPC_URL` and optionally `FORK_BLOCK_NUMBER`, then:

```powershell
node node_modules\hardhat\internal\cli\cli.js run scripts\fork_preflight.js --network hardhat
node node_modules\hardhat\internal\cli\cli.js run scripts\deploy_fork_pair.js --network hardhat
```

`deploy_fork_pair.js` creates two virtual bridge domains on the local fork so lock/mint/burn/release and adapter routing can be tested without a public transaction.

## Create an AI intent proposal

From the main `INSTANT_DEPLOY` directory:

```powershell
$env:PYTHONPATH="."
py -m ai_centrobank_sinergy.cli --root . --cycles 5 --depth 5 --beam 180 --write-proposal
```

The result is written under `deployments\ai-centrobank-proposal-*.json`. Policy-blocked proposals remain recorded but cannot proceed.

## Materialize live calldata

Fill `config\execution_map.example.json`, then copy it to a private configuration file:

```powershell
py scripts\materialize_ai_proposal.py `
  --proposal ..\deployments\ai-centrobank-proposal-TIMESTAMP.json `
  --config config\execution_map.private.json
```

The materializer queries current balances, router quotes, the configured price guard, central-bank target/selector policies, daily budgets and timelock limits. It refuses missing roles, zero addresses, inadequate reserve inventory, weak quotes or an unsupported action.

## Submit, execute or cancel

Dry-run submission:

```powershell
node scripts\submit_ai_proposal.js ..\deployments\PROPOSAL-materialized.json
```

Broadcast requires both controls:

```powershell
$env:LIVE_EXECUTION="1"
node scripts\submit_ai_proposal.js ..\deployments\PROPOSAL-materialized.json --broadcast
```

After the timelock:

```powershell
node scripts\execute_ai_proposal.js ..\deployments\PROPOSAL-materialized-submitted.json --broadcast
```

Guardian cancellation:

```powershell
node scripts\cancel_ai_proposal.js ..\deployments\PROPOSAL-materialized-submitted.json --broadcast
```

## Relay daemon

Each validator uses its own key and configuration:

```powershell
py scripts\relay_daemon.py --config config\bridge_config.validator1.json --sign --watch
```

The submitter instance may add `--submit`. Do not place multiple validator private keys in one process in production.

## Mainnet warning

No supplied command guarantees profit. Begin with low canary limits. Do not enable live execution until roles, oracle, reserve backing, token decimals, routes, peers, wrapped caps and emergency pause procedures have been independently verified.
