'use strict';
const fs = require('fs');
const path = require('path');
const solc = require('solc');

const root = __dirname;
const entry = '22_FlashLoanArbitrage.sol';
const source = fs.readFileSync(path.join(root, entry), 'utf8');

function findImports(importPath) {
  const candidates = [
    path.join(root, importPath),
    path.join(root, 'node_modules', importPath),
  ];
  for (const candidate of candidates) {
    if (fs.existsSync(candidate)) {
      return { contents: fs.readFileSync(candidate, 'utf8') };
    }
  }
  return { error: `Import not found: ${importPath}` };
}

const input = {
  language: 'Solidity',
  sources: { [entry]: { content: source } },
  settings: {
    optimizer: { enabled: true, runs: 500 },
    viaIR: true,
    outputSelection: {
      '*': {
        '*': [
          'abi',
          'metadata',
          'evm.bytecode.object',
          'evm.deployedBytecode.object',
          'evm.gasEstimates',
        ],
      },
    },
  },
};

const output = JSON.parse(solc.compile(JSON.stringify(input), { import: findImports }));
if (output.errors) {
  for (const item of output.errors) {
    const stream = item.severity === 'error' ? process.stderr : process.stdout;
    stream.write(`${item.severity.toUpperCase()}: ${item.formattedMessage}\n`);
  }
}
const errors = (output.errors || []).filter((item) => item.severity === 'error');
if (errors.length) process.exit(1);

const contract = output.contracts[entry].FlashLoanArbitrage;
const artifact = {
  contractName: 'FlashLoanArbitrage',
  sourceName: entry,
  compiler: solc.version(),
  abi: contract.abi,
  bytecode: `0x${contract.evm.bytecode.object}`,
  deployedBytecode: `0x${contract.evm.deployedBytecode.object}`,
  gasEstimates: contract.evm.gasEstimates,
};

const outDir = path.join(root, 'out_flash');
fs.mkdirSync(outDir, { recursive: true });
fs.writeFileSync(
  path.join(outDir, 'FlashLoanArbitrage.json'),
  JSON.stringify(artifact, null, 2),
);
console.log(`Compiled ${artifact.contractName} with ${artifact.compiler}`);
console.log(`Bytecode bytes: ${(artifact.bytecode.length - 2) / 2}`);
