// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {AccessControl} from "@openzeppelin/contracts/access/AccessControl.sol";
import {Pausable} from "@openzeppelin/contracts/utils/Pausable.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";

interface ISHTENCOV2Router {
    function getAmountsOut(uint256 amountIn, address[] calldata path)
        external view returns (uint256[] memory amounts);

    function swapExactTokensForTokens(
        uint256 amountIn,
        uint256 amountOutMin,
        address[] calldata path,
        address to,
        uint256 deadline
    ) external returns (uint256[] memory amounts);

    function addLiquidity(
        address tokenA,
        address tokenB,
        uint256 amountADesired,
        uint256 amountBDesired,
        uint256 amountAMin,
        uint256 amountBMin,
        address to,
        uint256 deadline
    ) external returns (uint256 amountA, uint256 amountB, uint256 liquidity);
}

interface ISHTENCOPriceGuard {
    function quote(address tokenIn, address tokenOut, uint256 amountIn)
        external view returns (uint256 expectedOut, uint256 updatedAt);
}

interface ISHTENCOBurnable {
    function burn(uint256 amount) external;
}

/**
 * @title SHTENCOMarketMaker
 * @notice Inventory rebalancer controlled by the AI Central Bank. It supports
 *         guarded swaps, liquidity additions and atomic buyback-and-burn.
 *         Every capital-consuming action is bounded by oracle checks, router
 *         and token allowlists, per-token daily limits, pair cooldowns and
 *         caller-supplied minimum outputs.
 */
contract SHTENCOMarketMaker is AccessControl, Pausable, ReentrancyGuard {
    using SafeERC20 for IERC20;

    bytes32 public constant CONTROLLER_ROLE = keccak256("CONTROLLER_ROLE");
    bytes32 public constant POLICY_ROLE = keccak256("POLICY_ROLE");
    bytes32 public constant GUARDIAN_ROLE = keccak256("GUARDIAN_ROLE");

    uint256 public constant BPS = 10_000;
    uint256 public constant MAX_PATH_LENGTH = 5;
    uint256 public constant MAX_DEADLINE_WINDOW = 5 minutes;

    struct DailyNotional {
        uint64 day;
        uint192 amount;
    }

    mapping(address => bool) public allowedRouter;
    mapping(address => bool) public allowedToken;
    mapping(address => bool) public burnableToken;
    mapping(address => uint256) public dailyNotionalLimit;
    mapping(address => DailyNotional) private _dailyNotional;
    mapping(bytes32 => uint256) public lastTradeAt;

    ISHTENCOPriceGuard public priceGuard;
    address public treasury;
    uint256 public maxOracleDeviationBps = 150;
    uint256 public maxOracleAge = 30 minutes;
    uint256 public pairCooldown = 60 seconds;

    uint256 public totalTrades;
    uint256 public totalLiquidityActions;
    mapping(address => uint256) public totalVolumeIn;
    mapping(address => uint256) public totalBurned;

    event RouterSet(address indexed router, bool allowed);
    event TokenSet(address indexed token, bool allowed, uint256 dailyLimit);
    event BurnableTokenSet(address indexed token, bool allowed);
    event GuardSet(address indexed guard, uint256 maxDeviationBps, uint256 maxAge);
    event TreasurySet(address indexed treasury);
    event CooldownSet(uint256 cooldown);
    event MarketTrade(
        bytes32 indexed pairKey,
        address indexed router,
        address indexed tokenIn,
        address tokenOut,
        uint256 amountIn,
        uint256 amountOut,
        bytes32 reason
    );
    event LiquidityAdded(
        bytes32 indexed pairKey,
        address indexed router,
        address indexed tokenA,
        address tokenB,
        uint256 amountA,
        uint256 amountB,
        uint256 liquidity,
        bytes32 reason
    );
    event BuybackBurn(address indexed token, uint256 amount, bytes32 indexed reason);
    event InventoryTransferred(address indexed token, address indexed to, uint256 amount, bytes32 reason);

    constructor(address admin, address treasury_) {
        require(admin != address(0) && treasury_ != address(0), "MM: bad init");
        treasury = treasury_;
        _grantRole(DEFAULT_ADMIN_ROLE, admin);
        _grantRole(POLICY_ROLE, admin);
        _grantRole(GUARDIAN_ROLE, admin);
    }

    function executeSwap(
        address router,
        uint256 amountIn,
        uint256 minAmountOut,
        address[] calldata path,
        uint256 deadline,
        bytes32 reason
    ) external onlyRole(CONTROLLER_ROLE) nonReentrant whenNotPaused returns (uint256 amountOut) {
        return _executeSwap(router, amountIn, minAmountOut, path, deadline, reason);
    }

    function executeBuybackAndBurn(
        address router,
        uint256 amountIn,
        uint256 minAmountOut,
        address[] calldata path,
        uint256 deadline,
        bytes32 reason
    ) external onlyRole(CONTROLLER_ROLE) nonReentrant whenNotPaused returns (uint256 burned) {
        require(path.length >= 2 && burnableToken[path[path.length - 1]], "MM: output not burnable");
        burned = _executeSwap(router, amountIn, minAmountOut, path, deadline, reason);
        ISHTENCOBurnable(path[path.length - 1]).burn(burned);
        totalBurned[path[path.length - 1]] += burned;
        emit BuybackBurn(path[path.length - 1], burned, reason);
    }

    function addLiquidity(
        address router,
        address tokenA,
        address tokenB,
        uint256 amountADesired,
        uint256 amountBDesired,
        uint256 amountAMin,
        uint256 amountBMin,
        uint256 deadline,
        bytes32 reason
    ) external onlyRole(CONTROLLER_ROLE) nonReentrant whenNotPaused
        returns (uint256 amountA, uint256 amountB, uint256 liquidity)
    {
        require(allowedRouter[router], "MM: router disabled");
        require(tokenA != tokenB && allowedToken[tokenA] && allowedToken[tokenB], "MM: token disabled");
        require(amountADesired > 0 && amountBDesired > 0, "MM: zero amount");
        require(amountAMin > 0 && amountBMin > 0, "MM: weak liquidity minimum");
        _validateDeadline(deadline);
        require(address(priceGuard) != address(0), "MM: no price guard");

        bytes32 pairKey = _pairKey(tokenA, tokenB);
        _checkCooldown(pairKey);
        _consumeNotional(tokenA, amountADesired);
        _consumeNotional(tokenB, amountBDesired);

        (uint256 expectedB, uint256 updatedAt) = priceGuard.quote(tokenA, tokenB, amountADesired);
        _validateOracleTime(expectedB, updatedAt);
        uint256 ratioFloor = (expectedB * (BPS - maxOracleDeviationBps)) / BPS;
        uint256 ratioCeiling = (expectedB * (BPS + maxOracleDeviationBps)) / BPS;
        require(amountBDesired >= ratioFloor && amountBDesired <= ratioCeiling, "MM: liquidity ratio");
        require(amountAMin >= (amountADesired * (BPS - maxOracleDeviationBps)) / BPS, "MM: weak amountAMin");
        require(amountBMin >= (amountBDesired * (BPS - maxOracleDeviationBps)) / BPS, "MM: weak amountBMin");

        IERC20(tokenA).forceApprove(router, amountADesired);
        IERC20(tokenB).forceApprove(router, amountBDesired);
        (amountA, amountB, liquidity) = ISHTENCOV2Router(router).addLiquidity(
            tokenA, tokenB, amountADesired, amountBDesired,
            amountAMin, amountBMin, treasury, deadline
        );
        IERC20(tokenA).forceApprove(router, 0);
        IERC20(tokenB).forceApprove(router, 0);
        require(amountA >= amountAMin && amountB >= amountBMin && liquidity > 0, "MM: liquidity result");

        lastTradeAt[pairKey] = block.timestamp;
        ++totalLiquidityActions;
        totalVolumeIn[tokenA] += amountA;
        totalVolumeIn[tokenB] += amountB;
        emit LiquidityAdded(pairKey, router, tokenA, tokenB, amountA, amountB, liquidity, reason);
    }

    function transferInventory(address token, address to, uint256 amount, bytes32 reason)
        external onlyRole(CONTROLLER_ROLE) nonReentrant whenNotPaused
    {
        require(allowedToken[token] && to == treasury, "MM: invalid transfer");
        require(amount > 0, "MM: zero amount");
        IERC20(token).safeTransfer(to, amount);
        emit InventoryTransferred(token, to, amount, reason);
    }

    function _executeSwap(
        address router,
        uint256 amountIn,
        uint256 minAmountOut,
        address[] calldata path,
        uint256 deadline,
        bytes32 reason
    ) internal returns (uint256 amountOut) {
        require(allowedRouter[router], "MM: router disabled");
        require(path.length >= 2 && path.length <= MAX_PATH_LENGTH, "MM: bad path");
        require(amountIn > 0 && minAmountOut > 0, "MM: zero amount");
        _validateDeadline(deadline);
        require(address(priceGuard) != address(0), "MM: no price guard");

        for (uint256 i; i < path.length; ++i) require(allowedToken[path[i]], "MM: token disabled");
        address tokenIn = path[0];
        address tokenOut = path[path.length - 1];
        require(tokenIn != tokenOut, "MM: circular single trade");

        bytes32 pairKey = _pairKey(tokenIn, tokenOut);
        _checkCooldown(pairKey);
        _consumeNotional(tokenIn, amountIn);

        (uint256 oracleOut, uint256 updatedAt) = priceGuard.quote(tokenIn, tokenOut, amountIn);
        _validateOracleTime(oracleOut, updatedAt);
        uint256 oracleFloor = (oracleOut * (BPS - maxOracleDeviationBps)) / BPS;
        require(minAmountOut >= oracleFloor, "MM: weak minOut");

        uint256[] memory quoted = ISHTENCOV2Router(router).getAmountsOut(amountIn, path);
        require(quoted[quoted.length - 1] >= minAmountOut, "MM: router quote below minOut");

        IERC20(tokenIn).forceApprove(router, amountIn);
        uint256 beforeOut = IERC20(tokenOut).balanceOf(address(this));
        ISHTENCOV2Router(router).swapExactTokensForTokens(amountIn, minAmountOut, path, address(this), deadline);
        IERC20(tokenIn).forceApprove(router, 0);
        uint256 afterOut = IERC20(tokenOut).balanceOf(address(this));
        require(afterOut > beforeOut, "MM: no output");
        amountOut = afterOut - beforeOut;
        require(amountOut >= minAmountOut, "MM: slippage");

        lastTradeAt[pairKey] = block.timestamp;
        ++totalTrades;
        totalVolumeIn[tokenIn] += amountIn;
        emit MarketTrade(pairKey, router, tokenIn, tokenOut, amountIn, amountOut, reason);
    }

    function _pairKey(address tokenA, address tokenB) internal pure returns (bytes32) {
        return keccak256(abi.encodePacked(
            tokenA < tokenB ? tokenA : tokenB,
            tokenA < tokenB ? tokenB : tokenA
        ));
    }

    function _validateDeadline(uint256 deadline) internal view {
        require(deadline >= block.timestamp && deadline <= block.timestamp + MAX_DEADLINE_WINDOW, "MM: bad deadline");
    }

    function _checkCooldown(bytes32 pairKey) internal view {
        require(block.timestamp >= lastTradeAt[pairKey] + pairCooldown, "MM: cooldown");
    }

    function _validateOracleTime(uint256 expectedOut, uint256 updatedAt) internal view {
        require(expectedOut > 0 && updatedAt <= block.timestamp && block.timestamp - updatedAt <= maxOracleAge, "MM: stale oracle");
    }

    function _consumeNotional(address token, uint256 amount) internal {
        DailyNotional storage flow = _dailyNotional[token];
        uint64 day = uint64(block.timestamp / 1 days);
        if (flow.day != day) {
            flow.day = day;
            flow.amount = 0;
        }
        uint256 next = uint256(flow.amount) + amount;
        uint256 limit = dailyNotionalLimit[token];
        require(limit != 0 && next <= limit, "MM: daily notional");
        require(next <= type(uint192).max, "MM: overflow");
        flow.amount = uint192(next);
    }

    function setRouter(address router, bool allowed) external onlyRole(POLICY_ROLE) {
        require(router != address(0) && (!allowed || router.code.length > 0), "MM: invalid router");
        allowedRouter[router] = allowed;
        emit RouterSet(router, allowed);
    }

    function setToken(address token, bool allowed, uint256 dailyLimit) external onlyRole(POLICY_ROLE) {
        require(token != address(0) && (!allowed || token.code.length > 0), "MM: invalid token");
        require(!allowed || dailyLimit > 0, "MM: zero daily limit");
        allowedToken[token] = allowed;
        dailyNotionalLimit[token] = dailyLimit;
        emit TokenSet(token, allowed, dailyLimit);
    }

    function setBurnableToken(address token, bool allowed) external onlyRole(POLICY_ROLE) {
        require(allowedToken[token], "MM: token not enabled");
        burnableToken[token] = allowed;
        emit BurnableTokenSet(token, allowed);
    }

    function setGuard(address guard, uint256 deviationBps, uint256 maxAge) external onlyRole(POLICY_ROLE) {
        require(guard != address(0) && guard.code.length > 0, "MM: invalid guard");
        require(deviationBps <= 500 && maxAge > 0 && maxAge <= 6 hours, "MM: bad guard policy");
        priceGuard = ISHTENCOPriceGuard(guard);
        maxOracleDeviationBps = deviationBps;
        maxOracleAge = maxAge;
        emit GuardSet(guard, deviationBps, maxAge);
    }

    function setTreasury(address treasury_) external onlyRole(POLICY_ROLE) {
        require(treasury_ != address(0), "MM: zero treasury");
        treasury = treasury_;
        emit TreasurySet(treasury_);
    }

    function setCooldown(uint256 cooldown) external onlyRole(POLICY_ROLE) {
        require(cooldown >= 30 seconds && cooldown <= 1 days, "MM: bad cooldown");
        pairCooldown = cooldown;
        emit CooldownSet(cooldown);
    }

    function notionalToday(address token) external view returns (uint256) {
        DailyNotional memory flow = _dailyNotional[token];
        return flow.day == uint64(block.timestamp / 1 days) ? flow.amount : 0;
    }

    function pause() external onlyRole(GUARDIAN_ROLE) { _pause(); }
    function unpause() external onlyRole(DEFAULT_ADMIN_ROLE) { _unpause(); }
}
