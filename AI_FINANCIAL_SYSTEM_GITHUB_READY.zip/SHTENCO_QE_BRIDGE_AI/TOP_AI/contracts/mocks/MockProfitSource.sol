// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
contract MockProfitSource {
    using SafeERC20 for IERC20;
    address public controller;
    constructor(address controller_) { controller = controller_; }
    function withdrawProfit(address token, address to, uint256 amount) external {
        require(msg.sender == controller, "PROFIT: controller only");
        IERC20(token).safeTransfer(to, amount);
    }
}
