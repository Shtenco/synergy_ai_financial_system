from __future__ import annotations

import argparse
import json
from dataclasses import asdict
from pathlib import Path

from .engine import EconomicEngine
from .mainnet_bridge import execute_on_mainnet, read_mainnet_state
from .models import SearchConfig
from .policy import evaluate


def main() -> int:
    parser = argparse.ArgumentParser(description="SHTENCO AI Central Bank optimizer")
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--cycles", type=int, default=1)
    parser.add_argument("--depth", type=int, default=5)
    parser.add_argument("--beam", type=int, default=180)
    parser.add_argument("--write-proposal", action="store_true")
    args = parser.parse_args()

    raw = read_mainnet_state(args.root, print)
    engine = EconomicEngine.from_mainnet(raw)
    before = engine.metrics(engine.state)
    cfg = SearchConfig(max_depth=args.depth, beam_width=args.beam)
    rows, _ = engine.run_cycles(args.cycles, cfg)
    after = engine.metrics(engine.state)
    decision = evaluate(before, after)
    result = {
        "before": before,
        "cycles": rows,
        "after": after,
        "policy": asdict(decision),
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))
    if args.write_proposal and decision.allowed:
        execute_on_mainnet(args.root, rows, print, before_metrics=before)
    return 0 if decision.allowed else 2


if __name__ == "__main__":
    raise SystemExit(main())
