#!/usr/bin/env python3
"""
SINERGY TROIKA - INSTANT DEPLOY (no timelocks)
Деплой всех контрактов с инстант-выводами
"""
import sys, io, os, json, time
from dotenv import load_dotenv
from web3 import Web3
from web3.middleware import ExtraDataToPOAMiddleware
from solcx import compile_source, install_solc, set_solc_version

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

load_dotenv()

# Установить solc 0.8.20
try:
    set_solc_version('0.8.20')
except:
    print("Устанавливаю solc 0.8.20...")
    install_solc('0.8.20')
    set_solc_version('0.8.20')

w3 = Web3(Web3.HTTPProvider("https://polygon-bor-rpc.publicnode.com", request_kwargs={"timeout": 120}))
w3.middleware_onion.inject(ExtraDataToPOAMiddleware, layer=0)

PK = os.getenv("OWNER_PRIVATE_KEY")
OWNER = "0x6946999DBCE63b140B1bB9D475F7c357130909E5"

print("=" * 60)
print("SINERGY TROIKA - INSTANT DEPLOY")
print("=" * 60)
print(f"Owner: {OWNER}")
print(f"Balance: {w3.eth.get_balance(OWNER) / 1e18:.4f} POL")
print("=" * 60)

nonce = w3.eth.get_transaction_count(OWNER, "pending")

def deploy(bytecode, abi, args=None, label="Contract"):
    global nonce
    base = w3.eth.get_block("latest").get("baseFeePerGas", int(100e9))
    prio = int(50e9)
    mf = base * 2 + prio

    contract = w3.eth.contract(abi=abi, bytecode=bytecode)
    if args:
        tx = contract.constructor(*args).build_transaction({
            "from": OWNER, "nonce": nonce, "chainId": 137, "type": 2,
            "maxPriorityFeePerGas": prio, "maxFeePerGas": mf, "gas": 8000000
        })
    else:
        tx = contract.constructor().build_transaction({
            "from": OWNER, "nonce": nonce, "chainId": 137, "type": 2,
            "maxPriorityFeePerGas": prio, "maxFeePerGas": mf, "gas": 8000000
        })

    signed = w3.eth.account.sign_transaction(tx, PK)
    tx_hash = w3.eth.send_raw_transaction(signed.raw_transaction)
    print(f"  {label} tx: {tx_hash.hex()[:20]}...", flush=True)

    receipt = w3.eth.wait_for_transaction_receipt(tx_hash, timeout=300)
    addr = receipt.contractAddress
    gas_cost = receipt.gasUsed * mf / 1e18

    if receipt.status == 1:
        print(f"  [OK] {label}: {addr} (gas: {gas_cost:.4f} POL)", flush=True)
    else:
        print(f"  [FAIL] {label}", flush=True)
        return None

    nonce += 1
    return addr

# Простой ERC20 токен без зависимостей от OpenZeppelin
TOKEN_SOURCE = '''
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract SimpleToken {
    string public name;
    string public symbol;
    uint8 public constant decimals = 18;
    uint256 public totalSupply;

    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;

    event Transfer(address indexed from, address indexed to, uint256 value);
    event Approval(address indexed owner, address indexed spender, uint256 value);

    constructor(string memory _name, string memory _symbol, uint256 _supply, address _admin) {
        name = _name;
        symbol = _symbol;
        totalSupply = _supply;
        balanceOf[_admin] = _supply;
        emit Transfer(address(0), _admin, _supply);
    }

    function transfer(address to, uint256 amount) external returns (bool) {
        require(balanceOf[msg.sender] >= amount, "Balance");
        balanceOf[msg.sender] -= amount;
        balanceOf[to] += amount;
        emit Transfer(msg.sender, to, amount);
        return true;
    }

    function approve(address spender, uint256 amount) external returns (bool) {
        allowance[msg.sender][spender] = amount;
        emit Approval(msg.sender, spender, amount);
        return true;
    }

    function transferFrom(address from, address to, uint256 amount) external returns (bool) {
        if (allowance[from][msg.sender] != type(uint256).max) {
            require(allowance[from][msg.sender] >= amount, "Allowance");
            allowance[from][msg.sender] -= amount;
        }
        require(balanceOf[from] >= amount, "Balance");
        balanceOf[from] -= amount;
        balanceOf[to] += amount;
        emit Transfer(from, to, amount);
        return true;
    }
}
'''

print("\n[1] Компиляция токенов...", flush=True)

compiled = compile_source(
    TOKEN_SOURCE,
    output_values=['abi', 'bin'],
    solc_version='0.8.20'
)

token_abi = compiled['<stdin>:SimpleToken']['abi']
token_bin = compiled['<stdin>:SimpleToken']['bin']

# Deploy TROIKA tokens
print("\n[2] Деплой TROIKA токенов...", flush=True)

SYNA = deploy(token_bin, token_abi, ["Sinergy Anchor", "SYNA", int(10_000_000e18), OWNER], "SYNA")
time.sleep(2)

SYNC = deploy(token_bin, token_abi, ["Sinergy Cycle", "SYNC", int(100_000_000e18), OWNER], "SYNC")
time.sleep(2)

SYNR = deploy(token_bin, token_abi, ["Sinergy Rise", "SYNR", int(21_000_000e18), OWNER], "SYNR")
time.sleep(2)

ALTN = deploy(token_bin, token_abi, ["Altyn Token", "ALTN", int(110_500_000e18), OWNER], "ALTN")
time.sleep(2)

# Результаты
result = {
    "deployed_at": time.strftime("%Y-%m-%d %H:%M:%S"),
    "owner": OWNER,
    "network": "Polygon Mainnet",
    "instant_withdrawals": True,
    "tokens": {
        "SYNA": SYNA,
        "SYNC": SYNC,
        "SYNR": SYNR,
        "ALTN": ALTN
    }
}

# Сохранить адреса
with open("deployed_instant.json", "w") as f:
    json.dump(result, f, indent=2)

print("\n" + "=" * 60)
print("ДЕПЛОЙ ЗАВЕРШЁН")
print("=" * 60)
print(f"SYNA: {SYNA}")
print(f"SYNC: {SYNC}")
print(f"SYNR: {SYNR}")
print(f"ALTN: {ALTN}")
print(f"\nАдреса сохранены в deployed_instant.json")
print(f"Остаток: {w3.eth.get_balance(OWNER) / 1e18:.4f} POL")
print("=" * 60)
