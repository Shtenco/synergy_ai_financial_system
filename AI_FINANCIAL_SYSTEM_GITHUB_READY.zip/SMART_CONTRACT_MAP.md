# Карта всех Solidity-файлов INSTANT_DEPLOY

Дата локального аудита: 22 июля 2026 года.

## Основное ядро

| Файл | Назначение | Итог аудита |
|---|---|---|
| `00_CircularInterfaces.sol` | Общие интерфейсы и `CircularMath` для связки ALTN/SYNA/SYNC/SYNR | Интерфейсный слой; критичных самостоятельных денежных потоков нет. |
| `01_PolygonConfig.sol` | Адреса Polygon/QuickSwap, интервалы и системные константы | Адреса QuickSwap V2 сверены с официальной документацией; любые будущие изменения адресов должны проходить повторную проверку. |
| `02_Tokens.sol` | ERC-20 токены SYNA, SYNC, SYNR, роли mint/burn и логика SYNR | Высокая зависимость от корректной выдачи ролей. Не выдавать `MINTER_ROLE`/`BURNER_ROLE` внешним ботам. |
| `03_TroikaVault.sol` | Центральный Vault, реальные QuickSwap-пулы, внутренние резервы и LP-буфер | Критический учётный риск: виртуальные прибавки LP могут быть перезаписаны `syncFromChain()`. `transferWpol()` привилегирован и не является пользовательским withdraw. |
| `04_TWAPOracle.sol` | Буфер из 48 периодических spot-наблюдений | Это не классический cumulative-price TWAP. Для залога/кредитования недостаточно устойчив к краткосрочной манипуляции. |
| `05_DividendPool.sol` | Дивиденды основателя и держателей SYNR | Проверять соответствие фактических переводов уведомлениям `notify*`; выплаты зависят от ролей и адреса founder. |
| `06_FeeRouter.sol` | Распределение комиссий между Vault, DivPool, CB и циклами | Большое число внешних взаимодействий; нужен строгий инвариант «учётное начисление только после успешного перевода». |
| `07_EmissionEngine.sol` | Эмиссия, виртуальный dLP, founder payout, fix и buyback | Критично: `totalEmitted*` увеличивается даже при неудачном mint; виртуальный dLP синхронизацией заменяется реальными резервами; founder WPOL берётся из существующего Vault, а не создаётся как внешний доход. |
| `07_EmissionEngine_MAX.sol` | Альтернативный максимальный режим эмиссии | Те же риски mint/accounting; не держать одновременно активным с основной версией без единого источника истины. |
| `08_CBArbitrage.sol` | Внутренний QuickSwap арбитраж на WPOL-буфере | Не flash loan. Нужны реальные `amountOutMin`, запрет торгов на устаревшем сигнале и проверка net profit после газа. |
| `09_SelfReinforcingLoop.sol` | Два внутренних распределительных кольца | «Умножение капитала» не является внешней прибылью; это перераспределение системных средств. |
| `10_TroikaCore.sol` | Главный оркестратор tick/processFee/pause | Много пустых `catch`, поэтому отдельные подсистемы могут не выполниться, а общий tick завершиться успешно. Нужны события ошибок и health-check. |
| `11_FounderControl.sol` | Централизованное управление, старт/стоп, rescue | `START_TIMELOCK` и `RESCUE_TIMELOCK` равны нулю. Это административный и custody-риск. |
| `12_TroikaDeployer.sol` | Монолитный деплой TROIKA | Требует проверки адресов, ролей и фактического кода каждого созданного контракта после deployment. |
| `13_CollateralEmission.sol` | Залог ALTN и выпуск SYNA | Критично: стоимость ALTN берётся прямо из spot-reserves пары; flash-манипуляция ценой может исказить LTV/ликвидацию. |
| `14_CircularHub_v2.sol` | Оркестратор ALTN ↔ TROIKA | Пустые `catch` допускают частичное исполнение цикла и расхождение состояния подсистем. |
| `15_CircularDeployer.sol` | Деплой CollateralEmission и CircularHub | Выдача ролей обёрнута в `try/catch`; после деплоя обязательно проверять каждую роль on-chain. |
| `16_AltynCircularPatch.sol` | Адаптер callback для ALTN | Должен быть жёстко ограничен доверенными отправителями; не использовать как самостоятельный источник цены. |
| `17_EmissionCircular.sol` | Патчи внешнего ценового сигнала и fee callback | Сигнал должен быть защищён от манипуляции и иметь freshness check. |
| `18_MutualPoolDeployer.sol` | Создание пяти TOKEN/TOKEN пар | Пулы создают возможность треугольного арбитража, но также увеличивают поверхность ценовой манипуляции. |
| `19_Altyn_v1_original.sol` | ALTN Omega Deflationary v4, налоги, LP, buyback, staking | Очень большая и сложная поверхность; встречаются `amountOutMin=0` и min-liquidity=0. Требует отдельного формального аудита перед ростом TVL. |
| `19_MutualPoolRouter.sol` | Распределение ликвидности по 9 пулам | Использует spot TVL и местами нулевые minimums; маршрутизация может быть искажена манипуляцией резервов. |

## Flash-loan файлы

| Файл | Статус | Причина |
|---|---|---|
| `20_FlashProfitCycle.sol` | **НЕ ДЕПЛОИТЬ** | Вызывает отсутствующие в `TroikaVault` функции `deposit()` и `withdraw()`. Экономически пытается превратить внутреннюю эмиссию/Vault в «прибыль». |
| `21_FlashProfitAtomic.sol` | **НЕ ДЕПЛОИТЬ** | Требует привилегии `OPERATOR_ROLE` для возврата principal из Vault; founder payout уходит founder-адресу; несколько эмиссий нельзя ожидать внутри одной транзакции; внешняя прибыль не создаётся. |
| `TroikaFlashProfit.sol` | **НЕ ДЕПЛОИТЬ** | Неверно использует ETH-функции Router для WPOL-путей, ставит нулевые `amountOutMin`, подавляет ошибки и не имеет строгого конечного инварианта прибыли. |
| `22_FlashLoanArbitrage.sol` | **НОВЫЙ РЕКОМЕНДОВАННЫЙ** | Реальный Aave V3 flash loan + whitelisted V2-совместимые роутеры + циклический маршрут + атомарная проверка principal/premium/minProfit. Не использует эмиссию или Vault как источник прибыли. |

## Компиляция

Команда `npm run check:contracts` компилирует все Solidity-исходники на уровне ABI. На момент выдачи:

- 26 Solidity-файлов;
- 140 contracts/interfaces/libraries вместе с импортами;
- 0 fatal compiler errors;
- сохранены предупреждения по старым исходникам, перечисленные в основном отчёте.

---

## SHTENCO QE BRIDGE AI V2 extension

| File | Role |
|---|---|
| `23_SHTENCOBridgeRelayV2.sol` | Threshold relay bridge and capped wrapped SYNA token. |
| `24_SHTENCOBridgeQEReserve.sol` | Reserve-backed capital allocator with reserve floors and daily limits. |
| `25_SHTENCOMarketMaker.sol` | Oracle-guarded swaps, liquidity, buyback/burn and treasury inventory return. |
| `26_SHTENCOAICentralBank.sol` | Timelocked action policy, exact target/selector allowlist, budgets and guardian. |
| `27_SHTENCOBridgeQEAdapter.sol` | Restricted reserve-to-bridge inventory rebalancing adapter. |

The executable workflow and deployment order are documented in `RUN_AI_CENTROBANK_BRIDGE.md` and `SHTENCO_QE_BRIDGE_AI/SECURITY_AND_DEPLOYMENT.md`.
