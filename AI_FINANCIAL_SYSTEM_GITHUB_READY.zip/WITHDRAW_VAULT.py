#!/usr/bin/env python3
"""Вывод freeWpol из Vault"""
import sys, io, os, json, time
from dotenv import load_dotenv
from web3 import Web3
from web3.middleware import ExtraDataToPOAMiddleware

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

load_dotenv()
w3 = Web3(Web3.HTTPProvider("https://polygon-bor-rpc.publicnode.com", request_kwargs={"timeout": 300}))
w3.middleware_onion.inject(ExtraDataToPOAMiddleware, layer=0)

PK = os.getenv("OWNER_PRIVATE_KEY")
OWNER = "0x6946999DBCE63b140B1bB9D475F7c357130909E5"

def C(a): return Web3.to_checksum_address(a)

with open("deployed_TROIKA_v3.json") as f:
    d = json.load(f)

vault_abi = [
    {"name": "freeWpol", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "transferWpol", "inputs": [{"name": "to", "type": "address"}, {"name": "amount", "type": "uint256"}], "outputs": [], "stateMutability": "nonpayable", "type": "function"},
]

vault = w3.eth.contract(address=C(d["vault"]), abi=vault_abi)
free = vault.functions.freeWpol().call()
print(f"Vault freeWpol: {free / 1e18:.10f}")

if free > 0:
    nonce = w3.eth.get_transaction_count(C(OWNER), "pending")
    base = w3.eth.get_block("latest").get("baseFeePerGas", int(100e9))
    prio = int(50e9)
    mf = base * 2 + prio

    print(f"Withdrawing {free / 1e18:.10f} WPOL...")
    tx = vault.functions.transferWpol(C(OWNER), free).build_transaction({
        "from": C(OWNER), "nonce": nonce, "chainId": 137, "type": 2,
        "maxPriorityFeePerGas": prio, "maxFeePerGas": mf, "gas": 100000
    })
    signed = w3.eth.account.sign_transaction(tx, PK)
    h = w3.eth.send_raw_transaction(signed.raw_transaction)
    r = w3.eth.wait_for_transaction_receipt(h, timeout=120)
    print(f"{'[OK]' if r.status else '[FAIL]'}")

# Final balances
WPOL = "0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270"
token_abi = [{"name": "balanceOf", "inputs": [{"type": "address"}], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"}]
wpol = w3.eth.contract(address=C(WPOL), abi=token_abi)

print(f"\nFinal balances:")
print(f"  Owner POL: {w3.eth.get_balance(C(OWNER)) / 1e18:.6f}")
print(f"  Owner WPOL: {wpol.functions.balanceOf(C(OWNER)).call() / 1e18:.6f}")
print(f"  Vault WPOL: {wpol.functions.balanceOf(C(d['vault'])).call() / 1e18:.6f}")
print(f"  Vault free: {vault.functions.freeWpol().call() / 1e18:.6f}")
