#!/usr/bin/env python3
"""
Создание QuickSwap пулов для TROIKA токенов - V2
Используем нативный POL через addLiquidityETH
"""
import sys, io, os, json, time
from dotenv import load_dotenv
from web3 import Web3
from web3.middleware import ExtraDataToPOAMiddleware

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

load_dotenv()

w3 = Web3(Web3.HTTPProvider("https://polygon-bor-rpc.publicnode.com", request_kwargs={"timeout": 120}))
w3.middleware_onion.inject(ExtraDataToPOAMiddleware, layer=0)

PK = os.getenv("OWNER_PRIVATE_KEY")
OWNER = "0x6946999DBCE63b140B1bB9D475F7c357130909E5"
ROUTER = "0xa5E0829CaCEd8fFDD4De3c43696c57F7D7A678ff"
FACTORY = "0x5757371414417b8C6CAad45bAeF941aBc7d3Ab32"
WPOL = "0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270"

# Загрузить адреса токенов
with open("deployed_instant.json") as f:
    data = json.load(f)
    SYNA = data["tokens"]["SYNA"]
    SYNC = data["tokens"]["SYNC"]
    SYNR = data["tokens"]["SYNR"]
    ALTN = data["tokens"]["ALTN"]

def C(a): return Web3.to_checksum_address(a)

print("=" * 60)
print("СОЗДАНИЕ QUICKSWAP ПУЛОВ V2")
print("=" * 60)
print(f"Balance: {w3.eth.get_balance(C(OWNER)) / 1e18:.4f} POL")
print("=" * 60)

nonce = w3.eth.get_transaction_count(C(OWNER), "pending")

TOKEN_ABI = [
    {"name": "balanceOf", "inputs": [{"name": "", "type": "address"}], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "approve", "inputs": [{"name": "spender", "type": "address"}, {"name": "amount", "type": "uint256"}], "outputs": [{"type": "bool"}], "type": "function"},
]

# Full Router ABI для addLiquidityETH
ROUTER_ABI = json.loads('''[
    {
        "inputs": [
            {"internalType": "address", "name": "token", "type": "address"},
            {"internalType": "uint256", "name": "amountTokenDesired", "type": "uint256"},
            {"internalType": "uint256", "name": "amountTokenMin", "type": "uint256"},
            {"internalType": "uint256", "name": "amountETHMin", "type": "uint256"},
            {"internalType": "address", "name": "to", "type": "address"},
            {"internalType": "uint256", "name": "deadline", "type": "uint256"}
        ],
        "name": "addLiquidityETH",
        "outputs": [
            {"internalType": "uint256", "name": "amountToken", "type": "uint256"},
            {"internalType": "uint256", "name": "amountETH", "type": "uint256"},
            {"internalType": "uint256", "name": "liquidity", "type": "uint256"}
        ],
        "stateMutability": "payable",
        "type": "function"
    }
]''')

FACTORY_ABI = [
    {"name": "getPair", "inputs": [{"name": "tokenA", "type": "address"}, {"name": "tokenB", "type": "address"}], "outputs": [{"type": "address"}], "stateMutability": "view", "type": "function"},
]

router = w3.eth.contract(address=C(ROUTER), abi=ROUTER_ABI)
factory = w3.eth.contract(address=C(FACTORY), abi=FACTORY_ABI)

def send_tx(tx, label, value=0):
    global nonce
    base = w3.eth.get_block("latest").get("baseFeePerGas", int(100e9))
    prio = int(50e9)
    mf = base * 2 + prio
    tx.update({
        "from": C(OWNER), "nonce": nonce, "chainId": 137, "type": 2,
        "maxPriorityFeePerGas": prio, "maxFeePerGas": mf
    })
    if value: tx["value"] = value
    tx.pop("gasPrice", None)
    signed = w3.eth.account.sign_transaction(tx, PK)
    h = w3.eth.send_raw_transaction(signed.raw_transaction)
    r = w3.eth.wait_for_transaction_receipt(h, timeout=300)
    cost = r.gasUsed * mf / 1e18
    ok = "OK" if r.status == 1 else "FAIL"
    print(f"  [{ok}] {label} (gas: {cost:.4f} POL)", flush=True)
    nonce += 1
    return r

def create_pool(token_addr, token_name, token_amount, pol_amount):
    """Создать пул TOKEN/WPOL на QuickSwap"""
    global nonce

    token = w3.eth.contract(address=C(token_addr), abi=TOKEN_ABI)

    print(f"\n[{token_name}] Создание пула...", flush=True)
    print(f"  Токенов: {token_amount / 1e18:,.0f}", flush=True)
    print(f"  POL: {pol_amount / 1e18:.4f}", flush=True)

    # 1. Approve Router
    tx = token.functions.approve(C(ROUTER), token_amount).build_transaction({"gas": 100000})
    send_tx(tx, f"Approve {token_name}")
    time.sleep(3)

    # 2. Add Liquidity с native ETH (POL)
    dl = int(time.time()) + 1200

    # Закодировать вызов вручную
    func = router.functions.addLiquidityETH(
        C(token_addr),      # token
        token_amount,       # amountTokenDesired
        token_amount * 95 // 100,  # amountTokenMin (5% slippage)
        pol_amount * 95 // 100,    # amountETHMin (5% slippage)
        C(OWNER),           # to
        dl                  # deadline
    )

    try:
        gas_est = func.estimate_gas({
            "from": C(OWNER),
            "value": pol_amount
        })
        print(f"  Gas estimate: {gas_est}", flush=True)
    except Exception as e:
        print(f"  Gas estimate failed: {e}", flush=True)
        gas_est = 500000

    tx = func.build_transaction({
        "gas": gas_est + 50000,
        "value": pol_amount
    })

    send_tx(tx, f"AddLiquidity {token_name}", value=pol_amount)

    # 3. Получить адрес пары
    time.sleep(3)
    pair = factory.functions.getPair(C(token_addr), C(WPOL)).call()
    print(f"  Пара: {pair}", flush=True)

    return pair

# Создаём пулы
# 3 POL на каждый пул

POL_AMOUNT = int(3e18)  # 3 POL на пул

# SYNA
pair_syna = create_pool(SYNA, "SYNA", int(600e18), POL_AMOUNT)
time.sleep(3)

# SYNC
pair_sync = create_pool(SYNC, "SYNC", int(6000e18), POL_AMOUNT)
time.sleep(3)

# SYNR
pair_synr = create_pool(SYNR, "SYNR", int(300e18), POL_AMOUNT)
time.sleep(3)

# ALTN
pair_altn = create_pool(ALTN, "ALTN", int(1500e18), POL_AMOUNT)

# Обновить JSON
data["pools"] = {
    "SYNA_WPOL": pair_syna,
    "SYNC_WPOL": pair_sync,
    "SYNR_WPOL": pair_synr,
    "ALTN_WPOL": pair_altn
}
data["liquidity_added"] = time.strftime("%Y-%m-%d %H:%M:%S")

with open("deployed_instant.json", "w") as f:
    json.dump(data, f, indent=2)

print("\n" + "=" * 60)
print("РЕЗУЛЬТАТ")
print("=" * 60)
print(f"SYNA/WPOL: {pair_syna}")
print(f"SYNC/WPOL: {pair_sync}")
print(f"SYNR/WPOL: {pair_synr}")
print(f"ALTN/WPOL: {pair_altn}")
print(f"\nОстаток: {w3.eth.get_balance(C(OWNER)) / 1e18:.4f} POL")
print("=" * 60)
