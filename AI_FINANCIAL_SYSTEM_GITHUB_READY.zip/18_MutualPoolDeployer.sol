// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

// ═══════════════════════════════════════════════════════════════════════════
//  SINERGY DEFLATION SYSTEM — 18_MutualPoolDeployer.sol
//  Создаёт взаимные TOKEN/TOKEN пары за одну транзакцию
//
//  НОВЫЕ ПАРЫ:
//   ALTN/SYNR  — двойной буст: burn ALTN = рост SYNR через AMM инвариант
//   ALTN/SYNA  — залоговый: repay SYNA инжектит в этот пул
//   SYNR/SYNA  — эмиссионный: часть dlp инжектится здесь
//   SYNR/SYNC  — CBArb v2: gap арбитраж теперь в этой паре тоже
//   ALTN/SYNC  — кросс: ALTN burn = SYNC через треугольный арб
//
//  МЕХАНИКА ВЗАИМНОГО РОСТА (AMM математика):
//   k = reserveA × reserveB = const
//   Если A дефляционный (burn) → supply A↓ → цена A в WPOL↑
//   В паре A/B: цена A↑ → B относительно дешевеет
//   → Арбитражеры покупают B за A → reserveB↓ → цена B↑
//   → Итог: burn одного токена = рост ОБОИХ автоматически
//
//  СТАРТОВЫЕ ПРОПОРЦИИ (из текущих цен):
//   ALTN price ≈ 7.8e-6 POL, SYNR price ≈ 2.5e-6 POL → ratio ≈ 3.12
//   Стартовая ликвидность берётся из MutualPoolRouter.initialLiquidity
// ═══════════════════════════════════════════════════════════════════════════

import {IERC20}    from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import "./01_PolygonConfig.sol";

interface IQSFactoryMPD {
    function getPair(address, address) external view returns (address);
    function createPair(address, address) external returns (address);
}

interface IQSRouterMPD {
    function addLiquidity(
        address tokenA, address tokenB,
        uint256 amountADesired, uint256 amountBDesired,
        uint256 amountAMin, uint256 amountBMin,
        address to, uint256 deadline
    ) external returns (uint256, uint256, uint256 liquidity);
    function getAmountsOut(uint256, address[] calldata)
        external view returns (uint256[] memory);
}

interface IQSPairMPD {
    function getReserves() external view returns (uint112, uint112, uint32);
    function token0()      external view returns (address);
    function totalSupply() external view returns (uint256);
}

error MPD_AlreadyDeployed();
error MPD_ZeroAddress();
error MPD_InsufficientBalance(address token, uint256 have, uint256 need);
error MPD_PairExists(address tokenA, address tokenB, address pair);

contract MutualPoolDeployer is ReentrancyGuard {
    using SafeERC20 for IERC20;

    IQSFactoryMPD public immutable factory;
    IQSRouterMPD  public immutable router;

    // ── Созданные пары ────────────────────────────────────────────────
    address public pairALTN_SYNR;
    address public pairALTN_SYNA;
    address public pairSYNR_SYNA;
    address public pairSYNR_SYNC;
    address public pairALTN_SYNC;

    bool public deployed;
    address public owner;

    // ── Параметры каждой пары ─────────────────────────────────────────
    struct PairParams {
        address tokenA;
        address tokenB;
        uint256 amountA;  // стартовая ликвидность tokenA
        uint256 amountB;  // стартовая ликвидность tokenB
        string  name;
    }

    event PairCreated(string name, address tokenA, address tokenB, address pair);
    event LiquidityAdded(string name, address pair, uint256 amtA, uint256 amtB, uint256 lp);
    event AllPairsDeployed(
        address pairALTN_SYNR,
        address pairALTN_SYNA,
        address pairSYNR_SYNA,
        address pairSYNR_SYNC,
        address pairALTN_SYNC
    );

    modifier onlyOwner() { require(msg.sender == owner, "!owner"); _; }

    constructor() {
        factory = IQSFactoryMPD(PolygonConfig.QS_FACTORY);
        router  = IQSRouterMPD(PolygonConfig.QS_ROUTER);
        owner   = msg.sender;
    }

    // ═══════════════════════════════════════════════════════════════════
    //  DEPLOY ALL MUTUAL PAIRS
    //  Вызвать после одобрения достаточного количества каждого токена
    //
    //  Пример вызова:
    //   altn.approve(deployer, altnAmount)
    //   synr.approve(deployer, synrAmount)
    //   syna.approve(deployer, synaAmount)
    //   sync.approve(deployer, syncAmount)
    //   deployer.deployAllPairs(params)
    // ═══════════════════════════════════════════════════════════════════
    function deployAllPairs(
        address altn_, address synr_, address syna_, address sync_,
        // Стартовые количества (в wei) для каждой пары
        uint256 altnForSYNR,  uint256 synrForALTN,   // пара ALTN/SYNR
        uint256 altnForSYNA,  uint256 synaForALTN,   // пара ALTN/SYNA
        uint256 synrForSYNA,  uint256 synaForSYNR,   // пара SYNR/SYNA
        uint256 synrForSYNC,  uint256 syncForSYNR,   // пара SYNR/SYNC
        uint256 altnForSYNC,  uint256 syncForALTN    // пара ALTN/SYNC
    ) external nonReentrant onlyOwner {
        if (deployed) revert MPD_AlreadyDeployed();
        deployed = true;

        // Перевести все токены от деплоера сюда
        _pullTokens(altn_, altnForSYNR + altnForSYNA + altnForSYNC);
        _pullTokens(synr_, synrForALTN + synrForSYNA + synrForSYNC);
        _pullTokens(syna_, synaForALTN + synaForSYNR);
        _pullTokens(sync_, syncForSYNR + syncForALTN);

        // Одобрить Router
        _approveMax(altn_, synr_, syna_, sync_);

        uint256 dl = block.timestamp + 600;

        // 1. ALTN/SYNR
        pairALTN_SYNR = _createAndAdd(
            altn_, synr_, altnForSYNR, synrForALTN, dl, "ALTN/SYNR"
        );

        // 2. ALTN/SYNA
        pairALTN_SYNA = _createAndAdd(
            altn_, syna_, altnForSYNA, synaForALTN, dl, "ALTN/SYNA"
        );

        // 3. SYNR/SYNA
        pairSYNR_SYNA = _createAndAdd(
            synr_, syna_, synrForSYNA, synaForSYNR, dl, "SYNR/SYNA"
        );

        // 4. SYNR/SYNC
        pairSYNR_SYNC = _createAndAdd(
            synr_, sync_, synrForSYNC, syncForSYNR, dl, "SYNR/SYNC"
        );

        // 5. ALTN/SYNC
        pairALTN_SYNC = _createAndAdd(
            altn_, sync_, altnForSYNC, syncForALTN, dl, "ALTN/SYNC"
        );

        emit AllPairsDeployed(
            pairALTN_SYNR, pairALTN_SYNA,
            pairSYNR_SYNA, pairSYNR_SYNC, pairALTN_SYNC
        );
    }

    // ── ДОБАВИТЬ ЛИКВИДНОСТЬ В УЖЕ СУЩЕСТВУЮЩУЮ ПАРУ ─────────────────
    function addLiquidityToPair(
        address tokenA, address tokenB,
        uint256 amountA, uint256 amountB
    ) external nonReentrant onlyOwner {
        IERC20(tokenA).safeTransferFrom(msg.sender, address(this), amountA);
        IERC20(tokenB).safeTransferFrom(msg.sender, address(this), amountB);

        IERC20(tokenA).forceApprove(address(router), amountA);
        IERC20(tokenB).forceApprove(address(router), amountB);

        (,, uint256 lp) = router.addLiquidity(
            tokenA, tokenB,
            amountA, amountB,
            amountA * 95 / 100,
            amountB * 95 / 100,
            address(this),
            block.timestamp + 300
        );
        emit LiquidityAdded("manual", factory.getPair(tokenA, tokenB), amountA, amountB, lp);
    }

    // ── INTERNALS ─────────────────────────────────────────────────────
    function _pullTokens(address token, uint256 amount) private {
        if (amount == 0) return;
        uint256 bal = IERC20(token).balanceOf(msg.sender);
        if (bal < amount) revert MPD_InsufficientBalance(token, bal, amount);
        IERC20(token).safeTransferFrom(msg.sender, address(this), amount);
    }

    function _approveMax(address a, address b, address c, address d) private {
        uint256 MAX = type(uint256).max;
        IERC20(a).forceApprove(address(router), MAX);
        IERC20(b).forceApprove(address(router), MAX);
        IERC20(c).forceApprove(address(router), MAX);
        IERC20(d).forceApprove(address(router), MAX);
    }

    function _createAndAdd(
        address tA, address tB,
        uint256 aA, uint256 aB,
        uint256 dl, string memory name_
    ) private returns (address pair) {
        // Создать пару если не существует
        pair = factory.getPair(tA, tB);
        if (pair == address(0)) {
            pair = factory.createPair(tA, tB);
            emit PairCreated(name_, tA, tB, pair);
        }

        // Добавить ликвидность
        if (aA > 0 && aB > 0) {
            (uint256 usedA, uint256 usedB, uint256 lp) = router.addLiquidity(
                tA, tB, aA, aB,
                aA * 95 / 100,
                aB * 95 / 100,
                address(this), dl
            );
            emit LiquidityAdded(name_, pair, usedA, usedB, lp);
        }
    }

    // ── VIEW ──────────────────────────────────────────────────────────
    function getAllPairs() external view returns (
        address altn_synr, address altn_syna, address synr_syna,
        address synr_sync, address altn_sync
    ) {
        return (pairALTN_SYNR, pairALTN_SYNA, pairSYNR_SYNA, pairSYNR_SYNC, pairALTN_SYNC);
    }

    function getPairPrice(address pair, address tokenA) external view returns (uint256 priceAinB) {
        if (pair == address(0)) return 0;
        try IQSPairMPD(pair).getReserves() returns (uint112 r0, uint112 r1, uint32) {
            address t0 = IQSPairMPD(pair).token0();
            (uint256 rA, uint256 rB) = t0 == tokenA
                ? (uint256(r0), uint256(r1))
                : (uint256(r1), uint256(r0));
            return rA > 0 ? rB * 1e18 / rA : 0;
        } catch { return 0; }
    }

    function getTVL(address pair) external view returns (uint256 tvlA, uint256 tvlB) {
        if (pair == address(0)) return (0,0);
        try IQSPairMPD(pair).getReserves() returns (uint112 r0, uint112 r1, uint32) {
            return (uint256(r0), uint256(r1));
        } catch { return (0,0); }
    }

    // LP токены хранятся здесь — owner может забрать
    function withdrawLP(address pair, address to) external onlyOwner {
        uint256 bal = IERC20(pair).balanceOf(address(this));
        if (bal > 0) IERC20(pair).safeTransfer(to, bal);
    }
}
