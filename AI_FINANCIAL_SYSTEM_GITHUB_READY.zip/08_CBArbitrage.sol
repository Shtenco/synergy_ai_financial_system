// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

// ═══════════════════════════════════════════════════════════════════════════
//  SINERGY SYSTEM — 08_CBArbitrage.sol
//  ЦБ Арбитраж | Polygon + QuickSwap V2 (РЕАЛЬНЫЕ СВАПЫ)
//
//  Логика из Python-модели v9.2:
//  Каждые 5 блоков, если cbFund ≥ 0.001 WPOL и gap ≥ 1%:
//
//  1. Определяем направление:
//     buySide=true  → P_P < TWAP → покупаем SYNR за WPOL (дешевле)
//     buySide=false → P_P > TWAP → покупаем SYNC за WPOL (продаём дорогой)
//
//  2. arbSz = min(0.5% LP_min, cbFund, MAX_SINGLE_ARB) WPOL
//     Шаг 1: WPOL → token  (swapExactTokensForTokens)
//     Шаг 2: token → WPOL  (обратный своп для фиксации прибыли)
//
//  3. Прибыль распределяется 50/50:
//     50% реинвест: 40%→LP + 30%→reserveR + 15%→holders + 5%→buyback
//     50% обычное:  50%→reserveR + 25%→traders + 15%→LP + 5%→buyback + 5%→founder
//
//  Паттерн безопасности:
//  ✓ notifyCBFund — FeeRouter делает safeTransfer WPOL сюда, затем notify
//  ✓ CEI везде: Effects (cbFund -= arbSz) до Interactions (swap)
//  ✓ try/catch на оба свапа — сбой QuickSwap не блокирует систему
//  ✓ Откат cbFund при неудаче первого свапа
//  ✓ MAX_SINGLE_ARB — лимит одной операции
//  ✓ MIN_FUND — минимальный порог для запуска арба
//  ✓ Reentrancy guard
// ═══════════════════════════════════════════════════════════════════════════

import {IERC20}          from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20}       from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {AccessControl}   from "@openzeppelin/contracts/access/AccessControl.sol";
import {Pausable}        from "@openzeppelin/contracts/utils/Pausable.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {Math}            from "@openzeppelin/contracts/utils/math/Math.sol";
import "./01_PolygonConfig.sol";

// ── Интерфейсы (file-level) ────────────────────────────────────────────────

interface IVaultCB {
    function lpR() external view returns (uint256);
    function lpT() external view returns (uint256);
    function lpP() external view returns (uint256);
    function batchAddLP(uint256 dR, uint256 dT, uint256 dP) external;
    function addToReserveR(uint256 a)       external;
    function addToTraderReserve(uint256 a)  external;
    function addToBuyback(uint256 a)        external;
    function addToLpBuf(uint256 a)          external;
    function subFromLpP(uint256 a)          external;
    function subFromLpT(uint256 a)          external;
    function syncFromChain()                external;
}

interface IDivPoolCB {
    function notifyHolders(uint256 amount) external;
    function notifyFounder(uint256 amount) external;
}

interface IOracleCB {
    function getGapBps() external view returns (uint256 gapBps, bool buySide);
}

// ── Custom Errors ─────────────────────────────────────────────────────────
error CB_ZeroAddress();
error CB_ZeroAmount();
error CB_AlreadyInitialized();

contract CBArbitrage is AccessControl, Pausable, ReentrancyGuard {
    using SafeERC20 for IERC20;

    bytes32 public constant CALLER_ROLE = keccak256("CALLER_ROLE"); // TroikaCore
    bytes32 public constant FEEDER_ROLE = keccak256("FEEDER_ROLE"); // FeeRouter
    bytes32 public constant PAUSER_ROLE = keccak256("PAUSER_ROLE");

    // ── QuickSwap ─────────────────────────────────────────────────────
    IQSRouter public immutable router;
    IERC20    public immutable WPOL;
    IERC20    public immutable SYNR;
    IERC20    public immutable SYNC;

    // ── Зависимости ───────────────────────────────────────────────────
    IVaultCB   public immutable vault;
    IDivPoolCB public immutable divPool;
    IOracleCB  public immutable oracle;

    address public immutable vaultAddr;
    address public immutable divPoolAddr;

    // ── CB Fund (физически WPOL на этом контракте) ────────────────────
    uint256 public cbFund;
    uint256 public lastArbBlock;

    // ── Параметры ─────────────────────────────────────────────────────
    uint256 public constant MIN_GAP_BPS    = 100;       // 1% = 100 basis points
    uint256 public constant MIN_FUND       = 1e15;      // 0.001 WPOL
    uint256 public constant MAX_SINGLE_ARB = 50_000e18; // 50k WPOL max
    uint256 public constant ARB_SIZE_BPS   = 50;        // 0.5% LP_min

    // ── Статистика ────────────────────────────────────────────────────
    uint256 public totalProfit;
    uint256 public totalReinvested;
    uint256 public arbCount;

    // ── Events ────────────────────────────────────────────────────────
    event CBFundNotified(uint256 amount, uint256 totalFund);
    event ArbExecuted(uint256 arbN, uint256 spent, uint256 profit, bool buySide);
    event ArbFailed(uint256 arbN, string reason);

    constructor(
        address vault_,
        address divPool_,
        address oracle_,
        address synr_,
        address sync__,
        address admin_
    ) {
        if (vault_   == address(0) || divPool_ == address(0) ||
            oracle_  == address(0) || synr_   == address(0) ||
            sync__   == address(0) || admin_   == address(0)) revert CB_ZeroAddress();

        router     = IQSRouter(PolygonConfig.QS_ROUTER);
        WPOL       = IERC20(PolygonConfig.WPOL);
        SYNR      = IERC20(synr_);
        SYNC      = IERC20(sync__);
        vault      = IVaultCB(vault_);
        divPool    = IDivPoolCB(divPool_);
        oracle     = IOracleCB(oracle_);
        vaultAddr  = vault_;
        divPoolAddr= divPool_;

        // Approve router для обоих направлений
        WPOL.approve(address(router),  type(uint256).max);
        SYNR.approve(address(router), type(uint256).max);
        SYNC.approve(address(router), type(uint256).max);

        _grantRole(DEFAULT_ADMIN_ROLE, admin_);
        _grantRole(CALLER_ROLE,        admin_);
        _grantRole(FEEDER_ROLE,        admin_);
        _grantRole(PAUSER_ROLE,        admin_);
    }

    // ── FeeRouter пополняет cbFund (PUSH+NOTIFY) ──────────────────────
    function notifyCBFund(uint256 amount)
        external whenNotPaused onlyRole(FEEDER_ROLE)
    {
        if (amount == 0) revert CB_ZeroAmount();
        cbFund += amount;
        emit CBFundNotified(amount, cbFund);
    }

    // ═══════════════════════════════════════════════════════════════════
    //  EXECUTE ARB — вызывается TroikaCore каждые 5 блоков
    // ═══════════════════════════════════════════════════════════════════
    function executeArb()
        external nonReentrant whenNotPaused onlyRole(CALLER_ROLE)
        returns (uint256 profit)
    {
        // Ранние выходы без revert (не блокируем tick)
        if (block.number < lastArbBlock + PolygonConfig.ARB_INTERVAL) return 0;
        if (cbFund < MIN_FUND) return 0;

        (uint256 gapBps, bool buySide) = oracle.getGapBps();
        if (gapBps < MIN_GAP_BPS) return 0;

        // Размер арб-операции
        uint256 lpMin = _min3(vault.lpR(), vault.lpT(), vault.lpP());
        if (lpMin == 0) return 0;

        uint256 arbSz = lpMin * ARB_SIZE_BPS / 10_000;
        if (arbSz > MAX_SINGLE_ARB) arbSz = MAX_SINGLE_ARB;
        if (arbSz > cbFund)          arbSz = cbFund;
        if (arbSz == 0) return 0;

        ++arbCount;
        uint256 arbN = arbCount;

        // ── Выбор токена для арба ─────────────────────────────────────
        // buySide=true  → P_P дешевле → покупаем SYNR (помогает цене P вырасти)
        // buySide=false → P_P дороже  → покупаем SYNC (выравниваем)
        address buyToken = buySide ? address(SYNR) : address(SYNC);

        address[] memory pathBuy  = new address[](2);
        address[] memory pathSell = new address[](2);
        pathBuy[0] = PolygonConfig.WPOL;   pathBuy[1] = buyToken;
        pathSell[0] = buyToken;             pathSell[1] = PolygonConfig.WPOL;

        // ── CEI: Effects сначала ──────────────────────────────────────
        cbFund -= arbSz;
        lastArbBlock = block.number;

        // ── Шаг 1: WPOL → token (покупка) ────────────────────────────
        uint256 wpolBefore   = WPOL.balanceOf(address(this));
        uint256 tokenBefore  = IERC20(buyToken).balanceOf(address(this));
        uint256 tokenBought  = 0;

        {
            uint256[] memory estOut = router.getAmountsOut(arbSz, pathBuy);
            uint256 minOut = estOut[1] * (10_000 - PolygonConfig.SLIPPAGE_BPS) / 10_000;
            try router.swapExactTokensForTokens(
                arbSz, minOut, pathBuy,
                address(this), block.timestamp + PolygonConfig.SWAP_DEADLINE
            ) returns (uint256[] memory) {
                tokenBought = IERC20(buyToken).balanceOf(address(this)) - tokenBefore;
            } catch {
                // Откат: вернуть WPOL в cbFund
                cbFund += arbSz;
                emit ArbFailed(arbN, "buy failed");
                return 0;
            }
        }

        if (tokenBought == 0) {
            cbFund += arbSz;
            emit ArbFailed(arbN, "zero tokens bought");
            return 0;
        }

        // ── Шаг 2: token → WPOL (продажа, фиксация прибыли) ──────────
        uint256 wpolReceived = 0;
        {
            uint256[] memory estOut2 = router.getAmountsOut(tokenBought, pathSell);
            uint256 minWpol = estOut2[1] * (10_000 - PolygonConfig.SLIPPAGE_BPS) / 10_000;
            try router.swapExactTokensForTokens(
                tokenBought, minWpol, pathSell,
                address(this), block.timestamp + PolygonConfig.SWAP_DEADLINE
            ) returns (uint256[] memory) {
                uint256 wpolAfter = WPOL.balanceOf(address(this));
                // wpolAfter = wpolBefore - arbSz + wpolReceived
                wpolReceived = (wpolAfter + arbSz > wpolBefore)
                    ? wpolAfter + arbSz - wpolBefore : 0;
            } catch {
                // Продажа неудалась → отдаём купленный токен в Vault как LP
                IERC20(buyToken).safeTransfer(vaultAddr, tokenBought);
                vault.addToLpBuf(arbSz / 2);
                cbFund += arbSz / 2;
                emit ArbFailed(arbN, "sell failed");
                return 0;
            }
        }

        profit = wpolReceived > arbSz ? wpolReceived - arbSz : 0;
        uint256 recovered = wpolReceived > 0 ? wpolReceived : arbSz / 2;

        // ── Ценовое давление (учётное) ────────────────────────────────
        uint256 press = recovered * 6 / 100;
        if (buySide)  vault.subFromLpT(press);   // SYNC выровнялся
        else          vault.subFromLpP(press);   // SYNR выровнялся

        // ── Распределить recovered WPOL ───────────────────────────────
        _distributeProfit(recovered);

        vault.syncFromChain();

        totalProfit    += profit;
        totalReinvested += recovered * 50 / 100;

        emit ArbExecuted(arbN, arbSz, profit, buySide);
        (wpolBefore); // suppress unused
    }

    // ── Распределение арб-прибыли (50% реинвест / 50% обычное) ───────
    function _distributeProfit(uint256 an) private {
        // 50% → реинвест
        uint256 reinv = an * 50 / 100;
        {
            uint256 lp40 = reinv * 40 / 100;
            uint256 r30  = reinv * 30 / 100;
            uint256 h15  = reinv * 15 / 100;
            uint256 b5   = reinv * 5  / 100;
            uint256 rem  = reinv - lp40 - r30 - h15 - b5;

            vault.batchAddLP(lp40 * 22/100, lp40 * 13/100, lp40 * 65/100);
            WPOL.safeTransfer(vaultAddr, r30 + rem + b5);
            vault.addToReserveR(r30 + rem);
            vault.addToBuyback(b5);

            if (h15 > 0) {
                WPOL.safeTransfer(divPoolAddr, h15);
                divPool.notifyHolders(h15);
            }
        }

        // 50% → обычное
        uint256 rest = an - reinv;
        {
            uint256 r50  = rest * 50 / 100;
            uint256 tr25 = rest * 25 / 100;
            uint256 lp15 = rest * 15 / 100;
            uint256 f5   = rest * 5  / 100;
            uint256 b5   = rest - r50 - tr25 - lp15 - f5;

            vault.batchAddLP(lp15 * 25/100, lp15 * 10/100, lp15 * 65/100);
            WPOL.safeTransfer(vaultAddr, r50 + tr25 + b5);
            vault.addToReserveR(r50);
            vault.addToTraderReserve(tr25);
            vault.addToBuyback(b5);

            if (f5 > 0) {
                WPOL.safeTransfer(divPoolAddr, f5);
                divPool.notifyFounder(f5);
            }
        }
    }

    function _min3(uint256 a, uint256 b, uint256 c) private pure returns (uint256) {
        return a < b ? (a < c ? a : c) : (b < c ? b : c);
    }

    function pause()   external onlyRole(PAUSER_ROLE) { _pause(); }
    function unpause() external onlyRole(PAUSER_ROLE) { _unpause(); }
}
