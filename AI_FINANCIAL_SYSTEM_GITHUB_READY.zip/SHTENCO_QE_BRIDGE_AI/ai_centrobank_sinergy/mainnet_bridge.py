from __future__ import annotations

import json
import os
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable
from dataclasses import asdict

from .policy import evaluate

LogFn = Callable[[str], None]


def _log(log_fn: LogFn | None, message: str) -> None:
    if log_fn:
        log_fn(message)


def read_mainnet_state(root: Path, log_fn: LogFn | None = None) -> dict:
    root = Path(root)
    candidates = [
        root / "deployments" / "mainnet-state-latest.json",
        root / "deployments" / "mainnet-state-check.json",
        root / "mainnet-state-latest.json",
    ]
    for path in candidates:
        if path.exists():
            _log(log_fn, f"Loading on-chain snapshot: {path}")
            return json.loads(path.read_text(encoding="utf-8"))
    _log(log_fn, "No on-chain snapshot found; using conservative offline state")
    return {
        "network": "offline",
        "chain_id": 137,
        "pools": [],
        "wallet": {"WPOL": 50.0, "USDT": 25.0, "SYNA": 10.0, "SYNC": 10.0, "SYNR": 10.0},
        "supplies": {"SYNA": 100000.0, "SYNC": 75000.0, "SYNR": 50000.0},
        "bridge_inventory": {
            "polygon": {"SYNA": 100.0, "SYNC": 100.0, "SYNR": 100.0},
            "secondary": {"SYNA": 50.0, "SYNC": 50.0, "SYNR": 50.0},
        },
        "metrics": {},
        "cycles_executed": 0,
    }


def execute_on_mainnet(root: Path, rows: list[dict], log_fn: LogFn | None = None, before_metrics: dict | None = None) -> dict:
    """Create a reviewable AI proposal; send only through an explicit executor.

    LIVE_EXECUTION=1 is necessary but not sufficient: AI_EXECUTOR_COMMAND must
    point to a reviewed script that submits the timelocked on-chain proposal.
    """
    root = Path(root)
    deploy_dir = root / "deployments"
    deploy_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    proposal_path = deploy_dir / f"ai-centrobank-proposal-{stamp}.json"
    after_metrics = rows[-1]["metrics"] if rows else (before_metrics or {})
    decision = evaluate(before_metrics or after_metrics, after_metrics)
    payload = {
        "created_at": datetime.now(timezone.utc).isoformat(),
        "mode": "intent_proposal",
        "policy": asdict(decision),
        "cycles": rows,
        "safety": {
            "timelock_required": True,
            "guardian_cancel_required": True,
            "live_execution_default": False,
            "no_unbacked_mint": True,
            "no_wash_trading": True,
        },
    }
    proposal_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    _log(log_fn, f"Proposal written: {proposal_path}")

    if not decision.allowed:
        _log(log_fn, f"Proposal blocked by policy: {decision.reason}")
        return {"status": "BLOCKED", "proposal": str(proposal_path), "policy": asdict(decision), "transactions": []}

    live = os.getenv("LIVE_EXECUTION", "0") == "1"
    command = os.getenv("AI_EXECUTOR_COMMAND", "").strip()
    if not live:
        return {"status": "DRY_RUN", "proposal": str(proposal_path), "transactions": []}
    if not command:
        raise RuntimeError("LIVE_EXECUTION=1 requires AI_EXECUTOR_COMMAND")

    _log(log_fn, "Submitting proposal through explicit executor command")
    result = subprocess.run(
        command.split() + [str(proposal_path)],
        cwd=root,
        text=True,
        capture_output=True,
        timeout=300,
        check=False,
    )
    report = {
        "status": "SUBMITTED" if result.returncode == 0 else "FAILED",
        "proposal": str(proposal_path),
        "returncode": result.returncode,
        "stdout": result.stdout[-8000:],
        "stderr": result.stderr[-8000:],
    }
    report_path = deploy_dir / f"ai-centrobank-execution-{stamp}.json"
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    if result.returncode != 0:
        raise RuntimeError(f"Executor command failed; see {report_path}")
    return report
