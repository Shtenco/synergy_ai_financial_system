#!/usr/bin/env python3
"""
ШАГ 2: Создание пулов на QuickSwap для новых токенов
"""
import sys, io, os, json, time
from dotenv import load_dotenv
from web3 import Web3
from web3.middleware import ExtraDataToPOAMiddleware

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

load_dotenv()

w3 = Web3(Web3.HTTPProvider("https://polygon-bor-rpc.publicnode.com", request_kwargs={"timeout": 180}))
w3.middleware_onion.inject(ExtraDataToPOAMiddleware, layer=0)

PK = os.getenv("OWNER_PRIVATE_KEY")
OWNER = "0x6946999DBCE63b140B1bB9D475F7c357130909E5"
WPOL = "0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270"
ROUTER = "0xa5E0829CaCEd8fFDD4De3c43696c57F7D7A678ff"
FACTORY = "0x5757371414417b8C6CAad45bAeF941aBc7d3Ab32"

def C(a): return Web3.to_checksum_address(a)

with open("deployed_v2.json") as f:
    data = json.load(f)

tokens = data["tokens"]
SYNA = tokens["SYNA"]
SYNC = tokens["SYNC"]
SYNR = tokens["SYNR"]
ALTN = tokens["ALTN"]

print("=" * 70)
print("СОЗДАНИЕ ПУЛОВ НА QUICKSWAP")
print("=" * 70)
print(f"Баланс: {w3.eth.get_balance(C(OWNER)) / 1e18:.4f} POL")
print("=" * 70)

nonce = w3.eth.get_transaction_count(C(OWNER), "pending")

ERC20_ABI = [
    {"name": "approve", "inputs": [{"name": "spender", "type": "address"}, {"name": "amount", "type": "uint256"}], "outputs": [{"type": "bool"}], "stateMutability": "nonpayable", "type": "function"},
    {"name": "balanceOf", "inputs": [{"name": "account", "type": "address"}], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "transfer", "inputs": [{"name": "to", "type": "address"}, {"name": "amount", "type": "uint256"}], "outputs": [{"type": "bool"}], "stateMutability": "nonpayable", "type": "function"},
]

ROUTER_ABI = [
    {"name": "addLiquidityETH", "inputs": [
        {"name": "token", "type": "address"},
        {"name": "amountTokenDesired", "type": "uint256"},
        {"name": "amountTokenMin", "type": "uint256"},
        {"name": "amountETHMin", "type": "uint256"},
        {"name": "to", "type": "address"},
        {"name": "deadline", "type": "uint256"}
    ], "outputs": [
        {"type": "uint256"}, {"type": "uint256"}, {"type": "uint256"}
    ], "stateMutability": "payable", "type": "function"},
]

FACTORY_ABI = [
    {"name": "getPair", "inputs": [{"name": "tokenA", "type": "address"}, {"name": "tokenB", "type": "address"}], "outputs": [{"type": "address"}], "stateMutability": "view", "type": "function"},
    {"name": "createPair", "inputs": [{"name": "tokenA", "type": "address"}, {"name": "tokenB", "type": "address"}], "outputs": [{"type": "address"}], "stateMutability": "nonpayable", "type": "function"},
]

router = w3.eth.contract(address=C(ROUTER), abi=ROUTER_ABI)
factory = w3.eth.contract(address=C(FACTORY), abi=FACTORY_ABI)

pools_created = {}

def send_tx(func, value, label, gas=500000):
    global nonce
    print(f"\n[TX] {label}...", flush=True)

    base = w3.eth.get_block("latest").get("baseFeePerGas", int(100e9))
    prio = int(50e9)
    mf = base * 2 + prio

    try:
        tx = func.build_transaction({
            "from": C(OWNER),
            "nonce": nonce,
            "chainId": 137,
            "type": 2,
            "maxPriorityFeePerGas": prio,
            "maxFeePerGas": mf,
            "gas": gas,
            "value": value
        })

        signed = w3.eth.account.sign_transaction(tx, PK)
        tx_hash = w3.eth.send_raw_transaction(signed.raw_transaction)
        print(f"  TX: {tx_hash.hex()[:20]}...", flush=True)

        receipt = w3.eth.wait_for_transaction_receipt(tx_hash, timeout=300)
        gas_cost = receipt.gasUsed * mf / 1e18

        if receipt.status == 1:
            print(f"  [OK] gas: {gas_cost:.4f} POL", flush=True)
            nonce += 1
            return True
        else:
            print(f"  [FAIL] reverted", flush=True)
            nonce += 1
            return False
    except Exception as e:
        print(f"  [ERROR] {e}")
        return False

# Тест: простой transfer
print("\n[TEST] Тест transfer токена SYNA...")
token = w3.eth.contract(address=C(SYNA), abi=ERC20_ABI)
test_func = token.functions.transfer(C("0x0000000000000000000000000000000000000001"), 1)
try:
    base = w3.eth.get_block("latest").get("baseFeePerGas", int(100e9))
    prio = int(50e9)
    mf = base * 2 + prio
    tx = test_func.build_transaction({
        "from": C(OWNER), "nonce": nonce, "chainId": 137, "type": 2,
        "maxPriorityFeePerGas": prio, "maxFeePerGas": mf, "gas": 100000, "value": 0
    })
    signed = w3.eth.account.sign_transaction(tx, PK)
    tx_hash = w3.eth.send_raw_transaction(signed.raw_transaction)
    print(f"  TX: {tx_hash.hex()[:20]}...")
    receipt = w3.eth.wait_for_transaction_receipt(tx_hash, timeout=120)
    if receipt.status == 1:
        print("  [OK] Transfer работает!")
        nonce += 1
    else:
        print("  [FAIL] Transfer ревертится - проблема с токеном")
        nonce += 1
except Exception as e:
    print(f"  [ERROR] {e}")

# Создать пулы для каждого токена
LP_AMOUNT = int(3e18)  # 3 POL per pool
TOKEN_AMOUNT = int(100_000e18)  # 100K tokens (меньше)

for token_name, token_addr in [("SYNA", SYNA), ("SYNC", SYNC), ("SYNR", SYNR), ("ALTN", ALTN)]:
    print(f"\n{'=' * 50}")
    print(f"Создание пула {token_name}/WPOL")
    print("=" * 50)

    token = w3.eth.contract(address=C(token_addr), abi=ERC20_ABI)
    balance = token.functions.balanceOf(C(OWNER)).call()
    print(f"Баланс {token_name}: {balance / 1e18:,.0f}")

    # Add Liquidity напрямую (approve уже сделан)
    deadline = int(time.time()) + 600
    add_liq_func = router.functions.addLiquidityETH(
        C(token_addr),
        TOKEN_AMOUNT,
        0,
        0,
        C(OWNER),
        deadline
    )

    # Попробуем estimate gas
    try:
        est = w3.eth.estimate_gas({
            "from": C(OWNER),
            "to": C(ROUTER),
            "data": add_liq_func._encode_transaction_data(),
            "value": LP_AMOUNT
        })
        print(f"  Estimated gas: {est}")
    except Exception as e:
        print(f"  [WARN] Estimate failed: {e}")

    send_tx(add_liq_func, LP_AMOUNT, f"AddLiquidity {token_name}", gas=800000)
    time.sleep(3)

    # Get pair address
    pair = factory.functions.getPair(C(token_addr), C(WPOL)).call()
    if pair != "0x0000000000000000000000000000000000000000":
        pools_created[f"{token_name}_WPOL"] = pair
        print(f"  Pair: {pair}")

# Сохранить
data["pools"] = pools_created
with open("deployed_v2.json", "w") as f:
    json.dump(data, f, indent=2)

print("\n" + "=" * 70)
print("ПУЛЫ СОЗДАНЫ!")
print("=" * 70)
for name, addr in pools_created.items():
    print(f"  {name}: {addr}")
print(f"\nБаланс: {w3.eth.get_balance(C(OWNER)) / 1e18:.4f} POL")
