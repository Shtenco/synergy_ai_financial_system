// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

// ═══════════════════════════════════════════════════════════════════════════
//  SINERGY SYSTEM — 03_TroikaVault.sol
//  Центральное хранилище ликвидности | Polygon + QuickSwap V2
//
//  Хранит:
//   • Реальные LP-токены QuickSwap (SYNA/WPOL, SYNC/WPOL, SYNR/WPOL)
//   • Резервные фонды WPOL: traderReserve, reserveR, mcgFund
//   • lpBuf        — буфер WPOL → добавляется в QuickSwap при flush
//   • buybackAccum — накопленный WPOL для buyback SYNR
//
//  Виртуальные LP-балансы lpR/lpT/lpP:
//   Значение = reserveWPOL_in_pair × 2 (синхронизируется через syncFromChain)
//   Все контракты системы читают именно эти балансы для расчётов модели.
//
//  Паттерн безопасности:
//   ✓ OPERATOR_ROLE — единственный, кто меняет балансы
//   ✓ CEI (Checks → Effects → Interactions) во всех функциях
//   ✓ ReentrancyGuard на функциях с внешними вызовами
//   ✓ SafeERC20 для всех token transfers
//   ✓ try/catch при addLiquidity (сбой QuickSwap не ломает систему)
//   ✓ Emergency withdraw: таймлок 2 дня + окно 7 дней
//   ✓ Нет selfdestruct, delegatecall, tx.origin
// ═══════════════════════════════════════════════════════════════════════════

import {IERC20}        from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20}     from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {AccessControl} from "@openzeppelin/contracts/access/AccessControl.sol";
import {Pausable}      from "@openzeppelin/contracts/utils/Pausable.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {Math}          from "@openzeppelin/contracts/utils/math/Math.sol";
import "./01_PolygonConfig.sol";

// ── Custom Errors ─────────────────────────────────────────────────────────
error VT_AlreadyInitialized();
error VT_NotInitialized();
error VT_ZeroAddress();
error VT_ZeroAmount();
error VT_InsufficientWPOL(uint256 have, uint256 need);
error VT_InsufficientFreeWPOL(uint256 free, uint256 need);
error VT_AmountTooLarge(uint256 amount, uint256 max);
error VT_InvalidPool(uint8 pool);
error VT_SubUnderflow(bytes32 field);
error VT_EmergencyNotQueued(uint8 pool);
error VT_TimelockActive(uint256 unlockAt, uint256 blockTs);
error VT_TimelockExpired(uint256 expiredAt, uint256 blockTs);

// ── Интерфейсы для внутренних вызовов (file-level) ───────────────────────
interface IVaultLpBuf {
    function addToLpBuf(uint256 amount) external;
}

contract TroikaVault is AccessControl, Pausable, ReentrancyGuard {
    using SafeERC20 for IERC20;

    bytes32 public constant OPERATOR_ROLE = keccak256("OPERATOR_ROLE");
    bytes32 public constant PAUSER_ROLE   = keccak256("PAUSER_ROLE");

    // ── QuickSwap V2 (Polygon Mainnet, immutable) ──────────────────────
    IQSRouter  public immutable router;
    IQSFactory public immutable factory;
    IERC20     public immutable WPOL;

    // ── Системные токены (immutable) ──────────────────────────────────
    IERC20 public immutable SYNA;
    IERC20 public immutable SYNC;
    IERC20 public immutable SYNR;

    // ── QuickSwap LP-пары (создаются в initialize) ─────────────────────
    IQSPair public pairR;   // SYNA/WPOL
    IQSPair public pairT;   // SYNC/WPOL
    IQSPair public pairP;   // SYNR/WPOL

    // ── Виртуальные LP-балансы (WPOL-эквивалент = reserveWPOL × 2) ───
    uint256 public lpR;
    uint256 public lpT;
    uint256 public lpP;

    // ── Резервные фонды (физически WPOL на балансе контракта) ─────────
    uint256 public traderReserve;  // дозаправка caps трейдеров
    uint256 public reserveR;       // collateral резерв
    uint256 public mcgFund;        // MCap Guard фонд

    // ── Операционные буферы ───────────────────────────────────────────
    uint256 public lpBuf;          // WPOL для добавления в LP при flush
    uint256 public buybackAccum;   // WPOL для buyback SYNR

    bool    public initialized;

    // ── Лимиты ────────────────────────────────────────────────────────
    uint256 public constant MAX_SINGLE_OP   = 500_000e18; // 500k POL за операцию
    uint256 public constant MIN_LIQ_WPOL    = 1e14;       // 0.0001 WPOL мин для addLiq

    // ── MCG Recycler ────────────────────────────────────────────────────
    uint256 public constant MCG_TARGET_BPS  = 1_500;       // 15% of totalLP
    uint256 public constant MCG_MIN_RECYCLE = 1e15;        // 0.001 WPOL min

    // ── Emergency Withdraw — INSTANT (no timelock) ────────────────────
    uint256 public constant TIMELOCK_DELAY  = 0;
    uint256 public constant TIMELOCK_WINDOW = type(uint256).max;

    struct EmergencyReq {
        uint256 lpAmount;
        uint256 unlockAt;
        bool    active;
    }
    mapping(uint8 => EmergencyReq) public emergencyReqs; // 0=R, 1=T, 2=P

    // ── Events ────────────────────────────────────────────────────────
    event VaultInitialized(address pairR, address pairT, address pairP);
    event LiqAdded(uint8 indexed pool, uint256 wpolAdded, uint256 lpMinted);
    event LpBufFlushed(uint256 toR, uint256 toT, uint256 toP, bool realLiq);
    event PoolsSynced(uint256 lpR, uint256 lpT, uint256 lpP);
    event WpolTransferred(address indexed to, uint256 amount);
    event EmergencyQueued(uint8 indexed pool, uint256 lpAmount, uint256 unlockAt);
    event EmergencyExecuted(uint8 indexed pool, uint256 lpBurned);

    modifier requireInit() {
        if (!initialized) revert VT_NotInitialized();
        _;
    }

    // ── Constructor ───────────────────────────────────────────────────
    constructor(address syna_, address sync__, address synr_, address admin_) {
        if (syna_ == address(0) || sync__ == address(0) ||
            synr_ == address(0) || admin_  == address(0)) revert VT_ZeroAddress();

        router  = IQSRouter (PolygonConfig.QS_ROUTER);
        factory = IQSFactory(PolygonConfig.QS_FACTORY);
        WPOL    = IERC20(PolygonConfig.WPOL);
        SYNA   = IERC20(syna_);
        SYNC   = IERC20(sync__);
        SYNR   = IERC20(synr_);

        _grantRole(DEFAULT_ADMIN_ROLE, admin_);
        _grantRole(OPERATOR_ROLE,      admin_);
        _grantRole(PAUSER_ROLE,        admin_);
    }

    // ═══════════════════════════════════════════════════════════════════
    //  INITIALIZE — один раз из TroikaDeployer
    //  Предусловие: WPOL + токены уже на балансе этого контракта
    // ═══════════════════════════════════════════════════════════════════
    function initialize(
        uint256 wpolR_,  uint256 tokR_,
        uint256 wpolT_,  uint256 tokT_,
        uint256 wpolP_,  uint256 tokP_,
        uint256 traderRes_, uint256 reserveR_, uint256 mcgFund_
    ) external nonReentrant onlyRole(OPERATOR_ROLE) {
        if (initialized) revert VT_AlreadyInitialized();

        // Checks
        uint256 needWpol = wpolR_ + wpolT_ + wpolP_ + traderRes_ + reserveR_ + mcgFund_;
        uint256 bal = WPOL.balanceOf(address(this));
        if (bal < needWpol) revert VT_InsufficientWPOL(bal, needWpol);

        // Effects (до внешних вызовов)
        traderReserve = traderRes_;
        reserveR      = reserveR_;
        mcgFund       = mcgFund_;
        initialized   = true;

        // Interactions — approve router (max, один раз)
        WPOL.approve(address(router),  type(uint256).max);
        SYNA.approve(address(router), type(uint256).max);
        SYNC.approve(address(router), type(uint256).max);
        SYNR.approve(address(router), type(uint256).max);

        // Создать / найти QuickSwap пары
        pairR = _getOrCreatePair(address(SYNA));
        pairT = _getOrCreatePair(address(SYNC));
        pairP = _getOrCreatePair(address(SYNR));

        // Approve LP-токены для router (removeLiquidity)
        IERC20(address(pairR)).approve(address(router), type(uint256).max);
        IERC20(address(pairT)).approve(address(router), type(uint256).max);
        IERC20(address(pairP)).approve(address(router), type(uint256).max);

        // Добавить начальную ликвидность (try/catch — сбой не ломает)
        if (wpolR_ >= MIN_LIQ_WPOL && tokR_ > 0) _addLiq(address(SYNA), tokR_, wpolR_, 0);
        if (wpolT_ >= MIN_LIQ_WPOL && tokT_ > 0) _addLiq(address(SYNC), tokT_, wpolT_, 1);
        if (wpolP_ >= MIN_LIQ_WPOL && tokP_ > 0) _addLiq(address(SYNR), tokP_, wpolP_, 2);

        _syncLP();
        emit VaultInitialized(address(pairR), address(pairT), address(pairP));
    }

    // ═══════════════════════════════════════════════════════════════════
    //  SYNC — обновить lpR/lpT/lpP из реальных резервов QuickSwap
    // ═══════════════════════════════════════════════════════════════════
    function syncFromChain()
        external onlyRole(OPERATOR_ROLE) requireInit
    {
        _syncLP();
    }

    function _syncLP() private {
        lpR = _wpolValueOf(pairR);
        lpT = _wpolValueOf(pairT);
        lpP = _wpolValueOf(pairP);
        emit PoolsSynced(lpR, lpT, lpP);
    }

    function _wpolValueOf(IQSPair p) private view returns (uint256) {
        if (address(p) == address(0)) return 0;
        try p.getReserves() returns (uint112 r0, uint112 r1, uint32) {
            uint256 rWpol = (p.token0() == PolygonConfig.WPOL) ? r0 : r1;
            return rWpol * 2;
        } catch { return 0; }
    }

    // ═══════════════════════════════════════════════════════════════════
    //  LP BUF FLUSH — добавить WPOL из буфера в QuickSwap (каждые 10 блоков)
    // ═══════════════════════════════════════════════════════════════════
    function flushLpBuf()
        external nonReentrant whenNotPaused onlyRole(OPERATOR_ROLE) requireInit
    {
        uint256 buf = lpBuf;
        if (buf < MIN_LIQ_WPOL * 3) return;

        // Распределение: 55% → P, 28% → R, 17% → T (из модели)
        uint256 toP = buf * 55 / 100;
        uint256 toR = buf * 28 / 100;
        uint256 toT = buf - toP - toR;

        // Effects сначала
        lpBuf = 0;

        bool realLiq = false;
        uint256 free = _freeWpol();
        if (free >= buf) {
            // Interactions — реальное добавление в QuickSwap
            _addLiqFromWpol(address(SYNA), toR, 0);
            _addLiqFromWpol(address(SYNC), toT, 1);
            _addLiqFromWpol(address(SYNR), toP, 2);
            _syncLP();
            realLiq = true;
        } else {
            // Виртуальный учёт (WPOL не хватает — будет добавлено позже)
            lpR += toR;
            lpT += toT;
            lpP += toP;
        }
        emit LpBufFlushed(toR, toT, toP, realLiq);
    }

    // Добавить WPOL в пул, вычислив нужное кол-во токенов из reserves
    function _addLiqFromWpol(address token, uint256 wpolAmt, uint8 pool) private {
        if (wpolAmt < MIN_LIQ_WPOL) return;
        IQSPair p = pool == 0 ? pairR : (pool == 1 ? pairT : pairP);
        if (address(p) == address(0)) return;
        try p.getReserves() returns (uint112 r0, uint112 r1, uint32) {
            if (r0 == 0 || r1 == 0) return;
            (uint256 rWpol, uint256 rTok) = (p.token0() == PolygonConfig.WPOL)
                ? (uint256(r0), uint256(r1)) : (uint256(r1), uint256(r0));
            if (rWpol == 0) return;
            uint256 tokAmt = Math.mulDiv(wpolAmt, rTok, rWpol);
            if (tokAmt == 0) return;
            if (IERC20(token).balanceOf(address(this)) < tokAmt) return;
            _addLiq(token, tokAmt, wpolAmt, pool);
        } catch {}
    }

    function _addLiq(address token, uint256 tokAmt, uint256 wpolAmt, uint8 pool) private {
        uint256 minTok  = tokAmt  * (10_000 - PolygonConfig.SLIPPAGE_BPS) / 10_000;
        uint256 minWpol = wpolAmt * (10_000 - PolygonConfig.SLIPPAGE_BPS) / 10_000;
        uint256 dl = block.timestamp + PolygonConfig.SWAP_DEADLINE;
        try router.addLiquidity(
            token, PolygonConfig.WPOL,
            tokAmt, wpolAmt, minTok, minWpol,
            address(this), dl
        ) returns (uint256, uint256, uint256 lp) {
            emit LiqAdded(pool, wpolAmt, lp);
        } catch {}
    }

    function _getOrCreatePair(address token) private returns (IQSPair) {
        address p = factory.getPair(token, PolygonConfig.WPOL);
        if (p == address(0)) p = factory.createPair(token, PolygonConfig.WPOL);
        return IQSPair(p);
    }

    // ═══════════════════════════════════════════════════════════════════
    //  МУТАТОРЫ — только OPERATOR_ROLE
    //  Нет внешних вызовов → нет нужды в nonReentrant здесь
    // ═══════════════════════════════════════════════════════════════════

    function addToLpBuf(uint256 a) external onlyRole(OPERATOR_ROLE) whenNotPaused requireInit {
        if (a > MAX_SINGLE_OP) revert VT_AmountTooLarge(a, MAX_SINGLE_OP);
        lpBuf += a;
    }

    function batchAddLP(uint256 dR, uint256 dT, uint256 dP)
        external onlyRole(OPERATOR_ROLE) whenNotPaused requireInit
    {
        uint256 tot = dR + dT + dP;
        if (tot > MAX_SINGLE_OP * 3) revert VT_AmountTooLarge(tot, MAX_SINGLE_OP * 3);
        lpR += dR; lpT += dT; lpP += dP;
        emit PoolsSynced(lpR, lpT, lpP);
    }

    function addToLpP(uint256 a)   external onlyRole(OPERATOR_ROLE) whenNotPaused requireInit {
        if (a > MAX_SINGLE_OP) revert VT_AmountTooLarge(a, MAX_SINGLE_OP);
        lpP += a;
    }
    function subFromLpP(uint256 a) external onlyRole(OPERATOR_ROLE) whenNotPaused requireInit {
        if (lpP >= a) lpP -= a;
    }
    function subFromLpT(uint256 a) external onlyRole(OPERATOR_ROLE) whenNotPaused requireInit {
        if (lpT >= a) lpT -= a;
    }

    function addToTraderReserve(uint256 a)
        external onlyRole(OPERATOR_ROLE) whenNotPaused requireInit {
        traderReserve += a;
    }
    function subFromTraderReserve(uint256 a)
        external onlyRole(OPERATOR_ROLE) whenNotPaused requireInit {
        if (traderReserve < a) revert VT_SubUnderflow("traderReserve");
        traderReserve -= a;
    }

    function addToReserveR(uint256 a)
        external onlyRole(OPERATOR_ROLE) whenNotPaused requireInit {
        reserveR += a;
    }

    function addToMcgFund(uint256 a)
        external onlyRole(OPERATOR_ROLE) whenNotPaused requireInit {
        mcgFund += a;
    }
    function subFromMcgFund(uint256 a)
        external onlyRole(OPERATOR_ROLE) whenNotPaused requireInit {
        if (mcgFund < a) revert VT_SubUnderflow("mcgFund");
        mcgFund -= a;
    }

    function addToBuyback(uint256 a)
        external onlyRole(OPERATOR_ROLE) whenNotPaused requireInit {
        buybackAccum += a;
    }
    function resetBuyback()
        external onlyRole(OPERATOR_ROLE) whenNotPaused requireInit {
        buybackAccum = 0;
    }

    // ── WPOL transfer — для выплат из DividendPool ───────────────────
    function transferWpol(address to, uint256 amount)
        external nonReentrant whenNotPaused onlyRole(OPERATOR_ROLE) requireInit
    {
        // Checks
        if (to     == address(0)) revert VT_ZeroAddress();
        if (amount == 0)          revert VT_ZeroAmount();
        uint256 free = _freeWpol();
        if (amount > free) revert VT_InsufficientFreeWPOL(free, amount);
        // Interactions (CEI: нет effects — WPOL уходит)
        WPOL.safeTransfer(to, amount);
        emit WpolTransferred(to, amount);
    }

    // ═══════════════════════════════════════════════════════════════════
    //  MCG RECYCLER
    // ═══════════════════════════════════════════════════════════════════

    function mcgExcess() external view returns (uint256) {
        uint256 target = totalLP() * MCG_TARGET_BPS / 10_000;
        return mcgFund > target ? mcgFund - target : 0;
    }

    function mcgRecycle() external onlyRole(OPERATOR_ROLE) whenNotPaused requireInit {
        uint256 target = totalLP() * MCG_TARGET_BPS / 10_000;
        if (mcgFund <= target + MCG_MIN_RECYCLE) return;
        uint256 excess = mcgFund - target;
        mcgFund -= excess;
        // 50% → reserveR, 30% → lpBuf, 20% → buybackAccum
        reserveR     += excess * 50 / 100;
        lpBuf        += excess * 30 / 100;
        buybackAccum += excess * 20 / 100;
    }

    // ═══════════════════════════════════════════════════════════════════
    //  VIEW
    // ═══════════════════════════════════════════════════════════════════

    function totalLP()   public view returns (uint256) { return lpR + lpT + lpP; }
    function totalMCap() public view returns (uint256) { return (lpR + lpT + lpP) * 2; }

    function priceR() public view returns (uint256) { return _spotPrice(pairR); }
    function priceT() public view returns (uint256) { return _spotPrice(pairT); }
    function priceP() public view returns (uint256) { return _spotPrice(pairP); }

    function _spotPrice(IQSPair p) private view returns (uint256) {
        if (address(p) == address(0)) return 0;
        try p.getReserves() returns (uint112 r0, uint112 r1, uint32) {
            if (r0 == 0 || r1 == 0) return 0;
            (uint256 rWpol, uint256 rTok) = (p.token0() == PolygonConfig.WPOL)
                ? (uint256(r0), uint256(r1)) : (uint256(r1), uint256(r0));
            return rTok == 0 ? 0 : Math.mulDiv(rWpol, 1e18, rTok);
        } catch { return 0; }
    }

    function collateralRatio() external view returns (uint256) {
        uint256 mc = totalMCap();
        return mc == 0 ? 0 : Math.mulDiv(reserveR, 1e18, mc);
    }

    function _freeWpol() private view returns (uint256) {
        uint256 bal    = WPOL.balanceOf(address(this));
        uint256 locked = traderReserve + reserveR + mcgFund;
        return bal > locked ? bal - locked : 0;
    }

    function freeWpol() external view returns (uint256) { return _freeWpol(); }

    function pairPAddress() external view returns (address) { return address(pairP); }
    function pairTAddress() external view returns (address) { return address(pairT); }

    function lpTokenBal(uint8 pool) external view returns (uint256) {
        IQSPair p = pool == 0 ? pairR : (pool == 1 ? pairT : pairP);
        return address(p) != address(0) ? p.balanceOf(address(this)) : 0;
    }

    // ═══════════════════════════════════════════════════════════════════
    //  EMERGENCY WITHDRAW — Timelock 2 дня, окно 7 дней
    // ═══════════════════════════════════════════════════════════════════

    function queueEmergencyWithdraw(uint8 pool, uint256 lpAmount)
        external onlyRole(DEFAULT_ADMIN_ROLE)
    {
        if (pool > 2)     revert VT_InvalidPool(pool);
        if (lpAmount == 0) revert VT_ZeroAmount();
        emergencyReqs[pool] = EmergencyReq({
            lpAmount: lpAmount,
            unlockAt: block.timestamp + TIMELOCK_DELAY,
            active:   true
        });
        emit EmergencyQueued(pool, lpAmount, block.timestamp + TIMELOCK_DELAY);
    }

    function executeEmergencyWithdraw(uint8 pool)
        external nonReentrant onlyRole(DEFAULT_ADMIN_ROLE)
    {
        if (pool > 2) revert VT_InvalidPool(pool);
        EmergencyReq memory req = emergencyReqs[pool];
        if (!req.active)                               revert VT_EmergencyNotQueued(pool);
        if (block.timestamp < req.unlockAt)            revert VT_TimelockActive(req.unlockAt, block.timestamp);
        if (block.timestamp > req.unlockAt + TIMELOCK_WINDOW)
                                                        revert VT_TimelockExpired(req.unlockAt + TIMELOCK_WINDOW, block.timestamp);

        // Effects
        delete emergencyReqs[pool];

        // Interactions
        IQSPair pair = pool == 0 ? pairR : (pool == 1 ? pairT : pairP);
        address tok  = pool == 0 ? address(SYNA) : (pool == 1 ? address(SYNC) : address(SYNR));
        if (address(pair) == address(0)) revert VT_InvalidPool(pool);

        try router.removeLiquidity(
            tok, PolygonConfig.WPOL,
            req.lpAmount, 0, 0,
            address(this),
            block.timestamp + PolygonConfig.SWAP_DEADLINE
        ) {} catch {}

        _syncLP();
        emit EmergencyExecuted(pool, req.lpAmount);
    }

    function pause()   external onlyRole(PAUSER_ROLE) { _pause(); }
    function unpause() external onlyRole(PAUSER_ROLE) { _unpause(); }
}
