#!/usr/bin/env python3
"""Read-only scanner and optional executor for FlashLoanArbitrage.

The bot searches triangular QuickSwap V2 routes created by the TROIKA/SYNA
system. It never assumes that a flash loan is profitable. A route is eligible
only when the current router quote covers:

    principal + live Aave premium + gas reserve + requested net profit

The smart contract repeats the final profitability check atomically and reverts
on any shortfall.
"""

from __future__ import annotations

import argparse
import json
import math
import os
import sys
import time
from dataclasses import dataclass
from decimal import Decimal, getcontext
from pathlib import Path
from typing import Any, Iterable

from dotenv import load_dotenv
from web3 import Web3
from web3.contract import Contract
from web3.exceptions import ContractLogicError

getcontext().prec = 60
ROOT = Path(__file__).resolve().parent
CONFIG_PATH = ROOT / "flash_arb_config.json"
ARTIFACT_PATH = ROOT / "out_flash" / "FlashLoanArbitrage.json"
DEPLOYED_PATH = ROOT / "deployed_flash_arbitrage.json"
LOG_PATH = ROOT / "flash_arb_opportunities.jsonl"
BPS = 10_000
WAD = 10**18

ROUTER_ABI = [
    {
        "inputs": [
            {"internalType": "uint256", "name": "amountIn", "type": "uint256"},
            {"internalType": "address[]", "name": "path", "type": "address[]"},
        ],
        "name": "getAmountsOut",
        "outputs": [
            {"internalType": "uint256[]", "name": "amounts", "type": "uint256[]"}
        ],
        "stateMutability": "view",
        "type": "function",
    }
]

FACTORY_ABI = [
    {
        "inputs": [
            {"internalType": "address", "name": "tokenA", "type": "address"},
            {"internalType": "address", "name": "tokenB", "type": "address"},
        ],
        "name": "getPair",
        "outputs": [{"internalType": "address", "name": "pair", "type": "address"}],
        "stateMutability": "view",
        "type": "function",
    }
]

AAVE_POOL_ABI = [
    {
        "inputs": [],
        "name": "FLASHLOAN_PREMIUM_TOTAL",
        "outputs": [{"internalType": "uint128", "name": "", "type": "uint128"}],
        "stateMutability": "view",
        "type": "function",
    }
]


@dataclass(frozen=True)
class Candidate:
    route_names: tuple[str, ...]
    path: tuple[str, ...]
    amount_in: int
    quoted_out: int
    premium: int
    gas_reserve: int
    desired_net_profit: int
    expected_net_after_gas: int
    min_amount_out: int


def d(value: Any) -> Decimal:
    return Decimal(str(value))


def to_wad(value: Any) -> int:
    return int(d(value) * Decimal(WAD))


def from_wad(value: int) -> Decimal:
    return Decimal(value) / Decimal(WAD)


def checksum(w3: Web3, value: str) -> str:
    return w3.to_checksum_address(value)


def require_contract(w3: Web3, label: str, address: str) -> None:
    if not w3.eth.get_code(address):
        raise RuntimeError(f"{label} has no bytecode at {address}")


def geometric_amounts(minimum: int, maximum: int, samples: int) -> list[int]:
    if minimum <= 0 or maximum < minimum or samples < 1:
        raise ValueError("Invalid amount search range")
    if samples == 1 or minimum == maximum:
        return [minimum]
    lo = math.log(minimum)
    hi = math.log(maximum)
    values = {
        max(minimum, min(maximum, int(round(math.exp(lo + (hi - lo) * i / (samples - 1))))))
        for i in range(samples)
    }
    return sorted(values)


def fee_values(w3: Web3, cfg: dict[str, Any]) -> tuple[int, int, int]:
    latest = w3.eth.get_block("latest")
    base_fee = int(latest.get("baseFeePerGas", w3.eth.gas_price))
    priority = int(d(cfg["max_priority_fee_gwei"]) * Decimal(10**9))
    max_fee = int(Decimal(base_fee) * d(cfg["max_fee_multiplier"])) + priority
    expected = base_fee + priority
    return expected, max_fee, priority


def pair_exists(factory: Contract, path: Iterable[str]) -> bool:
    values = list(path)
    zero = "0x0000000000000000000000000000000000000000"
    for token_a, token_b in zip(values, values[1:]):
        pair = factory.functions.getPair(token_a, token_b).call()
        if pair.lower() == zero.lower():
            return False
    return True


def route_quote(router: Contract, amount_in: int, path: list[str]) -> int | None:
    try:
        amounts = router.functions.getAmountsOut(amount_in, path).call()
    except (ContractLogicError, ValueError, OSError):
        return None
    if not amounts or len(amounts) != len(path):
        return None
    return int(amounts[-1])


def append_log(record: dict[str, Any]) -> None:
    with LOG_PATH.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(record, ensure_ascii=False) + "\n")


def scan(
    w3: Web3,
    config: dict[str, Any],
    router: Contract,
    factory: Contract,
    premium_bps: int,
    gas_units: int,
    gas_price_wei: int,
) -> list[Candidate]:
    search_cfg = config["search"]
    token_map = {name: checksum(w3, addr) for name, addr in config["tokens"].items()}
    minimum = to_wad(search_cfg["minimum_loan_wpol"])
    maximum = to_wad(search_cfg["maximum_loan_wpol"])
    amounts = geometric_amounts(minimum, maximum, int(search_cfg["amount_samples"]))
    slippage_bps = int(search_cfg["slippage_bps"])
    desired_net = to_wad(search_cfg["minimum_net_profit_wpol"])
    gas_multiplier = d(search_cfg["gas_safety_multiplier"])
    gas_reserve = int(Decimal(gas_units * gas_price_wei) * gas_multiplier)

    candidates: list[Candidate] = []
    for route_names_raw in config["route_templates"]:
        route_names = tuple(route_names_raw)
        try:
            path = [token_map[name] for name in route_names]
        except KeyError:
            continue
        if path[0] != token_map["WPOL"] or path[-1] != token_map["WPOL"]:
            continue
        if not pair_exists(factory, path):
            continue

        for amount in amounts:
            quoted = route_quote(router, amount, path)
            if quoted is None:
                continue
            premium = (amount * premium_bps + BPS - 1) // BPS
            expected_net = quoted - amount - premium - gas_reserve
            if expected_net < desired_net:
                continue

            required_out = amount + premium + gas_reserve + desired_net
            slip_min = quoted * (BPS - slippage_bps) // BPS
            min_out = max(required_out, slip_min)
            if min_out > quoted:
                continue

            candidates.append(
                Candidate(
                    route_names=route_names,
                    path=tuple(path),
                    amount_in=amount,
                    quoted_out=quoted,
                    premium=premium,
                    gas_reserve=gas_reserve,
                    desired_net_profit=desired_net,
                    expected_net_after_gas=expected_net,
                    min_amount_out=min_out,
                )
            )

    candidates.sort(key=lambda item: item.expected_net_after_gas, reverse=True)
    return candidates


def candidate_record(candidate: Candidate, premium_bps: int, gas_units: int) -> dict[str, Any]:
    return {
        "timestamp": int(time.time()),
        "route": list(candidate.route_names),
        "amount_wpol": str(from_wad(candidate.amount_in)),
        "quoted_out_wpol": str(from_wad(candidate.quoted_out)),
        "aave_premium_bps": premium_bps,
        "aave_premium_wpol": str(from_wad(candidate.premium)),
        "gas_units": gas_units,
        "gas_reserve_wpol": str(from_wad(candidate.gas_reserve)),
        "expected_net_after_gas_wpol": str(from_wad(candidate.expected_net_after_gas)),
        "minimum_router_out_wpol": str(from_wad(candidate.min_amount_out)),
    }


def execute_candidate(
    w3: Web3,
    contract: Contract,
    account: Any,
    router_address: str,
    candidate: Candidate,
    config: dict[str, Any],
    premium_bps: int,
) -> str:
    execution_cfg = config["execution"]
    search_cfg = config["search"]
    deadline = int(time.time()) + int(execution_cfg["deadline_seconds"])
    expected_gas_price, max_fee, priority = fee_values(w3, execution_cfg)
    fallback_gas = int(search_cfg["fallback_gas_units"])
    desired_net = candidate.desired_net_profit

    def build_function(gas_units: int) -> tuple[Any, int, int]:
        gas_reserve = int(
            Decimal(gas_units * max_fee) * d(search_cfg["gas_safety_multiplier"])
        )
        min_profit_onchain = gas_reserve + desired_net
        required_out = candidate.amount_in + candidate.premium + min_profit_onchain
        slip_min = candidate.quoted_out * (BPS - int(search_cfg["slippage_bps"])) // BPS
        min_out = max(required_out, slip_min)
        step = (router_address, list(candidate.path), min_out, False)
        function = contract.functions.startArbitrage(
            candidate.path[0],
            candidate.amount_in,
            [step],
            min_profit_onchain,
            deadline,
        )
        return function, gas_reserve, min_out

    function, _, _ = build_function(fallback_gas)
    tx_probe = {"from": account.address, "value": 0}
    estimated = int(function.estimate_gas(tx_probe))
    safe_gas = max(estimated + 50_000, int(estimated * 1.20))
    function, gas_reserve, min_out = build_function(safe_gas)

    if min_out > candidate.quoted_out:
        raise RuntimeError("Opportunity disappeared after exact gas reserve calculation")

    # Full atomic preflight. This simulates the Aave callback and every swap.
    function.call({"from": account.address})

    nonce = w3.eth.get_transaction_count(account.address, "pending")
    tx = function.build_transaction(
        {
            "from": account.address,
            "nonce": nonce,
            "chainId": 137,
            "gas": safe_gas,
            "maxPriorityFeePerGas": priority,
            "maxFeePerGas": max_fee,
            "type": 2,
        }
    )
    signed = account.sign_transaction(tx)
    tx_hash = w3.eth.send_raw_transaction(signed.raw_transaction)
    receipt = w3.eth.wait_for_transaction_receipt(tx_hash, timeout=300)
    if receipt.status != 1:
        raise RuntimeError(f"Arbitrage reverted: {tx_hash.hex()}")

    append_log(
        {
            "timestamp": int(time.time()),
            "status": "executed",
            "transaction": tx_hash.hex(),
            "route": list(candidate.route_names),
            "amount_wpol": str(from_wad(candidate.amount_in)),
            "quoted_out_wpol": str(from_wad(candidate.quoted_out)),
            "premium_bps": premium_bps,
            "gas_limit": safe_gas,
            "gas_reserve_wpol": str(from_wad(gas_reserve)),
            "min_out_wpol": str(from_wad(min_out)),
            "effective_gas_price_wei": int(receipt.get("effectiveGasPrice", expected_gas_price)),
        }
    )
    return tx_hash.hex()


def load_contract_address(w3: Web3) -> str | None:
    env_address = os.getenv("FLASH_ARBITRAGE_ADDRESS")
    if env_address:
        return checksum(w3, env_address)
    if DEPLOYED_PATH.exists():
        deployed = json.loads(DEPLOYED_PATH.read_text(encoding="utf-8"))
        return checksum(w3, deployed["contract"])
    return None


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--once", action="store_true", help="scan once and exit")
    parser.add_argument("--live", action="store_true", help="allow transaction submission")
    parser.add_argument("--yes", action="store_true", help="confirm live transaction submission")
    parser.add_argument("--top", type=int, default=5, help="number of opportunities to print")
    args = parser.parse_args()

    if args.live and not args.yes:
        print("Live mode requires both --live and --yes", file=sys.stderr)
        return 2

    load_dotenv(ROOT / ".env")
    load_dotenv(ROOT / ".env.flash", override=True)
    config = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    rpc_url = os.getenv("POLYGON_RPC_URL") or os.getenv("RPC_URL")
    if not rpc_url:
        print("POLYGON_RPC_URL is required", file=sys.stderr)
        return 2

    w3 = Web3(Web3.HTTPProvider(rpc_url, request_kwargs={"timeout": 30}))
    if not w3.is_connected():
        raise RuntimeError("Cannot connect to Polygon RPC")
    if w3.eth.chain_id != int(config["network"]["chain_id"]):
        raise RuntimeError(f"Wrong chain ID: {w3.eth.chain_id}")

    addresses = config["contracts"]
    router_address = checksum(w3, addresses["quickswap_v2_router"])
    factory_address = checksum(w3, addresses["quickswap_v2_factory"])
    aave_pool_address = checksum(w3, addresses["aave_pool"])
    require_contract(w3, "QuickSwap Router", router_address)
    require_contract(w3, "QuickSwap Factory", factory_address)
    require_contract(w3, "Aave Pool", aave_pool_address)
    router = w3.eth.contract(address=router_address, abi=ROUTER_ABI)
    factory = w3.eth.contract(address=factory_address, abi=FACTORY_ABI)
    aave_pool = w3.eth.contract(address=aave_pool_address, abi=AAVE_POOL_ABI)

    artifact = json.loads(ARTIFACT_PATH.read_text(encoding="utf-8"))
    arb_address = load_contract_address(w3)
    contract = w3.eth.contract(address=arb_address, abi=artifact["abi"]) if arb_address else None

    account = None
    if args.live:
        private_key = os.getenv("BOT_PRIVATE_KEY") or os.getenv("OWNER_PRIVATE_KEY")
        if not private_key:
            raise RuntimeError("BOT_PRIVATE_KEY or OWNER_PRIVATE_KEY is required in live mode")
        account = w3.eth.account.from_key(private_key)
        if contract is None:
            raise RuntimeError("FLASH_ARBITRAGE_ADDRESS or deployed_flash_arbitrage.json is required")

    poll_seconds = int(config["search"]["poll_seconds"])
    while True:
        # Governance can change the premium; never rely on a startup constant.
        premium_bps = int(aave_pool.functions.FLASHLOAN_PREMIUM_TOTAL().call())
        _, max_fee, _ = fee_values(w3, config["execution"])
        fallback_gas = int(config["search"]["fallback_gas_units"])
        candidates = scan(
            w3,
            config,
            router,
            factory,
            premium_bps,
            fallback_gas,
            max_fee,
        )

        now = time.strftime("%Y-%m-%d %H:%M:%S")
        if not candidates:
            print(f"[{now}] No route covers premium + gas reserve + minimum profit")
        else:
            print(f"[{now}] {len(candidates)} eligible quote(s); Aave premium={premium_bps} bps")
            for candidate in candidates[: max(1, args.top)]:
                record = candidate_record(candidate, premium_bps, fallback_gas)
                print(json.dumps(record, ensure_ascii=False))
                append_log({**record, "status": "quoted"})

            if args.live and account is not None and contract is not None:
                best = candidates[0]
                try:
                    tx_hash = execute_candidate(
                        w3,
                        contract,
                        account,
                        router_address,
                        best,
                        config,
                        premium_bps,
                    )
                    print(f"EXECUTED {tx_hash}")
                except (ContractLogicError, ValueError, RuntimeError) as exc:
                    print(f"Preflight/execution rejected: {exc}", file=sys.stderr)

        if args.once:
            return 0
        time.sleep(max(1, poll_seconds))


if __name__ == "__main__":
    raise SystemExit(main())
