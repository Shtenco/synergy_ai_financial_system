#!/usr/bin/env python3
"""
РЕАЛЬНЫЙ РАСЧЁТ ПРИБЫЛЬНОГО ЦИКЛА

КЛЮЧЕВОЕ ПОНИМАНИЕ:
══════════════════════════════════════════════════════════════════════
Flash Loan даёт только WPOL. Для addLiquidity нужны ТОКЕНЫ.

РЕШЕНИЕ 1: Single-sided liquidity через Vault
─────────────────────────────────────────────
TroikaVault.deposit(wpol) может принять ТОЛЬКО WPOL и:
1. Купить токены на часть WPOL (swap)
2. Добавить liquidity

РЕШЕНИЕ 2: Использовать OWNER токены как collateral
─────────────────────────────────────────────────────
Owner имеет: 100 SYNA, 1000 SYNC, 200 SYNR
Цикл:
1. Flash Loan WPOL
2. addLiquidity (owner токены + WPOL)
3. Emission
4. removeLiquidity (получаем больше)
5. Return Flash + fee
6. PROFIT = delta tokens + delta WPOL

РЕШЕНИЕ 3 (ЛУЧШЕЕ): Прямой вызов emission + founder withdrawal
──────────────────────────────────────────────────────────────────
Не нужен Flash Loan!
1. Trigger emission (бесплатно, платим только gas)
2. Новые токены минтятся в Vault
3. 30% → Founder (WPOL)
4. Свапнуть эмитированные токены из Vault

НО: Vault токены не принадлежат owner напрямую.

РЕАЛЬНАЯ СХЕМА ПРИБЫЛИ:
═══════════════════════════════════════════════════════════════════════
"""
import sys, io, os, json
from decimal import Decimal, getcontext
from dotenv import load_dotenv
from web3 import Web3
from web3.middleware import ExtraDataToPOAMiddleware

getcontext().prec = 50

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

load_dotenv()
w3 = Web3(Web3.HTTPProvider("https://polygon-bor-rpc.publicnode.com"))
w3.middleware_onion.inject(ExtraDataToPOAMiddleware, layer=0)

def C(a): return Web3.to_checksum_address(a)

with open("deployed_TROIKA_v3.json") as f:
    d = json.load(f)

OWNER = "0x6946999DBCE63b140B1bB9D475F7c357130909E5"
WPOL = "0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270"

print("="*70)
print(" РЕАЛЬНЫЙ ПРИБЫЛЬНЫЙ ЦИКЛ - ТОЧНАЯ МАТЕМАТИКА")
print("="*70)

# ═══════════════════════════════════════════════════════════════════════════
# ТЕКУЩЕЕ СОСТОЯНИЕ
# ═══════════════════════════════════════════════════════════════════════════

TOKEN_ABI = [
    {"name": "balanceOf", "inputs": [{"type": "address"}], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "totalSupply", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
]

PAIR_ABI = [
    {"name": "getReserves", "inputs": [], "outputs": [{"type": "uint112"}, {"type": "uint112"}, {"type": "uint32"}], "stateMutability": "view", "type": "function"},
    {"name": "token0", "inputs": [], "outputs": [{"type": "address"}], "stateMutability": "view", "type": "function"},
    {"name": "totalSupply", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "balanceOf", "inputs": [{"type": "address"}], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
]

VAULT_ABI = [
    {"name": "lpR", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "lpT", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "lpP", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "totalLP", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "freeWpol", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
]

# Цены из пулов
def get_prices():
    prices = {}
    for pool_name, pool_addr in d["pools"].items():
        pair = w3.eth.contract(address=C(pool_addr), abi=PAIR_ABI)
        r0, r1, _ = pair.functions.getReserves().call()
        token0 = pair.functions.token0().call()
        token_name = pool_name.split("_")[0]

        if token0.lower() == WPOL.lower():
            wpol_r = Decimal(r0) / Decimal(10**18)
            token_r = Decimal(r1) / Decimal(10**18)
        else:
            wpol_r = Decimal(r1) / Decimal(10**18)
            token_r = Decimal(r0) / Decimal(10**18)

        prices[token_name] = wpol_r / token_r if token_r > 0 else Decimal(0)
    return prices

prices = get_prices()
print(f"\n[ЦЕНЫ ТОКЕНОВ в WPOL]")
for t, p in prices.items():
    print(f"  {t}: {p:.10f} WPOL")

# Supplies
supplies = {}
for name, addr in d["tokens"].items():
    tk = w3.eth.contract(address=C(addr), abi=TOKEN_ABI)
    supplies[name] = Decimal(tk.functions.totalSupply().call()) / Decimal(10**18)

print(f"\n[SUPPLIES]")
for t, s in supplies.items():
    print(f"  {t}: {s:.10f}")

# Owner balances
owner_pol = Decimal(w3.eth.get_balance(C(OWNER))) / Decimal(10**18)
wpol_c = w3.eth.contract(address=C(WPOL), abi=TOKEN_ABI)
owner_wpol = Decimal(wpol_c.functions.balanceOf(C(OWNER)).call()) / Decimal(10**18)

print(f"\n[OWNER BALANCES]")
print(f"  POL: {owner_pol:.10f}")
print(f"  WPOL: {owner_wpol:.10f}")

owner_tokens = {}
for name, addr in d["tokens"].items():
    tk = w3.eth.contract(address=C(addr), abi=TOKEN_ABI)
    owner_tokens[name] = Decimal(tk.functions.balanceOf(C(OWNER)).call()) / Decimal(10**18)
    print(f"  {name}: {owner_tokens[name]:.10f}")

# Vault state
vault = w3.eth.contract(address=C(d["vault"]), abi=VAULT_ABI)
vault_lp = Decimal(vault.functions.totalLP().call()) / Decimal(10**18)
vault_free_wpol = Decimal(vault.functions.freeWpol().call()) / Decimal(10**18)

print(f"\n[VAULT]")
print(f"  totalLP: {vault_lp:.10f}")
print(f"  freeWpol: {vault_free_wpol:.10f}")

# ═══════════════════════════════════════════════════════════════════════════
# ЭМИССИЯ - ИСТОЧНИК ПРИБЫЛИ
# ═══════════════════════════════════════════════════════════════════════════

print("\n" + "="*70)
print(" РАСЧЁТ ЭМИССИИ (ИСТОЧНИК НОВОЙ СТОИМОСТИ)")
print("="*70)

EMIT_RATE = Decimal("2e-6")  # из контракта (2e12 / 1e18)

# em = S × emitRate × 100
em = {}
for t, s in supplies.items():
    em[t] = s * EMIT_RATE * 100

print(f"\n[ЭМИССИЯ ЗА ОДИН ЦИКЛ]")
total_emission_wpol = Decimal(0)
for t, e in em.items():
    value_wpol = e * prices[t]
    total_emission_wpol += value_wpol
    print(f"  {t}: {e:.10f} токенов = {value_wpol:.10f} WPOL")

print(f"\n  TOTAL EMISSION VALUE: {total_emission_wpol:.10f} WPOL")

# Распределение эмиссии
founder_share = total_emission_wpol * Decimal("0.30")  # 30% founder
lp_share = total_emission_wpol * Decimal("0.62")  # 62% LP
reserve_share = total_emission_wpol * Decimal("0.08")  # 8% reserve

print(f"\n[РАСПРЕДЕЛЕНИЕ]")
print(f"  Founder (30%): {founder_share:.10f} WPOL")
print(f"  LP providers (62%): {lp_share:.10f} WPOL")
print(f"  Reserve (8%): {reserve_share:.10f} WPOL")

# ═══════════════════════════════════════════════════════════════════════════
# РЕАЛЬНЫЙ ПРИБЫЛЬНЫЙ ЦИКЛ
# ═══════════════════════════════════════════════════════════════════════════

print("\n" + "="*70)
print(" РЕАЛЬНЫЙ ПРИБЫЛЬНЫЙ ЦИКЛ")
print("="*70)

print("""
СХЕМА ЦИКЛА (С ИСПОЛЬЗОВАНИЕМ OWNER ТОКЕНОВ):
══════════════════════════════════════════════════════════════════════

[СТАРТ]
  Owner: 100 SYNA, 1000 SYNC, 200 SYNR, 5 POL, 5 WPOL
  Vault: LP tokens, 3 WPOL

[ШАГ 1] Flash Loan 100 WPOL из Aave
  └── Aave fee: 0.05 WPOL

[ШАГ 2] Добавить ликвидность в пулы
  Используем OWNER токены + Flash WPOL:
  - SYNA_WPOL: 33.3 WPOL + 22.2 SYNA
  - SYNC_WPOL: 33.3 WPOL + 211 SYNC
  - SYNR_WPOL: 33.3 WPOL + 44.4 SYNR
  └── Получаем LP tokens

[ШАГ 3] Trigger Emission (50 blocks = 100 sec later)
  EmissionEngine.executeEmission():
  - MINT: +0.02 SYNA, +0.2 SYNC, +0.04 SYNR
  - VALUE: ~0.06 WPOL новых активов

[ШАГ 4] Remove Liquidity
  Получаем назад:
  - WPOL: 100 + доля от emission
  - Tokens: исходные + доля от emission

[ШАГ 5] Swap излишек токенов → WPOL
  QuickSwap fee: 0.3%

[ШАГ 6] Return Flash Loan
  Return: 100 + 0.05 = 100.05 WPOL

[PROFIT]
  = (emission_value × our_LP_share) - flash_fee - gas
""")

# Расчёт для конкретного Flash Loan
flash = Decimal(100)
aave_fee = flash * Decimal("0.0005")
gas_cost = Decimal("0.15")

# Наша доля LP после добавления
# Текущий total LP = 18, добавляем ~18 LP → наша доля = 50%
current_lp = Decimal(18)
# При добавлении 100 WPOL в пулы (3 WPOL в каждом сейчас)
# Пропорционально: 100/9 = 11x текущего LP
# Новый total = 18 + 18*11 = ~216

added_lp_value_wpol = flash  # добавляем 100 WPOL в ликвидность
current_tvl = Decimal(18)  # 9 WPOL × 2 (AMM)
new_tvl = current_tvl + added_lp_value_wpol * 2

our_lp_share = added_lp_value_wpol * 2 / new_tvl

print(f"\n[РАСЧЁТ ДЛЯ FLASH {flash} WPOL]")
print(f"  Текущий TVL: {current_tvl} WPOL")
print(f"  После add: {new_tvl} WPOL")
print(f"  Наша доля LP: {our_lp_share*100:.2f}%")

# Эмиссия создаёт новую стоимость
emission_value = total_emission_wpol
our_emission_share = emission_value * lp_share / Decimal(100) * 100  # 62% идёт в LP

# Но LP share зависит от нашей доли!
our_profit_from_emission = our_emission_share * our_lp_share

print(f"\n  Emission value: {emission_value:.10f} WPOL")
print(f"  LP share (62%): {lp_share:.10f} WPOL")
print(f"  Our share of LP: {our_profit_from_emission:.10f} WPOL")

gross_profit = our_profit_from_emission - aave_fee
net_profit = gross_profit - gas_cost

print(f"\n[ПРИБЫЛЬ]")
print(f"  Gross: {gross_profit:.10f} WPOL")
print(f"  - Aave fee: {aave_fee:.10f}")
print(f"  - Gas: {gas_cost:.10f}")
print(f"  NET PROFIT: {net_profit:.10f} WPOL")

# ═══════════════════════════════════════════════════════════════════════════
# ОПТИМАЛЬНАЯ СТРАТЕГИЯ
# ═══════════════════════════════════════════════════════════════════════════

print("\n" + "="*70)
print(" ОПТИМАЛЬНАЯ СТРАТЕГИЯ")
print("="*70)

print("""
ПРОБЛЕМА: Одна эмиссия даёт ~0.06 WPOL.
          Aave fee 100 WPOL = 0.05 WPOL.
          При большом Flash Loan наша доля emission падает.

РЕШЕНИЕ: MULTI-EMISSION COMPOUND CYCLE
═══════════════════════════════════════════════════════════════════════

[1] Используем ТОЛЬКО owner POL (без Flash Loan)
    - Оборачиваем 5 WPOL
    - addLiquidity с owner токенами

[2] Ждём 50 blocks, trigger emission
    - Получаем долю emission

[3] Repeat N раз
    - Каждая эмиссия добавляет новые токены
    - NAV растёт

[4] После N эмиссий: removeLiquidity
    - Получаем БОЛЬШЕ токенов чем вложили

[5] Swap excess → WPOL

PROFIT = N × emission_per_cycle × our_share - total_gas
""")

# Расчёт multi-emission
n_cycles = 10
gas_per_emission = Decimal("0.15")
total_gas = n_cycles * gas_per_emission

# При использовании только owner средств (без flash)
owner_wpol_available = owner_wpol + owner_pol  # ~10.5 WPOL
owner_lp_share = owner_wpol_available / (current_tvl / 2 + owner_wpol_available)

multi_profit = n_cycles * emission_value * Decimal("0.62") * owner_lp_share - total_gas

print(f"\n[MULTI-EMISSION РАСЧЁТ (N={n_cycles})]")
print(f"  Owner WPOL: {owner_wpol_available:.6f}")
print(f"  Owner LP share: {owner_lp_share*100:.2f}%")
print(f"  Emission per cycle: {emission_value:.10f} WPOL")
print(f"  LP share (62%): {emission_value * Decimal('0.62'):.10f} WPOL")
print(f"  Our share per cycle: {emission_value * Decimal('0.62') * owner_lp_share:.10f} WPOL")
print(f"  Total {n_cycles} cycles: {n_cycles * emission_value * Decimal('0.62') * owner_lp_share:.10f} WPOL")
print(f"  Total gas: {total_gas:.10f} WPOL")
print(f"  NET PROFIT: {multi_profit:.10f} WPOL")

# ═══════════════════════════════════════════════════════════════════════════
# НАСТОЯЩИЙ ПУТЬ К ПРИБЫЛИ
# ═══════════════════════════════════════════════════════════════════════════

print("\n" + "="*70)
print(" НАСТОЯЩИЙ ПУТЬ К ПРИБЫЛИ")
print("="*70)

print("""
ТЕКУЩАЯ ПРОБЛЕМА:
─────────────────
- Emission value: ~0.06 WPOL per cycle
- Gas cost: ~0.15 WPOL per cycle
- УБЫТОК на каждом цикле!

РЕШЕНИЕ: УВЕЛИЧИТЬ EMISSION VALUE
═══════════════════════════════════════════════════════════════════════

Способ 1: Увеличить emitRate
────────────────────────────
Текущий: EMIT_RATE = 2e-6 (минимум)
Максимум: EMIT_RATE = 50e-6 (25x больше)

При emitRate = 50e-6:
  emission_value = 0.06 × 25 = 1.5 WPOL per cycle
  PROFIT = 1.5 - 0.15 = 1.35 WPOL per cycle!

Способ 2: Увеличить Supply
─────────────────────────
Текущий supply ~102 SYNA + 1019 SYNC + 204 SYNR
Если supply ×10:
  emission_value = 0.06 × 10 = 0.6 WPOL
  PROFIT = 0.6 - 0.15 = 0.45 WPOL per cycle

Способ 3: Увеличить цены токенов (через LP)
──────────────────────────────────────────
Добавить больше WPOL в пулы → цена токенов растёт
→ emission_value растёт
""")

# Расчёт при увеличенном emitRate
max_emit_rate = Decimal("50e-6")
max_em = {}
max_total_emission_wpol = Decimal(0)
for t, s in supplies.items():
    max_em[t] = s * max_emit_rate * 100
    value_wpol = max_em[t] * prices[t]
    max_total_emission_wpol += value_wpol

print(f"\n[ПРИ EMIT_RATE = 50e-6 (МАКСИМУМ)]")
print(f"  Emission value: {max_total_emission_wpol:.10f} WPOL")
print(f"  Gas: {gas_per_emission:.10f} WPOL")
print(f"  PROFIT per cycle: {max_total_emission_wpol * Decimal('0.62') - gas_per_emission:.10f} WPOL")

print("\n" + "="*70)
print(" ИТОГ: КЛЮЧЕВЫЕ МЕТРИКИ ДЛЯ ПРИБЫЛЬНОСТИ")
print("="*70)

break_even_emission = gas_per_emission / Decimal("0.62")
required_supply_multiplier = break_even_emission / total_emission_wpol

print(f"""
ТЕКУЩЕЕ СОСТОЯНИЕ:
  Emission value:    {total_emission_wpol:.10f} WPOL
  LP share (62%):    {total_emission_wpol * Decimal('0.62'):.10f} WPOL
  Gas cost:          {gas_per_emission:.10f} WPOL
  УБЫТОК per cycle: -{(gas_per_emission - total_emission_wpol * Decimal('0.62')):.10f} WPOL

ТОЧКА БЕЗУБЫТОЧНОСТИ:
  Нужен emission >= {break_even_emission:.10f} WPOL
  Или supply × {required_supply_multiplier:.1f}
  Или emitRate × {required_supply_multiplier:.1f}

РЕКОМЕНДАЦИЯ:
  1. Увеличить emitRate до 10e-6 (×5)
  2. Или увеличить TVL пулов до 50 WPOL
  3. Или объединить несколько эмиссий в один Flash Loan cycle
""")
