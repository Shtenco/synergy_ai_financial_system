const fs = require("fs");
const path = require("path");
const { ethers } = require("hardhat");

function envAddress(name, fallback) {
  const value = (process.env[name] || "").trim();
  return value ? ethers.getAddress(value) : fallback;
}

async function grantIfDifferent(contract, role, address, bootstrap) {
  if (address.toLowerCase() !== bootstrap.toLowerCase()) {
    await (await contract.grantRole(role, address)).wait();
  }
}

async function main() {
  const [deployer] = await ethers.getSigners();
  if (!deployer) throw new Error("No deployer signer configured");
  const bootstrap = deployer.address;
  const admin = envAddress("ADMIN_ADDRESS", bootstrap);
  const aiProposer = envAddress("AI_PROPOSER_ADDRESS", bootstrap);
  const executor = envAddress("EXECUTOR_ADDRESS", bootstrap);
  const guardian = envAddress("GUARDIAN_ADDRESS", bootstrap);

  const Reserve = await ethers.getContractFactory("SHTENCOBridgeQEReserve");
  const reserve = await Reserve.deploy(bootstrap);
  await reserve.waitForDeployment();

  const MM = await ethers.getContractFactory("SHTENCOMarketMaker");
  const marketMaker = await MM.deploy(bootstrap, await reserve.getAddress());
  await marketMaker.waitForDeployment();

  const Adapter = await ethers.getContractFactory("SHTENCOBridgeQEAdapter");
  const bridgeAdapter = await Adapter.deploy(bootstrap, await reserve.getAddress());
  await bridgeAdapter.waitForDeployment();

  const CentralBank = await ethers.getContractFactory("SHTENCOAICentralBank");
  const centralBank = await CentralBank.deploy(bootstrap, aiProposer, executor, guardian);
  await centralBank.waitForDeployment();

  const cbAddress = await centralBank.getAddress();
  const reserveAddress = await reserve.getAddress();
  const mmAddress = await marketMaker.getAddress();
  const adapterAddress = await bridgeAdapter.getAddress();

  await (await reserve.grantRole(await reserve.CONTROLLER_ROLE(), cbAddress)).wait();
  await (await marketMaker.grantRole(await marketMaker.CONTROLLER_ROLE(), cbAddress)).wait();
  await (await bridgeAdapter.grantRole(await bridgeAdapter.CONTROLLER_ROLE(), cbAddress)).wait();
  await (await reserve.setRecipient(mmAddress, true)).wait();
  await (await reserve.setRecipient(adapterAddress, true)).wait();

  const policies = [
    [reserve, "allocate", false],
    [marketMaker, "executeSwap", true],
    [marketMaker, "addLiquidity", true],
    [marketMaker, "executeBuybackAndBurn", true],
    [marketMaker, "transferInventory", false],
    [bridgeAdapter, "executeRebalance", true],
    [bridgeAdapter, "returnInventory", false],
  ];
  for (const [target, fn, budgetRequired] of policies) {
    const targetAddress = await target.getAddress();
    const selector = target.interface.getFunction(fn).selector;
    await (await centralBank.setTarget(targetAddress, true)).wait();
    await (await centralBank.setSelector(targetAddress, selector, true)).wait();
    if (budgetRequired) {
      await (await centralBank.setSelectorBudgetRequired(targetAddress, selector, true)).wait();
    }
  }

  for (const contract of [reserve, marketMaker, bridgeAdapter, centralBank]) {
    await grantIfDifferent(contract, await contract.DEFAULT_ADMIN_ROLE(), admin, bootstrap);
    if (contract.POLICY_ROLE) {
      await grantIfDifferent(contract, await contract.POLICY_ROLE(), admin, bootstrap);
    }
  }
  await grantIfDifferent(reserve, await reserve.GUARDIAN_ROLE(), guardian, bootstrap);
  await grantIfDifferent(marketMaker, await marketMaker.GUARDIAN_ROLE(), guardian, bootstrap);
  await grantIfDifferent(bridgeAdapter, await bridgeAdapter.GUARDIAN_ROLE(), guardian, bootstrap);
  await grantIfDifferent(centralBank, await centralBank.GUARDIAN_ROLE(), guardian, bootstrap);

  const output = {
    chainId: (await ethers.provider.getNetwork()).chainId.toString(),
    reserve: reserveAddress,
    marketMaker: mmAddress,
    bridgeQEAdapter: adapterAddress,
    aiCentralBank: cbAddress,
    bootstrapDeployer: bootstrap,
    admin,
    aiProposer,
    executor,
    guardian,
    liveTradingConfigured: false,
    safety: {
      timelock: true,
      guardianCancel: true,
      selectorAllowlist: true,
      selectorBudgetRequirements: true,
      reserveBackedOnly: true,
    },
    nextSteps: [
      "configure reserve token policies and fund reserve",
      "configure approved market-maker routers/tokens/oracle and burnable token list",
      "configure bridge adapter routes and recipients",
      "configure central-bank daily budgets for every spend token",
      "transfer or renounce bootstrap roles only after multisig/timelock verification",
    ],
  };
  const outDir = path.join(__dirname, "..", "deployments");
  fs.mkdirSync(outDir, { recursive: true });
  const outPath = path.join(outDir, `ai-central-bank-stack-${output.chainId}.json`);
  fs.writeFileSync(outPath, JSON.stringify(output, null, 2));
  console.log(JSON.stringify(output, null, 2));
}

main().catch(error => { console.error(error); process.exitCode = 1; });
