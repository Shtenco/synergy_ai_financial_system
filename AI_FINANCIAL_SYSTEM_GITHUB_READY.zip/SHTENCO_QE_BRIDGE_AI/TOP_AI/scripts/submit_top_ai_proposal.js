const fs = require("fs");
const path = require("path");
const { ethers } = require("hardhat");
async function main() {
  const file = path.resolve(process.env.PROPOSAL_PAYLOAD || "../../../deployments/top-ai-proposal-payload.json");
  const payload = JSON.parse(fs.readFileSync(file, "utf8"));
  const controller = await ethers.getContractAt("SHTENCOTopAIController", payload.controller);
  const tx = await controller.propose(payload.actions, payload.request);
  const receipt = await tx.wait();
  const event = receipt.logs.map(log => { try { return controller.interface.parseLog(log); } catch { return null; } })
    .find(x => x && x.name === "ProposalCreated");
  console.log("tx:", receipt.hash);
  console.log("proposalId:", event ? event.args.proposalId : "not parsed");
}
main().catch(e => { console.error(e); process.exitCode = 1; });
