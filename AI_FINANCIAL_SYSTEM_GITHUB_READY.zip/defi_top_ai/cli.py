from __future__ import annotations

import argparse
import json
from dataclasses import asdict
from pathlib import Path

from .models import ModelPolicy, SystemState
from .optimizer import build_report, optimize


def default_state() -> SystemState:
    return SystemState(
        liquid_reserves=1_500.0,
        liabilities=1_000.0,
        owned_liquidity_nav=600.0,
        bridge_capital=300.0,
        insurance_fund=80.0,
        circulating_supply=1_000_000.0,
        market_price=0.0015,
        liquidity_depth=800.0,
        monthly_volume=3_000.0,
        protocol_fee_revenue_30d=18.0,
        flash_profit_30d=8.0,
        yield_revenue_30d=5.0,
        bridge_fee_revenue_30d=3.0,
        operating_cost_30d=7.0,
        gas_cost_30d=4.0,
        volatility_bps=1_800.0,
        peg_error_bps=250.0,
        bridge_imbalance_bps=800.0,
    )


def load_state(path: str | None) -> SystemState:
    if not path:
        return default_state()
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    if "state" in data:
        data = data["state"]
    return SystemState(**data)


def main() -> None:
    parser = argparse.ArgumentParser(description="SHTENCO DeFi TOP AI econometric optimizer")
    parser.add_argument("--state", help="JSON state file")
    parser.add_argument("--scenarios", type=int, default=500)
    parser.add_argument("--months", type=int, default=6)
    parser.add_argument("--seed", type=int, default=137)
    parser.add_argument("--output", default="deployments/defi-top-ai-decision.json")
    args = parser.parse_args()

    state = load_state(args.state)
    policy = ModelPolicy()
    best, ranked = optimize(state, policy, max(50, args.scenarios), max(1, args.months), args.seed)
    report = build_report(state, best, ranked, policy)
    report["input_source"] = str(Path(args.state).resolve()) if args.state else "built-in demonstration state (not live mainnet data)"
    report["calibration_warning"] = (
        "Illustrative output until state inputs are populated from verified on-chain balances, "
        "oracle prices, liabilities, realized revenue, gas, bridge finality and security-loss assumptions."
    )
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report["best"], ensure_ascii=False, indent=2))
    print(f"\nSaved: {output.resolve()}")


if __name__ == "__main__":
    main()
