#!/usr/bin/env python3
"""
СИМУЛЯЦИЯ 100% ПРИБЫЛЬНОГО FLASH LOAN ЦИКЛА
С точной механикой контрактов TROIKA v3
"""
import sys, io, os, json
from dotenv import load_dotenv
from web3 import Web3
from web3.middleware import ExtraDataToPOAMiddleware

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

load_dotenv()

w3 = Web3(Web3.HTTPProvider("https://polygon-bor-rpc.publicnode.com"))
w3.middleware_onion.inject(ExtraDataToPOAMiddleware, layer=0)

OWNER = "0x6946999DBCE63b140B1bB9D475F7c357130909E5"
WPOL = "0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270"
AAVE_POOL = "0x794a61358D6845594F94dc1DB02A252b5b4814aD"

def C(a): return Web3.to_checksum_address(a)

with open("deployed_TROIKA_v3.json") as f:
    d = json.load(f)

print("=" * 70)
print("СИМУЛЯЦИЯ 100% ПРИБЫЛЬНОГО FLASH LOAN ЦИКЛА")
print("СИСТЕМА TROIKA v3")
print("=" * 70)

# Загрузить данные пулов
PAIR_ABI = [
    {"name": "getReserves", "inputs": [], "outputs": [{"type": "uint112"},{"type": "uint112"},{"type": "uint32"}], "stateMutability": "view", "type": "function"},
    {"name": "token0", "inputs": [], "outputs": [{"type": "address"}], "stateMutability": "view", "type": "function"},
    {"name": "totalSupply", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
]

TOKEN_ABI = [
    {"name": "totalSupply", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "balanceOf", "inputs": [{"type": "address"}], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
]

pools = {}
for name, addr in d["pools"].items():
    pair = w3.eth.contract(address=C(addr), abi=PAIR_ABI)
    r0, r1, _ = pair.functions.getReserves().call()
    t0 = pair.functions.token0().call()
    lp_total = pair.functions.totalSupply().call()

    if t0.lower() == WPOL.lower():
        wpol_r, tok_r = r0, r1
    else:
        wpol_r, tok_r = r1, r0

    pools[name] = {"wpol": wpol_r, "token": tok_r, "lp_total": lp_total, "addr": addr}

print("\nТЕКУЩЕЕ СОСТОЯНИЕ ПУЛОВ:")
for name, p in pools.items():
    print(f"  {name}: {p['wpol']/1e18:.4f} WPOL / {p['token']/1e18:.2f} tokens")
    print(f"    LP total: {p['lp_total']/1e18:.6f}")

# Токены supply
tokens_supply = {}
for name, addr in d["tokens"].items():
    tk = w3.eth.contract(address=C(addr), abi=TOKEN_ABI)
    supply = tk.functions.totalSupply().call()
    tokens_supply[name] = supply
    print(f"  {name} supply: {supply/1e18:,.0f}")

# ═══════════════════════════════════════════════════════════════════════════
# МЕХАНИКА ПРИБЫЛЬНОГО ЦИКЛА
# ═══════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 70)
print("МЕХАНИКА 100% ПРИБЫЛЬНОГО ЦИКЛА")
print("=" * 70)

print("""
┌─────────────────────────────────────────────────────────────────────┐
│  ИСТОЧНИК ПРИБЫЛИ: EmissionEngine создаёт НОВЫЕ токены              │
│                                                                      │
│  EmissionEngine.executeEmission() минтит:                            │
│    emR = totalSupply(SYNA) × EMIT_RATE × 100 / 1e18                 │
│    emT = totalSupply(SYNC) × EMIT_RATE × 100 / 1e18                 │
│    emP = totalSupply(SYNR) × EMIT_RATE × 100 / 1e18                 │
│                                                                      │
│  EMIT_RATE = 2e12 (2e-6 в 1e18 масштабе)                            │
│  EMIT_INTERVAL = 1000 блоков (~33 минуты)                           │
│                                                                      │
│  30% эмиссии → Founder (через DividendPool)                         │
│  70% → LP провайдерам                                                │
└─────────────────────────────────────────────────────────────────────┘
""")

# Расчёт эмиссии
EMIT_RATE = 2e12  # 2e-6 scaled by 1e18
FOUNDER_BPS = 3000  # 30%

print("\nРАСЧЁТ ЭМИССИИ ЗА 1 TICK:")

em_syna = tokens_supply["SYNA"] * EMIT_RATE * 100 / 1e18
em_sync = tokens_supply["SYNC"] * EMIT_RATE * 100 / 1e18
em_synr = tokens_supply["SYNR"] * EMIT_RATE * 100 / 1e18

print(f"  SYNA supply: {tokens_supply['SYNA']/1e18:,.0f}")
print(f"    Emission: {em_syna/1e18:.4f} SYNA")
print(f"  SYNC supply: {tokens_supply['SYNC']/1e18:,.0f}")
print(f"    Emission: {em_sync/1e18:.4f} SYNC")
print(f"  SYNR supply: {tokens_supply['SYNR']/1e18:,.0f}")
print(f"    Emission: {em_synr/1e18:.4f} SYNR")

# Цены токенов
price_syna = pools["SYNA_WPOL"]["wpol"] / pools["SYNA_WPOL"]["token"] if pools["SYNA_WPOL"]["token"] > 0 else 0
price_sync = pools["SYNC_WPOL"]["wpol"] / pools["SYNC_WPOL"]["token"] if pools["SYNC_WPOL"]["token"] > 0 else 0
price_synr = pools["SYNR_WPOL"]["wpol"] / pools["SYNR_WPOL"]["token"] if pools["SYNR_WPOL"]["token"] > 0 else 0

print(f"\nЦЕНЫ ТОКЕНОВ:")
print(f"  SYNA: {price_syna:.4f} POL")
print(f"  SYNC: {price_sync:.4f} POL")
print(f"  SYNR: {price_synr:.4f} POL")

# Стоимость эмиссии в POL
em_value_syna = em_syna * price_syna / 1e18
em_value_sync = em_sync * price_sync / 1e18
em_value_synr = em_synr * price_synr / 1e18
total_emission_value = em_value_syna + em_value_sync + em_value_synr

print(f"\nСТОИМОСТЬ ЭМИССИИ:")
print(f"  SYNA: {em_value_syna:.4f} POL")
print(f"  SYNC: {em_value_sync:.4f} POL")
print(f"  SYNR: {em_value_synr:.4f} POL")
print(f"  ВСЕГО: {total_emission_value:.4f} POL")

# ═══════════════════════════════════════════════════════════════════════════
# СИМУЛЯЦИЯ FLASH LOAN
# ═══════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 70)
print("СИМУЛЯЦИЯ FLASH LOAN ЦИКЛА")
print("=" * 70)

LOAN_AMOUNT = 100  # POL
AAVE_FEE_BPS = 5  # 0.05%
SWAP_FEE_BPS = 30  # 0.3%

print(f"\n[STEP 1] Flash Loan {LOAN_AMOUNT} POL из Aave")
aave_fee = LOAN_AMOUNT * AAVE_FEE_BPS / 10000
print(f"  Aave fee: {aave_fee:.4f} POL")
available = LOAN_AMOUNT

print(f"\n[STEP 2] Add LP во все 3 пула")
per_pool = available / 3
print(f"  Per pool: {per_pool:.4f} POL")

# Расчёт доли LP после добавления
lp_shares = {}
for name, p in pools.items():
    current_wpol = p["wpol"] / 1e18
    new_wpol = current_wpol + per_pool
    our_share = per_pool / new_wpol * 100
    lp_shares[name] = our_share
    print(f"  {name}: добавляем {per_pool:.4f} POL -> наша доля {our_share:.2f}%")

print(f"\n[STEP 3] Вызов TroikaCore.tick()")
print("  tick() запускает:")
print("    - EmissionEngine.executeEmission() -> минтит новые токены")
print("    - DividendPool.executeHoldersPayout() -> начисляет дивиденды")
print("    - Vault.flushLpBuf() -> добавляет из буфера")
print("    - CBArbitrage (если gap > 1%)")

print(f"\n[STEP 4] Получаем эмиссию")
# Как founder получаем 30%
founder_share = total_emission_value * FOUNDER_BPS / 10000
# Как LP получаем ~99% от 70% (мы мажоритарный LP)
avg_lp_share = sum(lp_shares.values()) / len(lp_shares) / 100
lp_share = total_emission_value * (10000 - FOUNDER_BPS) / 10000 * avg_lp_share

total_received = founder_share + lp_share
print(f"  Founder share (30%): {founder_share:.4f} POL")
print(f"  LP share ({avg_lp_share*100:.1f}% от 70%): {lp_share:.4f} POL")
print(f"  ВСЕГО получено: {total_received:.4f} POL")

print(f"\n[STEP 5] Remove LP")
# При remove LP получаем обратно наши POL + комиссии за торговлю
# Но пока торговли нет, получаем примерно то что вложили
remove_amount = available  # упрощённо
print(f"  Возвращаем: ~{remove_amount:.4f} POL")

print(f"\n[STEP 6] Sell полученные токены")
# Токены от эмиссии можно продать
sell_slippage = 0.5  # 0.5% slippage
tokens_value_after_sell = total_received * (1 - sell_slippage/100)
print(f"  После продажи токенов: {tokens_value_after_sell:.4f} POL")

print(f"\n[STEP 7] Repay Flash Loan")
repay_amount = LOAN_AMOUNT + aave_fee
print(f"  Возврат: {repay_amount:.4f} POL")

# ═══════════════════════════════════════════════════════════════════════════
# ИТОГОВЫЙ РАСЧЁТ
# ═══════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 70)
print("ИТОГОВЫЙ РАСЧЁТ")
print("=" * 70)

final_balance = remove_amount + tokens_value_after_sell
profit = final_balance - repay_amount

print(f"  Получено из LP: {remove_amount:.4f} POL")
print(f"  Продажа токенов: {tokens_value_after_sell:.4f} POL")
print(f"  ВСЕГО: {final_balance:.4f} POL")
print(f"  Возврат Aave: {repay_amount:.4f} POL")
print(f"  ─────────────────────────────────")
print(f"  PROFIT: {profit:.4f} POL")

if profit > 0:
    print(f"\n  ✅ ЦИКЛ ПРИБЫЛЬНЫЙ: +{profit:.4f} POL ({profit/LOAN_AMOUNT*100:.2f}%)")
else:
    print(f"\n  ❌ ЦИКЛ УБЫТОЧНЫЙ: {profit:.4f} POL")

# ═══════════════════════════════════════════════════════════════════════════
# УСЛОВИЯ ПРИБЫЛЬНОСТИ
# ═══════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 70)
print("УСЛОВИЯ 100% ПРИБЫЛЬНОСТИ")
print("=" * 70)

print("""
┌─────────────────────────────────────────────────────────────────────┐
│  1. EmissionEngine.isEmissionDue() == true                          │
│     (прошло 1000+ блоков с последней эмиссии)                       │
│                                                                      │
│  2. Мы = Founder (получаем 30% эмиссии напрямую)                    │
│                                                                      │
│  3. Мы = мажоритарный LP (получаем ~99% от 70% эмиссии)             │
│                                                                      │
│  4. Supply токенов достаточно большой для существенной эмиссии      │
│     (сейчас: SYNA=10M, SYNC=100M, SYNR=21M)                         │
│                                                                      │
│  5. Цены токенов > 0 (есть ликвидность для продажи)                 │
│                                                                      │
│  ФОРМУЛА ПРИБЫЛИ:                                                    │
│  Profit = (EmissionValue × 99.16%) - AaveFee - GasCost              │
│                                                                      │
│  При текущих параметрах:                                             │
│  Profit ≈ {:.4f} POL за цикл                                        │
└─────────────────────────────────────────────────────────────────────┘
""".format(profit))

# Проверить isEmissionDue
with open("out/07_EmissionEngine.sol/EmissionEngine.json", encoding="utf-8") as f:
    emit_abi = json.load(f)["abi"]

emit = w3.eth.contract(address=C(d["emitEngine"]), abi=emit_abi)
is_due = emit.functions.isEmissionDue().call()
last_block = emit.functions.lastEmitBlock().call()
current_block = w3.eth.block_number

print(f"\nСТАТУС EMISSION ENGINE:")
print(f"  isEmissionDue: {is_due}")
print(f"  lastEmitBlock: {last_block}")
print(f"  currentBlock: {current_block}")
print(f"  blocks since: {current_block - last_block}")
print(f"  EMIT_INTERVAL: 1000")

if is_due:
    print(f"\n  ✅ ЭМИССИЯ ГОТОВА! Можно запускать прибыльный цикл.")
else:
    blocks_to_wait = 1000 - (current_block - last_block)
    time_to_wait = blocks_to_wait * 2  # ~2 сек на блок
    print(f"\n  ⏳ Ждать ещё {blocks_to_wait} блоков (~{time_to_wait//60} мин)")
