#!/usr/bin/env python3
import sys, io, json, os, time
from dotenv import load_dotenv
from web3 import Web3
from web3.middleware import ExtraDataToPOAMiddleware

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

load_dotenv()
w3 = Web3(Web3.HTTPProvider("https://polygon-bor-rpc.publicnode.com", request_kwargs={"timeout": 300}))
w3.middleware_onion.inject(ExtraDataToPOAMiddleware, layer=0)

PK = os.getenv("OWNER_PRIVATE_KEY")
OWNER = "0x6946999DBCE63b140B1bB9D475F7c357130909E5"

def C(a): return Web3.to_checksum_address(a)

with open("deployed_TROIKA_v3.json") as f:
    d = json.load(f)

NEW_EMIT = "0x76f1CeD709BcaD98A387BBe356f8ce1C9F92cbc9"

print("=" * 70)
print("GRANT ROLES TO NEW EmissionEngine")
print("=" * 70)
print(f"New Emit: {NEW_EMIT}")

nonce = w3.eth.get_transaction_count(C(OWNER), "pending")
base = w3.eth.get_block("latest").get("baseFeePerGas", int(100e9))
prio = int(50e9)
mf = base * 2 + prio

token_abi = [
    {"name": "MINTER_ROLE", "inputs": [], "outputs": [{"type": "bytes32"}], "stateMutability": "view", "type": "function"},
    {"name": "BURNER_ROLE", "inputs": [], "outputs": [{"type": "bytes32"}], "stateMutability": "view", "type": "function"},
    {"name": "grantRole", "inputs": [{"name": "role", "type": "bytes32"}, {"name": "account", "type": "address"}], "outputs": [], "stateMutability": "nonpayable", "type": "function"},
]

vault_abi = [
    {"name": "OPERATOR_ROLE", "inputs": [], "outputs": [{"type": "bytes32"}], "stateMutability": "view", "type": "function"},
    {"name": "grantRole", "inputs": [{"name": "role", "type": "bytes32"}, {"name": "account", "type": "address"}], "outputs": [], "stateMutability": "nonpayable", "type": "function"},
]

div_abi = [
    {"name": "NOTIFIER_ROLE", "inputs": [], "outputs": [{"type": "bytes32"}], "stateMutability": "view", "type": "function"},
    {"name": "grantRole", "inputs": [{"name": "role", "type": "bytes32"}, {"name": "account", "type": "address"}], "outputs": [], "stateMutability": "nonpayable", "type": "function"},
]

emit_abi = [
    {"name": "CALLER_ROLE", "inputs": [], "outputs": [{"type": "bytes32"}], "stateMutability": "view", "type": "function"},
    {"name": "grantRole", "inputs": [{"name": "role", "type": "bytes32"}, {"name": "account", "type": "address"}], "outputs": [], "stateMutability": "nonpayable", "type": "function"},
    {"name": "isEmissionDue", "inputs": [], "outputs": [{"type": "bool"}], "stateMutability": "view", "type": "function"},
    {"name": "lastEmitBlock", "inputs": [], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
]

def send_tx(func, label):
    global nonce
    print(f"  {label}...", end=" ", flush=True)
    tx = func.build_transaction({
        "from": C(OWNER), "nonce": nonce, "chainId": 137, "type": 2,
        "maxPriorityFeePerGas": prio, "maxFeePerGas": mf, "gas": 100000
    })
    signed = w3.eth.account.sign_transaction(tx, PK)
    h = w3.eth.send_raw_transaction(signed.raw_transaction)
    r = w3.eth.wait_for_transaction_receipt(h, timeout=120)
    print("OK" if r.status else "FAIL")
    nonce += 1
    time.sleep(1)
    return r.status

print("\n[1] Grant MINTER_ROLE to tokens...")
for name, addr in d["tokens"].items():
    tk = w3.eth.contract(address=C(addr), abi=token_abi)
    MINTER = tk.functions.MINTER_ROLE().call()
    send_tx(tk.functions.grantRole(MINTER, C(NEW_EMIT)), f"{name} MINTER")

print("\n[2] Grant BURNER_ROLE for SYNR...")
synr = w3.eth.contract(address=C(d["tokens"]["SYNR"]), abi=token_abi)
BURNER = synr.functions.BURNER_ROLE().call()
send_tx(synr.functions.grantRole(BURNER, C(NEW_EMIT)), "SYNR BURNER")

print("\n[3] Grant OPERATOR_ROLE in Vault...")
vault = w3.eth.contract(address=C(d["vault"]), abi=vault_abi)
OP = vault.functions.OPERATOR_ROLE().call()
send_tx(vault.functions.grantRole(OP, C(NEW_EMIT)), "Vault OPERATOR")

print("\n[4] Grant NOTIFIER_ROLE in DividendPool...")
divpool = w3.eth.contract(address=C(d["divPool"]), abi=div_abi)
NOT = divpool.functions.NOTIFIER_ROLE().call()
send_tx(divpool.functions.grantRole(NOT, C(NEW_EMIT)), "DivPool NOTIFIER")

print("\n[5] Grant CALLER_ROLE to Core...")
emit_contract = w3.eth.contract(address=C(NEW_EMIT), abi=emit_abi)
CALLER = emit_contract.functions.CALLER_ROLE().call()
send_tx(emit_contract.functions.grantRole(CALLER, C(d["core"])), "EmitEngine CALLER")

# Save
d["emitEngine_v2"] = NEW_EMIT
d["emitEngine_v2_interval"] = 50
with open("deployed_TROIKA_v3.json", "w") as f:
    json.dump(d, f, indent=2)

# Check status
is_due = emit_contract.functions.isEmissionDue().call()
last = emit_contract.functions.lastEmitBlock().call()
current = w3.eth.block_number

print("\n" + "=" * 70)
print("NEW EmissionEngine STATUS:")
print(f"  Address: {NEW_EMIT}")
print(f"  EMIT_INTERVAL: 50 blocks")
print(f"  isEmissionDue: {is_due}")
print(f"  lastEmitBlock: {last}")
print(f"  currentBlock: {current}")
print(f"  POL: {w3.eth.get_balance(C(OWNER)) / 1e18:.4f}")
print("=" * 70)
