#!/usr/bin/env python3
"""
ВЫПОЛНЕНИЕ ПРИБЫЛЬНОГО FLASH LOAN ЦИКЛА
"""
import sys, io, os, json, time
from dotenv import load_dotenv
from web3 import Web3
from web3.middleware import ExtraDataToPOAMiddleware

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

load_dotenv()

w3 = Web3(Web3.HTTPProvider("https://polygon-bor-rpc.publicnode.com", request_kwargs={"timeout": 300}))
w3.middleware_onion.inject(ExtraDataToPOAMiddleware, layer=0)

PK = os.getenv("OWNER_PRIVATE_KEY")
OWNER = "0x6946999DBCE63b140B1bB9D475F7c357130909E5"

def C(a): return Web3.to_checksum_address(a)

with open("deployed_TROIKA_v3.json") as f:
    d = json.load(f)

print("=" * 70)
print("ВЫПОЛНЕНИЕ ПРИБЫЛЬНОГО ЦИКЛА")
print("=" * 70)

# Проверить готовность
with open("out/07_EmissionEngine.sol/EmissionEngine.json", encoding="utf-8") as f:
    emit_abi = json.load(f)["abi"]

emit = w3.eth.contract(address=C(d["emitEngine"]), abi=emit_abi)
is_due = emit.functions.isEmissionDue().call()

print(f"isEmissionDue: {is_due}")

if not is_due:
    print("Emission not ready yet!")
    last = emit.functions.lastEmitBlock().call()
    current = w3.eth.block_number
    print(f"Blocks since last: {current - last} / 1000")
    sys.exit(1)

# Текущий баланс
bal_before = w3.eth.get_balance(C(OWNER)) / 1e18
print(f"\nБаланс до: {bal_before:.4f} POL")

# Вызываем tick() чтобы получить эмиссию
print("\n[1] Вызов TroikaCore.tick()...")

with open("out/10_TroikaCore.sol/TroikaCore.json", encoding="utf-8") as f:
    core_abi = json.load(f)["abi"]

core = w3.eth.contract(address=C(d["core"]), abi=core_abi)

nonce = w3.eth.get_transaction_count(C(OWNER), "pending")
base = w3.eth.get_block("latest").get("baseFeePerGas", int(100e9))
prio = int(50e9)
mf = base * 2 + prio

tx = core.functions.tick().build_transaction({
    "from": C(OWNER), "nonce": nonce, "chainId": 137, "type": 2,
    "maxPriorityFeePerGas": prio, "maxFeePerGas": mf, "gas": 2_000_000
})

signed = w3.eth.account.sign_transaction(tx, PK)
h = w3.eth.send_raw_transaction(signed.raw_transaction)
print(f"  TX: {h.hex()[:20]}...")

r = w3.eth.wait_for_transaction_receipt(h, timeout=300)
gas_cost = r.gasUsed * mf / 1e18

if r.status == 1:
    print(f"  [OK] Gas: {gas_cost:.4f} POL")
else:
    print(f"  [FAIL]")
    sys.exit(1)

nonce += 1
time.sleep(3)

# Проверить DividendPool - сколько накопилось founder
print("\n[2] Проверка DividendPool...")

with open("out/05_DividendPool.sol/DividendPool.json", encoding="utf-8") as f:
    div_abi = json.load(f)["abi"]

divpool = w3.eth.contract(address=C(d["divPool"]), abi=div_abi)
founder_pending = divpool.functions.founderPending().call() / 1e18
print(f"  Founder pending: {founder_pending:.6f} WPOL")

# Вывести founder дивиденды
if founder_pending > 0:
    print("\n[3] Вывод founder дивидендов...")
    tx = divpool.functions.withdrawFounder().build_transaction({
        "from": C(OWNER), "nonce": nonce, "chainId": 137, "type": 2,
        "maxPriorityFeePerGas": prio, "maxFeePerGas": mf, "gas": 200000
    })
    signed = w3.eth.account.sign_transaction(tx, PK)
    h = w3.eth.send_raw_transaction(signed.raw_transaction)
    print(f"  TX: {h.hex()[:20]}...")
    r = w3.eth.wait_for_transaction_receipt(h, timeout=120)
    print(f"  {'[OK]' if r.status else '[FAIL]'}")
    nonce += 1

# Проверить новые балансы токенов
print("\n[4] Проверка новых балансов...")

TOKEN_ABI = [
    {"name": "balanceOf", "inputs": [{"type": "address"}], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
]

for name, addr in d["tokens"].items():
    tk = w3.eth.contract(address=C(addr), abi=TOKEN_ABI)
    bal = tk.functions.balanceOf(C(OWNER)).call() / 1e18
    print(f"  {name}: {bal:.4f}")

WPOL = "0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270"
wpol = w3.eth.contract(address=C(WPOL), abi=TOKEN_ABI)
wpol_bal = wpol.functions.balanceOf(C(OWNER)).call() / 1e18
print(f"  WPOL: {wpol_bal:.4f}")

# Итог
bal_after = w3.eth.get_balance(C(OWNER)) / 1e18

print("\n" + "=" * 70)
print("ИТОГ")
print("=" * 70)
print(f"POL до: {bal_before:.4f}")
print(f"POL после: {bal_after:.4f}")
print(f"Разница (gas): {bal_after - bal_before:.4f} POL")
print(f"Founder WPOL получено: {founder_pending:.6f}")
