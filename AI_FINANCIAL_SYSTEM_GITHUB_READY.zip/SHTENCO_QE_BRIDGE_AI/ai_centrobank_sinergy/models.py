from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(slots=True)
class PoolState:
    name: str
    a: str
    b: str
    ra: float
    rb: float
    fee_bps: float = 30.0
    owner_share: float = 1.0

    def copy(self) -> "PoolState":
        return PoolState(self.name, self.a, self.b, self.ra, self.rb, self.fee_bps, self.owner_share)


@dataclass(slots=True)
class EconomyState:
    pools: dict[str, PoolState]
    treasury: dict[str, float]
    supply: dict[str, float]
    bridge_inventory: dict[str, dict[str, float]] = field(default_factory=dict)
    liabilities: dict[str, float] = field(default_factory=dict)
    burned: dict[str, float] = field(default_factory=dict)
    cumulative_fees: float = 0.0
    cumulative_gas: float = 0.0
    cycle: int = 0

    def copy(self) -> "EconomyState":
        return EconomyState(
            pools={name: pool.copy() for name, pool in self.pools.items()},
            treasury=dict(self.treasury),
            supply=dict(self.supply),
            bridge_inventory={chain: dict(values) for chain, values in self.bridge_inventory.items()},
            liabilities=dict(self.liabilities),
            burned=dict(self.burned),
            cumulative_fees=self.cumulative_fees,
            cumulative_gas=self.cumulative_gas,
            cycle=self.cycle,
        )


@dataclass(frozen=True, slots=True)
class Action:
    kind: str
    label: str
    params: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class Candidate:
    state: EconomyState
    actions: list[Action]
    metrics: dict[str, float]
    score: float
    risk: float


@dataclass(slots=True)
class SearchConfig:
    max_depth: int = 5
    beam_width: int = 180
    gas_wpol: float = 0.0015
    mcap_haircut: float = 0.02
    liquidation_haircut: float = 0.35
    max_trade_fraction: float = 0.08
    max_liquidity_fraction: float = 0.05
    bridge_fee_bps: float = 10.0
    min_reserve_ratio: float = 1.10
    max_peg_error: float = 0.12
    max_bridge_imbalance: float = 0.35
    max_valuation_gap: float = 0.25
    drawdown_penalty: float = 4.0
    inventory_penalty: float = 2.5
    peg_penalty: float = 5.0
    bridge_penalty: float = 2.0
    valuation_gap_penalty: float = 4.0
    reserve_penalty: float = 8.0
    growth_weight: float = 2.0
    treasury_weight: float = 1.2
    liquidity_weight: float = 1.5
    burn_weight: float = 0.25

    def normalized(self) -> "SearchConfig":
        return SearchConfig(
            max_depth=max(1, min(8, int(self.max_depth))),
            beam_width=max(10, min(1000, int(self.beam_width))),
            gas_wpol=max(0.0, float(self.gas_wpol)),
            mcap_haircut=min(0.5, max(0.0, float(self.mcap_haircut))),
            liquidation_haircut=min(0.95, max(0.0, float(self.liquidation_haircut))),
            max_trade_fraction=min(0.25, max(0.001, float(self.max_trade_fraction))),
            max_liquidity_fraction=min(0.20, max(0.001, float(self.max_liquidity_fraction))),
            bridge_fee_bps=min(100.0, max(0.0, float(self.bridge_fee_bps))),
            min_reserve_ratio=max(1.0, float(self.min_reserve_ratio)),
            max_peg_error=min(1.0, max(0.01, float(self.max_peg_error))),
            max_bridge_imbalance=min(1.0, max(0.01, float(self.max_bridge_imbalance))),
            max_valuation_gap=min(2.0, max(0.01, float(self.max_valuation_gap))),
            drawdown_penalty=max(0.0, float(self.drawdown_penalty)),
            inventory_penalty=max(0.0, float(self.inventory_penalty)),
            peg_penalty=max(0.0, float(self.peg_penalty)),
            bridge_penalty=max(0.0, float(self.bridge_penalty)),
            valuation_gap_penalty=max(0.0, float(self.valuation_gap_penalty)),
            reserve_penalty=max(0.0, float(self.reserve_penalty)),
            growth_weight=max(0.0, float(self.growth_weight)),
            treasury_weight=max(0.0, float(self.treasury_weight)),
            liquidity_weight=max(0.0, float(self.liquidity_weight)),
            burn_weight=max(0.0, float(self.burn_weight)),
        )
