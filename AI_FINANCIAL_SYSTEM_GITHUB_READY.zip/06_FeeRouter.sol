// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

// ═══════════════════════════════════════════════════════════════════════════
//  SINERGY SYSTEM — 06_FeeRouter.sol
//  Маршрутизатор комиссий в WPOL | Polygon
//
//  Распределение fee (из Python-модели v9.2):
//   alphaLP  = 35% → lpBuf  → QuickSwap LP при flush
//   alphaRES = 30% → traderReserve → дозаправка трейдеров
//   alphaCB  = 15% → cbFund → CBArbitrage
//   alphaDIV = 10% → дивиденды (70% founder / 30% holders)
//   остаток  = 10% → reserveR (collateral)
//
//  Дивиденды основателя (7% от fee):
//   50% cash → founderPending (DividendPool.notifyFounder)
//   50% buyback → Vault.buybackAccum
//   30% из cash → lpBuf (реинвест при reinvestMode)
//
//  Адаптивный контроль alphaLP / alphaRES (каждые 20 блоков):
//   traderReserve < LOW  → alphaRES ↑, alphaLP ↓ (дозаправить трейдеров)
//   traderReserve > HIGH → alphaRES ↓, alphaLP ↑ (больше в LP)
//
//  Паттерн безопасности:
//   ✓ PUSH-NOTIFY: FeeRouter сам делает safeTransfer к получателям,
//     затем вызывает notify* (нет transferFrom у DivPool/CBArb/Vault)
//   ✓ CEI везде
//   ✓ ReentrancyGuard на routeFee
//   ✓ require баланс WPOL перед маршрутизацией
// ═══════════════════════════════════════════════════════════════════════════

import {IERC20}          from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20}       from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {AccessControl}   from "@openzeppelin/contracts/access/AccessControl.sol";
import {Pausable}        from "@openzeppelin/contracts/utils/Pausable.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import "./01_PolygonConfig.sol";

// ── Интерфейсы (file-level) ────────────────────────────────────────────────

interface IVaultFR {
    function addToLpBuf(uint256 a)          external;
    function addToTraderReserve(uint256 a)  external;
    function addToReserveR(uint256 a)       external;
    function addToBuyback(uint256 a)        external;
    function transferWpol(address to, uint256 amount) external;
    function traderReserve()                external view returns (uint256);
}

interface IDivPoolFR {
    function notifyFounder(uint256 amount)  external;
    function notifyHolders(uint256 amount)  external;
}

interface ICBArbFR {
    function notifyCBFund(uint256 amount)   external;
}

// ── Custom Errors ─────────────────────────────────────────────────────────
error FR_ZeroAddress();
error FR_ZeroAmount();
error FR_InvalidTokenType(uint8 tokenType);
error FR_InsufficientWPOL(uint256 have, uint256 need);
error FR_BadThresholds(uint256 low, uint256 high);

contract FeeRouter is AccessControl, Pausable, ReentrancyGuard {
    using SafeERC20 for IERC20;

    bytes32 public constant CALLER_ROLE = keccak256("CALLER_ROLE"); // TroikaCore
    bytes32 public constant ADMIN_ROLE  = keccak256("ADMIN_ROLE");  // управление параметрами
    bytes32 public constant PAUSER_ROLE = keccak256("PAUSER_ROLE");

    // ── Зависимости ───────────────────────────────────────────────────
    IVaultFR   public immutable vault;
    IDivPoolFR public immutable divPool;
    ICBArbFR   public immutable cbArb;
    IERC20     public immutable WPOL;

    address public immutable vaultAddr;
    address public immutable divPoolAddr;
    address public immutable cbArbAddr;

    // ── Адаптивные alpha (basis points, сумма = 10 000) ───────────────
    uint256 public alphaLP  = 3_500;  // 35%
    uint256 public alphaRES = 3_000;  // 30%
    uint256 public alphaCB  = 1_500;  // 15%
    uint256 public alphaDIV = 1_000;  // 10%
    // alphaRR = 10000 - sum = 10% → reserveR

    // Границы адаптации
    uint256 public constant ALPHA_LP_MIN  = 2_800;
    uint256 public constant ALPHA_LP_MAX  = 4_800;
    uint256 public constant ALPHA_RES_MIN = 2_200;
    uint256 public constant ALPHA_RES_MAX = 4_000;
    uint256 public constant ADAPT_STEP    = 80;    // 0.8% за шаг

    // Пороговые значения traderReserve для адаптации
    uint256 public traderResLow  =  25e18; // < 25 WPOL → наращивать резерв
    uint256 public traderResHigh = 150e18; // > 150 WPOL → наращивать LP

    uint256 public lastAdaptBlock;
    uint256 public totalFeeRouted;

    // ── Events ────────────────────────────────────────────────────────
    event FeeRouted(
        uint256 totalFee,
        uint256 toLp, uint256 toRes, uint256 toCB,
        uint256 toDiv, uint256 toRR,
        uint8   tokenType
    );
    event AlphaAdapted(uint256 alphaLP, uint256 alphaRES, uint256 traderReserve);

    constructor(
        address vault_,
        address divPool_,
        address cbArb_,
        address admin_
    ) {
        if (vault_   == address(0) || divPool_ == address(0) ||
            cbArb_   == address(0) || admin_   == address(0)) revert FR_ZeroAddress();

        vault      = IVaultFR(vault_);
        divPool    = IDivPoolFR(divPool_);
        cbArb      = ICBArbFR(cbArb_);
        vaultAddr  = vault_;
        divPoolAddr= divPool_;
        cbArbAddr  = cbArb_;
        WPOL       = IERC20(PolygonConfig.WPOL);

        _grantRole(DEFAULT_ADMIN_ROLE, admin_);
        _grantRole(ADMIN_ROLE,         admin_);
        _grantRole(CALLER_ROLE,        admin_);
        _grantRole(PAUSER_ROLE,        admin_);
    }

    // ═══════════════════════════════════════════════════════════════════
    //  ROUTE FEE
    //  TroikaCore уже сделал safeTransferFrom(trader, address(this), fee)
    //  перед этим вызовом → WPOL физически здесь.
    //  tokenType: 0=SYNA, 1=SYNC, 2=SYNR
    // ═══════════════════════════════════════════════════════════════════
    function routeFee(uint256 feeAmount, uint8 tokenType)
        external nonReentrant whenNotPaused onlyRole(CALLER_ROLE)
    {
        // Checks
        if (feeAmount == 0) revert FR_ZeroAmount();
        if (tokenType > 2)  revert FR_InvalidTokenType(tokenType);
        uint256 bal = WPOL.balanceOf(address(this));
        if (bal < feeAmount) revert FR_InsufficientWPOL(bal, feeAmount);

        // Адаптация параметров (каждые 20 блоков)
        if (block.number >= lastAdaptBlock + PolygonConfig.ADAPT_INTERVAL) {
            _adaptAlpha();
            lastAdaptBlock = block.number;
        }

        // Расчёт долей
        uint256 toLp  = feeAmount * alphaLP  / 10_000;
        uint256 toRes = feeAmount * alphaRES / 10_000;
        uint256 toCB  = feeAmount * alphaCB  / 10_000;
        uint256 toDiv = feeAmount * alphaDIV / 10_000;
        uint256 toRR  = feeAmount - toLp - toRes - toCB - toDiv; // remainder → reserveR

        // Effects (учётные: totalFeeRouted)
        totalFeeRouted += feeAmount;

        // Interactions — PUSH + NOTIFY (CEI: каждый transfer + уведомление)

        // 1. LP buf → Vault
        WPOL.safeTransfer(vaultAddr, toLp);
        vault.addToLpBuf(toLp);

        // 2. traderReserve → Vault
        WPOL.safeTransfer(vaultAddr, toRes);
        vault.addToTraderReserve(toRes);

        // 3. reserveR → Vault
        WPOL.safeTransfer(vaultAddr, toRR);
        vault.addToReserveR(toRR);

        // 4. CB Fund → CBArb
        WPOL.safeTransfer(cbArbAddr, toCB);
        cbArb.notifyCBFund(toCB);

        // 5. Дивиденды → DividendPool
        _routeDividends(toDiv);

        emit FeeRouted(feeAmount, toLp, toRes, toCB, toDiv, toRR, tokenType);
    }

    // ── Маршрутизация дивидендов ──────────────────────────────────────
    function _routeDividends(uint256 toDiv) private {
        if (toDiv == 0) return;

        // founder: 70% | holders: 30%
        uint256 founderTotal = toDiv * 70 / 100;
        uint256 holderTotal  = toDiv - founderTotal;

        // founder: 50% cash, 50% buyback
        uint256 founderCash   = founderTotal * 50 / 100;
        uint256 founderBuyb   = founderTotal - founderCash;
        // Из cash: 30% → lpBuf (реинвест), 70% → notifyFounder
        uint256 founderReinv  = founderCash * 30 / 100;
        uint256 founderNet    = founderCash - founderReinv;

        // Founder cash → DivPool
        if (founderNet > 0) {
            WPOL.safeTransfer(divPoolAddr, founderNet);
            divPool.notifyFounder(founderNet);
        }

        // Founder buyback → Vault
        if (founderBuyb > 0) {
            WPOL.safeTransfer(vaultAddr, founderBuyb);
            vault.addToBuyback(founderBuyb);
        }

        // Founder reinvest → Vault lpBuf
        if (founderReinv > 0) {
            WPOL.safeTransfer(vaultAddr, founderReinv);
            vault.addToLpBuf(founderReinv);
        }

        // Holders → DivPool
        if (holderTotal > 0) {
            WPOL.safeTransfer(divPoolAddr, holderTotal);
            divPool.notifyHolders(holderTotal);
        }
    }

    // ── Адаптация alphaLP / alphaRES ──────────────────────────────────
    function _adaptAlpha() private {
        uint256 tr = vault.traderReserve();
        if (tr < traderResLow) {
            // Traders starving → grow reserve
            if (alphaRES + ADAPT_STEP <= ALPHA_RES_MAX) alphaRES += ADAPT_STEP;
            else alphaRES = ALPHA_RES_MAX;
            if (alphaLP >= ALPHA_LP_MIN + ADAPT_STEP) alphaLP -= ADAPT_STEP;
            else alphaLP = ALPHA_LP_MIN;
            emit AlphaAdapted(alphaLP, alphaRES, tr);
        } else if (tr > traderResHigh) {
            // Reserve full → grow LP
            uint256 step = ADAPT_STEP * 60 / 100;
            if (alphaRES >= ALPHA_RES_MIN + step) alphaRES -= step;
            else alphaRES = ALPHA_RES_MIN;
            if (alphaLP + step <= ALPHA_LP_MAX) alphaLP += step;
            else alphaLP = ALPHA_LP_MAX;
            emit AlphaAdapted(alphaLP, alphaRES, tr);
        }
    }

    // ── Admin ──────────────────────────────────────────────────────────
    function setThresholds(uint256 low, uint256 high)
        external onlyRole(ADMIN_ROLE)
    {
        if (low >= high || high > 10_000e18) revert FR_BadThresholds(low, high);
        traderResLow  = low;
        traderResHigh = high;
    }

    function currentAlphas() external view returns (
        uint256 lp_, uint256 res_, uint256 cb_, uint256 div_, uint256 rr_
    ) {
        uint256 rr = 10_000 - alphaLP - alphaRES - alphaCB - alphaDIV;
        return (alphaLP, alphaRES, alphaCB, alphaDIV, rr);
    }

    function pause()   external onlyRole(PAUSER_ROLE) { _pause(); }
    function unpause() external onlyRole(PAUSER_ROLE) { _unpause(); }
}
