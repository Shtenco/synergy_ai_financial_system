#!/usr/bin/env python3
"""
ДЕПЛОЙ TROIKA ПОШАГОВО (каждый контракт отдельно)
"""
import sys, io, os, json, time
from dotenv import load_dotenv
from web3 import Web3
from web3.middleware import ExtraDataToPOAMiddleware

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

load_dotenv()

w3 = Web3(Web3.HTTPProvider("https://polygon-bor-rpc.publicnode.com", request_kwargs={"timeout": 300}))
w3.middleware_onion.inject(ExtraDataToPOAMiddleware, layer=0)

PK = os.getenv("OWNER_PRIVATE_KEY")
OWNER = "0x6946999DBCE63b140B1bB9D475F7c357130909E5"
WPOL = "0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270"

def C(a): return Web3.to_checksum_address(a)

print("=" * 70)
print("ДЕПЛОЙ TROIKA ПОШАГОВО")
print("=" * 70)
print(f"POL: {w3.eth.get_balance(C(OWNER)) / 1e18:.4f}")

nonce = w3.eth.get_transaction_count(C(OWNER), "pending")
deployed = {}

def deploy_contract(name, artifact_path, constructor_args):
    global nonce
    print(f"\n[DEPLOY] {name}...", flush=True)

    with open(artifact_path, encoding="utf-8") as f:
        artifact = json.load(f)

    abi = artifact["abi"]
    bytecode = artifact["bytecode"]["object"]

    print(f"  Bytecode: {len(bytecode)//2} bytes")

    base = w3.eth.get_block("latest").get("baseFeePerGas", int(100e9))
    prio = int(50e9)
    mf = base * 2 + prio

    contract = w3.eth.contract(abi=abi, bytecode=bytecode)

    tx = contract.constructor(*constructor_args).build_transaction({
        "from": C(OWNER), "nonce": nonce, "chainId": 137, "type": 2,
        "maxPriorityFeePerGas": prio, "maxFeePerGas": mf, "gas": 8_000_000
    })

    signed = w3.eth.account.sign_transaction(tx, PK)
    h = w3.eth.send_raw_transaction(signed.raw_transaction)
    print(f"  TX: {h.hex()[:20]}...")

    r = w3.eth.wait_for_transaction_receipt(h, timeout=300)
    cost = r.gasUsed * mf / 1e18

    if r.status == 1:
        addr = r.contractAddress
        print(f"  [OK] {addr} (gas: {cost:.4f})")
        nonce += 1
        return addr, abi
    else:
        print(f"  [FAIL]")
        nonce += 1
        return None, None

# ═══════════════════════════════════════════════════════════════════════════
# 1. TOKENS
# ═══════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 70)
print("[STEP 1] DEPLOY TOKENS")
print("=" * 70)

syna_addr, syna_abi = deploy_contract("SYNA", "out/02_Tokens.sol/SYNA.json", [C(OWNER)])
time.sleep(3)

sync_addr, sync_abi = deploy_contract("SYNC", "out/02_Tokens.sol/SYNC.json", [C(OWNER)])
time.sleep(3)

synr_addr, synr_abi = deploy_contract("SYNR", "out/02_Tokens.sol/SYNR.json", [C(OWNER)])
time.sleep(3)

deployed["tokens"] = {"SYNA": syna_addr, "SYNC": sync_addr, "SYNR": synr_addr}
print(f"\nTokens deployed: {deployed['tokens']}")

# ═══════════════════════════════════════════════════════════════════════════
# 2. TROIKA CORE (admin = OWNER)
# ═══════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 70)
print("[STEP 2] DEPLOY TROIKA CORE")
print("=" * 70)

core_addr, core_abi = deploy_contract("TroikaCore", "out/10_TroikaCore.sol/TroikaCore.json", [C(OWNER)])
time.sleep(3)
deployed["core"] = core_addr

# ═══════════════════════════════════════════════════════════════════════════
# 3. VAULT
# ═══════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 70)
print("[STEP 3] DEPLOY VAULT")
print("=" * 70)

vault_addr, vault_abi = deploy_contract("TroikaVault", "out/03_TroikaVault.sol/TroikaVault.json",
    [C(syna_addr), C(sync_addr), C(synr_addr), C(OWNER)])
time.sleep(3)
deployed["vault"] = vault_addr

# ═══════════════════════════════════════════════════════════════════════════
# 4. TWAP ORACLE
# ═══════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 70)
print("[STEP 4] DEPLOY TWAP ORACLE")
print("=" * 70)

oracle_addr, oracle_abi = deploy_contract("TWAPOracle", "out/04_TWAPOracle.sol/TWAPOracle.json", [C(OWNER)])
time.sleep(3)
deployed["oracle"] = oracle_addr

# ═══════════════════════════════════════════════════════════════════════════
# 5. DIVIDEND POOL
# ═══════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 70)
print("[STEP 5] DEPLOY DIVIDEND POOL")
print("=" * 70)

divpool_addr, divpool_abi = deploy_contract("DividendPool", "out/05_DividendPool.sol/DividendPool.json",
    [C(synr_addr), C(OWNER), C(OWNER)])  # synr, founder, admin
time.sleep(3)
deployed["divPool"] = divpool_addr

# ═══════════════════════════════════════════════════════════════════════════
# 6. CB ARBITRAGE
# ═══════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 70)
print("[STEP 6] DEPLOY CB ARBITRAGE")
print("=" * 70)

cbarb_addr, cbarb_abi = deploy_contract("CBArbitrage", "out/08_CBArbitrage.sol/CBArbitrage.json",
    [C(vault_addr), C(divpool_addr), C(oracle_addr), C(synr_addr), C(sync_addr), C(OWNER)])
time.sleep(3)
deployed["cbArb"] = cbarb_addr

# ═══════════════════════════════════════════════════════════════════════════
# 7. FEE ROUTER
# ═══════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 70)
print("[STEP 7] DEPLOY FEE ROUTER")
print("=" * 70)

feerouter_addr, feerouter_abi = deploy_contract("FeeRouter", "out/06_FeeRouter.sol/FeeRouter.json",
    [C(vault_addr), C(divpool_addr), C(cbarb_addr), C(OWNER)])
time.sleep(3)
deployed["feeRouter"] = feerouter_addr

# ═══════════════════════════════════════════════════════════════════════════
# 8. EMISSION ENGINE
# ═══════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 70)
print("[STEP 8] DEPLOY EMISSION ENGINE")
print("=" * 70)

emit_addr, emit_abi = deploy_contract("EmissionEngine", "out/07_EmissionEngine.sol/EmissionEngine.json",
    [C(vault_addr), C(syna_addr), C(sync_addr), C(synr_addr), C(divpool_addr), C(OWNER)])
time.sleep(3)
deployed["emitEngine"] = emit_addr

# ═══════════════════════════════════════════════════════════════════════════
# 9. SELF REINFORCING LOOP
# ═══════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 70)
print("[STEP 9] DEPLOY SELF REINFORCING LOOP")
print("=" * 70)

loop_addr, loop_abi = deploy_contract("SelfReinforcingLoop", "out/09_SelfReinforcingLoop.sol/SelfReinforcingLoop.json",
    [C(vault_addr), C(OWNER)])
time.sleep(3)
deployed["loop"] = loop_addr

# ═══════════════════════════════════════════════════════════════════════════
# 10. FOUNDER CONTROL
# ═══════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 70)
print("[STEP 10] DEPLOY FOUNDER CONTROL")
print("=" * 70)

fc_addr, fc_abi = deploy_contract("FounderControl", "out/11_FounderControl.sol/FounderControl.json",
    [C(core_addr), C(vault_addr), C(divpool_addr), C(loop_addr), C(OWNER), C(OWNER)])
time.sleep(3)
deployed["founderCtl"] = fc_addr

# Сохранить
deployed["deployed_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
deployed["owner"] = OWNER

with open("deployed_TROIKA_v3.json", "w") as f:
    json.dump(deployed, f, indent=2)

print("\n" + "=" * 70)
print("ВСЕ КОНТРАКТЫ ЗАДЕПЛОЕНЫ!")
print("=" * 70)
for k, v in deployed.items():
    if k not in ["deployed_at", "owner", "tokens"]:
        print(f"  {k}: {v}")
print(f"\nТокены: {deployed['tokens']}")
print(f"\nPOL: {w3.eth.get_balance(C(OWNER)) / 1e18:.4f}")
print("\nСохранено в deployed_TROIKA_v3.json")
print("\nСледующий шаг: INITIALIZE_TROIKA.py")
