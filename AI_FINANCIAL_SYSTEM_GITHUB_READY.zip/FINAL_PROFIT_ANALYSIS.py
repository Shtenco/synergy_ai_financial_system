#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
 ФИНАЛЬНЫЙ АНАЛИЗ ПРИБЫЛЬНОСТИ TROIKA SYSTEM

 КЛЮЧЕВАЯ ФОРМУЛА:
   dlp = LP × (√((S+em)/S) − 1) × 0.997
   founder = dlp × 30%

 ГДЕ:
   LP = virtual LP value в Vault (не TVL пулов!)
   S = token supply
   em = S × emitRate × 100

 ПРОБЛЕМА:
   При LP = 6 и em/S = 0.5%, dlp = 0.0149 WPOL
   Founder (30%) = 0.0045 WPOL
   Gas = 0.2 POL
   УБЫТОК!

 РЕШЕНИЕ:
   Увеличить LP value в Vault до 1000+
   Тогда founder = 0.0045 × 166 = 0.75 WPOL per emission!
═══════════════════════════════════════════════════════════════════════════════
"""
from decimal import Decimal, getcontext
getcontext().prec = 50

print(__doc__)

# Current state
LP_CURRENT = Decimal('6')
GAS_PER_EMISSION = Decimal('0.2')

def calc_founder(lp_val, emit_rate=Decimal('50e-6')):
    """Рассчитать founder share при данном LP"""
    supplies = {
        'SYNA': Decimal('102'),
        'SYNC': Decimal('1020'),
        'SYNR': Decimal('204')
    }

    dlp_total = Decimal(0)
    for t, s in supplies.items():
        em = s * emit_rate * 100
        if s > 0 and em > 0:
            ratio = (s + em) / s
            sqrt_ratio = ratio.sqrt()
            dlp = lp_val * (sqrt_ratio - 1) * Decimal('0.997')
            dlp_total += dlp

    return dlp_total * Decimal('0.30')

print("="*70)
print(" ЗАВИСИМОСТЬ FOUNDER SHARE ОТ LP VALUE")
print("="*70)
print(f"{'LP Value':<15} {'Founder/emit':<15} {'Net Profit':<15} {'Status':<10}")
print("-"*70)

lp_values = [6, 10, 20, 50, 100, 200, 500, 1000, 2000]

for lp in lp_values:
    founder = calc_founder(Decimal(lp))
    net = founder - GAS_PER_EMISSION
    status = "PROFIT" if net > 0 else "LOSS"
    print(f"{lp:<15} {founder:<15.6f} {net:<15.6f} {status:<10}")

# Break-even
print("\n" + "="*70)
print(" ТОЧКА БЕЗУБЫТОЧНОСТИ")
print("="*70)

# founder = dlp * 0.30
# dlp = LP * factor * 0.997
# factor ≈ em / (2*S) for small em
# founder = LP * em/(2*S) * 0.997 * 0.30
# При em = S * 50e-6 * 100 = S * 0.005
# founder = LP * 0.005/2 * 0.997 * 0.30 = LP * 0.000748

# Для founder >= gas:
# LP * 0.000748 >= 0.2
# LP >= 267

factor = Decimal('0.000748')  # approximate
breakeven_lp = GAS_PER_EMISSION / factor

print(f"  Формула: founder ≈ LP × {factor}")
print(f"  Gas per emission: {GAS_PER_EMISSION} POL")
print(f"  Break-even LP: {breakeven_lp:.0f}")
print(f"  Текущий LP: {LP_CURRENT}")
print(f"  Нужно увеличить LP в {breakeven_lp / LP_CURRENT:.0f}x раз!")

print("\n" + "="*70)
print(" FLASH LOAN SCHEME С FEE = 1 POL")
print("="*70)

flash_amount = Decimal('2000')  # для fee = 1 POL
flash_fee = flash_amount * Decimal('0.0005')

# При Flash 2000 WPOL → LP увеличивается
# Но нужно учитывать что LP это виртуальный учёт в Vault!

print(f"""
ПРОБЛЕМА:
  Flash Loan даёт 2000 WPOL
  Но LP value в Vault = виртуальный учёт!
  Простой transfer в Vault НЕ увеличивает LP!

  LP увеличивается через:
  1. Vault.initialize() - начальная ликвидность
  2. Vault.flushLpBuf() - из lpBuf в реальные пулы
  3. EmissionEngine.batchAddLP() - виртуальное добавление

РЕШЕНИЕ - FLASH LOAN PROFIT SCHEME:
───────────────────────────────────

[1] Flash Loan 2000 WPOL (fee = 1 POL)

[2] QuickSwap: addLiquidity напрямую
    └── Добавить 2000 WPOL + пропорционально токенов в пулы
    └── TVL пулов: 6 → 2006 WPOL
    └── Получить LP tokens

[3] EmissionEngine.executeEmission()
    └── LP value теперь ~2000, не 6!
    └── dlp ≈ 2000 × 0.00075 = 1.5 WPOL
    └── Founder 30% = 0.45 WPOL

[4] QuickSwap: removeLiquidity
    └── Забрать WPOL + токены обратно

[5] Return Flash Loan + fee

[6] PROFIT = 0.45 - 1 - 0.2 = -0.75 POL
    (всё ещё убыток за 1 emission!)

НУЖНО 3+ EMISSIONS ЗА ПЕРИОД FLASH LOAN:
────────────────────────────────────────
  3 × 0.45 - 1 - 0.6 = -0.25 POL (убыток)
  4 × 0.45 - 1 - 0.8 = +0.00 POL (break-even)
  5 × 0.45 - 1 - 1.0 = +0.25 POL (PROFIT!)

НО: Flash Loan атомарный → 1 emission max!
""")

print("="*70)
print(" ЕДИНСТВЕННАЯ РАБОЧАЯ СХЕМА")
print("="*70)

print("""
СХЕМА БЕЗ FLASH LOAN - ДОЛГОСРОЧНАЯ СТРАТЕГИЯ:
──────────────────────────────────────────────

[1] Добавить МНОГО ликвидности в пулы (>500 WPOL)
    └── addLiquidity в QuickSwap напрямую
    └── TVL пулов вырастет

[2] Ждать эмиссии каждые 50 блоков (~100 сек)
    └── Каждая эмиссия: founder = LP × 0.00075
    └── При LP = 1000: founder = 0.75 WPOL

[3] withdrawFounder() после каждой эмиссии
    └── Gas: 0.05 POL
    └── Net: 0.75 - 0.15 = 0.60 POL PROFIT!

[4] После N эмиссий: removeLiquidity
    └── Забрать исходные средства + все accumulated emissions

РАСЧЁТ ПРИ LP = 1000:
─────────────────────
  Founder per emission: 0.75 WPOL
  Gas per emission: 0.15 POL
  Net per emission: 0.60 POL

  10 emissions: 6.0 POL PROFIT
  100 emissions: 60 POL PROFIT

  Time: 100 emissions × 50 blocks × 2 sec = 2.8 hours
""")

# Final calculation
print("\n" + "="*70)
print(" ИТОГОВЫЕ РЕКОМЕНДАЦИИ")
print("="*70)

print("""
1. FLASH LOAN НЕ ПРИБЫЛЬНЫЙ при текущих параметрах
   └── Fee 1 POL > emission value за 1 TX

2. Для прибыльности нужно:
   └── LP value >= 270 в каждом пуле
   └── Или multiple emissions (невозможно атомарно)

3. РАБОЧАЯ СТРАТЕГИЯ:
   └── Добавить 1000+ WPOL в ликвидность
   └── Запустить автоматизированный emission loop
   └── 0.60 POL profit per emission
   └── ~60 POL per day (if continuous)

4. АЛЬТЕРНАТИВА:
   └── Увеличить emitRate (но MAX уже = 50e-6)
   └── Увеличить Supply (mint больше токенов)
   └── Оба варианта требуют редеплоя контрактов
""")
