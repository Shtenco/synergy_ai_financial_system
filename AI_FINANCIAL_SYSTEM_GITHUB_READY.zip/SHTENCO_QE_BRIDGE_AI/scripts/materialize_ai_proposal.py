from __future__ import annotations

import argparse
import json
import os
from decimal import Decimal, ROUND_DOWN
from pathlib import Path
from typing import Any

from web3 import Web3

ERC20_ABI = [
    {"inputs": [{"name": "account", "type": "address"}], "name": "balanceOf", "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
]
ROUTER_ABI = [
    {"inputs": [{"name": "amountIn", "type": "uint256"}, {"name": "path", "type": "address[]"}], "name": "getAmountsOut", "outputs": [{"type": "uint256[]"}], "stateMutability": "view", "type": "function"},
]
GUARD_ABI = [
    {"inputs": [{"name": "tokenIn", "type": "address"}, {"name": "tokenOut", "type": "address"}, {"name": "amountIn", "type": "uint256"}], "name": "quote", "outputs": [{"name": "expectedOut", "type": "uint256"}, {"name": "updatedAt", "type": "uint256"}], "stateMutability": "view", "type": "function"},
]
MM_ABI = [
    {"inputs": [], "name": "priceGuard", "outputs": [{"type": "address"}], "stateMutability": "view", "type": "function"},
    {"inputs": [], "name": "maxOracleDeviationBps", "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"inputs": [{"type": "address"},{"type": "uint256"},{"type": "uint256"},{"type": "address[]"},{"type": "uint256"},{"type": "bytes32"}], "name": "executeSwap", "outputs": [{"type": "uint256"}], "stateMutability": "nonpayable", "type": "function"},
    {"inputs": [{"type": "address"},{"type": "uint256"},{"type": "uint256"},{"type": "address[]"},{"type": "uint256"},{"type": "bytes32"}], "name": "executeBuybackAndBurn", "outputs": [{"type": "uint256"}], "stateMutability": "nonpayable", "type": "function"},
    {"inputs": [{"type": "address"},{"type": "address"},{"type": "address"},{"type": "uint256"},{"type": "uint256"},{"type": "uint256"},{"type": "uint256"},{"type": "uint256"},{"type": "bytes32"}], "name": "addLiquidity", "outputs": [{"type": "uint256"},{"type": "uint256"},{"type": "uint256"}], "stateMutability": "nonpayable", "type": "function"},
]
RESERVE_ABI = [
    {"inputs": [{"type": "address"},{"type": "address"},{"type": "uint256"},{"type": "bytes32"}], "name": "allocate", "outputs": [], "stateMutability": "nonpayable", "type": "function"},
]
ADAPTER_ABI = [
    {"inputs": [{"type": "address"},{"type": "address"},{"type": "uint256"},{"type": "uint256"},{"type": "address"},{"type": "bytes32"}], "name": "executeRebalance", "outputs": [{"type": "bytes32"},{"type": "uint256"}], "stateMutability": "nonpayable", "type": "function"},
]
CB_ABI = [
    {"inputs": [], "name": "minimumScoreBps", "outputs": [{"type": "uint16"}], "stateMutability": "view", "type": "function"},
    {"inputs": [], "name": "maximumRiskBps", "outputs": [{"type": "uint16"}], "stateMutability": "view", "type": "function"},
    {"inputs": [], "name": "minDelay", "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"inputs": [], "name": "maxDelay", "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"inputs": [], "name": "maxExecutionWindow", "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"inputs": [{"type": "address"}], "name": "targetEnabled", "outputs": [{"type": "bool"}], "stateMutability": "view", "type": "function"},
    {"inputs": [{"type": "address"},{"type": "bytes4"}], "name": "selectorEnabled", "outputs": [{"type": "bool"}], "stateMutability": "view", "type": "function"},
    {"inputs": [{"type": "address"},{"type": "bytes4"}], "name": "selectorBudgetRequired", "outputs": [{"type": "bool"}], "stateMutability": "view", "type": "function"},
    {"inputs": [{"type": "address"}], "name": "dailyBudgetLimit", "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
]


def checksum(value: str) -> str:
    if not value or value == "0x0000000000000000000000000000000000000000":
        raise ValueError("zero/unconfigured address in execution map")
    return Web3.to_checksum_address(value)


def encode(contract: Any, function_name: str, args: list[Any]) -> str:
    if hasattr(contract, "encode_abi"):
        return contract.encode_abi(function_name, args=args)
    return contract.encodeABI(fn_name=function_name, args=args)


def units(value: Any, decimals: int) -> int:
    scaled = Decimal(str(value)) * (Decimal(10) ** decimals)
    result = int(scaled.to_integral_value(rounding=ROUND_DOWN))
    if result <= 0:
        raise ValueError(f"amount rounds to zero: {value}")
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description="Materialize safe on-chain actions from an AI intent proposal")
    parser.add_argument("--proposal", type=Path, required=True)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()

    proposal = json.loads(args.proposal.read_text(encoding="utf-8"))
    config = json.loads(args.config.read_text(encoding="utf-8"))
    policy = proposal.get("policy") or {}
    if not policy.get("allowed", False):
        raise SystemExit(f"Proposal policy is not allowed: {policy.get('reason', 'unknown')}")

    rpc = os.environ.get(config.get("rpc_env", "POLYGON_RPC_URL"), "").strip()
    if not rpc:
        raise SystemExit("RPC environment variable is not set")
    w3 = Web3(Web3.HTTPProvider(rpc, request_kwargs={"timeout": 60}))
    if not w3.is_connected():
        raise SystemExit("RPC connection failed")

    addresses = {k: checksum(v) for k, v in config["contracts"].items()}
    token_cfg = config["tokens"]
    tokens = {symbol: checksum(row["address"]) for symbol, row in token_cfg.items()}
    decimals = {symbol: int(row["decimals"]) for symbol, row in token_cfg.items()}

    reserve = w3.eth.contract(address=addresses["reserve"], abi=RESERVE_ABI)
    mm = w3.eth.contract(address=addresses["market_maker"], abi=MM_ABI)
    adapter = w3.eth.contract(address=addresses["bridge_adapter"], abi=ADAPTER_ABI)
    cb = w3.eth.contract(address=addresses["central_bank"], abi=CB_ABI)
    guard = w3.eth.contract(address=checksum(mm.functions.priceGuard().call()), abi=GUARD_ABI)
    max_deviation = int(mm.functions.maxOracleDeviationBps().call())
    slippage_bps = int(config.get("slippage_bps", 75))
    if not 0 <= slippage_bps <= 500:
        raise ValueError("slippage_bps must be 0..500")

    block = w3.eth.get_block("latest")
    deadline = int(block["timestamp"]) + int(config.get("deadline_seconds", 180))
    inventory: dict[tuple[str, str], int] = {}
    actions: list[dict[str, Any]] = []

    def balance(holder: str, symbol: str) -> int:
        key = (holder.lower(), symbol)
        if key not in inventory:
            token = w3.eth.contract(address=tokens[symbol], abi=ERC20_ABI)
            inventory[key] = int(token.functions.balanceOf(holder).call())
        return inventory[key]

    def add_action(target: str, data: str, budget_symbol: str | None = None, budget_amount: int = 0) -> None:
        actions.append({
            "target": target,
            "value": "0",
            "data": data,
            "budgetToken": tokens[budget_symbol] if budget_symbol else "0x0000000000000000000000000000000000000000",
            "budgetAmount": str(budget_amount),
        })

    def ensure_inventory(holder: str, symbol: str, required: int, purpose: str) -> None:
        current = balance(holder, symbol)
        if current >= required:
            return
        shortfall = required - current
        reserve_balance = balance(addresses["reserve"], symbol)
        if reserve_balance < shortfall:
            raise ValueError(f"reserve lacks {symbol}: need {shortfall}, has {reserve_balance}")
        data = encode(reserve, "allocate", [tokens[symbol], holder, shortfall, Web3.keccak(text=purpose)])
        add_action(addresses["reserve"], data)
        inventory[(addresses["reserve"].lower(), symbol)] = reserve_balance - shortfall
        inventory[(holder.lower(), symbol)] = current + shortfall

    def quote(router_address: str, path_symbols: list[str], amount_in: int) -> tuple[int, int]:
        path = [tokens[s] for s in path_symbols]
        router = w3.eth.contract(address=checksum(router_address), abi=ROUTER_ABI)
        router_out = int(router.functions.getAmountsOut(amount_in, path).call()[-1])
        oracle_out, _updated = guard.functions.quote(path[0], path[-1], amount_in).call()
        oracle_floor = int(oracle_out) * (10_000 - max_deviation) // 10_000
        quote_floor = router_out * (10_000 - slippage_bps) // 10_000
        min_out = max(oracle_floor, quote_floor)
        if min_out <= 0 or min_out > router_out:
            raise ValueError("route fails oracle/slippage preflight")
        return router_out, min_out

    cycles = proposal.get("cycles", [])
    for row in cycles:
        intent = row.get("action") or {}
        kind = intent.get("kind", "HOLD")
        params = intent.get("params") or {}
        if kind == "HOLD":
            continue
        reason = Web3.keccak(text=f"AI:{kind}:{row.get('state_hash', '')}")

        if kind == "SWAP":
            pool = config["pools"][params["pool"]]
            token_in = str(params["token_in"]).upper()
            path_symbols = pool["paths"][token_in]
            amount_in = units(params["amount"], decimals[token_in])
            router_out, min_out = quote(pool["router"], path_symbols, amount_in)
            ensure_inventory(addresses["market_maker"], token_in, amount_in, f"AI SWAP {params['pool']}")
            data = encode(mm, "executeSwap", [checksum(pool["router"]), amount_in, min_out, [tokens[s] for s in path_symbols], deadline, reason])
            add_action(addresses["market_maker"], data, token_in, amount_in)
            inventory[(addresses["market_maker"].lower(), token_in)] -= amount_in
            token_out = path_symbols[-1]
            inventory[(addresses["market_maker"].lower(), token_out)] = balance(addresses["market_maker"], token_out) + router_out

        elif kind == "ADD_LIQUIDITY":
            pool = config["pools"][params["pool"]]
            a, b = pool["tokenA"], pool["tokenB"]
            amount_a = units(params["amount_a"], decimals[a])
            amount_b = units(params["amount_b"], decimals[b])
            expected_b, _ = guard.functions.quote(tokens[a], tokens[b], amount_a).call()
            lower = int(expected_b) * (10_000 - max_deviation) // 10_000
            upper = int(expected_b) * (10_000 + max_deviation) // 10_000
            if not lower <= amount_b <= upper:
                raise ValueError(f"liquidity ratio for {params['pool']} fails oracle guard")
            min_a = amount_a * (10_000 - slippage_bps) // 10_000
            min_b = amount_b * (10_000 - slippage_bps) // 10_000
            ensure_inventory(addresses["market_maker"], a, amount_a, f"AI LP {params['pool']} {a}")
            ensure_inventory(addresses["market_maker"], b, amount_b, f"AI LP {params['pool']} {b}")
            data = encode(mm, "addLiquidity", [checksum(pool["router"]), tokens[a], tokens[b], amount_a, amount_b, min_a, min_b, deadline, reason])
            add_action(addresses["market_maker"], data, a, amount_a)
            inventory[(addresses["market_maker"].lower(), a)] -= amount_a
            inventory[(addresses["market_maker"].lower(), b)] -= amount_b

        elif kind == "BRIDGE_REBALANCE":
            token = str(params["token"]).upper()
            route_key = f"{params['source']}->{params['destination']}:{token}"
            route = config["bridge_routes"][route_key]
            amount = units(params["amount"], decimals[token])
            ensure_inventory(addresses["bridge_adapter"], token, amount, f"AI BRIDGE {route_key}")
            data = encode(adapter, "executeRebalance", [checksum(route["bridge"]), tokens[token], amount, int(route["target_chain_id"]), checksum(route["recipient"]), reason])
            add_action(addresses["bridge_adapter"], data, token, amount)
            inventory[(addresses["bridge_adapter"].lower(), token)] -= amount

        elif kind == "BUYBACK_BURN":
            buyback = config["buyback"]
            path_symbols = buyback["path"]
            token_in = path_symbols[0]
            amount_in = units(params["amount_wpol"], decimals[token_in])
            _router_out, min_out = quote(buyback["router"], path_symbols, amount_in)
            ensure_inventory(addresses["market_maker"], token_in, amount_in, "AI BUYBACK BURN")
            data = encode(mm, "executeBuybackAndBurn", [checksum(buyback["router"]), amount_in, min_out, [tokens[s] for s in path_symbols], deadline, reason])
            add_action(addresses["market_maker"], data, token_in, amount_in)
            inventory[(addresses["market_maker"].lower(), token_in)] -= amount_in
        else:
            raise ValueError(f"unsupported AI action: {kind}")

    if not actions:
        raise SystemExit("No executable actions: proposal resolves to HOLD")

    min_score = int(cb.functions.minimumScoreBps().call())
    max_risk = int(cb.functions.maximumRiskBps().call())
    score_bps = int(policy["score_bps"])
    risk_bps = int(policy["risk_bps"])
    if score_bps < min_score or risk_bps > max_risk:
        raise ValueError(f"policy incompatible with on-chain limits: score {score_bps}/{min_score}, risk {risk_bps}/{max_risk}")

    for action in actions:
        target = checksum(action["target"])
        selector = bytes.fromhex(action["data"][2:10])
        if not cb.functions.targetEnabled(target).call():
            raise ValueError(f"central bank target disabled: {target}")
        if not cb.functions.selectorEnabled(target, selector).call():
            raise ValueError(f"central bank selector disabled: {target} 0x{selector.hex()}")
        required = bool(cb.functions.selectorBudgetRequired(target, selector).call())
        amount = int(action["budgetAmount"])
        if required and amount <= 0:
            raise ValueError("selector requires non-zero budget metadata")
        if amount > 0:
            limit = int(cb.functions.dailyBudgetLimit(checksum(action["budgetToken"])).call())
            if limit == 0 or amount > limit:
                raise ValueError("central bank daily budget is missing or below action amount")

    chain_min_delay = int(cb.functions.minDelay().call())
    chain_max_delay = int(cb.functions.maxDelay().call())
    chain_window = int(cb.functions.maxExecutionWindow().call())
    delay = int(config.get("proposal_delay_seconds", chain_min_delay))
    window = int(config.get("execution_window_seconds", chain_window))
    if not chain_min_delay <= delay <= chain_max_delay:
        raise ValueError("proposal delay outside on-chain policy")
    if not 3600 <= window <= chain_window:
        raise ValueError("execution window outside on-chain policy")

    state_hash = cycles[-1].get("state_hash") if cycles else None
    if not state_hash or len(state_hash) != 66:
        raise ValueError("missing final state hash")
    materialized = {
        "createdFrom": str(args.proposal),
        "chainId": w3.eth.chain_id,
        "centralBank": addresses["central_bank"],
        "actions": actions,
        "stateHash": state_hash,
        "objectiveHash": Web3.keccak(text=config.get("objective", "risk-adjusted ecosystem growth")).hex(),
        "scoreBps": score_bps,
        "riskBps": risk_bps,
        "executeAfter": int(block["timestamp"]) + delay,
        "expiresAt": int(block["timestamp"]) + delay + window,
        "policy": policy,
        "reviewRequired": True,
    }
    output = args.output or args.proposal.with_name(args.proposal.stem + "-materialized.json")
    output.write_text(json.dumps(materialized, indent=2), encoding="utf-8")
    print(json.dumps({"output": str(output), "actions": len(actions), "chainId": w3.eth.chain_id}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
