from __future__ import annotations

import argparse
import json
from pathlib import Path


def build_plan(decision: dict, profit_amount: float, token: str) -> dict:
    d = decision["decision"] if "decision" in decision else decision
    allocation = d["allocation"]
    amount_by_bucket = {
        key.replace("_bps", ""): profit_amount * value / 10_000
        for key, value in allocation.items()
    }
    return {
        "objective": "convert realized external revenue into durable ecosystem value",
        "profit_token": token,
        "realized_profit_amount": profit_amount,
        "recommended_decision": d["name"],
        "atomic_stage_1": [
            "FlashLoanArbitrage completes only if principal + Aave premium + minProfit are covered",
            "FlashProfitHarvester withdraws the realized profit to ValueFlowTreasury",
            "ValueFlowTreasury records the exact balance delta with a replay-protected sourceId",
            "ValueFlowTreasury allocates the recorded revenue into bounded accounting buckets"
        ],
        "bucket_amounts": amount_by_bucket,
        "controlled_stage_2": [
            "LIQUIDITY bucket -> MarketMaker -> oracle-bounded addLiquidity",
            "BUYBACK bucket -> MarketMaker -> buyback-and-burn only near/below fundamental value",
            "BRIDGE bucket -> BridgeQEReserve -> BridgeQEAdapter -> approved relay route",
            "RESERVE bucket remains above the configured floor; backed excess may be reclassified only to liquidity, bridge or insurance",
            "OPERATIONS bucket -> approved operations multisig",
            "INSURANCE bucket remains dedicated to tail-risk coverage"
        ],
        "qe": {
            "fraction_of_excess_reserve": d["qe_fraction_of_excess"],
            "liquidity_share": d["qe_liquidity_share"],
            "bridge_share": d["qe_bridge_share"],
            "insurance_share": d["qe_insurance_share"],
            "prohibited_destinations": ["buyback", "operations", "unbacked mint"]
        },
        "flash_search_intensity": d["flash_search_intensity"],
        "execution_requirements": [
            "fresh M-of-N state snapshot",
            "timelock elapsed",
            "target and selector allowlisted",
            "daily token budget available",
            "reserve, peg, bridge, volatility and valuation gates pass at execution time"
        ]
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Build a human-reviewable TOP AI value-cycle plan")
    parser.add_argument("decision", help="defi-top-ai-decision.json")
    parser.add_argument("--profit-amount", type=float, required=True)
    parser.add_argument("--token", default="USDC")
    parser.add_argument("--output", default="deployments/defi-top-ai-value-cycle.json")
    args = parser.parse_args()
    raw = json.loads(Path(args.decision).read_text(encoding="utf-8"))
    best = raw["best"] if "best" in raw else raw
    plan = build_plan(best, args.profit_amount, args.token)
    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(plan, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(plan, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
