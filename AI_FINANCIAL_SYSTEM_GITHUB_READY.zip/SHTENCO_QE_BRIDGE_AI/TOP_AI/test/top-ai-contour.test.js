const assert = require("assert");
const { ethers, network } = require("hardhat");
async function expectRevert(promise, text) {
  try { await promise; throw new Error("expected revert"); }
  catch (e) { assert(String(e).includes(text), `expected ${text}, got ${e}`); }
}
async function advance(seconds) {
  await network.provider.send("evm_increaseTime", [seconds]);
  await network.provider.send("evm_mine");
}
function state(overrides = {}) {
  return {
    liquidReserves: ethers.parseEther("1500"), liabilities: ethers.parseEther("1000"),
    ownedLiquidityNav: ethers.parseEther("600"), bridgeCapital: ethers.parseEther("300"),
    circulatingSupply: ethers.parseEther("1000000"), protocolRevenue30d: ethers.parseEther("50"),
    marketPrice: ethers.parseEther("0.0015"), volatilityBps: 1800, pegErrorBps: 250,
    bridgeImbalanceBps: 800, liquidityCoverageBps: 4000,
    externalDataHash: ethers.id("independent-evidence"), ...overrides
  };
}
async function finalize(oracle, r1, r2, input) {
  await oracle.connect(r1).submitSnapshot(input);
  await oracle.connect(r2).submitSnapshot(input);
  return oracle.getLatestSnapshot();
}
describe("SHTENCO DeFi TOP AI contour", function () {
  it("uses M-of-N state and does not convert market-price movement into fundamental value", async function () {
    const [admin, r1, r2, r3] = await ethers.getSigners();
    const O = await ethers.getContractFactory("SHTENCOSystemStateOracle");
    const oracle = await O.deploy(admin.address, [r1.address, r2.address, r3.address], 2);
    const input = state({ marketPrice: ethers.parseEther("0.003") });
    await oracle.connect(r1).submitSnapshot(input);
    await expectRevert(oracle.connect(r1).submitSnapshot(input), "STATE: reporter already voted");
    await oracle.connect(r2).submitSnapshot(input);
    const first = await oracle.getLatestSnapshot();
    assert.equal(first.backingNav, ethers.parseEther("1400"));
    assert.equal(first.discountedRevenueValue, ethers.parseEther("300"));
    assert.equal(first.fundamentalMcap, ethers.parseEther("1700"));
    assert.equal(first.marketCap, ethers.parseEther("3000"));
    const second = await finalize(oracle, r1, r2, state({ marketPrice: ethers.parseEther("0.009"), externalDataHash: ethers.id("price-only-change") }));
    assert.equal(second.fundamentalMcap, first.fundamentalMcap);
    assert(second.marketCap > first.marketCap);
  });

  it("allocates realized revenue and forbids reserve QE into buyback", async function () {
    const [admin, controller, recorder] = await ethers.getSigners();
    const T = await ethers.getContractFactory("MockERC20");
    const token = await T.deploy("Reserve", "RSV", 18);
    const V = await ethers.getContractFactory("SHTENCOValueFlowTreasury");
    const value = await V.deploy(admin.address);
    await value.grantRole(await value.CONTROLLER_ROLE(), controller.address);
    await value.grantRole(await value.REVENUE_RECORDER_ROLE(), recorder.address);
    await value.setTokenPolicy(await token.getAddress(), { enabled: true, reserveFloor: ethers.parseEther("25"), dailyReleaseLimit: ethers.parseEther("1000") });
    await token.mint(await value.getAddress(), ethers.parseEther("100"));
    const sourceId = ethers.id("profit-1");
    await value.connect(recorder).recordRevenue(await token.getAddress(), ethers.parseEther("100"), sourceId);
    await expectRevert(value.connect(recorder).recordRevenue(await token.getAddress(), 1, sourceId), "VALUE: revenue replay");
    const alloc = { reserveBps: 3000, liquidityBps: 3000, buybackBps: 1500, bridgeBps: 1000, insuranceBps: 1000, operationsBps: 500 };
    await value.connect(controller).allocateRevenue(await token.getAddress(), ethers.parseEther("100"), alloc);
    assert.equal(await value.bucketBalance(await token.getAddress(), 0), ethers.parseEther("30"));
    assert.equal(await value.bucketBalance(await token.getAddress(), 2), ethers.parseEther("15"));
    await expectRevert(value.connect(controller).reclassifyReserveQE(await token.getAddress(), 2, 1, ethers.id("bad-qe")), "VALUE: QE target forbidden");
    await expectRevert(value.connect(controller).reclassifyReserveQE(await token.getAddress(), 1, ethers.parseEther("6"), ethers.id("floor")), "VALUE: reserve floor");
  });

  it("atomically harvests flash-like profit and allocates it under oracle policy", async function () {
    const [admin, ai, executor, guardian, r1, r2] = await ethers.getSigners();
    const T = await ethers.getContractFactory("MockERC20");
    const token = await T.deploy("USDC", "USDC", 18);
    const O = await ethers.getContractFactory("SHTENCOSystemStateOracle");
    const oracle = await O.deploy(admin.address, [r1.address, r2.address], 2);
    const snap = await finalize(oracle, r1, r2, state());
    const C = await ethers.getContractFactory("SHTENCOTopAIController");
    const controller = await C.deploy(admin.address, await oracle.getAddress(), ai.address, executor.address, guardian.address);
    const V = await ethers.getContractFactory("SHTENCOValueFlowTreasury");
    const value = await V.deploy(admin.address);
    const H = await ethers.getContractFactory("SHTENCOFlashProfitHarvester");
    const harvester = await H.deploy(admin.address, await value.getAddress());
    const P = await ethers.getContractFactory("MockProfitSource");
    const profit = await P.deploy(await harvester.getAddress());
    await value.grantRole(await value.CONTROLLER_ROLE(), await controller.getAddress());
    await value.grantRole(await value.REVENUE_RECORDER_ROLE(), await harvester.getAddress());
    await harvester.grantRole(await harvester.CONTROLLER_ROLE(), await controller.getAddress());
    await harvester.setSource(await profit.getAddress(), true);
    await value.setTokenPolicy(await token.getAddress(), { enabled: true, reserveFloor: ethers.parseEther("5"), dailyReleaseLimit: ethers.parseEther("1000") });
    await token.mint(await profit.getAddress(), ethers.parseEther("100"));
    await controller.setTarget(await harvester.getAddress(), true);
    await controller.setTarget(await value.getAddress(), true);
    await controller.setSelector(await harvester.getAddress(), harvester.interface.getFunction("harvest").selector, true, true);
    await controller.setSelector(await value.getAddress(), value.interface.getFunction("allocateRevenue").selector, true, false);
    await controller.setBudgetLimit(await token.getAddress(), ethers.parseEther("500"));
    await controller.setTimingPolicy(60, 86400, 3600, 7200);
    const amount = ethers.parseEther("100");
    const alloc = { reserveBps: 3000, liquidityBps: 3000, buybackBps: 1500, bridgeBps: 1000, insuranceBps: 1000, operationsBps: 500 };
    const actions = [
      { target: await harvester.getAddress(), value: 0, data: harvester.interface.encodeFunctionData("harvest", [await profit.getAddress(), await token.getAddress(), amount, ethers.id("flash-cycle-7")]), budgetToken: await token.getAddress(), budgetAmount: amount },
      { target: await value.getAddress(), value: 0, data: value.interface.encodeFunctionData("allocateRevenue", [await token.getAddress(), amount, alloc]), budgetToken: ethers.ZeroAddress, budgetAmount: 0 }
    ];
    const b = await ethers.provider.getBlock("latest");
    const after = b.timestamp + 65;
    const request = { snapshotRound: snap.round, objectiveHash: ethers.id("realized-profit-value"), expectedNavDelta: ethers.parseEther("2"), maxCapitalAtRisk: amount, modelRiskBps: 800, executeAfter: after, expiresAt: after + 1800 };
    const id = await controller.connect(ai).propose.staticCall(actions, request);
    await controller.connect(ai).propose(actions, request);
    await expectRevert(controller.connect(executor).execute(id), "TOP-AI: timelocked");
    await advance(66);
    await controller.connect(executor).execute(id);
    assert.equal(await token.balanceOf(await profit.getAddress()), 0n);
    assert.equal(await value.totalRealizedRevenue(await token.getAddress()), amount);
    assert.equal(await value.bucketBalance(await token.getAddress(), 1), ethers.parseEther("30"));
    assert.equal(await value.bucketBalance(await token.getAddress(), 2), ethers.parseEther("15"));
  });

  it("blocks execution after a bridge-risk deterioration", async function () {
    const [admin, ai, executor, guardian, r1, r2] = await ethers.getSigners();
    const O = await ethers.getContractFactory("SHTENCOSystemStateOracle");
    const oracle = await O.deploy(admin.address, [r1.address, r2.address], 2);
    const healthy = await finalize(oracle, r1, r2, state());
    const C = await ethers.getContractFactory("SHTENCOTopAIController");
    const c = await C.deploy(admin.address, await oracle.getAddress(), ai.address, executor.address, guardian.address);
    const M = await ethers.getContractFactory("MockActionTarget");
    const target = await M.deploy();
    await c.setTarget(await target.getAddress(), true);
    await c.setSelector(await target.getAddress(), target.interface.getFunction("setValue").selector, true, false);
    await c.setTimingPolicy(60, 86400, 3600, 7200);
    const b = await ethers.provider.getBlock("latest"); const after = b.timestamp + 65;
    const action = { target: await target.getAddress(), value: 0, data: target.interface.encodeFunctionData("setValue", [9, ethers.id("test")]), budgetToken: ethers.ZeroAddress, budgetAmount: 0 };
    const request = { snapshotRound: healthy.round, objectiveHash: ethers.id("policy-gate"), expectedNavDelta: 1, maxCapitalAtRisk: 0, modelRiskBps: 500, executeAfter: after, expiresAt: after + 1800 };
    const id = await c.connect(ai).propose.staticCall([action], request);
    await c.connect(ai).propose([action], request);
    await finalize(oracle, r1, r2, state({ bridgeImbalanceBps: 7000, externalDataHash: ethers.id("bridge-outage") }));
    await advance(66);
    await expectRevert(c.connect(executor).execute(id), "TOP-AI: bridge imbalance");
  });

  it("registers all production modules and exposes a stable topology hash", async function () {
    const [admin] = await ethers.getSigners();
    const R = await ethers.getContractFactory("SHTENCODeFiContourRegistry");
    const registry = await R.deploy(admin.address, "v3.0-test");
    const M = await ethers.getContractFactory("MockActionTarget");
    const modules = [];
    for (let i = 0; i < 9; i++) modules.push(await M.deploy());
    for (let i = 0; i < 9; i++) {
      const id = await registry.requiredModule(i);
      await registry.setModule(id, await modules[i].getAddress());
    }
    assert.equal(await registry.validateContour(), true);
    const hash1 = await registry.topologyHash();
    await registry.setVersion("v3.0.1-test");
    const hash2 = await registry.topologyHash();
    assert.notEqual(hash1, hash2);
  });

});
