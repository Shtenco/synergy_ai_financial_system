// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

// ═══════════════════════════════════════════════════════════════════════════
//  SINERGY SYSTEM — 07_EmissionEngine.sol
//  Двигатель эмиссии + Fix механизм + Buyback SYNR | Polygon
//
//  Логика из Python-модели v9.2 (исправленные масштабы):
//
//  ЭМИССИЯ (каждые 1000 блоков = ~33 мин):
//   em   = S × emitRate × 100   (для каждого токена)
//   dlp  ≈ LP × (√((S+em)/S) − 1) × 0.997  (sqrt-AMM инъекция)
//   8%  dlp → reserveR
//   70% dlp → LP пулы (batchAddLP)
//   30% dlp → WPOL → DividendPool.notifyFounderEmission() [ДОЛЯ ОСНОВАТЕЛЯ]
//
//  FIX (сложный процент, срабатывает при LP ≥ fixBase × fixThr):
//   fixEth = min(0.6% LP, 0.7% LP)
//   55% → reserveR | 25% → LP | 20% остаток
//   fixBase пересчитывается, fixThr растёт до 1.20
//
//  BUYBACK (при buybackAccum ≥ 0.005 WPOL):
//   burnAmt = S_P × accum/LP_P × 0.30  (ограничен 0.2% supply)
//   85% accum → lpP (boost LP_P)
//
//  ADAPT (каждые 20 блоков):
//   Пересчёт g_P и emitRate через KAPPA = 1.10
//   (те же формулы что в Python-модели)
//
//  ДОЛЯ ОСНОВАТЕЛЯ 30%:
//   Физически переводим WPOL (эквивалент dlp × 0.30) в DividendPool
//   через notifyFounderEmission(). Vault уже имеет этот WPOL через
//   трейдеров и fee — эмиссия использует накопленные ресурсы Vault.
//   Если WPOL в Vault недостаточно → учётно (виртуально), без transfer.
//
//  Безопасность:
//   ✓ ReentrancyGuard на executeEmission
//   ✓ CEI: все state changes до внешних вызовов
//   ✓ try/catch на mint (не ломаем систему при MAX_SUPPLY)
//   ✓ cap на buyback: 0.2% supply
//   ✓ fixBaseSet (setFixBase вызывается только один раз)
// ═══════════════════════════════════════════════════════════════════════════

import {AccessControl}   from "@openzeppelin/contracts/access/AccessControl.sol";
import {Pausable}        from "@openzeppelin/contracts/utils/Pausable.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {Math}            from "@openzeppelin/contracts/utils/math/Math.sol";
import "./01_PolygonConfig.sol";

// ── Интерфейсы (file-level) ────────────────────────────────────────────────

interface IVaultEE {
    function batchAddLP(uint256 dR, uint256 dT, uint256 dP) external;
    function addToReserveR(uint256 a)    external;
    function addToLpP(uint256 a)         external;
    function buybackAccum()              external view returns (uint256);
    function resetBuyback()              external;
    function lpP()                       external view returns (uint256);
    function lpR()                       external view returns (uint256);
    function lpT()                       external view returns (uint256);
    function totalLP()                   external view returns (uint256);
    function traderReserve()             external view returns (uint256);
    function freeWpol()                  external view returns (uint256);
    function transferWpol(address to, uint256 amount) external;
    function syncFromChain()             external;
}

interface ITokenEE {
    function mint(address to, uint256 amount) external;
    function buybackBurn(address from, uint256 amount) external;
    function totalSupply()              external view returns (uint256);
    function balanceOf(address account) external view returns (uint256);
}

interface IDivPoolEE {
    function notifyFounderEmission(uint256 amount) external;
}

// ── Custom Errors ─────────────────────────────────────────────────────────
error EE_ZeroAddress();
error EE_FixBaseAlreadySet();
error EE_EmitTooEarly(uint256 nextBlock, uint256 currentBlock);
error EE_AlphaLPOutOfRange(uint256 bps);

contract EmissionEngine is AccessControl, Pausable, ReentrancyGuard {

    bytes32 public constant CALLER_ROLE = keccak256("CALLER_ROLE"); // TroikaCore
    bytes32 public constant PAUSER_ROLE = keccak256("PAUSER_ROLE");

    uint256 public constant PRECISION     = 1e18;
    uint256 public constant KAPPA_BPS     = 11_000;  // κ = 1.10 → KAPPA_BPS / 10000
    uint256 public constant EMIT_RATE_MIN = 2e-6 * 1e18 / 1;   // 2e-6 (scaled)
    uint256 public constant EMIT_RATE_MAX = 50e-6 * 1e18 / 1;  // 5e-5 (scaled)
    uint256 public constant G_P_MIN       = 3e-6 * 1e18 / 1;
    uint256 public constant G_P_MAX       = 500e-6 * 1e18 / 1;
    uint256 public constant BUYBACK_THRESHOLD = 5e15; // 0.005 WPOL

    // Доля основателя в эмиссии (из модели: 30% dlp)
    uint256 public constant FOUNDER_EMIT_BPS = 3_000;  // 30%

    // ── Зависимости ───────────────────────────────────────────────────
    IVaultEE   public immutable vault;
    ITokenEE   public immutable syna;
    ITokenEE   public immutable sync_;
    ITokenEE   public immutable synr;
    IDivPoolEE public immutable divPool;
    address    public immutable vaultAddr;
    address    public immutable divPoolAddr;

    // ── Параметры g_P / emitRate ──────────────────────────────────────
    uint256 public gP;        // scaled by PRECISION (начальное = G_P_MIN)
    uint256 public emitRate;  // scaled by PRECISION

    // ── Fix mechanism ─────────────────────────────────────────────────
    uint256 public fixBase;
    uint256 public fixThrBPS     = 10_800;  // 1.08 × 10000
    uint256 public constant FIX_THR_MAX  = 12_000;  // 1.20
    uint256 public constant FIX_CMP_BPS  = 60;      // 0.6% compounding
    uint256 public constant FIX_THR_STEP = 18;       // шаг роста порога
    uint256 public fixCount;
    bool    public fixBaseSet;

    // ── Fee window (для адаптации) ────────────────────────────────────
    uint256 public feeWindowSum;
    uint256 public feeWindowCount;
    uint256 public alphaLPBPS = 3_500;  // текущий alphaLP из FeeRouter

    // ── Блочные метки ─────────────────────────────────────────────────
    uint256 public lastEmitBlock;
    uint256 public lastAdaptBlock;

    // ── Статистика ────────────────────────────────────────────────────
    uint256 public totalEmittedR;
    uint256 public totalEmittedT;
    uint256 public totalEmittedP;
    uint256 public totalBuybacks;
    uint256 public fixCount_total;

    // ── Events ────────────────────────────────────────────────────────
    event EmissionExecuted(uint256 emR, uint256 emT, uint256 emP, uint256 toReserve, uint256 toFounder);
    event FixExecuted(uint256 fixWpol, uint256 newThrBPS, uint256 fixN);
    event BuybackExecuted(uint256 burned, uint256 lpBoost);
    event ParamsAdapted(uint256 gP, uint256 emitRate, uint256 blockN);
    event FixBaseInitialized(uint256 base);

    constructor(
        address vault_,
        address syna_,
        address sync__,
        address synr_,
        address divPool_,
        address admin_
    ) {
        if (vault_   == address(0) || syna_   == address(0) ||
            sync__   == address(0) || synr_   == address(0) ||
            divPool_ == address(0) || admin_   == address(0)) revert EE_ZeroAddress();

        vault      = IVaultEE(vault_);
        syna      = ITokenEE(syna_);
        sync_      = ITokenEE(sync__);
        synr      = ITokenEE(synr_);
        divPool    = IDivPoolEE(divPool_);
        vaultAddr  = vault_;
        divPoolAddr= divPool_;

        gP       = G_P_MIN;
        emitRate = EMIT_RATE_MIN;

        _grantRole(DEFAULT_ADMIN_ROLE, admin_);
        _grantRole(CALLER_ROLE,        admin_);
        _grantRole(PAUSER_ROLE,        admin_);
    }

    // ── Инициализировать fixBase (один раз, после vault.initialize) ────
    function setFixBase(uint256 base_)
        external onlyRole(CALLER_ROLE)
    {
        if (fixBaseSet) revert EE_FixBaseAlreadySet();
        fixBase    = base_ > 0 ? base_ : 600e18;
        fixBaseSet = true;
        emit FixBaseInitialized(fixBase);
    }

    // ── Записать fee в окно адаптации ─────────────────────────────────
    function recordFee(uint256 amount) external whenNotPaused onlyRole(CALLER_ROLE) {
        feeWindowSum   += amount;
        feeWindowCount += 1;
    }

    // ── Синхронизировать alphaLP из FeeRouter ─────────────────────────
    function setAlphaLP(uint256 bps) external onlyRole(CALLER_ROLE) {
        if (bps < 2_800 || bps > 4_800) revert EE_AlphaLPOutOfRange(bps);
        alphaLPBPS = bps;
    }

    // ═══════════════════════════════════════════════════════════════════
    //  ADAPT g_P / emitRate (каждые 20 блоков)
    // ═══════════════════════════════════════════════════════════════════
    function adapt() external whenNotPaused onlyRole(CALLER_ROLE) {
        if (block.number < lastAdaptBlock + PolygonConfig.ADAPT_INTERVAL) return;

        uint256 avgFee = (feeWindowCount > 0)
            ? feeWindowSum / feeWindowCount
            : 5e14; // fallback 0.0005 WPOL

        feeWindowSum   = 0;
        feeWindowCount = 0;

        uint256 totalLpV = vault.totalLP();
        if (totalLpV == 0) {
            lastAdaptBlock = block.number;
            return;
        }

        // fee_lp_rate = avgFee × alphaLP / totalLP  (в единицах PRECISION)
        uint256 feeLpRate = Math.mulDiv(avgFee * alphaLPBPS / 10_000, PRECISION, totalLpV);

        // emitNeeded = (κ × g_P − feeLpRate) / (1 + κ/2)
        uint256 kGP = gP * KAPPA_BPS / 10_000;
        uint256 emitNeeded;
        if (kGP > feeLpRate) {
            uint256 denom = PRECISION + (KAPPA_BPS * PRECISION / 10_000 / 2);
            emitNeeded = Math.mulDiv(kGP - feeLpRate, PRECISION, denom);
        } else {
            emitNeeded = EMIT_RATE_MIN;
        }

        emitRate = _clamp(emitNeeded, EMIT_RATE_MIN, EMIT_RATE_MAX);
        // g_P = (feeLpRate + emitRate) / κ
        gP = _clamp(
            (feeLpRate + emitRate) * 10_000 / KAPPA_BPS,
            G_P_MIN, G_P_MAX
        );

        lastAdaptBlock = block.number;
        emit ParamsAdapted(gP, emitRate, block.number);
    }

    // ═══════════════════════════════════════════════════════════════════
    //  EXECUTE EMISSION (каждые 1000 блоков)
    // ═══════════════════════════════════════════════════════════════════
    function executeEmission()
        external nonReentrant whenNotPaused onlyRole(CALLER_ROLE)
    {
        if (block.number < lastEmitBlock + PolygonConfig.EMIT_INTERVAL)
            revert EE_EmitTooEarly(lastEmitBlock + PolygonConfig.EMIT_INTERVAL, block.number);

        // ── Snapshot supply ───────────────────────────────────────────
        uint256 sR = syna.totalSupply();
        uint256 sT = sync_.totalSupply();
        uint256 sP = synr.totalSupply();

        // ── Расчёт em для каждого токена ──────────────────────────────
        // em = S × emitRate × 100 / PRECISION
        uint256 emR = sR * emitRate * 100 / PRECISION;
        uint256 emT = sT * emitRate * 100 / PRECISION;
        uint256 emP = sP * emitRate * 100 / PRECISION;

        uint256 totalLpV = vault.totalLP();

        // ── sqrt-AMM dlp ──────────────────────────────────────────────
        // dlp ≈ LP × (√(1 + em/S) − 1) × 0.997
        // ≈ LP × em/(2×S) × 0.997  (линейное прибл. при малом em)
        uint256 lpRv = vault.lpR();
        uint256 lpTv = vault.lpT();
        uint256 lpPv = vault.lpP();

        uint256 dlpR = (sR > 0 && lpRv > 0) ? _sqrtAmmDlp(lpRv, emR, sR) : 0;
        uint256 dlpT = (sT > 0 && lpTv > 0) ? _sqrtAmmDlp(lpTv, emT, sT) : 0;
        uint256 dlpP = (sP > 0 && lpPv > 0) ? _sqrtAmmDlp(lpPv, emP, sP) : 0;

        uint256 dlpTotal = dlpR + dlpT + dlpP;

        // ── Распределение dlp (CEI: Effects до Interactions) ──────────
        // 8% → reserveR | 30% → founder | 62% → LP
        uint256 toReserve = dlpTotal * 8 / 100;
        uint256 toFounder = dlpTotal * FOUNDER_EMIT_BPS / 10_000; // 30%
        uint256 toLpTotal = dlpTotal - toReserve - toFounder;

        // Пропорционально по пулам
        uint256 toLpR = dlpTotal > 0 ? Math.mulDiv(toLpTotal, dlpR, dlpTotal) : 0;
        uint256 toLpT = dlpTotal > 0 ? Math.mulDiv(toLpTotal, dlpT, dlpTotal) : 0;
        uint256 toLpP = (dlpTotal > 0 && toLpTotal >= toLpR + toLpT)
                        ? toLpTotal - toLpR - toLpT : 0;

        // Effects (все state changes до mint и transfer)
        lastEmitBlock = block.number;

        // ── Mint токены в Vault ───────────────────────────────────────
        // (try/catch — MAX_SUPPLY не ломает систему)
        if (emR > 0) { try syna.mint(vaultAddr, emR) {} catch {} totalEmittedR += emR; }
        if (emT > 0) { try sync_.mint(vaultAddr, emT) {} catch {} totalEmittedT += emT; }
        if (emP > 0) { try synr.mint(vaultAddr, emP) {} catch {} totalEmittedP += emP; }

        // ── LP (виртуальный учёт) ─────────────────────────────────────
        if (toLpTotal > 0) {
            vault.batchAddLP(toLpR, toLpT, toLpP);
        }

        // ── reserveR ──────────────────────────────────────────────────
        if (toReserve > 0) {
            vault.addToReserveR(toReserve);
        }

        // ── Доля основателя 30% → DividendPool ────────────────────────
        // Физически WPOL переводим из Vault если хватает freeWpol
        uint256 actualFounderWpol = 0;
        if (toFounder > 0) {
            uint256 freeW = vault.freeWpol();
            if (freeW >= toFounder) {
                // CEI: Vault.transferWpol → DivPool.notifyFounderEmission
                vault.transferWpol(divPoolAddr, toFounder);
                divPool.notifyFounderEmission(toFounder);
                actualFounderWpol = toFounder;
            } else if (freeW >= 1e12) {
                // Частичный перевод того что есть
                vault.transferWpol(divPoolAddr, freeW);
                divPool.notifyFounderEmission(freeW);
                actualFounderWpol = freeW;
            }
            // Если WPOL нет — учётно (виртуально), без transfer
        }

        emit EmissionExecuted(emR, emT, emP, toReserve, actualFounderWpol);

        // ── Fix mechanism ─────────────────────────────────────────────
        _checkFix();

        // ── Buyback SYNR ─────────────────────────────────────────────
        _checkBuyback();

        // ── Sync ──────────────────────────────────────────────────────
        vault.syncFromChain();
        (totalLpV); // suppress unused warning
    }

    // ── sqrt-AMM dlp инъекция ─────────────────────────────────────────
    // dlp = LP × (√((S+em)/S) − 1) × 0.997
    // ≈ LP × em / (2×S) × 0.997  при em << S
    // Используем точную формулу через Math.sqrt
    function _sqrtAmmDlp(uint256 lpV, uint256 em, uint256 supply)
        private pure returns (uint256)
    {
        if (supply == 0 || em == 0) return 0;
        // Масштабируем для sqrt: ratio = (S+em)/S × PRECISION²
        // sqrt(ratio × PRECISION²) = sqrt((S+em)/S) × PRECISION
        uint256 newS   = supply + em;
        // sqrt(newS × PRECISION / supply) - PRECISION
        uint256 sqrtRatio;
        // Используем Math.sqrt из OZ: входит в OZ 5.x
        // sqrt(newS * 1e18 / supply) приближение
        uint256 ratio = Math.mulDiv(newS, PRECISION, supply); // (S+em)/S × 1e18
        sqrtRatio = _sqrt(ratio * PRECISION); // √(ratio × 1e18) = sqrt((S+em)/S) × 1e9
        // sqrtRatio / 1e9 = √((S+em)/S) × 1e9, надо в единицах 1e18
        // lp_factor = sqrtRatio - 1e9 (единицы: 1e9 = 1.0)
        uint256 SQRT_PREC = 1e18;
        if (sqrtRatio <= SQRT_PREC) return 0;
        uint256 factor = sqrtRatio - SQRT_PREC;
        // dlp = lpV × factor / 1e9 × 997 / 1000
        return Math.mulDiv(lpV, factor * 997, SQRT_PREC * 1000);
    }

    // Целочисленное sqrt (Babylonian method)
    function _sqrt(uint256 x) private pure returns (uint256 y) {
        if (x == 0) return 0;
        uint256 z = x;
        y = x;
        unchecked {
            while (true) {
                z = (y + x / y) / 2;
                if (z >= y) break;
                y = z;
            }
        }
    }

    // ── Fix mechanism ─────────────────────────────────────────────────
    function _checkFix() private {
        if (!fixBaseSet || fixBase == 0) return;
        uint256 totalLpV = vault.totalLP();
        uint256 thresh   = Math.mulDiv(fixBase, fixThrBPS, 10_000);
        if (totalLpV < thresh) return;

        uint256 fixWpol = totalLpV * 6 / 1_000;
        uint256 cap     = totalLpV * 7 / 1_000;
        if (fixWpol > cap) fixWpol = cap;
        if (fixWpol == 0) return;

        // 55% → reserveR | 25% → LP (65%P / 22%R / 13%T) | 20% → зарезервировано
        uint256 toRR = fixWpol * 55 / 100;
        uint256 toLp = fixWpol * 25 / 100;
        vault.batchAddLP(toLp * 22/100, toLp * 13/100, toLp * 65/100);
        vault.addToReserveR(toRR);

        // Обновить fixBase и порог
        fixBase    = Math.mulDiv(fixBase, fixThrBPS * (10_000 + FIX_CMP_BPS), 10_000 * 10_000);
        fixThrBPS  = fixThrBPS + FIX_THR_STEP;
        if (fixThrBPS > FIX_THR_MAX) fixThrBPS = FIX_THR_MAX;
        ++fixCount;

        emit FixExecuted(fixWpol, fixThrBPS, fixCount);
    }

    // ── Buyback SYNR ─────────────────────────────────────────────────
    function _checkBuyback() private {
        uint256 accum = vault.buybackAccum();
        if (accum < BUYBACK_THRESHOLD) return;

        uint256 lpPv = vault.lpP();
        uint256 sP   = synr.totalSupply();
        if (lpPv == 0 || sP == 0) return;

        // burnAmt = S_P × accum/LP_P × 0.30, ограничен 0.2% supply
        uint256 burnRaw = Math.mulDiv(sP, accum * 30 / 100, lpPv);
        uint256 burnCap = sP * 2 / 1_000; // 0.2%
        if (burnCap == 0) burnCap = 1;
        uint256 burnAmt = burnRaw < burnCap ? burnRaw : burnCap;

        // LP boost: 85% accum
        uint256 lpBoost = accum * 85 / 100;

        // Effects
        vault.resetBuyback();
        vault.addToLpP(lpBoost);

        // Interactions (try/catch — buybackBurn cap не ломает)
        if (burnAmt > 0 && synr.balanceOf(vaultAddr) >= burnAmt) {
            try synr.buybackBurn(vaultAddr, burnAmt) {
                totalBuybacks += burnAmt;
                emit BuybackExecuted(burnAmt, lpBoost);
            } catch {
                emit BuybackExecuted(0, lpBoost);
            }
        } else {
            emit BuybackExecuted(0, lpBoost);
        }
    }

    // ── VIEW ──────────────────────────────────────────────────────────
    function isEmissionDue() external view returns (bool) {
        return block.number >= lastEmitBlock + PolygonConfig.EMIT_INTERVAL;
    }

    function getParams() external view returns (uint256 gP_, uint256 emitRate_) {
        return (gP, emitRate);
    }

    function _clamp(uint256 v, uint256 lo, uint256 hi) private pure returns (uint256) {
        return v < lo ? lo : (v > hi ? hi : v);
    }

    function pause()   external onlyRole(PAUSER_ROLE) { _pause(); }
    function unpause() external onlyRole(PAUSER_ROLE) { _unpause(); }
}
