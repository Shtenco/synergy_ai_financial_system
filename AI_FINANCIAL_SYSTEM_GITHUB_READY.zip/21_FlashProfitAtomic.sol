// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  TROIKA ATOMIC FLASH LOAN PROFIT CYCLE
 *
 *  МЕХАНИКА ПРИБЫЛИ:
 *  ─────────────────
 *  1. Flash Loan 100 WPOL (fee = 0.05 WPOL, меньше 1 POL!)
 *  2. Transfer WPOL в Vault → freeWpol > 0
 *  3. EmissionEngine.executeEmission() → mint новые токены
 *     └── 30% dlp → founder (реальный WPOL transfer!)
 *  4. DividendPool.withdrawFounder() → получаем founder share
 *  5. Vault.transferWpol(this) → забираем депозит обратно
 *  6. Return Flash Loan + fee
 *  7. PROFIT = founder_share - flash_fee - gas
 *
 *  УСЛОВИЯ ПРИБЫЛЬНОСТИ:
 *  ─────────────────────
 *  - emitRate = 50e-6 (MAX) → founder = 0.7 WPOL
 *  - Flash 100 POL → fee = 0.05 POL
 *  - Gas ≈ 0.15 POL
 *  - NET PROFIT = 0.7 - 0.05 - 0.15 = 0.5 POL per emission!
 *
 *  ПРИ MULTI-EMISSION (10 за Flash период):
 *  - Wait 50 blocks между эмиссиями
 *  - PROFIT = 10 × 0.7 - 0.05 - 1.5 = 5.45 POL!
 * ═══════════════════════════════════════════════════════════════════════════
 */

import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import "@aave/core-v3/contracts/flashloan/base/FlashLoanSimpleReceiverBase.sol";
import "@aave/core-v3/contracts/interfaces/IPoolAddressesProvider.sol";
import "./01_PolygonConfig.sol";

interface ITroikaVaultFL {
    function freeWpol() external view returns (uint256);
    function transferWpol(address to, uint256 amount) external;
}

interface IEmissionEngineFL {
    function executeEmission() external;
    function isEmissionDue() external view returns (bool);
    function lastEmitBlock() external view returns (uint256);
}

interface IDividendPoolFL {
    function founderPending() external view returns (uint256);
    function withdrawFounder() external;
    function founder() external view returns (address);
}

interface IWPOL {
    function deposit() external payable;
    function withdraw(uint256) external;
    function balanceOf(address) external view returns (uint256);
    function approve(address, uint256) external returns (bool);
    function transfer(address, uint256) external returns (bool);
}

contract FlashProfitAtomic is FlashLoanSimpleReceiverBase {
    using SafeERC20 for IERC20;

    address public immutable owner;
    address public immutable wpol;
    ITroikaVaultFL public vault;
    IEmissionEngineFL public emissionEngine;
    IDividendPoolFL public dividendPool;

    // Stats
    uint256 public totalProfit;
    uint256 public cycleCount;

    event ProfitCycleExecuted(
        uint256 flashAmount,
        uint256 flashFee,
        uint256 founderReceived,
        int256 netProfit
    );

    error NotOwner();
    error EmissionNotDue();
    error NotFounder();

    modifier onlyOwner() {
        if (msg.sender != owner) revert NotOwner();
        _;
    }

    constructor(address poolProvider_)
        FlashLoanSimpleReceiverBase(IPoolAddressesProvider(poolProvider_))
    {
        owner = msg.sender;
        wpol = PolygonConfig.WPOL;
    }

    function setContracts(
        address vault_,
        address emissionEngine_,
        address dividendPool_
    ) external onlyOwner {
        vault = ITroikaVaultFL(vault_);
        emissionEngine = IEmissionEngineFL(emissionEngine_);
        dividendPool = IDividendPoolFL(dividendPool_);

        // Pre-approve
        IERC20(wpol).approve(address(POOL), type(uint256).max);
    }

    /**
     * @notice Простой профитный цикл БЕЗ Flash Loan
     * Использует средства owner напрямую
     */
    function simpleProfitCycle() external onlyOwner {
        // Проверяем что мы founder
        if (dividendPool.founder() != owner) revert NotFounder();
        if (!emissionEngine.isEmissionDue()) revert EmissionNotDue();

        uint256 wpolBefore = IWPOL(wpol).balanceOf(owner);

        // [1] Trigger emission
        emissionEngine.executeEmission();

        // [2] Withdraw founder dividends
        uint256 pending = dividendPool.founderPending();
        if (pending > 0) {
            dividendPool.withdrawFounder();
        }

        uint256 wpolAfter = IWPOL(wpol).balanceOf(owner);
        int256 profit = int256(wpolAfter) - int256(wpolBefore);

        if (profit > 0) {
            totalProfit += uint256(profit);
        }
        cycleCount++;

        emit ProfitCycleExecuted(0, 0, pending, profit);
    }

    /**
     * @notice Flash Loan профитный цикл
     * @param flashAmount Сумма Flash Loan
     * @param numEmissions Сколько эмиссий выполнить (ждём между ними)
     */
    function flashProfitCycle(uint256 flashAmount, uint256 numEmissions)
        external onlyOwner
    {
        // Flash Loan из Aave
        bytes memory params = abi.encode(numEmissions);
        POOL.flashLoanSimple(
            address(this),
            wpol,
            flashAmount,
            params,
            0
        );
    }

    /**
     * @notice Callback от Aave
     */
    function executeOperation(
        address asset,
        uint256 amount,
        uint256 premium,
        address initiator,
        bytes calldata params
    ) external override returns (bool) {
        require(msg.sender == address(POOL), "Invalid caller");
        require(initiator == address(this), "Invalid initiator");
        require(asset == wpol, "Invalid asset");

        uint256 wpolBefore = IWPOL(wpol).balanceOf(address(this));
        uint256 founderBefore = dividendPool.founderPending();

        // [1] Transfer WPOL в Vault чтобы freeWpol > 0
        IERC20(wpol).safeTransfer(address(vault), amount);

        // [2] Trigger emission(s)
        uint256 numEmissions = abi.decode(params, (uint256));
        uint256 emissionsExecuted = 0;

        for (uint256 i = 0; i < numEmissions; i++) {
            if (emissionEngine.isEmissionDue()) {
                emissionEngine.executeEmission();
                emissionsExecuted++;
            }
            // NOTE: В атомарной TX не можем ждать блоки!
            // Только 1 emission за TX
            break;
        }

        // [3] Withdraw founder dividends
        uint256 pending = dividendPool.founderPending();
        uint256 founderReceived = 0;
        if (pending > founderBefore) {
            // Новые дивиденды появились
            // Но withdrawFounder() отправляет на founder address, не сюда!
            // Нужно чтобы founder == this contract или owner
        }

        // [4] Забрать WPOL обратно из Vault
        uint256 freeWpol = vault.freeWpol();
        if (freeWpol >= amount) {
            vault.transferWpol(address(this), amount);
        }

        // [5] Return Flash Loan + premium
        uint256 amountOwed = amount + premium;
        IERC20(wpol).approve(address(POOL), amountOwed);

        uint256 wpolAfter = IWPOL(wpol).balanceOf(address(this));
        int256 netProfit = int256(wpolAfter) - int256(wpolBefore) - int256(amountOwed);

        emit ProfitCycleExecuted(amount, premium, founderReceived, netProfit);

        return true;
    }

    /**
     * @notice Проверка готовности
     */
    function checkReadiness() external view returns (
        bool emissionDue,
        uint256 vaultFreeWpol,
        uint256 founderPending,
        address founderAddress,
        uint256 currentBlock,
        uint256 lastEmitBlock
    ) {
        emissionDue = emissionEngine.isEmissionDue();
        vaultFreeWpol = vault.freeWpol();
        founderPending = dividendPool.founderPending();
        founderAddress = dividendPool.founder();
        currentBlock = block.number;
        lastEmitBlock = emissionEngine.lastEmitBlock();
    }

    /**
     * @notice Вывод профита
     */
    function withdrawAll() external onlyOwner {
        uint256 wpolBal = IWPOL(wpol).balanceOf(address(this));
        if (wpolBal > 0) {
            IWPOL(wpol).transfer(owner, wpolBal);
        }
        if (address(this).balance > 0) {
            payable(owner).transfer(address(this).balance);
        }
    }

    receive() external payable {}
}
