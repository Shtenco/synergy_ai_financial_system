// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

// ═══════════════════════════════════════════════════════════════════════════
//  SINERGY DEFLATION SYSTEM — 15_CircularDeployer.sol
//  Деплой CollateralEmission + CircularHub за одну транзакцию
//
//  Предусловия:
//   - ALTN задеплоен: 0x1132B52E7C28c2082564C8aaa3294C4096CD1C83
//   - SINERGY система задеплоена через 12_TroikaDeployer.sol
//   - Адреса из deployed_sinergy.json готовы
// ═══════════════════════════════════════════════════════════════════════════

import {IERC20}    from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import "./13_CollateralEmission.sol";
import "./14_CircularHub_v2.sol";

interface IGrantRole {
    function grantRole(bytes32 role, address account) external;
    function KEEPER_ROLE()       external view returns (bytes32);
    function OPERATOR_ROLE()     external view returns (bytes32);
    function CONTRIBUTOR_ROLE()  external view returns (bytes32);
    function NOTIFIER_ROLE()     external view returns (bytes32);
    function CALLER_ROLE()       external view returns (bytes32);
}

interface ICircularHub2 { function setMutualPoolRouter(address) external; }
error CD_AlreadyDeployed();
error CD_ZeroAddress();

contract CircularDeployer {
    using SafeERC20 for IERC20;

    CollateralEmission public collEmit;
    CircularHubV2      public hub;
    bool               public deployed;

    event CircularDeployed(
        address indexed owner,
        address collEmit_,
        address hub_,
        uint256 blockN
    );

    struct SINERGYAddr {
        address core;
        address vault;
        address syna;       // SYNA token (мintintg)
        address synr;       // SYNR token
        address sync_;      // SYNC token
        address synrPair;   // SYNR/WPOL pair
        address loop_;
        address emitEngine;
        address divPool;
        address founder;
        address mpRouter;   // MutualPoolRouter (deploy after Circular)
    }

    struct ALTNAddr {
        address altn;       // 0x1132B52E7C28c2082564C8aaa3294C4096CD1C83
        address altnPair;   // 0xF59F26817003d7FF3ab9699c9aC1f538DBA00EB4
    }

    function deploy(SINERGYAddr calldata s, ALTNAddr calldata a) external {
        if (deployed)                       revert CD_AlreadyDeployed();
        if (a.altn == address(0) || s.core == address(0)) revert CD_ZeroAddress();
        deployed = true;
        address owner = msg.sender;

        // ── 1. CollateralEmission ─────────────────────────────────────
        collEmit = new CollateralEmission(
            s.syna, a.altn, a.altnPair,
            s.vault, s.loop_, s.divPool,
            owner
        );

        // ── 2. CircularHubV2 ──────────────────────────────────────────
        hub = new CircularHubV2(
            a.altn,       a.altnPair,
            s.core,       s.vault,
            s.loop_,      s.emitEngine,
            address(collEmit), s.divPool,
            s.synrPair,   s.synr,
            owner
        );

        // ── 3. Выдача ролей ───────────────────────────────────────────
        _grantRoles(s, a, owner);

        // Связать Hub с MutualPoolRouter если задан
        if (s.mpRouter != address(0)) {
            try ICircularHub2(address(hub)).setMutualPoolRouter(s.mpRouter) {} catch {}
        }

        emit CircularDeployed(owner, address(collEmit), address(hub), block.number);
    }

    function _grantRoles(SINERGYAddr calldata s, ALTNAddr calldata a, address owner) private {
        address hubA      = address(hub);
        address collEmitA = address(collEmit);

        // Hub нужен KEEPER_ROLE в ALTN (чтобы вызывать maintenance())
        try IGrantRole(a.altn).grantRole(
            IGrantRole(a.altn).KEEPER_ROLE(), hubA
        ) {} catch {}

        // Hub нужен CALLER_ROLE / ADMIN в TroikaCore (чтобы вызывать tick())
        try IGrantRole(s.core).grantRole(
            keccak256("ADMIN_ROLE"), hubA
        ) {} catch {}

        // Hub нужен OPERATOR_ROLE в TroikaVault
        try IGrantRole(s.vault).grantRole(
            IGrantRole(s.vault).OPERATOR_ROLE(), hubA
        ) {} catch {}

        // Hub нужен CONTRIBUTOR_ROLE в SelfReinforcingLoop
        try IGrantRole(s.loop_).grantRole(
            IGrantRole(s.loop_).CONTRIBUTOR_ROLE(), hubA
        ) {} catch {}

        // CollEmit нужен OPERATOR_ROLE в Vault
        try IGrantRole(s.vault).grantRole(
            IGrantRole(s.vault).OPERATOR_ROLE(), collEmitA
        ) {} catch {}

        // CollEmit нужен CONTRIBUTOR_ROLE в Loop
        try IGrantRole(s.loop_).grantRole(
            IGrantRole(s.loop_).CONTRIBUTOR_ROLE(), collEmitA
        ) {} catch {}

        // CollEmit нужен NOTIFIER_ROLE в DividendPool
        try IGrantRole(s.divPool).grantRole(
            IGrantRole(s.divPool).NOTIFIER_ROLE(), collEmitA
        ) {} catch {}

        // CollEmit нужен MINTER_ROLE + BURNER_ROLE в SYNA
        try IGrantRole(s.syna).grantRole(keccak256("MINTER_ROLE"), collEmitA) {} catch {}
        try IGrantRole(s.syna).grantRole(keccak256("BURNER_ROLE"), collEmitA) {} catch {}

        // Hub → CollEmit: KEEPER_ROLE (для processCircular)
        collEmit.grantRole(keccak256("KEEPER_ROLE"), hubA);
        collEmit.grantRole(keccak256("LIQUIDATOR_ROLE"), owner);

        // EmissionEngine → Hub: EMIT_ROLE (для onPriceUpdate)
        hub.grantEmitRole(s.emitEngine);

        // ALTN → Hub: ALTN_ROLE (для onALTNBurn)
        hub.grantALTNRole(a.altn);
    }
}
