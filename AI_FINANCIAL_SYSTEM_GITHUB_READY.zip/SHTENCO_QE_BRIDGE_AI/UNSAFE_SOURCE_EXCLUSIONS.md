# Source exclusions

The uploaded bridge archive was reviewed as an input source. Its threshold-signature and fork-testing ideas were retained in a new implementation. Historical mainnet automation and files whose purpose or naming indicated artificial pumping, wash trading, uncontrolled repeated live cycles, or direct cash-out were not copied into the production module.

Examples of excluded categories:

- `*pump*`, `*washtrade*` and price-fix scripts;
- repeated `live_*cycles*` transaction runners;
- scripts that use zero slippage limits or catch and suppress failures;
- private keys and `.env` material;
- historical deployment reports that are not authoritative configuration;
- generated caches and old artifacts.

The original uploaded archive remains unchanged outside the new final package. This file records the migration boundary so unsafe experimental code is not mistaken for the audited production path.
