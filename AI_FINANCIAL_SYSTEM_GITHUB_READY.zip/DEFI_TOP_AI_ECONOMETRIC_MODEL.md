# Эконометрическая модель генерации стоимости

## 1. Фундаментальная база

Все показатели приводятся к одной внешней расчётной единице, например USD 1e18.

```text
BackingNAVₜ = LiquidReservesₜ
             + OwnedLPNAVₜ
             + BridgeCapitalₜ
             + InsuranceFundₜ
             − Liabilitiesₜ
```

LP учитывается только в доле, принадлежащей системе, и оценивается по независимым reference/oracle prices. Цена внутреннего пула не используется как единственный источник оценки.

## 2. Реальный денежный поток

```text
NetRevenueₜ = ProtocolFeesₜ
            + FlashArbitrageProfitₜ
            + ReserveYieldₜ
            + BridgeFeesₜ
            − Gasₜ
            − OperatingCostₜ
            − RealizedLossesₜ
```

Flash loan не является капиталом системы и не входит в NAV. В стоимость попадает только чистая прибыль после premium Aave, газа, slippage и execution margin.

## 3. Консервативная фундаментальная стоимость

```text
DiscountedRevenueValueₜ = max(NetRevenue30dₜ, 0)
                         × RevenueHorizonMonths
                         × RevenueHaircut

FundamentalMCapₜ = BackingNAVₜ + DiscountedRevenueValueₜ
FundamentalPriceₜ = FundamentalMCapₜ / CirculatingSupplyₜ
```

Значения по умолчанию: горизонт 12 месяцев, haircut 50%. Governance может уменьшить их, но не должна использовать агрессивный multiple без внешнего аудита.

## 4. Декомпозиция роста

```text
ΔBackingNAV = realized external income
            − execution losses
            − gas
            − operating extraction
            − security/bridge/bad-debt losses
```

Добавление LP и bridge QE не создают стоимость мгновенно. Они меняют структуру активов и могут повышать будущую комиссионную выручку.

## 5. Buyback

Buyback оплачивается только из bucket `BUYBACK`, сформированного из реализованного дохода. Резервный QE не может быть переведён в buyback.

Модель разрешает buyback только когда market price не выше fundamental price более чем на установленный premium. Это снижает риск уничтожения backing value покупкой переоценённого токена.

## 6. Целевая функция AI

Monte Carlo / MPC оптимизатор максимизирует:

```text
Expected FundamentalMCap Growth
+ 0.65 × Expected BackingNAV Growth
+ 0.20 × Expected FundamentalPrice Growth
+ Liquidity Reward
− CVaR Downside Penalty
− Loss Probability Penalty
− Reserve Deficit Penalty
− Bridge Imbalance Penalty
```

Ограничения:

- reserve ratio;
- valuation premium;
- peg error;
- volatility;
- bridge imbalance;
- liquidity coverage;
- maximum capital at risk;
- monthly QE cap;
- allocation bounds;
- buyback valuation condition.

## 7. Почему рыночная капитализация не гарантируется

Рыночная капитализация зависит от внешнего спроса, ликвидности, поведения держателей и общего рынка. Контур способен улучшать backing, доход, глубину и supply discipline, но не может честно гарантировать цену. В отчётах отдельно показываются `market_mcap` и `fundamental_mcap`.
