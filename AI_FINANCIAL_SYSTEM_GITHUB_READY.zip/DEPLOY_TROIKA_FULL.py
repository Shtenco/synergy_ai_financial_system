#!/usr/bin/env python3
"""
ДЕПЛОЙ ПОЛНОЙ СИСТЕМЫ TROIKA ЧЕРЕЗ TroikaDeployer
"""
import sys, io, os, json, time
from dotenv import load_dotenv
from web3 import Web3
from web3.middleware import ExtraDataToPOAMiddleware

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

load_dotenv()

w3 = Web3(Web3.HTTPProvider("https://polygon-bor-rpc.publicnode.com", request_kwargs={"timeout": 300}))
w3.middleware_onion.inject(ExtraDataToPOAMiddleware, layer=0)

PK = os.getenv("OWNER_PRIVATE_KEY")
OWNER = "0x6946999DBCE63b140B1bB9D475F7c357130909E5"
WPOL = "0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270"

def C(a): return Web3.to_checksum_address(a)

print("=" * 70)
print("ДЕПЛОЙ TROIKA ЧЕРЕЗ TroikaDeployer")
print("=" * 70)

bal = w3.eth.get_balance(C(OWNER)) / 1e18
print(f"POL: {bal:.4f}")

WPOL_ABI = [
    {"name": "balanceOf", "inputs": [{"type": "address"}], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "deposit", "inputs": [], "outputs": [], "stateMutability": "payable", "type": "function"},
    {"name": "approve", "inputs": [{"name": "spender", "type": "address"}, {"name": "amount", "type": "uint256"}], "outputs": [{"type": "bool"}], "stateMutability": "nonpayable", "type": "function"},
]

wpol_contract = w3.eth.contract(address=C(WPOL), abi=WPOL_ABI)
wpol_bal = wpol_contract.functions.balanceOf(C(OWNER)).call() / 1e18
print(f"WPOL: {wpol_bal:.4f}")
print(f"TOTAL: {bal + wpol_bal:.4f}")
print("=" * 70)

# Загрузить артефакт
with open("out/12_TroikaDeployer.sol/TroikaDeployer.json") as f:
    artifact = json.load(f)

deployer_abi = artifact["abi"]
deployer_bytecode = artifact["bytecode"]["object"]

print(f"Bytecode size: {len(deployer_bytecode) // 2} bytes")

# Параметры (минимальные для теста)
# wpolR + wpolT + wpolP + trRes + rrRes + mcgRes + keeperSeed
wpolR = int(3e18)   # 3 POL
tokR = int(2e18)    # 2 SYNA
wpolT = int(3e18)   # 3 POL
tokT = int(19e18)   # 19 SYNC
wpolP = int(3e18)   # 3 POL
tokP = int(4e18)    # 4 SYNR
trRes = int(1e18)   # 1 POL
rrRes = int(1e18)   # 1 POL
mcgRes = int(1e18)  # 1 POL
keeperSeed = int(1e18)  # 1 POL

totalWpol = wpolR + wpolT + wpolP + trRes + rrRes + mcgRes + keeperSeed
print(f"\nНужно WPOL: {totalWpol / 1e18:.4f}")

# Wrap POL -> WPOL если надо
if wpol_bal * 1e18 < totalWpol:
    need_wrap = (totalWpol / 1e18) - wpol_bal + 0.5  # +0.5 запас
    print(f"Wrap {need_wrap:.4f} POL -> WPOL...")

    nonce = w3.eth.get_transaction_count(C(OWNER), "pending")
    base = w3.eth.get_block("latest").get("baseFeePerGas", int(100e9))
    prio = int(50e9)
    mf = base * 2 + prio

    tx = wpol_contract.functions.deposit().build_transaction({
        "from": C(OWNER), "nonce": nonce, "chainId": 137, "type": 2,
        "maxPriorityFeePerGas": prio, "maxFeePerGas": mf, "gas": 100000,
        "value": int(need_wrap * 1e18)
    })
    signed = w3.eth.account.sign_transaction(tx, PK)
    h = w3.eth.send_raw_transaction(signed.raw_transaction)
    r = w3.eth.wait_for_transaction_receipt(h, timeout=120)
    print(f"  {'OK' if r.status else 'FAIL'}")
    time.sleep(3)

    wpol_bal = wpol_contract.functions.balanceOf(C(OWNER)).call() / 1e18
    print(f"WPOL now: {wpol_bal:.4f}")

nonce = w3.eth.get_transaction_count(C(OWNER), "pending")
base = w3.eth.get_block("latest").get("baseFeePerGas", int(100e9))
prio = int(50e9)
mf = base * 2 + prio

# ═══════════════════════════════════════════════════════════════════════════
# 1. DEPLOY TroikaDeployer
# ═══════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 70)
print("[1] DEPLOY TroikaDeployer")
print("=" * 70)

contract = w3.eth.contract(abi=deployer_abi, bytecode=deployer_bytecode)

tx = contract.constructor().build_transaction({
    "from": C(OWNER), "nonce": nonce, "chainId": 137, "type": 2,
    "maxPriorityFeePerGas": prio, "maxFeePerGas": mf, "gas": 25_000_000
})

signed = w3.eth.account.sign_transaction(tx, PK)
h = w3.eth.send_raw_transaction(signed.raw_transaction)
print(f"TX: {h.hex()}")

r = w3.eth.wait_for_transaction_receipt(h, timeout=600)
cost = r.gasUsed * mf / 1e18

if r.status == 1:
    deployer_addr = r.contractAddress
    print(f"[OK] TroikaDeployer: {deployer_addr}")
    print(f"     Gas: {cost:.4f} POL")
    nonce += 1
else:
    print("[FAIL] Deploy failed")
    sys.exit(1)

time.sleep(5)

# ═══════════════════════════════════════════════════════════════════════════
# 2. APPROVE WPOL
# ═══════════════════════════════════════════════════════════════════════════
print("\n[2] APPROVE WPOL...")

tx = wpol_contract.functions.approve(C(deployer_addr), int(1e30)).build_transaction({
    "from": C(OWNER), "nonce": nonce, "chainId": 137, "type": 2,
    "maxPriorityFeePerGas": prio, "maxFeePerGas": mf, "gas": 100000
})
signed = w3.eth.account.sign_transaction(tx, PK)
h = w3.eth.send_raw_transaction(signed.raw_transaction)
r = w3.eth.wait_for_transaction_receipt(h, timeout=120)
print(f"  {'OK' if r.status else 'FAIL'}")
nonce += 1
time.sleep(3)

# ═══════════════════════════════════════════════════════════════════════════
# 3. CALL deploy()
# ═══════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 70)
print("[3] CALL deploy()")
print("=" * 70)
print(f"Founder: {OWNER}")
print(f"wpolR={wpolR/1e18}, tokR={tokR/1e18}")
print(f"wpolT={wpolT/1e18}, tokT={tokT/1e18}")
print(f"wpolP={wpolP/1e18}, tokP={tokP/1e18}")

deployer = w3.eth.contract(address=C(deployer_addr), abi=deployer_abi)

deploy_func = deployer.functions.deploy(
    C(OWNER),  # founder
    wpolR, tokR,
    wpolT, tokT,
    wpolP, tokP,
    trRes, rrRes, mcgRes, keeperSeed
)

tx = deploy_func.build_transaction({
    "from": C(OWNER), "nonce": nonce, "chainId": 137, "type": 2,
    "maxPriorityFeePerGas": prio, "maxFeePerGas": mf, "gas": 30_000_000
})

print(f"\nTX deploy()...")
signed = w3.eth.account.sign_transaction(tx, PK)
h = w3.eth.send_raw_transaction(signed.raw_transaction)
print(f"TX: {h.hex()}")

r = w3.eth.wait_for_transaction_receipt(h, timeout=900)
cost = r.gasUsed * mf / 1e18

if r.status == 1:
    print(f"\n[OK] СИСТЕМА РАЗВЁРНУТА!")
    print(f"     Gas: {cost:.4f} POL")
    nonce += 1
else:
    print(f"\n[FAIL] deploy() reverted")
    sys.exit(1)

# ═══════════════════════════════════════════════════════════════════════════
# 4. GET ALL ADDRESSES
# ═══════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 70)
print("АДРЕСА СИСТЕМЫ TROIKA")
print("=" * 70)

addrs = deployer.functions.allAddresses().call()
names = ["core", "syna", "sync", "synr", "vault", "oracle",
         "divPool", "cbArb", "feeRouter", "emitEngine", "loop", "founderCtl"]

result = {
    "deployed_at": time.strftime("%Y-%m-%d %H:%M:%S"),
    "owner": OWNER,
    "deployer": deployer_addr,
    "tokens": {},
    "system": {},
    "pools": {}
}

for name, addr in zip(names, addrs):
    print(f"  {name}: {addr}")
    if name in ["syna", "sync", "synr"]:
        result["tokens"][name.upper()] = addr
    else:
        result["system"][name] = addr

# Получить пулы из Vault
VAULT_ABI = [
    {"name": "pairR", "inputs": [], "outputs": [{"type": "address"}], "stateMutability": "view", "type": "function"},
    {"name": "pairT", "inputs": [], "outputs": [{"type": "address"}], "stateMutability": "view", "type": "function"},
    {"name": "pairP", "inputs": [], "outputs": [{"type": "address"}], "stateMutability": "view", "type": "function"},
]

vault = w3.eth.contract(address=C(result["system"]["vault"]), abi=VAULT_ABI)
result["pools"]["SYNA_WPOL"] = vault.functions.pairR().call()
result["pools"]["SYNC_WPOL"] = vault.functions.pairT().call()
result["pools"]["SYNR_WPOL"] = vault.functions.pairP().call()

print("\nПУЛЫ:")
for name, addr in result["pools"].items():
    print(f"  {name}: {addr}")

with open("deployed_TROIKA_FULL.json", "w") as f:
    json.dump(result, f, indent=2)

print(f"\nСохранено в deployed_TROIKA_FULL.json")
print(f"Баланс: {w3.eth.get_balance(C(OWNER)) / 1e18:.4f} POL")
print("\n" + "=" * 70)
print("ГОТОВО!")
print("=" * 70)
