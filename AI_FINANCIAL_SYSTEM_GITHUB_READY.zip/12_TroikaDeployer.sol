// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

// ═══════════════════════════════════════════════════════════════════════════
//  SINERGY SYSTEM — 12_TroikaDeployer.sol
//  Фабрика-деплоер всей системы за одну транзакцию | Polygon + QuickSwap V2
//
//  ПОРЯДОК ДЕПЛОЯ:
//   1.  TroikaCore
//   2.  ALTNR, ALTNT, ALTNP (initial supply → Deployer)
//   3.  TroikaVault
//   4.  TWAPOracle
//   5.  DividendPool
//   6.  CBArbitrage
//   7.  FeeRouter
//   8.  EmissionEngine (с divPool для notifyFounderEmission)
//   9.  SelfReinforcingLoop
//   10. FounderControl
//   11. Core.initialize(все адреса)
//   12. Core.setFounderControl(fcAddr)
//   13. _grantAllRoles() — выдать роли всем модулям
//   14. Перевод WPOL + токенов в Vault
//   15. Vault.initialize() — создать QuickSwap пары + начальная ликвидность
//   16. Core.linkOraclePairs() — TWAP + fixBase
//   17. Keeper seed
//   18. _transferAdminToOwner(deployer)
//   19. _renounceDeployerRoles() — Deployer лишается всех привилегий
//
//  ПРЕДУСЛОВИЯ:
//   WPOL.approve(deployerAddr, wpolR+wpolT+wpolP+trRes+rrRes+mcgRes+keeperSeed)
//
//  ПАРАМЕТРЫ (300 POL старт, POL ≈ $0.095):
//   wpolR = 110 POL   tokR = 2 SYNA       → P = 55 POL ≈ $5.23
//   wpolT =  46 POL   tokT = 19 SYNC      → P = 2.42 POL ≈ $0.23
//   wpolP =  44 POL   tokP = 4 SYNR       → P = 11 POL ≈ $1.05
//   trRes =  20 POL   rrRes = 50 POL   mcgRes = 15 POL   keeper = 15 POL
//   ИТОГО: 300 POL (≈ $28.50)
//
//  УПРАВЛЕНИЕ ПОСЛЕ ДЕПЛОЯ (через FounderControl):
//   founderCtl.systemStop()            — СТОП всей системы
//   founderCtl.queueSystemStart()      — поставить СТАРТ в очередь (1 час)
//   founderCtl.executeSystemStart()    — ЗАПУСК
//   founderCtl.enableReinvest()        — дивиденды → LP
//   founderCtl.disableReinvest(bool)   — дивиденды → кошелёк
//   founderCtl.withdrawNow()           — вывести сейчас
//   founderCtl.reinvestNow()           — реинвестировать сейчас
// ═══════════════════════════════════════════════════════════════════════════

import {IERC20}    from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";

// Импорт всех контрактов системы
import "./02_Tokens.sol";
import "./03_TroikaVault.sol";
import "./04_TWAPOracle.sol";
import "./05_DividendPool.sol";
import "./08_CBArbitrage.sol";
import "./06_FeeRouter.sol";
import "./07_EmissionEngine.sol";
import "./09_SelfReinforcingLoop.sol";
import "./10_TroikaCore.sol";
import "./11_FounderControl.sol";

// ── Custom Errors ─────────────────────────────────────────────────────────
error TD_AlreadyDeployed();
error TD_ZeroAddress();
error TD_InsufficientWPOL(uint256 have, uint256 need);
error TD_InsufficientToken(string token, uint256 have, uint256 need);

contract TroikaDeployer {
    using SafeERC20 for IERC20;

    // ── Публичные адреса всех задеплоенных контрактов ─────────────────
    TroikaCore          public core;
    SYNA                public syna;
    SYNC                public sync_;
    SYNR                public synr;
    TroikaVault         public vault;
    TWAPOracle          public oracle;
    DividendPool        public divPool;
    CBArbitrage         public cbArb;
    FeeRouter           public feeRouter;
    EmissionEngine      public emitEngine;
    SelfReinforcingLoop public loop_;
    FounderControl      public founderCtl;

    bool public deployed;

    event SystemDeployed(
        address indexed owner,
        address indexed founder,
        address core,
        address syna_, address sync__, address synr_,
        address vault, address oracle, address divPool,
        address cbArb, address feeRouter, address emitEngine,
        address loop_, address founderCtl
    );

    // ═══════════════════════════════════════════════════════════════════
    //  DEPLOY — разворачивает ВСЮ систему
    // ═══════════════════════════════════════════════════════════════════
    function deploy(
        address founder_,       // кошелёк основателя (WPOL дивиденды)
        uint256 wpolR_,  uint256 tokR_,   // ликвидность SYNA/WPOL пула
        uint256 wpolT_,  uint256 tokT_,   // ликвидность SYNC/WPOL пула
        uint256 wpolP_,  uint256 tokP_,   // ликвидность SYNR/WPOL пула
        uint256 trRes_,                   // traderReserve (WPOL)
        uint256 rrRes_,                   // reserveR (WPOL)
        uint256 mcgRes_,                  // mcgFund (WPOL)
        uint256 keeperSeed_               // keeper fund seed (WPOL)
    ) external {
        if (deployed)               revert TD_AlreadyDeployed();
        if (founder_ == address(0)) revert TD_ZeroAddress();
        deployed = true;

        IERC20  WPOL    = IERC20(0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270);
        address owner   = msg.sender;

        // ── Проверить и перевести WPOL ────────────────────────────────
        uint256 totalWpol = wpolR_ + wpolT_ + wpolP_ + trRes_ + rrRes_ + mcgRes_ + keeperSeed_;
        {
            uint256 bal = WPOL.balanceOf(owner);
            if (bal < totalWpol) revert TD_InsufficientWPOL(bal, totalWpol);
        }
        WPOL.safeTransferFrom(owner, address(this), totalWpol);

        // ── 1. TroikaCore (admin = this) ──────────────────────────────
        core = new TroikaCore(address(this));

        // ── 2-4. Токены (initial supply → this) ──────────────────────
        syna = new SYNA(address(this));  // 10M SYNA → this
        sync_ = new SYNC(address(this));  // 100M SYNC → this
        synr = new SYNR(address(this));  // 21M SYNR → this

        // Проверить что хватает токенов для ликвидности
        {
            if (IERC20(address(syna)).balanceOf(address(this)) < tokR_)
                revert TD_InsufficientToken("SYNA", IERC20(address(syna)).balanceOf(address(this)), tokR_);
            if (IERC20(address(sync_)).balanceOf(address(this)) < tokT_)
                revert TD_InsufficientToken("SYNC", IERC20(address(sync_)).balanceOf(address(this)), tokT_);
            if (IERC20(address(synr)).balanceOf(address(this)) < tokP_)
                revert TD_InsufficientToken("SYNR", IERC20(address(synr)).balanceOf(address(this)), tokP_);
        }

        // ── 5. TroikaVault ────────────────────────────────────────────
        vault = new TroikaVault(
            address(syna), address(sync_), address(synr), address(this)
        );

        // ── 6. TWAPOracle ─────────────────────────────────────────────
        oracle = new TWAPOracle(address(this));

        // ── 7. DividendPool ───────────────────────────────────────────
        divPool = new DividendPool(address(synr), founder_, address(this));

        // ── 8. CBArbitrage ────────────────────────────────────────────
        cbArb = new CBArbitrage(
            address(vault), address(divPool), address(oracle),
            address(synr), address(sync_), address(this)
        );

        // ── 9. FeeRouter ──────────────────────────────────────────────
        feeRouter = new FeeRouter(
            address(vault), address(divPool), address(cbArb), address(this)
        );

        // ── 10. EmissionEngine ────────────────────────────────────────
        emitEngine = new EmissionEngine(
            address(vault), address(syna), address(sync_), address(synr),
            address(divPool), address(this)
        );

        // ── 11. SelfReinforcingLoop ───────────────────────────────────
        loop_ = new SelfReinforcingLoop(address(vault), address(this));

        // ── 12. FounderControl ────────────────────────────────────────
        founderCtl = new FounderControl(
            address(core), address(vault), address(divPool), address(loop_),
            founder_, owner
        );

        // ── 13. Core.initialize ───────────────────────────────────────
        core.initialize(TroikaCore.Addresses({
            vault:      address(vault),
            oracle:     address(oracle),
            feeRouter:  address(feeRouter),
            cbArb:      address(cbArb),
            emitEngine: address(emitEngine),
            divPool:    address(divPool),
            loop:       address(loop_)
        }));

        // ── 14. Core.setFounderControl ────────────────────────────────
        core.setFounderControl(address(founderCtl));

        // ── 15. Выдача ролей ──────────────────────────────────────────
        _grantAllRoles();

        // ── 16. Перевести токены и WPOL в Vault ──────────────────────
        IERC20(address(syna)).safeTransfer(address(vault), tokR_);
        IERC20(address(sync_)).safeTransfer(address(vault), tokT_);
        IERC20(address(synr)).safeTransfer(address(vault), tokP_);
        uint256 vaultWpol = wpolR_ + wpolT_ + wpolP_ + trRes_ + rrRes_ + mcgRes_;
        WPOL.safeTransfer(address(vault), vaultWpol);

        // ── 17. Vault.initialize → QuickSwap пары + ликвидность ───────
        vault.initialize(
            wpolR_, tokR_, wpolT_, tokT_, wpolP_, tokP_,
            trRes_, rrRes_, mcgRes_
        );

        // ── 18. Core.linkOraclePairs → TWAP + fixBase ─────────────────
        core.linkOraclePairs();

        // ── 19. Keeper seed ───────────────────────────────────────────
        if (keeperSeed_ > 0) {
            WPOL.safeTransfer(address(core), keeperSeed_);
            core.initKeeperFund(keeperSeed_);
        }

        // ── 20. Передать DEFAULT_ADMIN_ROLE → owner ────────────────────
        _transferAdminToOwner(owner);

        // ── 21. Ренонс ролей Deployer ─────────────────────────────────
        _renounceDeployerRoles();

        emit SystemDeployed(
            owner, founder_,
            address(core),
            address(syna), address(sync_), address(synr),
            address(vault), address(oracle), address(divPool),
            address(cbArb), address(feeRouter), address(emitEngine),
            address(loop_), address(founderCtl)
        );
    }

    // ── Выдача всех ролей подсистемам ─────────────────────────────────
    function _grantAllRoles() private {
        address me      = address(this);
        address coreA   = address(core);
        address fcA     = address(founderCtl);

        // ── Vault: OPERATOR_ROLE ──────────────────────────────────────
        bytes32 OP = vault.OPERATOR_ROLE();
        vault.grantRole(OP, coreA);
        vault.grantRole(OP, address(feeRouter));
        vault.grantRole(OP, address(cbArb));
        vault.grantRole(OP, address(emitEngine));
        vault.grantRole(OP, address(loop_));
        vault.grantRole(OP, fcA);           // FounderControl добавляет в lpBuf

        // ── Tokens: MINTER_ROLE → EmitEngine ─────────────────────────
        syna.grantRole(syna.MINTER_ROLE(), address(emitEngine));
        sync_.grantRole(sync_.MINTER_ROLE(), address(emitEngine));
        synr.grantRole(synr.MINTER_ROLE(), address(emitEngine));

        // ── ALTNP: BURNER_ROLE → EmitEngine (buybackBurn) ────────────
        synr.grantRole(synr.BURNER_ROLE(), address(emitEngine));

        // ── DividendPool: NOTIFIER_ROLE → FeeRouter, CBArb, EmitEngine
        bytes32 NOT = divPool.NOTIFIER_ROLE();
        divPool.grantRole(NOT, address(feeRouter));
        divPool.grantRole(NOT, address(cbArb));
        divPool.grantRole(NOT, address(emitEngine));

        // ── DividendPool: PAYOUT_ROLE → Core
        divPool.grantRole(divPool.PAYOUT_ROLE(), coreA);

        // ── DividendPool: FOUNDER_CTL_ROLE → FounderControl
        divPool.grantRole(divPool.FOUNDER_CTL_ROLE(), fcA);

        // ── Oracle: UPDATER_ROLE → Core
        oracle.grantRole(oracle.UPDATER_ROLE(), coreA);

        // ── FeeRouter: CALLER_ROLE → Core
        feeRouter.grantRole(feeRouter.CALLER_ROLE(), coreA);

        // ── CBArb: CALLER_ROLE → Core; FEEDER_ROLE → FeeRouter
        cbArb.grantRole(cbArb.CALLER_ROLE(), coreA);
        cbArb.grantRole(cbArb.FEEDER_ROLE(), address(feeRouter));

        // ── EmitEngine: CALLER_ROLE → Core
        emitEngine.grantRole(emitEngine.CALLER_ROLE(), coreA);

        // ── Loop: CONTRIBUTOR_ROLE + EXECUTOR_ROLE → Core
        loop_.grantRole(loop_.CONTRIBUTOR_ROLE(), coreA);
        loop_.grantRole(loop_.EXECUTOR_ROLE(),    coreA);

        // ── FounderControl: KEEPER_ROLE → Core (для processFounderDividends)
        founderCtl.grantRole(founderCtl.KEEPER_ROLE(), coreA);

        (me); // suppress
    }

    // ── Передать DEFAULT_ADMIN_ROLE → реальному владельцу ─────────────
    function _transferAdminToOwner(address owner) private {
        core.grantRole(core.DEFAULT_ADMIN_ROLE(), owner);
        core.grantRole(core.ADMIN_ROLE(),         owner);
        core.grantRole(core.PAUSER_ROLE(),        owner);

        vault.grantRole(vault.DEFAULT_ADMIN_ROLE(), owner);
        vault.grantRole(vault.PAUSER_ROLE(),        owner);

        oracle.grantRole(oracle.DEFAULT_ADMIN_ROLE(), owner);
        oracle.grantRole(oracle.PAUSER_ROLE(),        owner);

        divPool.grantRole(divPool.DEFAULT_ADMIN_ROLE(), owner);
        divPool.grantRole(divPool.PAUSER_ROLE(),        owner);

        feeRouter.grantRole(feeRouter.DEFAULT_ADMIN_ROLE(), owner);
        feeRouter.grantRole(feeRouter.ADMIN_ROLE(),         owner);
        feeRouter.grantRole(feeRouter.PAUSER_ROLE(),        owner);

        cbArb.grantRole(cbArb.DEFAULT_ADMIN_ROLE(), owner);
        cbArb.grantRole(cbArb.PAUSER_ROLE(),        owner);

        emitEngine.grantRole(emitEngine.DEFAULT_ADMIN_ROLE(), owner);
        emitEngine.grantRole(emitEngine.PAUSER_ROLE(),        owner);

        loop_.grantRole(loop_.DEFAULT_ADMIN_ROLE(), owner);
        loop_.grantRole(loop_.PAUSER_ROLE(),        owner);

        syna.grantRole(syna.DEFAULT_ADMIN_ROLE(), owner);
        sync_.grantRole(sync_.DEFAULT_ADMIN_ROLE(), owner);
        synr.grantRole(synr.DEFAULT_ADMIN_ROLE(), owner);

        founderCtl.grantRole(founderCtl.DEFAULT_ADMIN_ROLE(), owner);
        founderCtl.grantRole(founderCtl.DEPLOYER_ROLE(),      owner);
    }

    // ── Ренонс ВСЕХ ролей TroikaDeployer (этот контракт теряет власть) ─
    function _renounceDeployerRoles() private {
        address me = address(this);

        core.renounceRole(core.DEFAULT_ADMIN_ROLE(), me);
        core.renounceRole(core.ADMIN_ROLE(),         me);
        core.renounceRole(core.PAUSER_ROLE(),        me);

        vault.renounceRole(vault.DEFAULT_ADMIN_ROLE(), me);
        vault.renounceRole(vault.OPERATOR_ROLE(),      me);
        vault.renounceRole(vault.PAUSER_ROLE(),        me);

        oracle.renounceRole(oracle.DEFAULT_ADMIN_ROLE(), me);
        oracle.renounceRole(oracle.UPDATER_ROLE(),       me);
        oracle.renounceRole(oracle.PAUSER_ROLE(),        me);

        divPool.renounceRole(divPool.DEFAULT_ADMIN_ROLE(), me);
        divPool.renounceRole(divPool.NOTIFIER_ROLE(),      me);
        divPool.renounceRole(divPool.PAYOUT_ROLE(),        me);
        divPool.renounceRole(divPool.FOUNDER_CTL_ROLE(),   me);
        divPool.renounceRole(divPool.PAUSER_ROLE(),        me);

        feeRouter.renounceRole(feeRouter.DEFAULT_ADMIN_ROLE(), me);
        feeRouter.renounceRole(feeRouter.CALLER_ROLE(),        me);
        feeRouter.renounceRole(feeRouter.ADMIN_ROLE(),         me);
        feeRouter.renounceRole(feeRouter.PAUSER_ROLE(),        me);

        cbArb.renounceRole(cbArb.DEFAULT_ADMIN_ROLE(), me);
        cbArb.renounceRole(cbArb.CALLER_ROLE(),        me);
        cbArb.renounceRole(cbArb.FEEDER_ROLE(),        me);
        cbArb.renounceRole(cbArb.PAUSER_ROLE(),        me);

        emitEngine.renounceRole(emitEngine.DEFAULT_ADMIN_ROLE(), me);
        emitEngine.renounceRole(emitEngine.CALLER_ROLE(),        me);
        emitEngine.renounceRole(emitEngine.PAUSER_ROLE(),        me);

        loop_.renounceRole(loop_.DEFAULT_ADMIN_ROLE(),  me);
        loop_.renounceRole(loop_.CONTRIBUTOR_ROLE(),    me);
        loop_.renounceRole(loop_.EXECUTOR_ROLE(),       me);
        loop_.renounceRole(loop_.PAUSER_ROLE(),         me);

        syna.renounceRole(syna.DEFAULT_ADMIN_ROLE(), me);
        syna.renounceRole(syna.MINTER_ROLE(),        me);
        syna.renounceRole(syna.BURNER_ROLE(),        me);
        syna.renounceRole(syna.PAUSER_ROLE(),        me);

        sync_.renounceRole(sync_.DEFAULT_ADMIN_ROLE(), me);
        sync_.renounceRole(sync_.MINTER_ROLE(),        me);
        sync_.renounceRole(sync_.BURNER_ROLE(),        me);
        sync_.renounceRole(sync_.PAUSER_ROLE(),        me);

        synr.renounceRole(synr.DEFAULT_ADMIN_ROLE(), me);
        synr.renounceRole(synr.MINTER_ROLE(),        me);
        synr.renounceRole(synr.BURNER_ROLE(),        me);
        synr.renounceRole(synr.PAUSER_ROLE(),        me);

        founderCtl.renounceRole(founderCtl.DEFAULT_ADMIN_ROLE(), me);
        founderCtl.renounceRole(founderCtl.DEPLOYER_ROLE(),      me);
        founderCtl.renounceRole(founderCtl.KEEPER_ROLE(),        me);
    }

    // ── Все адреса одним вызовом ──────────────────────────────────────
    function allAddresses() external view returns (
        address core_,
        address syna_, address sync__, address synr_,
        address vault_, address oracle_,
        address divPool_, address cbArb_,
        address feeRouter_, address emitEngine_,
        address loop__, address founderCtl_
    ) {
        return (
            address(core),
            address(syna), address(sync_), address(synr),
            address(vault), address(oracle),
            address(divPool), address(cbArb),
            address(feeRouter), address(emitEngine),
            address(loop_), address(founderCtl)
        );
    }
}
