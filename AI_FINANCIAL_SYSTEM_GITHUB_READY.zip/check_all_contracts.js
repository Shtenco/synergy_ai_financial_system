'use strict';
const fs = require('fs');
const path = require('path');
const solc = require('solc');

const root = __dirname;
const sources = {};
for (const file of fs.readdirSync(root).sort()) {
  if (file.endsWith('.sol')) {
    sources[file] = { content: fs.readFileSync(path.join(root, file), 'utf8') };
  }
}

function findImports(importPath) {
  const candidates = [
    path.join(root, importPath),
    path.join(root, 'node_modules', importPath),
  ];
  for (const candidate of candidates) {
    if (fs.existsSync(candidate)) {
      return { contents: fs.readFileSync(candidate, 'utf8') };
    }
  }
  return { error: `Import not found: ${importPath}` };
}

const input = {
  language: 'Solidity',
  sources,
  settings: {
    optimizer: { enabled: false, runs: 200 },
    viaIR: false,
    outputSelection: { '*': { '*': ['abi'] } },
  },
};

const output = JSON.parse(solc.compile(JSON.stringify(input), { import: findImports }));
for (const item of output.errors || []) {
  const stream = item.severity === 'error' ? process.stderr : process.stdout;
  stream.write(`${item.severity.toUpperCase()}: ${item.formattedMessage}\n`);
}

const errors = (output.errors || []).filter((item) => item.severity === 'error');
const contractCount = Object.values(output.contracts || {})
  .reduce((sum, contracts) => sum + Object.keys(contracts).length, 0);
console.log(`Solidity sources: ${Object.keys(sources).length}`);
console.log(`Compiled contracts/interfaces/libraries: ${contractCount}`);
console.log(`Fatal compiler errors: ${errors.length}`);
process.exit(errors.length ? 1 : 0);
