#!/usr/bin/env python3
"""
1. Выдать MINTER роль EmissionEngine для всех токенов
2. Задеплоить TroikaFlashProfit контракт
"""
import sys, io, os, json, time
from dotenv import load_dotenv
from web3 import Web3
from web3.middleware import ExtraDataToPOAMiddleware
from solcx import compile_source, install_solc, set_solc_version

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

load_dotenv()

try:
    set_solc_version('0.8.20')
except:
    print("Устанавливаю solc 0.8.20...")
    install_solc('0.8.20')
    set_solc_version('0.8.20')

w3 = Web3(Web3.HTTPProvider("https://polygon-bor-rpc.publicnode.com", request_kwargs={"timeout": 180}))
w3.middleware_onion.inject(ExtraDataToPOAMiddleware, layer=0)

PK = os.getenv("OWNER_PRIVATE_KEY")
OWNER = "0x6946999DBCE63b140B1bB9D475F7c357130909E5"
WPOL = "0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270"

def C(a): return Web3.to_checksum_address(a)

with open("deployed_instant.json") as f:
    data = json.load(f)

VAULT = data["troika_system"]["vault"]
DIVPOOL = data["troika_system"]["divPool"]
EMITENGINE = data["troika_system"]["emitEngine"]
CORE = data["troika_system"]["core"]

SYNA = data["tokens"]["SYNA"]
SYNC = data["tokens"]["SYNC"]
SYNR = data["tokens"]["SYNR"]
ALTN = data["tokens"]["ALTN"]

print("=" * 70)
print("НАСТРОЙКА MINTER И ДЕПЛОЙ FLASH PROFIT")
print("=" * 70)
print(f"Баланс: {w3.eth.get_balance(C(OWNER)) / 1e18:.4f} POL")
print("=" * 70)

nonce = w3.eth.get_transaction_count(C(OWNER), "pending")

def send_tx(contract, func, label):
    global nonce
    print(f"\n[TX] {label}...", flush=True)

    base = w3.eth.get_block("latest").get("baseFeePerGas", int(100e9))
    prio = int(50e9)
    mf = base * 2 + prio

    try:
        tx = func.build_transaction({
            "from": C(OWNER),
            "nonce": nonce,
            "chainId": 137,
            "type": 2,
            "maxPriorityFeePerGas": prio,
            "maxFeePerGas": mf,
            "gas": 200000
        })

        signed = w3.eth.account.sign_transaction(tx, PK)
        tx_hash = w3.eth.send_raw_transaction(signed.raw_transaction)
        print(f"  TX: {tx_hash.hex()[:20]}...", flush=True)

        receipt = w3.eth.wait_for_transaction_receipt(tx_hash, timeout=300)
        gas_cost = receipt.gasUsed * mf / 1e18

        if receipt.status == 1:
            print(f"  [OK] gas: {gas_cost:.4f} POL", flush=True)
            nonce += 1
            return True
        else:
            print(f"  [FAIL] reverted", flush=True)
            nonce += 1
            return False
    except Exception as e:
        print(f"  [ERROR] {e}")
        return False

# ═══════════════════════════════════════════════════════════════════════════
# 1. Grant MINTER_ROLE для EmissionEngine
# ═══════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 50)
print("[1] Выдача MINTER_ROLE токенам")
print("=" * 50)

# MINTER_ROLE = keccak256("MINTER_ROLE")
MINTER_ROLE = Web3.keccak(text="MINTER_ROLE")
print(f"MINTER_ROLE: {MINTER_ROLE.hex()}")

TOKEN_ABI = [
    {"name": "grantRole", "inputs": [{"name": "role", "type": "bytes32"}, {"name": "account", "type": "address"}], "outputs": [], "stateMutability": "nonpayable", "type": "function"},
    {"name": "hasRole", "inputs": [{"name": "role", "type": "bytes32"}, {"name": "account", "type": "address"}], "outputs": [{"type": "bool"}], "stateMutability": "view", "type": "function"},
]

for token_addr, token_name in [(SYNA, "SYNA"), (SYNC, "SYNC"), (SYNR, "SYNR")]:
    token_contract = w3.eth.contract(address=C(token_addr), abi=TOKEN_ABI)

    try:
        has_role = token_contract.functions.hasRole(MINTER_ROLE, C(EMITENGINE)).call()
        if has_role:
            print(f"  {token_name}: EmitEngine уже имеет MINTER_ROLE")
            continue
    except Exception as e:
        print(f"  {token_name}: Ошибка проверки роли: {e}")

    func = token_contract.functions.grantRole(MINTER_ROLE, C(EMITENGINE))
    send_tx(token_contract, func, f"{token_name}.grantRole(MINTER, EmitEngine)")
    time.sleep(2)

# ═══════════════════════════════════════════════════════════════════════════
# 2. Deploy TroikaFlashProfit
# ═══════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 50)
print("[2] Деплой TroikaFlashProfit")
print("=" * 50)

FLASH_SOURCE = '''
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

interface IERC20 {
    function balanceOf(address) external view returns (uint256);
    function transfer(address, uint256) external returns (bool);
    function approve(address, uint256) external returns (bool);
    function transferFrom(address, address, uint256) external returns (bool);
}

interface IWETH {
    function deposit() external payable;
    function withdraw(uint256) external;
    function balanceOf(address) external view returns (uint256);
    function approve(address, uint256) external returns (bool);
    function transfer(address, uint256) external returns (bool);
}

interface IRouter {
    function addLiquidityETH(
        address token, uint amountTokenDesired, uint amountTokenMin, uint amountETHMin,
        address to, uint deadline
    ) external payable returns (uint amountToken, uint amountETH, uint liquidity);

    function removeLiquidityETH(
        address token, uint liquidity, uint amountTokenMin, uint amountETHMin,
        address to, uint deadline
    ) external returns (uint amountToken, uint amountETH);

    function swapExactTokensForETH(
        uint amountIn, uint amountOutMin, address[] calldata path, address to, uint deadline
    ) external returns (uint[] memory amounts);

    function swapExactETHForTokens(
        uint amountOutMin, address[] calldata path, address to, uint deadline
    ) external payable returns (uint[] memory amounts);
}

interface IPair {
    function balanceOf(address) external view returns (uint256);
    function approve(address, uint256) external returns (bool);
    function getReserves() external view returns (uint112, uint112, uint32);
    function token0() external view returns (address);
}

interface IFactory {
    function getPair(address, address) external view returns (address);
}

interface IAavePool {
    function flashLoanSimple(
        address receiverAddress,
        address asset,
        uint256 amount,
        bytes calldata params,
        uint16 referralCode
    ) external;
}

interface ITroikaCore {
    function tick() external;
}

interface IDividendPool {
    function withdrawFounder() external;
    function founderPending() external view returns (uint256);
}

interface IEmissionEngine {
    function isEmissionDue() external view returns (bool);
}

contract TroikaFlashProfit {
    address public owner;

    address public constant AAVE_POOL = 0x794a61358D6845594F94dc1DB02A252b5b4814aD;
    address public constant WPOL = 0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270;
    address public constant ROUTER = 0xa5E0829CaCEd8fFDD4De3c43696c57F7D7A678ff;
    address public constant FACTORY = 0x5757371414417b8C6CAad45bAeF941aBc7d3Ab32;

    address public syna;
    address public sync;
    address public synr;
    address public altn;

    address public troikaCore;
    address public dividendPool;
    address public emissionEngine;

    address public pairSyna;
    address public pairSync;
    address public pairSynr;
    address public pairAltn;

    uint256 public totalProfit;
    uint256 public cycleCount;
    uint256 public lastCycleProfit;

    event CycleStarted(uint256 loanAmount, uint256 cycleNum);
    event CycleComplete(uint256 loanAmount, uint256 profit, uint256 cycleNum);
    event DebugStep(string step, uint256 value);

    modifier onlyOwner() {
        require(msg.sender == owner, "!owner");
        _;
    }

    constructor(
        address syna_,
        address sync_,
        address synr_,
        address altn_,
        address troikaCore_,
        address dividendPool_,
        address emissionEngine_
    ) {
        owner = msg.sender;

        syna = syna_;
        sync = sync_;
        synr = synr_;
        altn = altn_;

        troikaCore = troikaCore_;
        dividendPool = dividendPool_;
        emissionEngine = emissionEngine_;

        pairSyna = IFactory(FACTORY).getPair(syna_, WPOL);
        pairSync = IFactory(FACTORY).getPair(sync_, WPOL);
        pairSynr = IFactory(FACTORY).getPair(synr_, WPOL);
        pairAltn = IFactory(FACTORY).getPair(altn_, WPOL);

        IERC20(syna_).approve(ROUTER, type(uint256).max);
        IERC20(sync_).approve(ROUTER, type(uint256).max);
        IERC20(synr_).approve(ROUTER, type(uint256).max);
        IERC20(altn_).approve(ROUTER, type(uint256).max);
        IWETH(WPOL).approve(ROUTER, type(uint256).max);
        IWETH(WPOL).approve(AAVE_POOL, type(uint256).max);

        if (pairSyna != address(0)) IPair(pairSyna).approve(ROUTER, type(uint256).max);
        if (pairSync != address(0)) IPair(pairSync).approve(ROUTER, type(uint256).max);
        if (pairSynr != address(0)) IPair(pairSynr).approve(ROUTER, type(uint256).max);
        if (pairAltn != address(0)) IPair(pairAltn).approve(ROUTER, type(uint256).max);
    }

    function executeProfitCycle(uint256 loanAmount) external onlyOwner {
        require(loanAmount >= 10e18, "Min 10 POL");

        cycleCount++;
        emit CycleStarted(loanAmount, cycleCount);

        IAavePool(AAVE_POOL).flashLoanSimple(
            address(this),
            WPOL,
            loanAmount,
            abi.encode(cycleCount),
            0
        );
    }

    function executeOperation(
        address asset,
        uint256 amount,
        uint256 premium,
        address,
        bytes calldata
    ) external returns (bool) {
        require(msg.sender == AAVE_POOL, "!aave");
        require(asset == WPOL, "!wpol");

        uint256 startBal = IWETH(WPOL).balanceOf(address(this));
        emit DebugStep("Start WPOL bal", startBal);

        IWETH(WPOL).withdraw(amount);
        emit DebugStep("After unwrap, ETH", address(this).balance);

        // Add LP
        uint256 perPool = address(this).balance / 4;
        uint256 dl = block.timestamp + 600;

        _addLp(syna, perPool, dl);
        _addLp(sync, perPool, dl);
        _addLp(synr, perPool, dl);
        _addLp(altn, address(this).balance, dl);

        emit DebugStep("After addLP, ETH left", address(this).balance);

        // Tick
        if (troikaCore != address(0)) {
            try ITroikaCore(troikaCore).tick() {
                emit DebugStep("Tick success", 1);
            } catch {
                emit DebugStep("Tick failed", 0);
            }
        }

        // Claim founder dividends
        uint256 wpolBefore = IWETH(WPOL).balanceOf(address(this));
        if (dividendPool != address(0)) {
            try IDividendPool(dividendPool).withdrawFounder() {
                emit DebugStep("Founder claim success", 1);
            } catch {
                emit DebugStep("Founder claim failed", 0);
            }
        }
        uint256 wpolFromDiv = IWETH(WPOL).balanceOf(address(this)) - wpolBefore;
        emit DebugStep("WPOL from dividends", wpolFromDiv);

        // Remove all LP
        _removeLp(syna, pairSyna, dl);
        _removeLp(sync, pairSync, dl);
        _removeLp(synr, pairSynr, dl);
        _removeLp(altn, pairAltn, dl);

        emit DebugStep("After removeLP, ETH", address(this).balance);

        // Sell all tokens
        _sellToken(syna, dl);
        _sellToken(sync, dl);
        _sellToken(synr, dl);
        _sellToken(altn, dl);

        emit DebugStep("After sell, ETH", address(this).balance);

        // Wrap back
        if (address(this).balance > 0) {
            IWETH(WPOL).deposit{value: address(this).balance}();
        }

        uint256 owed = amount + premium;
        uint256 finalBal = IWETH(WPOL).balanceOf(address(this));

        emit DebugStep("Final WPOL bal", finalBal);
        emit DebugStep("Owed", owed);

        require(finalBal >= owed, "LOSS");

        uint256 profit = finalBal - owed;
        totalProfit += profit;
        lastCycleProfit = profit;

        emit CycleComplete(amount, profit, cycleCount);
        return true;
    }

    function _addLp(address token, uint256 ethAmount, uint256 dl) internal {
        if (ethAmount < 1e15) return;

        uint256 buyEth = ethAmount / 2;
        uint256 lpEth = ethAmount - buyEth;

        address[] memory path = new address[](2);
        path[0] = WPOL;
        path[1] = token;

        // Buy tokens
        try IRouter(ROUTER).swapExactETHForTokens{value: buyEth}(
            0, path, address(this), dl
        ) {} catch { return; }

        uint256 tokenBal = IERC20(token).balanceOf(address(this));
        if (tokenBal == 0) return;

        // Add LP
        try IRouter(ROUTER).addLiquidityETH{value: lpEth}(
            token, tokenBal, 0, 0, address(this), dl
        ) {} catch {}
    }

    function _removeLp(address token, address pair, uint256 dl) internal {
        if (pair == address(0)) return;
        uint256 lp = IPair(pair).balanceOf(address(this));
        if (lp == 0) return;

        try IRouter(ROUTER).removeLiquidityETH(
            token, lp, 0, 0, address(this), dl
        ) {} catch {}
    }

    function _sellToken(address token, uint256 dl) internal {
        uint256 bal = IERC20(token).balanceOf(address(this));
        if (bal == 0) return;

        address[] memory path = new address[](2);
        path[0] = token;
        path[1] = WPOL;

        try IRouter(ROUTER).swapExactTokensForETH(
            bal, 0, path, address(this), dl
        ) {} catch {}
    }

    function withdrawProfit() external onlyOwner {
        uint256 wpolBal = IWETH(WPOL).balanceOf(address(this));
        if (wpolBal > 0) {
            IWETH(WPOL).withdraw(wpolBal);
        }
        uint256 bal = address(this).balance;
        if (bal > 0) {
            (bool ok,) = owner.call{value: bal}("");
            require(ok);
        }
    }

    function checkReadiness() external view returns (
        bool hasPairs,
        bool hasCore,
        bool emissionDue,
        uint256 founderPending_
    ) {
        hasPairs = pairSyna != address(0) && pairSync != address(0) &&
                   pairSynr != address(0) && pairAltn != address(0);

        hasCore = troikaCore != address(0);

        if (emissionEngine != address(0)) {
            try IEmissionEngine(emissionEngine).isEmissionDue() returns (bool due) {
                emissionDue = due;
            } catch {}
        }

        if (dividendPool != address(0)) {
            try IDividendPool(dividendPool).founderPending() returns (uint256 p) {
                founderPending_ = p;
            } catch {}
        }
    }

    function getStats() external view returns (
        uint256 profit_,
        uint256 cycles_,
        uint256 lastProfit_,
        uint256 wpolBal_
    ) {
        return (
            totalProfit,
            cycleCount,
            lastCycleProfit,
            IWETH(WPOL).balanceOf(address(this))
        );
    }

    receive() external payable {}
}
'''

print("\n[DEPLOY] TroikaFlashProfit...", flush=True)

compiled = compile_source(
    FLASH_SOURCE,
    output_values=['abi', 'bin'],
    solc_version='0.8.20',
    optimize=True,
    optimize_runs=200
)

contract_key = None
for key in compiled.keys():
    if "TroikaFlashProfit" in key:
        contract_key = key
        break

abi = compiled[contract_key]['abi']
bytecode = compiled[contract_key]['bin']

base = w3.eth.get_block("latest").get("baseFeePerGas", int(100e9))
prio = int(50e9)
mf = base * 2 + prio

contract = w3.eth.contract(abi=abi, bytecode=bytecode)

tx = contract.constructor(
    C(SYNA), C(SYNC), C(SYNR), C(ALTN),
    C(CORE), C(DIVPOOL), C(EMITENGINE)
).build_transaction({
    "from": C(OWNER), "nonce": nonce, "chainId": 137, "type": 2,
    "maxPriorityFeePerGas": prio, "maxFeePerGas": mf, "gas": 5000000
})

signed = w3.eth.account.sign_transaction(tx, PK)
tx_hash = w3.eth.send_raw_transaction(signed.raw_transaction)
print(f"  TX: {tx_hash.hex()[:20]}...", flush=True)

receipt = w3.eth.wait_for_transaction_receipt(tx_hash, timeout=300)
gas_cost = receipt.gasUsed * mf / 1e18

if receipt.status == 1:
    flash_addr = receipt.contractAddress
    print(f"  [OK] {flash_addr} (gas: {gas_cost:.4f} POL)", flush=True)
    nonce += 1

    data["flash_profit"] = flash_addr
    with open("deployed_instant.json", "w") as f:
        json.dump(data, f, indent=2)

    print(f"\nTroikaFlashProfit: {flash_addr}")
else:
    print(f"  [FAIL] Deploy reverted", flush=True)

print(f"\nБаланс: {w3.eth.get_balance(C(OWNER)) / 1e18:.4f} POL")

# ═══════════════════════════════════════════════════════════════════════════
# 3. Проверка готовности
# ═══════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 70)
print("ПРОВЕРКА ГОТОВНОСТИ К FLASH LOAN")
print("=" * 70)

if 'flash_addr' in dir():
    flash_contract = w3.eth.contract(address=C(flash_addr), abi=abi)
    readiness = flash_contract.functions.checkReadiness().call()
    print(f"Has Pairs: {readiness[0]}")
    print(f"Has Core: {readiness[1]}")
    print(f"Emission Due: {readiness[2]}")
    print(f"Founder Pending: {readiness[3] / 1e18} WPOL")

print("\n" + "=" * 70)
print("ГОТОВО К ЗАПУСКУ!")
print("=" * 70)
