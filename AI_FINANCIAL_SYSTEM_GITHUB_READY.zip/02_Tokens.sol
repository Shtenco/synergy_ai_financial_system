// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

// ═══════════════════════════════════════════════════════════════════════════
//  SINERGY SYSTEM — 02_Tokens.sol
//  Три ERC-20 токена экосистемы
//
//  SYNA — Sinergy Anchor  (стабильный резервный токен, бывш. ALTNR)
//  SYNC — Sinergy Cycle   (торговый токен с управляемым снижением, бывш. ALTNT)
//  SYNR — Sinergy Rise    (растущий токен, 30% эмиссии → основателю, бывш. ALTNP)
//
//  OpenZeppelin Contracts 5.x | Solidity ^0.8.20
//
//  Все три токена:
//  ✓ Custom errors ERC-6093 / OZ5 — газ и bytecode экономия
//  ✓ ReentrancyGuard на mint / burn
//  ✓ Pausable — все операции заморожены при паузе системы
//  ✓ AccessControl: MINTER_ROLE, BURNER_ROLE, PAUSER_ROLE
//  ✓ MAX_SUPPLY — абсолютный потолок (never exceeded)
//  ✓ MAX_SINGLE_MINT — защита от случайного mint огромного кол-ва
//  ✓ ERC20Permit — gasless approve (EIP-2612)
//  ✓ Нет selfdestruct, delegatecall, tx.origin
//
//  SYNR дополнительно:
//  ✓ buybackBurn() — cap 0.2% supply за операцию (защита от резкого дефляции)
//  ✓ totalBurned — публичный счётчик
// ═══════════════════════════════════════════════════════════════════════════

import {ERC20}          from "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import {ERC20Burnable}  from "@openzeppelin/contracts/token/ERC20/extensions/ERC20Burnable.sol";
import {ERC20Permit}    from "@openzeppelin/contracts/token/ERC20/extensions/ERC20Permit.sol";
import {AccessControl}  from "@openzeppelin/contracts/access/AccessControl.sol";
import {Pausable}       from "@openzeppelin/contracts/utils/Pausable.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";

// ── Custom Errors (ERC-6093 compatible) ───────────────────────────────────
error TK_ZeroAddress();
error TK_ZeroAmount();
error TK_ExceedsMintCap(uint256 requested, uint256 cap);
error TK_ExceedsMaxSupply(uint256 requested, uint256 remaining);
error TK_InsufficientBalance(address account, uint256 have, uint256 need);
error TK_BuybackCapExceeded(uint256 requested, uint256 cap);

// ═══════════════════════════════════════════════════════════════════════════
//  SYNA  —  Sinergy Anchor Token
//  Стабильный резервный токен. Цена: ±0.07%/блок.
//  Initial: 10 000 000 | Max: 1 000 000 000
// ═══════════════════════════════════════════════════════════════════════════
contract SYNA is ERC20, ERC20Burnable, ERC20Permit,
                 AccessControl, Pausable, ReentrancyGuard
{
    bytes32 public constant MINTER_ROLE = keccak256("MINTER_ROLE");
    bytes32 public constant BURNER_ROLE = keccak256("BURNER_ROLE");
    bytes32 public constant PAUSER_ROLE = keccak256("PAUSER_ROLE");

    uint256 public constant MAX_SUPPLY      = 1_000_000_000e18;
    uint256 public constant INITIAL_SUPPLY  =    10_000_000e18;
    uint256 public constant MAX_SINGLE_MINT =    10_000_000e18;

    event Minted(address indexed to, uint256 amount);
    event ForceBurned(address indexed from, uint256 amount);

    constructor(address admin_)
        ERC20("Sinergy Anchor", "SYNA")
        ERC20Permit("Sinergy Anchor")
    {
        if (admin_ == address(0)) revert TK_ZeroAddress();
        _grantRole(DEFAULT_ADMIN_ROLE, admin_);
        _grantRole(MINTER_ROLE, admin_);
        _grantRole(BURNER_ROLE, admin_);
        _grantRole(PAUSER_ROLE, admin_);
        _mint(admin_, INITIAL_SUPPLY);
    }

    function mint(address to, uint256 amount)
        external nonReentrant whenNotPaused onlyRole(MINTER_ROLE)
    {
        if (to     == address(0))     revert TK_ZeroAddress();
        if (amount == 0)              revert TK_ZeroAmount();
        if (amount > MAX_SINGLE_MINT) revert TK_ExceedsMintCap(amount, MAX_SINGLE_MINT);
        uint256 rem = MAX_SUPPLY - totalSupply();
        if (amount > rem)             revert TK_ExceedsMaxSupply(amount, rem);
        _mint(to, amount);
        emit Minted(to, amount);
    }

    function forceBurn(address from, uint256 amount)
        external nonReentrant whenNotPaused onlyRole(BURNER_ROLE)
    {
        if (from   == address(0)) revert TK_ZeroAddress();
        if (amount == 0)          revert TK_ZeroAmount();
        uint256 bal = balanceOf(from);
        if (amount > bal) revert TK_InsufficientBalance(from, bal, amount);
        _burn(from, amount);
        emit ForceBurned(from, amount);
    }

    function pause()   external onlyRole(PAUSER_ROLE) { _pause(); }
    function unpause() external onlyRole(PAUSER_ROLE) { _unpause(); }

    function _update(address from, address to, uint256 value)
        internal override whenNotPaused
    { super._update(from, to, value); }
}

// ═══════════════════════════════════════════════════════════════════════════
//  SYNC  —  Sinergy Cycle Token
//  Управляемо снижается (медвежий торговый пул). Fee при продаже 7.5%.
//  Initial: 100 000 000 | Max: 10 000 000 000
// ═══════════════════════════════════════════════════════════════════════════
contract SYNC is ERC20, ERC20Burnable, ERC20Permit,
                 AccessControl, Pausable, ReentrancyGuard
{
    bytes32 public constant MINTER_ROLE = keccak256("MINTER_ROLE");
    bytes32 public constant BURNER_ROLE = keccak256("BURNER_ROLE");
    bytes32 public constant PAUSER_ROLE = keccak256("PAUSER_ROLE");

    uint256 public constant MAX_SUPPLY      = 10_000_000_000e18;
    uint256 public constant INITIAL_SUPPLY  =            19e18;
    uint256 public constant MAX_SINGLE_MINT =     50_000_000e18;

    event Minted(address indexed to, uint256 amount);
    event ForceBurned(address indexed from, uint256 amount);

    constructor(address admin_)
        ERC20("Sinergy Cycle", "SYNC")
        ERC20Permit("Sinergy Cycle")
    {
        if (admin_ == address(0)) revert TK_ZeroAddress();
        _grantRole(DEFAULT_ADMIN_ROLE, admin_);
        _grantRole(MINTER_ROLE, admin_);
        _grantRole(BURNER_ROLE, admin_);
        _grantRole(PAUSER_ROLE, admin_);
        _mint(admin_, INITIAL_SUPPLY);
    }

    function mint(address to, uint256 amount)
        external nonReentrant whenNotPaused onlyRole(MINTER_ROLE)
    {
        if (to     == address(0))     revert TK_ZeroAddress();
        if (amount == 0)              revert TK_ZeroAmount();
        if (amount > MAX_SINGLE_MINT) revert TK_ExceedsMintCap(amount, MAX_SINGLE_MINT);
        uint256 rem = MAX_SUPPLY - totalSupply();
        if (amount > rem)             revert TK_ExceedsMaxSupply(amount, rem);
        _mint(to, amount);
        emit Minted(to, amount);
    }

    function forceBurn(address from, uint256 amount)
        external nonReentrant whenNotPaused onlyRole(BURNER_ROLE)
    {
        if (from   == address(0)) revert TK_ZeroAddress();
        if (amount == 0)          revert TK_ZeroAmount();
        uint256 bal = balanceOf(from);
        if (amount > bal) revert TK_InsufficientBalance(from, bal, amount);
        _burn(from, amount);
        emit ForceBurned(from, amount);
    }

    function pause()   external onlyRole(PAUSER_ROLE) { _pause(); }
    function unpause() external onlyRole(PAUSER_ROLE) { _unpause(); }

    function _update(address from, address to, uint256 value)
        internal override whenNotPaused
    { super._update(from, to, value); }
}

// ═══════════════════════════════════════════════════════════════════════════
//  SYNR  —  Sinergy Rise Token
//  Растущий токен экосистемы.
//  30% от каждой эмиссии dlp идёт основателю через EmissionEngine.
//  Buyback burn cap = 0.2% supply за операцию.
//  Initial: 21 000 000 | Max: 1 000 000 000
// ═══════════════════════════════════════════════════════════════════════════
contract SYNR is ERC20, ERC20Burnable, ERC20Permit,
                 AccessControl, Pausable, ReentrancyGuard
{
    bytes32 public constant MINTER_ROLE = keccak256("MINTER_ROLE");
    bytes32 public constant BURNER_ROLE = keccak256("BURNER_ROLE");
    bytes32 public constant PAUSER_ROLE = keccak256("PAUSER_ROLE");

    uint256 public constant MAX_SUPPLY           = 1_000_000_000e18;
    uint256 public constant INITIAL_SUPPLY       =             4e18;
    uint256 public constant MAX_SINGLE_MINT      =      5_000_000e18;
    uint256 public constant BUYBACK_BURN_CAP_BPS = 20; // 0.2%

    uint256 public totalBurned;

    event Minted(address indexed to, uint256 amount);
    event ForceBurned(address indexed from, uint256 amount);
    event BuybackBurned(address indexed from, uint256 amount, uint256 supplyAfter);

    constructor(address admin_)
        ERC20("Sinergy Rise", "SYNR")
        ERC20Permit("Sinergy Rise")
    {
        if (admin_ == address(0)) revert TK_ZeroAddress();
        _grantRole(DEFAULT_ADMIN_ROLE, admin_);
        _grantRole(MINTER_ROLE, admin_);
        _grantRole(BURNER_ROLE, admin_);
        _grantRole(PAUSER_ROLE, admin_);
        _mint(admin_, INITIAL_SUPPLY);
    }

    function mint(address to, uint256 amount)
        external nonReentrant whenNotPaused onlyRole(MINTER_ROLE)
    {
        if (to     == address(0))     revert TK_ZeroAddress();
        if (amount == 0)              revert TK_ZeroAmount();
        if (amount > MAX_SINGLE_MINT) revert TK_ExceedsMintCap(amount, MAX_SINGLE_MINT);
        uint256 rem = MAX_SUPPLY - totalSupply();
        if (amount > rem)             revert TK_ExceedsMaxSupply(amount, rem);
        _mint(to, amount);
        emit Minted(to, amount);
    }

    /// @notice Buyback — ограничен 0.2% totalSupply за вызов
    function buybackBurn(address from, uint256 amount)
        external nonReentrant whenNotPaused onlyRole(BURNER_ROLE)
    {
        if (from   == address(0)) revert TK_ZeroAddress();
        if (amount == 0)          revert TK_ZeroAmount();
        uint256 bal = balanceOf(from);
        if (amount > bal) revert TK_InsufficientBalance(from, bal, amount);
        uint256 cap = totalSupply() * BUYBACK_BURN_CAP_BPS / 10_000;
        if (cap == 0) cap = 1;
        if (amount > cap) revert TK_BuybackCapExceeded(amount, cap);
        _burn(from, amount);
        totalBurned += amount;
        emit BuybackBurned(from, amount, totalSupply());
    }

    function forceBurn(address from, uint256 amount)
        external nonReentrant whenNotPaused onlyRole(BURNER_ROLE)
    {
        if (from   == address(0)) revert TK_ZeroAddress();
        if (amount == 0)          revert TK_ZeroAmount();
        uint256 bal = balanceOf(from);
        if (amount > bal) revert TK_InsufficientBalance(from, bal, amount);
        _burn(from, amount);
        totalBurned += amount;
        emit ForceBurned(from, amount);
    }

    function pause()   external onlyRole(PAUSER_ROLE) { _pause(); }
    function unpause() external onlyRole(PAUSER_ROLE) { _unpause(); }

    function _update(address from, address to, uint256 value)
        internal override whenNotPaused
    { super._update(from, to, value); }
}
