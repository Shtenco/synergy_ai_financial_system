const fs = require("fs");
const path = require("path");
const { ethers } = require("hardhat");

function envAddress(name, fallback = "") {
  const value = (process.env[name] || fallback).trim();
  return value && ethers.isAddress(value) ? value : "";
}

async function maybe(label, fn, pending) {
  try {
    const tx = await fn();
    await tx.wait();
    console.log(`  OK  ${label}`);
    return true;
  } catch (error) {
    console.log(`  PENDING  ${label}: ${error.shortMessage || error.message}`);
    pending.push(label);
    return false;
  }
}

async function main() {
  const [deployer] = await ethers.getSigners();
  const admin = envAddress("ADMIN_ADDRESS", deployer.address);
  const ai = envAddress("AI_PROPOSER_ADDRESS", deployer.address);
  const executor = envAddress("EXECUTOR_ADDRESS", deployer.address);
  const guardian = envAddress("GUARDIAN_ADDRESS", deployer.address);
  const reporters = (process.env.STATE_REPORTERS || deployer.address)
    .split(",").map(x => x.trim()).filter(ethers.isAddress);
  const threshold = Number(process.env.STATE_THRESHOLD || Math.min(2, reporters.length));
  if (!reporters.length || threshold < 1 || threshold > reporters.length) {
    throw new Error("Invalid STATE_REPORTERS / STATE_THRESHOLD");
  }

  console.log("Deploying SHTENCO DeFi TOP AI v3");
  console.log("Deployer:", deployer.address);
  console.log("Admin:", admin);

  const Oracle = await ethers.getContractFactory("SHTENCOSystemStateOracle");
  const oracle = await Oracle.deploy(admin, reporters, threshold);
  await oracle.waitForDeployment();

  const Treasury = await ethers.getContractFactory("SHTENCOValueFlowTreasury");
  const treasury = await Treasury.deploy(admin);
  await treasury.waitForDeployment();

  const Controller = await ethers.getContractFactory("SHTENCOTopAIController");
  const controller = await Controller.deploy(
    admin, await oracle.getAddress(), ai, executor, guardian
  );
  await controller.waitForDeployment();

  const Harvester = await ethers.getContractFactory("SHTENCOFlashProfitHarvester");
  const harvester = await Harvester.deploy(admin, await treasury.getAddress());
  await harvester.waitForDeployment();

  const Registry = await ethers.getContractFactory("SHTENCODeFiContourRegistry");
  const registry = await Registry.deploy(admin, "SHTENCO-DEFI-TOP-AI-v3.0");
  await registry.waitForDeployment();

  const pending = [];
  const isAdminSigner = deployer.address.toLowerCase() === admin.toLowerCase();
  if (isAdminSigner) {
    await maybe("treasury CONTROLLER_ROLE -> TOP AI", async () =>
      treasury.grantRole(await treasury.CONTROLLER_ROLE(), await controller.getAddress()), pending);
    await maybe("treasury REVENUE_RECORDER_ROLE -> harvester", async () =>
      treasury.grantRole(await treasury.REVENUE_RECORDER_ROLE(), await harvester.getAddress()), pending);
    await maybe("harvester CONTROLLER_ROLE -> TOP AI", async () =>
      harvester.grantRole(await harvester.CONTROLLER_ROLE(), await controller.getAddress()), pending);

    const coreModules = [
      [await registry.STATE_ORACLE(), await oracle.getAddress()],
      [await registry.TOP_AI_CONTROLLER(), await controller.getAddress()],
      [await registry.VALUE_TREASURY(), await treasury.getAddress()],
      [await registry.FLASH_HARVESTER(), await harvester.getAddress()],
    ];
    for (const [id, address] of coreModules) {
      await maybe(`registry ${id} -> ${address}`, async () => registry.setModule(id, address), pending);
    }
  } else {
    pending.push("Core role grants and registry setup must be executed by ADMIN_ADDRESS");
  }

  const external = {
    FLASH_ARBITRAGE: envAddress("FLASH_ARBITRAGE_ADDRESS"),
    MARKET_MAKER: envAddress("MARKET_MAKER_ADDRESS"),
    BRIDGE_RESERVE: envAddress("BRIDGE_RESERVE_ADDRESS"),
    BRIDGE_ADAPTER: envAddress("BRIDGE_ADAPTER_ADDRESS"),
    RELAY_BRIDGE: envAddress("RELAY_BRIDGE_ADDRESS"),
  };

  if (isAdminSigner) {
    for (const [name, address] of Object.entries(external)) {
      if (!address) { pending.push(`Set ${name}_ADDRESS and register module`); continue; }
      const id = await registry[name]();
      await maybe(`registry ${name}`, async () => registry.setModule(id, address), pending);
    }
  }

  // Configure selectors for the newly deployed modules. External module roles
  // and selectors are configured only when their addresses are supplied.
  if (isAdminSigner) {
    await maybe("enable harvester target", async () => controller.setTarget(await harvester.getAddress(), true), pending);
    await maybe("enable treasury target", async () => controller.setTarget(await treasury.getAddress(), true), pending);
    await maybe("enable harvest selector", async () => controller.setSelector(
      await harvester.getAddress(), harvester.interface.getFunction("harvest").selector, true, true
    ), pending);
    for (const [fn, budget] of [["allocateRevenue", false], ["reclassifyReserveQE", false], ["release", true]]) {
      await maybe(`enable treasury.${fn}`, async () => controller.setSelector(
        await treasury.getAddress(), treasury.interface.getFunction(fn).selector, true, budget
      ), pending);
    }
  }

  const deployment = {
    version: "3.0.0",
    chainId: Number((await ethers.provider.getNetwork()).chainId),
    deployedAt: new Date().toISOString(),
    deployer: deployer.address,
    roles: { admin, ai, executor, guardian, reporters, threshold },
    contracts: {
      stateOracle: await oracle.getAddress(),
      valueTreasury: await treasury.getAddress(),
      topAIController: await controller.getAddress(),
      flashProfitHarvester: await harvester.getAddress(),
      contourRegistry: await registry.getAddress(),
      ...external,
    },
    pending,
  };
  const outDir = path.resolve(__dirname, "../../../deployments");
  fs.mkdirSync(outDir, { recursive: true });
  const out = path.join(outDir, `defi-top-ai-v3-${deployment.chainId}.json`);
  fs.writeFileSync(out, JSON.stringify(deployment, null, 2));
  console.log("\nDeployment saved:", out);
  if (pending.length) {
    console.log("\nManual actions:");
    pending.forEach((x, i) => console.log(`${i + 1}. ${x}`));
  }
}

main().catch(error => {
  console.error(error);
  process.exitCode = 1;
});
