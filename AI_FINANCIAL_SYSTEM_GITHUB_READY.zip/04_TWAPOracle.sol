// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

// ═══════════════════════════════════════════════════════════════════════════
//  SINERGY SYSTEM — 04_TWAPOracle.sol
//  48-тиковый Rolling TWAP | Polygon + QuickSwap V2
//
//  Логика из Python-модели v9.2:
//   TWAP = avg(P_P / P_T) за 48 тиков (circular buffer)
//   gap  = |current_ratio / TWAP - 1|
//   gap ≥ 1% → emitArbSignal → CBArbitrage исполняет своп
//
//  Spot цена = reserveWPOL / reserveToken (из QuickSwap getReserves)
//
//  Защита от flash loan манипуляции:
//  ✓ 48-тиковый буфер (~8 мин на Polygon) — дорого держать искажение
//  ✓ Spike protection ±50% за тик → revert при аномальном скачке
//  ✓ MIN_INTERVAL = 5 блоков между обновлениями
//  ✓ Только UPDATER_ROLE (TroikaCore) может вызвать update()
//  ✓ Нулевые резервы → skip (не ломать буфер при пустом пуле)
//  ✓ setPairs() — только один раз (pairsSet = true)
// ═══════════════════════════════════════════════════════════════════════════

import {AccessControl}   from "@openzeppelin/contracts/access/AccessControl.sol";
import {Pausable}        from "@openzeppelin/contracts/utils/Pausable.sol";
import {Math}            from "@openzeppelin/contracts/utils/math/Math.sol";
import "./01_PolygonConfig.sol";

// ── Custom Errors ─────────────────────────────────────────────────────────
error OC_ZeroAddress();
error OC_PairsAlreadySet();
error OC_PairsNotSet();
error OC_TooEarly(uint256 nextBlock, uint256 currentBlock);
error OC_SpikePriceP(uint256 newPrice, uint256 prevPrice);
error OC_SpikePriceT(uint256 newPrice, uint256 prevPrice);

contract TWAPOracle is AccessControl, Pausable {

    bytes32 public constant UPDATER_ROLE = keccak256("UPDATER_ROLE");
    bytes32 public constant PAUSER_ROLE  = keccak256("PAUSER_ROLE");

    uint256 public constant PRECISION  = 1e18;
    uint256 public constant TWAP_SIZE  = 48;
    uint256 public constant SPIKE_BPS  = 5_000;   // ±50% max per tick (5000/10000)

    // ── QuickSwap пары ────────────────────────────────────────────────
    IQSPair public pairP;   // SYNR/WPOL
    IQSPair public pairT;   // SYNC/WPOL
    bool    public pairsSet;

    // ── 48-тиковый circular buffer (ratio = P_P/P_T × PRECISION) ─────
    uint256[48] private _buf;
    uint256     private _sum;
    uint256     public  writeIdx;
    uint256     public  filledCount;

    // ── Кэш ──────────────────────────────────────────────────────────
    uint256 public lastTWAP;            // P_P/P_T, scaled PRECISION
    uint256 public lastSpotP;           // WPOL per SYNR, scaled PRECISION
    uint256 public lastSpotT;           // WPOL per SYNC, scaled PRECISION
    uint256 public lastUpdateBlock;
    uint256 public totalUpdates;

    // ── Events ────────────────────────────────────────────────────────
    event PairsSet(address indexed pairP, address indexed pairT);
    event Updated(uint256 spotP, uint256 spotT, uint256 ratio, uint256 twap, uint256 blockN);
    event ArbSignal(uint256 gapBps, bool buySide, uint256 blockN);

    constructor(address admin_) {
        if (admin_ == address(0)) revert OC_ZeroAddress();
        _grantRole(DEFAULT_ADMIN_ROLE, admin_);
        _grantRole(UPDATER_ROLE,       admin_);
        _grantRole(PAUSER_ROLE,        admin_);

        // Инициализируем буфер значением 1.0 (нейтральное соотношение)
        for (uint256 i; i < TWAP_SIZE; ++i) _buf[i] = PRECISION;
        _sum        = TWAP_SIZE * PRECISION;
        filledCount = TWAP_SIZE;
        lastTWAP    = PRECISION;
    }

    // ── setPairs — только ONE TIME (после создания QuickSwap пар) ─────
    function setPairs(address pairP_, address pairT_)
        external onlyRole(DEFAULT_ADMIN_ROLE)
    {
        if (pairsSet)                   revert OC_PairsAlreadySet();
        if (pairP_ == address(0) ||
            pairT_ == address(0))       revert OC_ZeroAddress();
        pairP    = IQSPair(pairP_);
        pairT    = IQSPair(pairT_);
        pairsSet = true;
        emit PairsSet(pairP_, pairT_);
    }

    // ═══════════════════════════════════════════════════════════════════
    //  UPDATE — вызывается TroikaCore каждые 5 блоков
    //  Возвращает текущий TWAP
    // ═══════════════════════════════════════════════════════════════════
    function update()
        external
        whenNotPaused
        onlyRole(UPDATER_ROLE)
        returns (uint256 twap)
    {
        if (!pairsSet) revert OC_PairsNotSet();
        if (block.number < lastUpdateBlock + PolygonConfig.TWAP_INTERVAL)
            revert OC_TooEarly(lastUpdateBlock + PolygonConfig.TWAP_INTERVAL, block.number);

        uint256 spotP = _spotPrice(pairP);
        uint256 spotT = _spotPrice(pairT);

        // Нулевые резервы → skip тик (пул ещё не заполнен)
        if (spotP == 0 || spotT == 0) {
            lastUpdateBlock = block.number;
            return lastTWAP;
        }

        // ── Spike protection ±50% ─────────────────────────────────────
        if (lastSpotP > 0) {
            uint256 maxDeltaP = lastSpotP * SPIKE_BPS / 10_000;
            // spotP > lastSpotP + maxDeltaP || spotP < lastSpotP - maxDeltaP
            if (spotP > lastSpotP + maxDeltaP) revert OC_SpikePriceP(spotP, lastSpotP);
            if (lastSpotP > maxDeltaP && spotP < lastSpotP - maxDeltaP) revert OC_SpikePriceP(spotP, lastSpotP);
        }
        if (lastSpotT > 0) {
            uint256 maxDeltaT = lastSpotT * SPIKE_BPS / 10_000;
            if (spotT > lastSpotT + maxDeltaT) revert OC_SpikePriceT(spotT, lastSpotT);
            if (lastSpotT > maxDeltaT && spotT < lastSpotT - maxDeltaT) revert OC_SpikePriceT(spotT, lastSpotT);
        }

        // ── Вычислить ratio P_P/P_T ───────────────────────────────────
        uint256 ratio = Math.mulDiv(spotP, PRECISION, spotT);

        // ── Обновить circular buffer ──────────────────────────────────
        uint256 idx = writeIdx % TWAP_SIZE;
        _sum        = _sum - _buf[idx] + ratio;
        _buf[idx]   = ratio;
        ++writeIdx;
        if (filledCount < TWAP_SIZE) ++filledCount;

        twap        = _sum / filledCount;
        lastTWAP    = twap;
        lastSpotP   = spotP;
        lastSpotT   = spotT;
        lastUpdateBlock = block.number;
        ++totalUpdates;

        emit Updated(spotP, spotT, ratio, twap, block.number);

        // ── Проверить gap и emit ArbSignal ────────────────────────────
        (uint256 gapBps, bool buySide) = _gapBps(ratio, twap);
        if (gapBps >= 100) {   // 100 bps = 1%
            emit ArbSignal(gapBps, buySide, block.number);
        }
    }

    // ── Spot: WPOL per 1 token (scaled by PRECISION) ──────────────────
    function _spotPrice(IQSPair p) private view returns (uint256) {
        try p.getReserves() returns (uint112 r0, uint112 r1, uint32) {
            if (r0 == 0 || r1 == 0) return 0;
            (uint256 rWpol, uint256 rTok) = (p.token0() == PolygonConfig.WPOL)
                ? (uint256(r0), uint256(r1))
                : (uint256(r1), uint256(r0));
            return rTok == 0 ? 0 : Math.mulDiv(rWpol, PRECISION, rTok);
        } catch { return 0; }
    }

    function _gapBps(uint256 ratio, uint256 twap)
        private pure returns (uint256 gapBps, bool buySide)
    {
        if (twap == 0) return (0, false);
        if (ratio > twap) {
            gapBps  = (ratio - twap) * 10_000 / twap;
            buySide = false;
        } else {
            gapBps  = (twap - ratio) * 10_000 / twap;
            buySide = true;
        }
    }

    // ── VIEW ──────────────────────────────────────────────────────────
    function getTWAP() external view returns (uint256) { return lastTWAP; }

    /// @return gapBps  отклонение в basis points (100 = 1%)
    /// @return buySide true  → P_P дешевле TWAP → покупать SYNR
    ///                 false → P_P дороже TWAP → покупать SYNC
    function getGapBps() external view returns (uint256 gapBps, bool buySide) {
        if (lastTWAP == 0 || lastSpotP == 0 || lastSpotT == 0) return (0, false);
        uint256 ratio = Math.mulDiv(lastSpotP, PRECISION, lastSpotT);
        return _gapBps(ratio, lastTWAP);
    }

    function getSpots() external view returns (uint256 spotP, uint256 spotT) {
        return (lastSpotP, lastSpotT);
    }

    function needsUpdate() external view returns (bool) {
        return pairsSet && block.number >= lastUpdateBlock + PolygonConfig.TWAP_INTERVAL;
    }

    function pause()   external onlyRole(PAUSER_ROLE) { _pause(); }
    function unpause() external onlyRole(PAUSER_ROLE) { _unpause(); }
}
