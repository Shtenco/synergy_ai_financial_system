"""AI CENTROBANK SINERGY — desktop optimizer for the Troika ecosystem."""
from __future__ import annotations

import json
import os
import subprocess
import sys
import threading
from datetime import datetime
from pathlib import Path

import customtkinter as ctk
from tkinter import messagebox

from ai_centrobank_sinergy import EconomicEngine, SearchConfig

BG="#0a0a0a";PANEL="#111111";PANEL2="#161616";FIELD="#1a1a1a";BORDER="#282828"
GREEN="#00c853";GREEN_H="#00e676";GREEN_D="#00802f";WHITE="#e4e4e4";GRAY="#707070"
RED="#ff1744";YELLOW="#ffd600";FONT="Segoe UI";MONO="Consolas"
ROOT=Path(__file__).resolve().parent
MAINNET_STATE=ROOT/"deployments"/"mainnet-state-latest.json"
DEPLOY_REPORT=ROOT/"deployments"/"private-cp-mainnet-latest.json"

CONTRACTS={"SYNA":"0x1cf279f1F3735B8F0B28245f57D6E22BFB2c59ad",
           "SYNC":"0x460E9DDE5A80c07Ed92CBfcD4b9548e266989BcC",
           "SYNR":"0xE026825E696602dB4c94e4D69f8Ed30679440e85",
           "AMM":"0x1865Ecb199055317d1a0730065Fb5fe6255a2387",
           "Controller":"0x727D295fBee6E53B68e85bBCc6Fd1701BaB6bE42",
           "Owner":"0x6946999DBCE63b140B1bB9D475F7c357130909E5"}


def label(parent,text,color=WHITE,size=13,bold=False,**kw):
    return ctk.CTkLabel(parent,text=text,text_color=color,font=ctk.CTkFont(family=FONT,size=size,weight="bold" if bold else "normal"),**kw)


def button(parent,text,command,primary=True,width=150):
    return ctk.CTkButton(parent,text=text,command=command,width=width,height=34,corner_radius=6,
        fg_color=GREEN_D if primary else FIELD,hover_color=GREEN if primary else BORDER,
        border_color=GREEN_D if primary else BORDER,border_width=1,text_color=WHITE,
        font=ctk.CTkFont(family=FONT,size=13,weight="bold" if primary else "normal"))


class MetricCard(ctk.CTkFrame):
    def __init__(self,parent,title):
        super().__init__(parent,fg_color=PANEL2,border_color=BORDER,border_width=1,corner_radius=8)
        label(self,title.upper(),GRAY,10,True).pack(anchor="w",padx=12,pady=(9,0))
        self.value=ctk.CTkLabel(self,text="—",text_color=GREEN,font=ctk.CTkFont(family=MONO,size=20,weight="bold"))
        self.value.pack(anchor="w",padx=12,pady=(3,0))
        self.delta=ctk.CTkLabel(self,text="",text_color=GRAY,font=ctk.CTkFont(family=MONO,size=10))
        self.delta.pack(anchor="w",padx=12,pady=(0,9))

    def set(self,value,delta=None,suffix=""):
        if isinstance(value,(int,float)) and abs(value)>=1_000_000:
            self.value.configure(text=f"{value:,.0f} {suffix}".strip())
        elif isinstance(value,(int,float)):
            self.value.configure(text=f"{value:,.6f} {suffix}".strip())
        else:
            self.value.configure(text=f"{value} {suffix}".strip())
        if delta is None:self.delta.configure(text="")
        else:self.delta.configure(text=f"Δ {delta:+,.6f}",text_color=GREEN if delta>=0 else RED)


class App(ctk.CTk):
    def __init__(self):
        super().__init__();ctk.set_appearance_mode("dark")
        self.title("AI CENTROBANK SINERGY V2 — BRIDGE QE + MARKET MAKER");self.geometry("1280x960");self.minsize(1120,760);self.configure(fg_color=BG)
        self.mainnet_state=self._load_mainnet_state()
        self.on_chain=self._extract_on_chain_metrics()
        if self.mainnet_state:
            self.engine=EconomicEngine.from_mainnet(self.mainnet_state)
        else:
            self.engine=EconomicEngine(50.0,100.0)
        self.initial=dict(self.on_chain) if self.on_chain else self.engine.metrics(self.engine.state)
        self.running=False;self.nav={};self.tabs={};self.cards={};self.chart_rows=[]
        self._header();self._body();self._footer();self._show("dashboard");self.refresh()

    def _load_mainnet_state(self):
        for path in [MAINNET_STATE, ROOT/"deployments"/"mainnet-state-check.json"]:
            if path.exists():
                try:
                    return json.loads(path.read_text(encoding="utf-8"))
                except Exception:
                    continue
        return None

    def _extract_on_chain_metrics(self):
        if not self.mainnet_state:
            return None
        m=self.mainnet_state.get("metrics",{})
        w=self.mainnet_state.get("wallet",{})
        return {
            "lp_nav": float(m.get("lp_nav",0)),
            "tvl": float(m.get("lp_nav",0)),
            "mcap": float(m.get("mcap",0)),
            "wallet_wpol": float(w.get("WPOL",0)),
            "wallet_syna": float(w.get("SYNA",0)),
            "wallet_sync": float(w.get("SYNC",0)),
            "wallet_synr": float(w.get("SYNR",0)),
            "owner_native": float(m.get("owner_native",0)),
            "cycles_executed": int(self.mainnet_state.get("cycles_executed",0)),
            "free_wpol": float(m.get("free_wpol",0)),
        }

    def _header(self):
        hdr=ctk.CTkFrame(self,fg_color=PANEL,corner_radius=0,height=110);hdr.pack(fill="x");hdr.pack_propagate(False)
        row=ctk.CTkFrame(hdr,fg_color="transparent");row.pack(fill="x",padx=24,pady=(8,2))
        label(row,"◆  AI CENTROBANK SINERGY",GREEN,22,True).pack(side="left")
        cycles=self.on_chain.get("cycles_executed",0) if self.on_chain else 0
        self.net=label(row,f"● POLYGON MAINNET  •  {cycles} CYCLES",GREEN,12,True);self.net.pack(side="right",pady=(8,0))
        row2=ctk.CTkFrame(hdr,fg_color="transparent");row2.pack(fill="x",padx=24)
        addr_parts=[]
        for name,addr in [("Controller",CONTRACTS["Controller"]),("AMM",CONTRACTS["AMM"])]:
            addr_parts.append(f"{name}: {addr[:6]}...{addr[-4:]}")
        self.headline=label(row2,"  •  ".join(addr_parts),GRAY,10);self.headline.pack(side="left")
        refresh_btn=ctk.CTkButton(row2,text="⟳ REFRESH FROM CHAIN",command=self._refresh_from_chain,
            width=180,height=28,corner_radius=6,fg_color=GREEN_D,hover_color=GREEN,border_width=0,
            text_color=WHITE,font=ctk.CTkFont(family=FONT,size=11,weight="bold"))
        refresh_btn.pack(side="right",pady=(4,0))

    def _body(self):
        body=ctk.CTkFrame(self,fg_color="transparent");body.pack(fill="both",expand=True);body.grid_columnconfigure(1,weight=1);body.grid_rowconfigure(0,weight=1)
        side=ctk.CTkFrame(body,fg_color=PANEL,corner_radius=0,width=220);side.grid(row=0,column=0,sticky="nsw");side.grid_propagate(False)
        groups=[("CONTROL",[("dashboard","▰  Dashboard"),("optimizer","◆  Best Cycle"),("execute","▶  Proposals")]),("ECONOMY",[("pools","◈  Liquidity Pools"),("bridge","⇄  Bridge & Relays"),("accounting","≡  Accounting")]),("SYSTEM",[("policy","🛡  AI Risk Policy"),("settings","⚙  Parameters"),("reports","▣  Reports")])]
        for group,items in groups:
            label(side,group,GREEN,9,True).pack(anchor="w",padx=17,pady=(18,5))
            for key,text in items:
                b=ctk.CTkButton(side,text=text,anchor="w",height=32,corner_radius=6,fg_color="transparent",hover_color=BORDER,text_color=GRAY,font=ctk.CTkFont(family=FONT,size=12),command=lambda k=key:self._show(k));b.pack(fill="x",padx=10,pady=1);self.nav[key]=b
        self.content=ctk.CTkFrame(body,fg_color=BG,corner_radius=0);self.content.grid(row=0,column=1,sticky="nsew",padx=0);self.content.grid_columnconfigure(0,weight=1);self.content.grid_rowconfigure(0,weight=1)
        for key,builder in (("dashboard",self._dashboard),("optimizer",self._optimizer),("execute",self._execute),("pools",self._pools),("bridge",self._bridge),("accounting",self._accounting),("policy",self._policy),("settings",self._settings),("reports",self._reports)):
            frame=ctk.CTkFrame(self.content,fg_color=BG,corner_radius=0);frame.grid(row=0,column=0,sticky="nsew");self.tabs[key]=frame;builder(frame)

    def _title(self,parent,text,sub=""):
        f=ctk.CTkFrame(parent,fg_color="transparent");f.pack(fill="x",padx=22,pady=(18,10));label(f,text,WHITE,20,True).pack(anchor="w");label(f,sub,GRAY,11).pack(anchor="w",pady=(2,0));return f

    def _dashboard(self,parent):
        self._title(parent,"ON-CHAIN DASHBOARD","Реальные метрики с Polygon mainnet контрактов")
        grid=ctk.CTkFrame(parent,fg_color="transparent");grid.pack(fill="x",padx=18)
        card_defs=[("lp_nav","LP NAV"),("mcap","MCAP"),("owner_native","OWNER POL"),
                   ("wallet_wpol","CONTROLLER WPOL"),("wallet_syna","WALLET SYNA"),
                   ("wallet_sync","WALLET SYNC")]
        for i,(key,title) in enumerate(card_defs):
            card=MetricCard(grid,title);card.grid(row=i//3,column=i%3,sticky="ew",padx=5,pady=5);grid.grid_columnconfigure(i%3,weight=1);self.cards[key]=card
        contracts_frame=ctk.CTkFrame(parent,fg_color=PANEL2,border_color=BORDER,border_width=1,corner_radius=8);contracts_frame.pack(fill="x",padx=23,pady=8)
        label(contracts_frame,"DEPLOYED CONTRACTS — POLYGON MAINNET (chain 137)",GREEN,11,True).pack(anchor="w",padx=12,pady=(8,4))
        for name,addr in [("SYNA-AI",CONTRACTS["SYNA"]),("SYNC-AI",CONTRACTS["SYNC"]),("SYNR-AI",CONTRACTS["SYNR"]),
                          ("PrivateCPAMM",CONTRACTS["AMM"]),("PrivateCPController",CONTRACTS["Controller"]),
                          ("Owner",CONTRACTS["Owner"])]:
            row=ctk.CTkFrame(contracts_frame,fg_color="transparent");row.pack(fill="x",padx=12,pady=1)
            label(row,name,YELLOW,11,True).pack(side="left")
            label(row,addr,GRAY,10).pack(side="left",padx=(8,0))
        graph=ctk.CTkFrame(parent,fg_color=PANEL2,border_color=BORDER,border_width=1,corner_radius=8);graph.pack(fill="both",expand=True,padx=23,pady=8)
        label(graph,"GROWTH HISTORY",GREEN,11,True).pack(anchor="w",padx=12,pady=(10,3))
        self.canvas=ctk.CTkCanvas(graph,bg=PANEL2,highlightthickness=0,height=200);self.canvas.pack(fill="both",expand=True,padx=8,pady=(0,8));self.canvas.bind("<Configure>",lambda _e:self._draw_chart())

    def _optimizer(self,parent):
        self._title(parent,"BEST CYCLE SEARCH","Beam-search: HOLD / SWAP / ADD LIQUIDITY / BRIDGE QE / BUYBACK-BURN, глубина 1–5")
        controls=ctk.CTkFrame(parent,fg_color=PANEL2,border_color=BORDER,border_width=1,corner_radius=8);controls.pack(fill="x",padx=23,pady=5)
        self.calc_btn=button(controls,"РАССЧИТАТЬ НА MAINNET",self.calculate,True,230);self.calc_btn.pack(side="left",padx=12,pady=12)
        button(controls,"СБРОСИТЬ МОДЕЛЬ",self.reset,False,160).pack(side="left",padx=4)
        self.score_label=label(controls,"Score: —",YELLOW,13,True);self.score_label.pack(side="right",padx=15)
        self.candidate_box=ctk.CTkTextbox(parent,fg_color=FIELD,text_color=WHITE,border_color=BORDER,border_width=1,font=ctk.CTkFont(family=MONO,size=12));self.candidate_box.pack(fill="both",expand=True,padx=23,pady=10);self.candidate_box.configure(state="disabled")

    def _execute(self,parent):
        self._title(parent,"TIMELOCKED AI PROPOSALS","ИИ рассчитывает действия, формирует проверяемое предложение и передаёт его в on-chain timelock")
        row=ctk.CTkFrame(parent,fg_color=PANEL2,border_color=BORDER,border_width=1,corner_radius=8);row.pack(fill="x",padx=23,pady=5)
        self.exec_btn=button(row,"СОЗДАТЬ AI-ПРЕДЛОЖЕНИЕ",self.execute_mainnet,True,260);self.exec_btn.pack(side="left",padx=12,pady=12)
        self.ten_btn=button(row,"10 ЦИКЛОВ → ПРЕДЛОЖЕНИЕ",self.run_ten_mainnet,True,240);self.ten_btn.pack(side="left",padx=4)
        params=ctk.CTkFrame(parent,fg_color=PANEL2,border_color=BORDER,border_width=1,corner_radius=8);params.pack(fill="x",padx=23,pady=5)
        self.cycle_count=ctk.StringVar(value="5")
        box=ctk.CTkFrame(params,fg_color="transparent");box.pack(side="left",padx=12,pady=8)
        label(box,"ЦИКЛОВ",GRAY,10,True).pack(anchor="w")
        ctk.CTkEntry(box,textvariable=self.cycle_count,fg_color=FIELD,border_color=BORDER,text_color=WHITE,width=130,height=28).pack(anchor="w",pady=(3,0))
        label(params,"По умолчанию DRY-RUN; live требует LIVE_EXECUTION=1 + отдельный executor",GREEN,11,True).pack(side="right",padx=14)
        self.execution_box=ctk.CTkTextbox(parent,fg_color=FIELD,text_color=WHITE,border_color=BORDER,border_width=1,font=ctk.CTkFont(family=MONO,size=12));self.execution_box.pack(fill="both",expand=True,padx=23,pady=10);self.execution_box.configure(state="disabled")

    def _pools(self,parent):
        self._title(parent,"ON-CHAIN POOLS","Реальные резервы и доля LP с Polygon mainnet")
        self.pool_frame=ctk.CTkScrollableFrame(parent,fg_color="transparent");self.pool_frame.pack(fill="both",expand=True,padx=18,pady=5)


    def _bridge(self,parent):
        self._title(parent,"BRIDGE QE & RELAYS","M-of-N EIP-712 relay, replay protection, per-chain limits and reserve-backed liquidity")
        self.bridge_box=ctk.CTkTextbox(parent,fg_color=FIELD,text_color=WHITE,border_color=BORDER,border_width=1,font=ctk.CTkFont(family=MONO,size=12));self.bridge_box.pack(fill="both",expand=True,padx=23,pady=10);self.bridge_box.configure(state="disabled")

    def _policy(self,parent):
        self._title(parent,"AI RISK POLICY","Ограничения автономного режима: timelock, guardian, reserve floor, peg and bridge limits")
        self.policy_box=ctk.CTkTextbox(parent,fg_color=FIELD,text_color=WHITE,border_color=BORDER,border_width=1,font=ctk.CTkFont(family=MONO,size=12));self.policy_box.pack(fill="both",expand=True,padx=23,pady=10);self.policy_box.configure(state="disabled")

    def _accounting(self,parent):
        self._title(parent,"ON-CHAIN ACCOUNTING","Метрики напрямую из контракта PrivateCPController.metrics()")
        self.account_box=ctk.CTkTextbox(parent,fg_color=FIELD,text_color=WHITE,border_color=BORDER,border_width=1,font=ctk.CTkFont(family=MONO,size=12));self.account_box.pack(fill="both",expand=True,padx=23,pady=10);self.account_box.configure(state="disabled")

    def _settings(self,parent):
        self._title(parent,"SEARCH PARAMETERS","Настройка глубины, ширины beam и экономических коэффициентов")
        panel=ctk.CTkFrame(parent,fg_color=PANEL2,border_color=BORDER,border_width=1,corner_radius=8);panel.pack(fill="x",padx=23,pady=5)
        self.vars={"depth":ctk.StringVar(value="5"),"beam":ctk.StringVar(value="180"),"gas":ctk.StringVar(value="0.0015"),"mcap":ctk.StringVar(value="0.25"),"liquid":ctk.StringVar(value="0.35")}
        for i,(key,title) in enumerate((("depth","Chain depth"),("beam","Beam width"),("gas","Gas / action, WPOL"),("mcap","Max valuation gap"),("liquid","Max bridge imbalance"))):
            r=ctk.CTkFrame(panel,fg_color="transparent");r.grid(row=i,column=0,sticky="ew",padx=12,pady=6);label(r,title,GRAY,12).pack(side="left");ctk.CTkEntry(r,textvariable=self.vars[key],fg_color=FIELD,border_color=BORDER,text_color=WHITE,width=150).pack(side="right")
        button(panel,"ПРИМЕНИТЬ",lambda:self._log("Параметры применены"),True,130).grid(row=6,column=0,sticky="w",padx=12,pady=12)

    def _reports(self,parent):
        self._title(parent,"REPORTS","JSON-отчёты сохраняются в deployments/")
        self.report_box=ctk.CTkTextbox(parent,fg_color=FIELD,text_color=GRAY,border_color=BORDER,border_width=1,font=ctk.CTkFont(family=MONO,size=11));self.report_box.pack(fill="both",expand=True,padx=23,pady=10);self.report_box.configure(state="disabled");self._refresh_reports()

    def _footer(self):
        foot=ctk.CTkFrame(self,fg_color=PANEL,corner_radius=0,height=140);foot.pack(fill="x");foot.pack_propagate(False)
        row=ctk.CTkFrame(foot,fg_color="transparent");row.pack(fill="x",padx=18,pady=(8,3));self.status=label(row,"● Готов к работе",GREEN,11,True);self.status.pack(side="left");self.progress=ctk.CTkProgressBar(row,fg_color=FIELD,progress_color=GREEN_D,width=280,height=12);self.progress.pack(side="right");self.progress.set(0)
        self.log=ctk.CTkTextbox(foot,fg_color=FIELD,text_color=GRAY,border_color=BORDER,border_width=1,height=95,font=ctk.CTkFont(family=MONO,size=10));self.log.pack(fill="x",padx=18,pady=(0,8));self.log.configure(state="disabled")

    def config(self):
        return SearchConfig(max_depth=max(1,min(5,int(self.vars["depth"].get()))),beam_width=max(20,int(self.vars["beam"].get())),gas_wpol=float(self.vars["gas"].get()),max_valuation_gap=float(self.vars["mcap"].get()),max_bridge_imbalance=float(self.vars["liquid"].get()))

    def _show(self,key):
        self.tabs[key].tkraise()
        for k,b in self.nav.items():b.configure(fg_color=GREEN_D if k==key else "transparent",text_color=WHITE if k==key else GRAY)
        if key=="pools":self._refresh_pools()
        if key=="bridge":self._refresh_bridge()
        if key=="accounting":self._refresh_accounting()
        if key=="policy":self._refresh_policy()
        if key=="reports":self._refresh_reports()

    def _set_busy(self,busy,text="Работаю…"):
        self.running=busy;self.status.configure(text=f"● {text if busy else 'Готов к работе'}",text_color=YELLOW if busy else GREEN);self.progress.set(0.3 if busy else 0)
        if hasattr(self,"calc_btn"):self.calc_btn.configure(state="disabled" if busy else "normal")
        if hasattr(self,"exec_btn"):self.exec_btn.configure(state="disabled" if busy else "normal")
        if hasattr(self,"ten_btn"):self.ten_btn.configure(state="disabled" if busy else "normal")

    def _refresh_from_chain(self):
        if self.running:
            return
        self._set_busy(True, "Reading state from Polygon mainnet contracts...")
        def work():
            try:
                from ai_centrobank_sinergy.mainnet_bridge import read_mainnet_state
                state_data = read_mainnet_state(ROOT, log_fn=lambda s: self.after(0, lambda x=s: self._log(x)))
                self.after(0, lambda: self._apply_mainnet_state(state_data))
            except Exception as e:
                self.after(0, lambda error=e: self._error(error))
        threading.Thread(target=work, daemon=True).start()

    def _apply_mainnet_state(self, state_data):
        self.mainnet_state=state_data
        self.on_chain=self._extract_on_chain_metrics()
        self.engine=EconomicEngine.from_mainnet(state_data)
        self.initial=dict(self.on_chain) if self.on_chain else self.engine.metrics(self.engine.state)
        cycles=self.on_chain.get("cycles_executed",0) if self.on_chain else 0
        self.net.configure(text=f"● POLYGON MAINNET  •  {cycles} CYCLES")
        self._set_busy(False)
        self.refresh()
        self._log(f"Chain refreshed: LP NAV={self.on_chain['lp_nav']:,.2f} MCAP={self.on_chain['mcap']:,.2f} Cycles={cycles}")

    def calculate(self):
        if self.running:
            return
        self._set_busy(True,"Reading mainnet state + searching best cycle")
        def work():
            try:
                from ai_centrobank_sinergy.mainnet_bridge import read_mainnet_state
                state_data = read_mainnet_state(ROOT, log_fn=lambda s: self.after(0, lambda x=s: self._log(x)))
                self.after(0, lambda: self._mainnet_state_loaded(state_data))
            except Exception as e:
                self.after(0, lambda error=e: self._error(error))
        threading.Thread(target=work, daemon=True).start()

    def _mainnet_state_loaded(self, state_data):
        self.mainnet_state=state_data
        self.on_chain=self._extract_on_chain_metrics()
        engine=EconomicEngine.from_mainnet(state_data)
        self.engine=engine
        self.initial=dict(self.on_chain) if self.on_chain else engine.metrics(engine.state)
        self._set_busy(True,"Beam-search best cycle on mainnet state")
        cfg=self.config()
        def search_work():
            try:
                candidate=engine.search(cfg)
                self.after(0, lambda: self._calculated(candidate))
            except Exception as e:
                self.after(0, lambda error=e: self._error(error))
        threading.Thread(target=search_work, daemon=True).start()

    def _calculated(self,c):
        lines=["BEST CYCLE",f"Score: {c.score:+.8f}",""]+[f"{i+1}. {a.label}" for i,a in enumerate(c.actions)]+["", "PROJECTED METRICS"]+[f"{k:24s} {v:,.8f}" for k,v in c.metrics.items()]
        self._text(self.candidate_box,"\n".join(lines));self.score_label.configure(text=f"Score: {c.score:+.6f}",text_color=GREEN if c.score>=0 else RED);self._set_busy(False);self._log(f"Best cycle: {len(c.actions)} actions, score {c.score:+.6f}")

    def execute_mainnet(self):
        if self.running:
            return
        count=max(1,min(20,int(self.cycle_count.get())))
        self._set_busy(True,f"AI: расчёт {count} циклов и формирование timelocked proposal")
        def work():
            try:
                from ai_centrobank_sinergy.mainnet_bridge import read_mainnet_state, execute_on_mainnet
                state_data=read_mainnet_state(ROOT, log_fn=lambda s: self.after(0, lambda x=s: self._log(x)))
                engine=EconomicEngine.from_mainnet(state_data)
                before_metrics=engine.metrics(engine.state)
                cfg=self.config()
                rows, dividends=engine.run_cycles(count, cfg)
                exec_report=execute_on_mainnet(ROOT, rows, log_fn=lambda s: self.after(0, lambda x=s: self._log(x)), before_metrics=before_metrics)
                self.after(0, lambda: self._execution_done(rows, exec_report))
            except Exception as e:
                self.after(0, lambda error=e: self._error(error))
        threading.Thread(target=work, daemon=True).start()

    def _execution_done(self, rows, exec_report):
        self._set_busy(False)
        self.net.configure(text="● AI PROPOSAL READY",text_color=GREEN)
        report_text=json.dumps({"cycles":[r["cycle"] for r in rows],"execution":exec_report},ensure_ascii=False,indent=2)
        self._text(self.execution_box,report_text)
        self._log(f"Proposal complete: {len(rows)} AI cycles calculated; live execution requires timelock")
        self._refresh_from_chain()

    def run_ten_mainnet(self):
        self.cycle_count.set("10");self.execute_mainnet()

    def reset(self):
        self.engine.reset();self.initial=self.engine.metrics(self.engine.state);self.chart_rows=[];self._text(self.candidate_box,"");self.score_label.configure(text="Score: —",text_color=YELLOW);self.refresh();self._log("Model reset")

    def refresh(self):
        if self.on_chain:
            m=self.on_chain
            for key in ["lp_nav","mcap","wallet_wpol","owner_native"]:
                if key in self.cards and key in m:
                    self.cards[key].set(m[key])
            if "wallet_syna" in self.cards:
                self.cards["wallet_syna"].set(m.get("wallet_syna",0))
            if "wallet_sync" in self.cards:
                self.cards["wallet_sync"].set(m.get("wallet_sync",0))
        else:
            m=self.engine.metrics(self.engine.state)
            for key,c in self.cards.items():
                if key in m:
                    c.set(m[key])
        self._refresh_pools();self._refresh_bridge();self._refresh_accounting();self._refresh_policy();self._draw_chart()

    def _refresh_pools(self):
        if not hasattr(self,"pool_frame"):return
        for w in self.pool_frame.winfo_children():w.destroy()
        if self.mainnet_state and "pools" in self.mainnet_state:
            for p in self.mainnet_state["pools"]:
                r=ctk.CTkFrame(self.pool_frame,fg_color=PANEL2,border_color=BORDER,border_width=1,corner_radius=7);r.pack(fill="x",padx=5,pady=4)
                label(r,p["name"],GREEN,13,True).grid(row=0,column=0,sticky="w",padx=12,pady=9)
                label(r,f"{p['ra']:,.6f} {p['a']}",WHITE,11).grid(row=0,column=1,padx=12)
                label(r,f"{p['rb']:,.6f} {p['b']}",WHITE,11).grid(row=0,column=2,padx=12)
                label(r,f"shares {p['owner_share']:.4f}  total {p.get('total_shares',0):.4f}",GRAY,10).grid(row=0,column=3,padx=12)
                r.grid_columnconfigure(0,weight=1)
        else:
            prices=self.engine.token_prices(self.engine.state)
            for name,p in self.engine.state.pools.items():
                r=ctk.CTkFrame(self.pool_frame,fg_color=PANEL2,border_color=BORDER,border_width=1,corner_radius=7);r.pack(fill="x",padx=5,pady=4)
                label(r,name,GREEN,13,True).grid(row=0,column=0,sticky="w",padx=12,pady=9)
                label(r,f"{p.ra:,.6f} {p.a}",WHITE,11).grid(row=0,column=1,padx=12)
                label(r,f"{p.rb:,.6f} {p.b}",WHITE,11).grid(row=0,column=2,padx=12)
                label(r,f"NAV {self.engine.pool_nav(p,prices):,.6f} WPOL",YELLOW,11,True).grid(row=0,column=3,padx=12)
                r.grid_columnconfigure(0,weight=1)


    def _refresh_bridge(self):
        if not hasattr(self,"bridge_box"):return
        rows=["═══ SHTENCO BRIDGE QE V2 ═══","",
              "Mode: M-of-N EIP-712 threshold relay",
              "Fork mode: virtual chain domains supported only for tests",
              "Protections: replay guard / validator epoch / daily limits / per-chain pause",
              "Asset modes: canonical ESCROW or wrapped MINT_BURN",
              "QE reserve: no unbacked mint; allocations respect reserve floor",
              "Relayer: SHTENCO_QE_BRIDGE_AI/scripts/relay_daemon.py","",
              "BRIDGE INVENTORY"]
        state=self.engine.state if hasattr(self.engine,"state") else None
        if state and getattr(state,"bridge_inventory",None):
            for chain,values in state.bridge_inventory.items():
                rows.append(f"[{chain}]")
                for token,amount in sorted(values.items()):rows.append(f"  {token:8s} {amount:,.8f}")
        else:rows.append("No bridge snapshot loaded")
        self._text(self.bridge_box,"\n".join(rows))

    def _refresh_policy(self):
        if not hasattr(self,"policy_box"):return
        m=self.engine.metrics(self.engine.state)
        reserve=m.get("reserve_ratio",0);peg=m.get("peg_error",1);bridge=m.get("bridge_imbalance",1);gap=m.get("valuation_gap",1)
        rows=["═══ AI CENTRAL BANK POLICY ═══","",
              "Execution model       OFF-CHAIN SEARCH → ON-CHAIN PROPOSAL → TIMELOCK → EXECUTOR",
              "Unbacked mint          FORBIDDEN",
              "Wash trading           FORBIDDEN",
              "Arbitrary calls        FORBIDDEN — target + selector allowlist",
              "Guardian cancel        REQUIRED",
              "Default live mode      DISABLED","",
              f"Reserve ratio         {reserve:,.6f}",
              f"Peg error             {peg:,.6f}",
              f"Bridge imbalance      {bridge:,.6f}",
              f"Valuation gap         {gap:,.6f}","",
              "Hard guards: reserve >= 1.0; peg <= 0.25; bridge <= 0.60; valuation gap <= 0.60"]
        self._text(self.policy_box,"\n".join(rows))

    def _refresh_accounting(self):
        if not hasattr(self,"account_box"):return
        lines=["═══ ON-CHAIN METRICS (from PrivateCPController.metrics()) ═══",""]
        if self.on_chain:
            oc=self.on_chain
            lines+=[
                f"{'LP NAV':32s} {oc['lp_nav']:>16,.6f} WPOL",
                f"{'MCAP':32s} {oc['mcap']:>16,.2f} WPOL",
                f"{'CONTROLLER FREE WPOL':32s} {oc['free_wpol']:>16,.6f}",
                f"{'OWNER NATIVE POL':32s} {oc['owner_native']:>16,.6f}",
                f"{'CYCLES EXECUTED':32s} {oc['cycles_executed']:>16d}",
                "",
                "═══ OWNER WALLET ═══","",
                f"{'WPOL (ERC20)':32s} {oc.get('wallet_wpol',0):>16,.6f}",
                f"{'SYNA':32s} {oc.get('wallet_syna',0):>16,.6f}",
                f"{'SYNC':32s} {oc.get('wallet_sync',0):>16,.6f}",
                f"{'SYNR':32s} {oc.get('wallet_synr',0):>16,.6f}",
            ]
        else:
            m=self.engine.metrics(self.engine.state)
            lines+=[f"{k:32s} {v:>16,.6f}" for k,v in m.items()]
        lines+=["","═══ DEPLOYMENT ═══","",
                f"{'SYNA-AI':32s} {CONTRACTS['SYNA']}",
                f"{'SYNC-AI':32s} {CONTRACTS['SYNC']}",
                f"{'SYNR-AI':32s} {CONTRACTS['SYNR']}",
                f"{'PrivateCPAMM':32s} {CONTRACTS['AMM']}",
                f"{'PrivateCPController':32s} {CONTRACTS['Controller']}",
                f"{'Owner':32s} {CONTRACTS['Owner']}",
                f"{'Chain':32s} Polygon (137)"]
        self._text(self.account_box,"\n".join(lines))

    def _refresh_reports(self):
        if not hasattr(self,"report_box"):return
        files=sorted(list((ROOT/"deployments").glob("ai-centrobank-*.json"))+list((ROOT/"deployments").glob("private-cp-mainnet-*.json"))+list((ROOT/"deployments").glob("mainnet-state-*.json")),key=lambda p:p.stat().st_mtime,reverse=True)[:30]
        self._text(self.report_box,"\n".join(str(p) for p in files) or "No reports yet")

    def _draw_chart(self):
        if not hasattr(self,"canvas"):return
        c=self.canvas;c.delete("all");w=max(c.winfo_width(),400);h=max(c.winfo_height(),200);pad=28;c.create_line(pad,h-pad,w-pad,h-pad,fill=BORDER);c.create_line(pad,pad,pad,h-pad,fill=BORDER)
        data_points=[self.initial]+self.chart_rows
        keys=(("lp_nav",GREEN),("mcap",YELLOW))
        all_vals=[]
        for r in data_points:
            for k,_ in keys:
                v=r.get(k,0)
                if v>0:all_vals.append(v)
        if not all_vals:c.create_text(w//2,h//2,fill=GRAY,text="No data",font=(MONO,12));return
        lo=min(all_vals);hi=max(all_vals);span=max(hi-lo,1e-9)
        for key,color in keys:
            pts=[]
            for i,r in enumerate(data_points):
                v=r.get(key,0)
                if v<=0:continue
                x=pad+i*(w-2*pad)/max(len(data_points)-1,1)
                y=h-pad-(v-lo)*(h-2*pad)/span
                pts.extend((x,y))
            if len(pts)>=4:c.create_line(*pts,fill=color,width=2,smooth=True)
        c.create_text(pad+4,pad,anchor="nw",fill=GRAY,text="LP NAV (green)   MCAP (yellow)",font=(MONO,9))

    def _text(self,box,value):box.configure(state="normal");box.delete("1.0","end");box.insert("end",value);box.configure(state="disabled")
    def _log(self,text):self.log.configure(state="normal");self.log.insert("end",f"[{datetime.now():%H:%M:%S}] {text}\n");self.log.see("end");self.log.configure(state="disabled")
    def _error(self,e):self._set_busy(False);self._log(f"ERROR: {e}");messagebox.showerror("AI CENTROBANK SINERGY",str(e))


if __name__=="__main__":
    App().mainloop()
