#!/usr/bin/env python3
"""
Создание QuickSwap пулов для TROIKA токенов
"""
import sys, io, os, json, time
from dotenv import load_dotenv
from web3 import Web3
from web3.middleware import ExtraDataToPOAMiddleware

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

load_dotenv()

w3 = Web3(Web3.HTTPProvider("https://polygon-bor-rpc.publicnode.com", request_kwargs={"timeout": 120}))
w3.middleware_onion.inject(ExtraDataToPOAMiddleware, layer=0)

PK = os.getenv("OWNER_PRIVATE_KEY")
OWNER = "0x6946999DBCE63b140B1bB9D475F7c357130909E5"
ROUTER = "0xa5E0829CaCEd8fFDD4De3c43696c57F7D7A678ff"
FACTORY = "0x5757371414417b8C6CAad45bAeF941aBc7d3Ab32"
WPOL = "0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270"

# Загрузить адреса токенов
with open("deployed_instant.json") as f:
    data = json.load(f)
    SYNA = data["tokens"]["SYNA"]
    SYNC = data["tokens"]["SYNC"]
    SYNR = data["tokens"]["SYNR"]
    ALTN = data["tokens"]["ALTN"]

print("=" * 60)
print("СОЗДАНИЕ QUICKSWAP ПУЛОВ")
print("=" * 60)
print(f"SYNA: {SYNA}")
print(f"SYNC: {SYNC}")
print(f"SYNR: {SYNR}")
print(f"ALTN: {ALTN}")
print(f"Balance: {w3.eth.get_balance(OWNER) / 1e18:.4f} POL")
print("=" * 60)

nonce = w3.eth.get_transaction_count(OWNER, "pending")

TOKEN_ABI = [
    {"name": "balanceOf", "inputs": [{"name": "", "type": "address"}], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"name": "approve", "inputs": [{"name": "spender", "type": "address"}, {"name": "amount", "type": "uint256"}], "outputs": [{"type": "bool"}], "type": "function"},
    {"name": "allowance", "inputs": [{"name": "owner", "type": "address"}, {"name": "spender", "type": "address"}], "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
]

ROUTER_ABI = [
    {"name": "addLiquidityETH", "inputs": [
        {"name": "token", "type": "address"},
        {"name": "amountTokenDesired", "type": "uint256"},
        {"name": "amountTokenMin", "type": "uint256"},
        {"name": "amountETHMin", "type": "uint256"},
        {"name": "to", "type": "address"},
        {"name": "deadline", "type": "uint256"}
    ], "outputs": [{"type": "uint256"}, {"type": "uint256"}, {"type": "uint256"}], "stateMutability": "payable", "type": "function"},
]

FACTORY_ABI = [
    {"name": "getPair", "inputs": [{"name": "tokenA", "type": "address"}, {"name": "tokenB", "type": "address"}], "outputs": [{"type": "address"}], "stateMutability": "view", "type": "function"},
]

def C(a): return Web3.to_checksum_address(a)

router = w3.eth.contract(address=C(ROUTER), abi=ROUTER_ABI)
factory = w3.eth.contract(address=C(FACTORY), abi=FACTORY_ABI)

def send_tx(tx, label, value=0):
    global nonce
    base = w3.eth.get_block("latest").get("baseFeePerGas", int(100e9))
    prio = int(50e9)
    mf = base * 2 + prio
    tx.update({
        "from": C(OWNER), "nonce": nonce, "chainId": 137, "type": 2,
        "maxPriorityFeePerGas": prio, "maxFeePerGas": mf
    })
    if value: tx["value"] = value
    tx.pop("gasPrice", None)
    signed = w3.eth.account.sign_transaction(tx, PK)
    h = w3.eth.send_raw_transaction(signed.raw_transaction)
    r = w3.eth.wait_for_transaction_receipt(h, timeout=300)
    cost = r.gasUsed * mf / 1e18
    ok = "OK" if r.status == 1 else "FAIL"
    print(f"  [{ok}] {label} (gas: {cost:.4f} POL)", flush=True)
    nonce += 1
    return r

def create_pool(token_addr, token_name, token_amount, pol_amount):
    """Создать пул TOKEN/WPOL на QuickSwap"""
    global nonce

    token = w3.eth.contract(address=C(token_addr), abi=TOKEN_ABI)

    print(f"\n[{token_name}] Создание пула...", flush=True)

    # 1. Approve
    bal = token.functions.balanceOf(C(OWNER)).call()
    print(f"  Баланс {token_name}: {bal / 1e18:,.0f}", flush=True)

    allowance = token.functions.allowance(C(OWNER), C(ROUTER)).call()
    if allowance < token_amount:
        tx = token.functions.approve(C(ROUTER), int(2**256 - 1)).build_transaction({"gas": 100000})
        send_tx(tx, f"Approve {token_name}")
        time.sleep(2)

    # 2. Add Liquidity
    dl = int(time.time()) + 600
    tx = router.functions.addLiquidityETH(
        C(token_addr),
        token_amount,
        0,  # min tokens
        0,  # min ETH
        C(OWNER),
        dl
    ).build_transaction({"gas": 500000})
    send_tx(tx, f"AddLiquidity {token_name}", value=pol_amount)

    # 3. Получить адрес пары
    time.sleep(2)
    pair = factory.functions.getPair(C(token_addr), C(WPOL)).call()
    print(f"  Пара {token_name}/WPOL: {pair}", flush=True)

    return pair

# Создаём пулы с небольшой ликвидностью
# ~5 POL на каждый пул (всего ~20 POL)

POL_PER_POOL = int(4e18)  # 4 POL на пул

print("\nСоздание пулов...", flush=True)

# SYNA: 10M supply, цена ~0.00005 POL = 200 SYNA за 1 POL
SYNA_AMOUNT = int(800e18)  # 800 SYNA
pair_syna = create_pool(SYNA, "SYNA", SYNA_AMOUNT, POL_PER_POOL)
time.sleep(3)

# SYNC: 100M supply, дешевле, ~2000 SYNC за 1 POL
SYNC_AMOUNT = int(8000e18)  # 8000 SYNC
pair_sync = create_pool(SYNC, "SYNC", SYNC_AMOUNT, POL_PER_POOL)
time.sleep(3)

# SYNR: 21M supply, дороже, ~100 SYNR за 1 POL
SYNR_AMOUNT = int(400e18)  # 400 SYNR
pair_synr = create_pool(SYNR, "SYNR", SYNR_AMOUNT, POL_PER_POOL)
time.sleep(3)

# ALTN: 110M supply, ~500 ALTN за 1 POL
ALTN_AMOUNT = int(2000e18)  # 2000 ALTN
pair_altn = create_pool(ALTN, "ALTN", ALTN_AMOUNT, POL_PER_POOL)

# Обновить JSON с адресами пулов
data["pools"] = {
    "SYNA_WPOL": pair_syna,
    "SYNC_WPOL": pair_sync,
    "SYNR_WPOL": pair_synr,
    "ALTN_WPOL": pair_altn
}
data["liquidity_added"] = time.strftime("%Y-%m-%d %H:%M:%S")

with open("deployed_instant.json", "w") as f:
    json.dump(data, f, indent=2)

print("\n" + "=" * 60)
print("ПУЛЫ СОЗДАНЫ")
print("=" * 60)
print(f"SYNA/WPOL: {pair_syna}")
print(f"SYNC/WPOL: {pair_sync}")
print(f"SYNR/WPOL: {pair_synr}")
print(f"ALTN/WPOL: {pair_altn}")
print(f"\nОстаток: {w3.eth.get_balance(C(OWNER)) / 1e18:.4f} POL")
print("Адреса обновлены в deployed_instant.json")
print("=" * 60)
